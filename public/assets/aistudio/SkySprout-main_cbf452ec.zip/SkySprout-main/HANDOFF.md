# Kids Hub: handoff notes

## Decisions
- Framework: Flutter. Android first (parents' Android phones, kids' Amazon
  Fire tablets); iOS later from the same code.
- Standalone (2026-10-15): no Home Assistant and no family built in. Parents
  add their children on first run. All data is stored on the device.
- One app for every device. It opens on the home page (a button per child plus Parent portal); the parent screens
  are behind a 4-8 digit PIN, chosen on first run.
- Themes per child: Quest (pixel, Jersey 25), Construction, Princess, Unicorn.
- Chores reset each morning. Ticking a chore awards its points at once.
- Sync (2026-10-15): Supabase, one login per family (email + password) so
  friends can use it too. Family data is one JSON row with a version number;
  saves are compare-and-swap with retry. Access only through security-definer
  functions in supabase/setup.sql (checked on Postgres 16). A second grown-up
  joins with a 10-character family code. Kids' tablets use a parent's login.
  Supabase URL and anon key are baked in with --dart-define.

## Status
Done: setup and child editor, home page and ☰ menu, themed boards, shop, My Rewards,
screen-time timers, parent screens (points, goal, chores, prices, rewards,
orders, countdowns), PIN lock, on-device store, tests.

Open:
- Scott to create the Supabase project, run setup.sql, turn off email
  confirmation, and share the Project URL and anon key for the build.
- Not yet tried against a live Supabase project (the client is tested with
  fake responses).
- Chore approvals (a parent approves before points are given), if wanted.
- The APK has to be built where dl.google.com is reachable.
