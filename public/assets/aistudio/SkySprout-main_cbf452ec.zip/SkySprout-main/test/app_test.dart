import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:kids_hub/app_state.dart';
import 'package:kids_hub/backend.dart';
import 'package:kids_hub/catalog.dart';
import 'package:kids_hub/challenge_ai.dart';
import 'package:kids_hub/screens/how_to_screen.dart';
import 'package:kids_hub/config.dart';
import 'package:kids_hub/main.dart';
import 'package:kids_hub/models.dart';
import 'package:kids_hub/push.dart';
import 'package:kids_hub/screens/children_screen.dart';
import 'package:kids_hub/screens/kid_screen.dart';
import 'package:kids_hub/screens/parent_home.dart';
import 'package:kids_hub/screens/reset_password_screen.dart';
import 'package:kids_hub/screens/shop_screen.dart';
import 'package:kids_hub/screens/tablet_home.dart';
import 'package:kids_hub/screens/welcome_screen.dart';
import 'package:kids_hub/sync.dart';
import 'package:kids_hub/themes.dart';
import 'package:kids_hub/screens/routine_screen.dart';
import 'package:kids_hub/widgets/celebrate.dart';
import 'package:kids_hub/widgets/common.dart';
import 'package:kids_hub/widgets/kids_hub_sign.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// A made-up family for the tests, one child on each theme.
const family = [
  Child(id: 'k1', name: 'Sam', age: 9, theme: 'quest'),
  Child(id: 'k2', name: 'Alex', age: 6, theme: 'construction'),
  Child(id: 'k3', name: 'Mia', age: 5, theme: 'princess'),
  Child(id: 'k4', name: 'Lily', age: 7, theme: 'unicorn'),
];

/// The catalog built into the app.
Map<String, HowTo> bundledCatalog() => parseCatalog(File('assets/catalog/challenges.txt').readAsStringSync());

void main() {
  celebrationSounds = false;
  // Families get their challenges from the catalog; it is never downloaded in tests.
  setUpAll(() => Catalog.all = bundledCatalog());
  setUp(() => SharedPreferences.setMockInitialValues({}));
  tearDown(() => children = const []);

  group('on-device store', () {
    late DateTime today;
    late MemoryStore store;
    late HubBackend b;

    setUp(() async {
      today = DateTime(2026, 10, 15, 9);
      store = MemoryStore();
      b = HubBackend(store, now: () => today);
      await b.create(family.take(2).toList(), hashPin('1234'));
    });

    test('a new family starts with rewards, countdowns and chores for each child', () async {
      final d = await b.load();
      expect(d.shop.map((r) => r.name), contains('Tablet time'));
      expect(d.snap.countdowns.map((c) => c.name), ['Halloween', 'Christmas', 'Easter']);
      expect(d.snap.countdowns.first.days, 16);
      expect(d.choresFor('k1').map((c) => c.title), contains('Make your bed'));
      expect(d.points('k1'), 0);
    });

    test('ticking a chore adds its points and logs it; unticking takes them back', () async {
      final bed = (await b.load()).choresFor('k1').firstWhere((c) => c.title == 'Make your bed');
      await b.setChore('k1', bed, true);
      var d = await b.load();
      expect(d.points('k1'), 2);
      expect(d.log['k1']!.first.text, contains('Make your bed'));
      await b.setChore('k1', bed, false);
      d = await b.load();
      expect(d.points('k1'), 0);
    });

    test('chores reset the next day, points stay', () async {
      final bed = (await b.load()).choresFor('k1').first;
      await b.setChore('k1', bed, true);
      today = today.add(const Duration(days: 1));
      final d = await b.load();
      expect(d.choresFor('k1').every((c) => !c.done), isTrue);
      expect(d.points('k1'), greaterThan(0));
    });

    test('buying needs enough points; timed rewards start screen time, others become orders', () async {
      final d = await b.load();
      final tablet = d.shop.firstWhere((r) => r.name == 'Tablet time');
      final snack = d.shop.firstWhere((r) => r.name == 'Extra snack');
      expect(() => b.buy('k2', tablet), throwsA(isA<AppError>()));
      await b.adjustPoints('k2', 50);
      await b.buy('k2', tablet);
      await b.buy('k2', snack);
      var after = await b.load();
      expect(after.points('k2'), 50 - tablet.cost['k2']! - snack.cost['k2']!);
      expect(after.owned('k2').map((r) => r.name), containsAll(['Tablet time', 'Extra snack']));
      await b.useReward('k2', after.owned('k2').firstWhere((r) => r.name == 'Tablet time'));
      await b.useReward('k2', after.owned('k2').firstWhere((r) => r.name == 'Extra snack'));
      after = await b.load();
      expect(after.timer('k2')!.running, isTrue);
      expect(after.owed.map((o) => o.summary), ['Alex: Extra snack']);
    });

    test('prices are per child', () async {
      final tv = (await b.load()).shop.firstWhere((r) => r.name == 'TV time');
      await b.setPrice('k1', tv.key, 3);
      final d = await b.load();
      final again = d.shop.firstWhere((r) => r.key == tv.key);
      expect((again.cost['k1'], again.cost['k2']), (3, 8));
    });

    test('rewards and countdowns can be added and deleted', () async {
      await b.saveReward(
        Reward(key: '', emoji: '🚲', name: 'Bike ride', desc: '', minutes: 0, on: true, cost: {}, own: {}),
        on: true,
      );
      await b.saveCountdown(
        Countdown(id: '', emoji: '🎂', name: "Sam's birthday", date: DateTime(2020, 10, 20)),
      );
      var d = await b.load();
      expect(d.shop.map((r) => r.name), contains('Bike ride'));
      final bday = d.snap.countdowns.firstWhere((c) => c.name == "Sam's birthday");
      expect(bday.days, 5);
      await b.deleteReward(d.shop.firstWhere((r) => r.name == 'Bike ride').key);
      await b.deleteCountdown(bday.id);
      d = await b.load();
      expect(d.shop.map((r) => r.name), isNot(contains('Bike ride')));
      expect(d.snap.countdowns.map((c) => c.name), isNot(contains("Sam's birthday")));
    });

    test('everything is saved and read back', () async {
      await b.adjustPoints('k1', 12);
      await b.setGoal('k1', 60);
      final again = HubBackend(store, now: () => today);
      final d = await again.load();
      expect((d.points('k1'), d.snap.goal('k1')), (12, 60));
    });

    test('a removed child\'s data goes', () async {
      await b.adjustPoints('k2', 5);
      await b.saveFamily(family.take(1).toList());
      final d = await b.load();
      expect(d.chores.keys, ['k1']);
      expect(d.family.children.single.name, 'Sam');
      expect(d.family.pinHash, hashPin('1234'));
    });

    test('two devices changing things at once both count', () async {
      final tablet = HubBackend(store, now: () => today);
      final phone = HubBackend(store, now: () => today);
      final bed = (await tablet.load()).choresFor('k1').firstWhere((c) => c.title == 'Make your bed');
      await phone.load();
      // The tablet saves first, so the phone's save has to retry on top of it.
      await tablet.setChore('k1', bed, true);
      await phone.adjustPoints('k1', 5);
      final d = await b.load();
      expect(d.points('k1'), 7);
      expect(d.choresFor('k1').firstWhere((c) => c.title == 'Make your bed').done, isTrue);
    });

    test('children\'s birthdays become countdowns, and keep their age current', () async {
      final bday = Child(id: 'k1', name: 'Sam', age: 3, birthday: DateTime(2018, 10, 20), theme: 'quest');
      await b.saveFamily([bday, family[1]]);
      final d = await b.load();
      final c = d.snap.countdowns.firstWhere((c) => c.name == "Sam's birthday");
      expect((c.emoji, c.days), ('🎂', 5));
      expect(bday.ageOn(today), 7);
      expect(bday.ageOn(DateTime(2026, 10, 20)), 8);
      final back = Child.fromJson(bday.toJson());
      expect(back.birthday, DateTime(2018, 10, 20));
    });

    test('a new family can only be created once in a store', () async {
      expect(() => HubBackend(store).create(family, hashPin('1')), throwsA(isA<AppError>()));
    });
  });

  group('online accounts', () {
    http.Client fake(List<http.Request> calls, Map<String, Object?> Function(http.Request) answer) =>
        MockClient((req) async {
          calls.add(req);
          final a = answer(req);
          return http.Response(
            jsonEncode(a['body']),
            a['status'] as int? ?? 200,
            headers: {'content-type': 'application/json'},
          );
        });

    test('sign in, then read and save the family with the login token', () async {
      final calls = <http.Request>[];
      final client = fake(
        calls,
        (req) => switch (req.url.path) {
          '/auth/v1/token' => {
            'body': {
              'access_token': 'AT',
              'refresh_token': 'RT',
              'expires_in': 3600,
              'user': {'email': 'sam@example.com'},
            },
          },
          '/rest/v1/rpc/my_family' => {
            'body': [
              {
                'family_id': 'F1',
                'code': 'ABCDE23456',
                'data': {'day': 'x'},
                'version': 3,
              },
            ],
          },
          '/rest/v1/rpc/family_save' => {'body': -1},
          _ => {'status': 404, 'body': {}},
        },
      );
      final auth = SupabaseAuth(url: 'https://x.supabase.co', anonKey: 'ANON', client: client);
      await auth.signIn('sam@example.com', 'secret1');
      expect((auth.signedIn, auth.email), (true, 'sam@example.com'));
      final store = SupabaseStore(auth, client: client);
      final r = await store.fetch();
      expect((r.version, store.code), (3, 'ABCDE23456'));
      expect(await store.save({'a': 1}, 3), isNull);
      final save = calls.last;
      expect(save.headers['Authorization'], 'Bearer AT');
      expect(save.headers['apikey'], 'ANON');
      expect(jsonDecode(save.body), {
        'p_family': 'F1',
        'p_data': {'a': 1},
        'p_version': 3,
      });
    });

    test('forgot password: the emailed code signs in and sets a new password', () async {
      final calls = <http.Request>[];
      final client = fake(
        calls,
        (req) => switch (req.url.path) {
          '/auth/v1/recover' => {'body': {}},
          '/auth/v1/verify' =>
            jsonDecode(req.body)['token'] == '123456'
                ? {
                    'body': {
                      'access_token': 'AT2',
                      'refresh_token': 'RT2',
                      'expires_in': 3600,
                      'user': {'email': 'sam@example.com'},
                    },
                  }
                : {
                    'status': 403,
                    'body': {'msg': 'Token has expired or is invalid'},
                  },
          '/auth/v1/user' => {
            'body': {'email': 'sam@example.com'},
          },
          _ => {'status': 404, 'body': {}},
        },
      );
      final auth = SupabaseAuth(url: 'https://x.supabase.co', anonKey: 'ANON', client: client);
      await auth.resetPassword('sam@example.com');
      await expectLater(
        () => auth.resetWithCode('sam@example.com', '000000', 'newpass1'),
        throwsA(isA<AppError>().having((e) => e.message, 'message', contains('passcode didn'))),
      );
      expect(auth.signedIn, isFalse);
      await auth.resetWithCode('sam@example.com', '123456', 'newpass1');
      expect(auth.signedIn, isTrue);
      final put = calls.last;
      expect(
        (put.method, put.url.path, put.headers['Authorization']),
        ('PUT', '/auth/v1/user', 'Bearer AT2'),
      );
      expect(jsonDecode(put.body), {'password': 'newpass1'});
      expect(jsonDecode(calls[1].body), {'type': 'recovery', 'email': 'sam@example.com', 'token': '000000'});
    });

    test('forgot password also takes the pasted email link, or the page it opened', () async {
      final calls = <http.Request>[];
      final client = fake(
        calls,
        (req) => switch (req.url.path) {
          '/auth/v1/verify' || '/auth/v1/token' => {
            'body': {'access_token': 'AT3', 'refresh_token': 'RT3', 'expires_in': 3600},
          },
          _ => {'body': {}},
        },
      );
      final auth = SupabaseAuth(url: 'https://x.supabase.co', anonKey: 'ANON', client: client);
      await auth.resetWithCode(
        'sam@example.com',
        ' https://x.supabase.co/auth/v1/verify?token=abc123hash&type=recovery&redirect_to=http://localhost:3000 ',
        'newpass1',
      );
      expect(jsonDecode(calls[0].body), {'type': 'recovery', 'token_hash': 'abc123hash'});
      expect(calls[1].method, 'PUT');
      calls.clear();
      await auth.resetWithCode(
        'sam@example.com',
        'http://localhost:3000/#access_token=AT&expires_in=3600&refresh_token=RTX&type=recovery',
        'newpass2',
      );
      expect(calls[0].url.query, 'grant_type=refresh_token');
      expect(jsonDecode(calls[0].body), {'refresh_token': 'RTX'});
      expect(jsonDecode(calls[1].body), {'password': 'newpass2'});
    });

    test('a wrong password gets a plain message', () async {
      final client = fake(
        [],
        (_) => {
          'status': 400,
          'body': {'error_description': 'Invalid login credentials'},
        },
      );
      final auth = SupabaseAuth(url: 'https://x.supabase.co', anonKey: 'ANON', client: client);
      expect(
        () => auth.signIn('a@b.c', 'nope12'),
        throwsA(isA<AppError>().having((e) => e.message, 'message', 'That email and password don\'t match.')),
      );
    });

    test('family codes', () {
      expect(normalizeCode(' abcde-23456 '), 'ABCDE23456');
      expect(showCode('ABCDE23456'), 'ABCDE-23456');
      expect(validCode('abcde-23456'), isTrue);
      expect(validCode('ABCDE-2345O'), isFalse);
    });
  });

  test('device settings', () {
    const c = AppConfig(mode: DataMode.cloud);
    expect(AppConfig.fromJson(c.toJson()).mode, DataMode.cloud);
    expect(AppConfig.validPin('1234'), isTrue);
    expect(AppConfig.validPin('12a4'), isFalse);
    expect(KidTheme.byId('unicorn'), KidTheme.unicorn);
  });

  Widget wrap(AppState s, Widget child, Size size) => AppScope(
    state: s,
    child: MediaQuery(
      data: MediaQueryData(size: size),
      child: MaterialApp(key: UniqueKey(), home: child),
    ),
  );

  Future<AppState> show(
    WidgetTester tester,
    Widget child,
    Size size, {
    List<Child> kids = family,
    int points = 0,
  }) async {
    tester.view.physicalSize = size;
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    final backend = HubBackend(MemoryStore());
    late AppState s;
    await tester.runAsync(() async {
      await backend.create(kids, hashPin('1234'));
      for (final k in kids) {
        if (points > 0) await backend.adjustPoints(k.id, points);
      }
      s = AppState(const AppConfig(), backend, autoRefresh: false);
      await s.refresh();
    });
    addTearDown(s.dispose);
    await tester.pumpWidget(wrap(s, child, size));
    await tester.pump();
    await tester.pump();
    return s;
  }

  const tablet = Size(1280, 800);
  const phone = Size(400, 850);

  testWidgets('picker opens a child\'s board and the shop', (tester) async {
    await show(tester, const TabletHome(), tablet, points: 9);
    expect(find.text('Sam'), findsOneWidget);
    expect(find.text('Age 9'), findsOneWidget);
    await tester.tap(find.text('Sam'));
    await tester.pump();
    await tester.pump(const Duration(seconds: 1));
    expect(find.text("Sam's Quest Board"), findsOneWidget);
    expect(find.text('0 of 3 chores complete'), findsOneWidget);
    expect(find.text('Make your bed'), findsOneWidget);
    await tester.tap(find.text('Spend points'));
    await tester.pump();
    await tester.pump(const Duration(seconds: 1));
    expect(find.text("Sam's Shop"), findsOneWidget);
    expect(find.text('Buy now'), findsWidgets);
    expect(find.text('Need 3 more'), findsOneWidget);
  });

  for (final (name, size) in [
    ('tablet', tablet),
    ('portrait tablet', const Size(800, 1280)),
    ('phone', phone),
  ]) {
    testWidgets('four children on the $name picker', (tester) async {
      await show(tester, const TabletHome(), size);
      for (final c in family) {
        // Phones scroll the list; tablets fit everyone on screen.
        if (find.byType(Scrollable).evaluate().isNotEmpty) {
          await tester.scrollUntilVisible(find.text(c.name), 200, scrollable: find.byType(Scrollable).last);
        }
        expect(find.text(c.name), findsOneWidget);
      }
    });

    testWidgets('one child on the $name picker', (tester) async {
      await show(tester, const TabletHome(), size, kids: family.take(1).toList());
      expect(find.text('Sam'), findsOneWidget);
    });
  }

  for (final c in family) {
    for (final (name, size) in [
      ('phone', phone),
      ('portrait tablet', const Size(800, 1280)),
      ('tablet', tablet),
    ]) {
      testWidgets('${c.theme} board and shop on a $name', (tester) async {
        await show(tester, KidScreen(kid: c.id), size);
        expect(find.textContaining("${c.name}'s ${KidTheme.byId(c.theme).boardName}"), findsOneWidget);
        await show(tester, ShopScreen(kid: c.id), size);
      });
    }
  }

  testWidgets('parent screens: points, rewards and countdowns', (tester) async {
    final state = await show(tester, const ParentHome(), phone);
    expect(find.text('Screen time'), findsOneWidget);
    expect(find.textContaining('reward prices'), findsNothing);
    expect(find.text('Points log'), findsOneWidget);
    expect(find.textContaining('Mia'), findsWidgets);
    await tester.ensureVisible(find.text('🎁 Rewards'));
    await tester.tap(find.text('🎁 Rewards'));
    await tester.pumpAndSettle();
    expect(find.text('Manage rewards'), findsOneWidget);
    await tester.tap(find.text('Add').first);
    await tester.pumpAndSettle();
    expect(find.text('New reward'), findsOneWidget);
    await tester.tap(find.text('Cancel'));
    await tester.pumpAndSettle();
    // Prices live in the Rewards tab, one per child.
    await tester.scrollUntilVisible(
      find.text('Prices (points to claim)'),
      300,
      scrollable: find.ancestor(of: find.text('Manage rewards'), matching: find.byType(Scrollable)).first,
    );
    await tester.drag(find.text('Prices (points to claim)'), const Offset(0, -250));
    await tester.pumpAndSettle();
    final first = state.data!.snap.rewards.first;
    final before = first.cost['k1'] ?? 0;
    final card = find.ancestor(of: find.text(first.name).last, matching: find.byType(Card)).first;
    final plus = find.descendant(of: card, matching: find.byIcon(Icons.add)).first;
    await tester.ensureVisible(plus);
    await tester.pumpAndSettle();
    await tester.runAsync(() async {
      await tester.tap(plus);
      await Future<void>.delayed(const Duration(milliseconds: 100));
    });
    await tester.pump();
    expect(state.data!.snap.rewards.firstWhere((r) => r.key == first.key).cost['k1'] ?? 0, isNot(before));
    await tester.ensureVisible(find.text('📅 Countdowns'));
    await tester.tap(find.text('📅 Countdowns'));
    await tester.pumpAndSettle();
    expect(find.text('Halloween'), findsOneWidget);
    expect(find.text('Easter'), findsOneWidget);
    expect(find.text('Add Easter'), findsNothing);
  });

  testWidgets('the menu opens the parent portal with the PIN, and goes back to the kids', (tester) async {
    await show(tester, const TabletHome(), phone);
    Future<void> menu(String item) async {
      await tester.tap(find.byTooltip('Menu'));
      await tester.pumpAndSettle();
      await tester.tap(find.text(item).last);
      await tester.pumpAndSettle();
    }

    Future<void> tryPin(String pin) async {
      await menu('Parent portal');
      await tester.enterText(find.byType(TextField), pin);
      await tester.tap(find.text('Unlock'));
      await tester.pumpAndSettle();
    }

    // On the kids' screen the menu only switches places.
    await tester.tap(find.byTooltip('Menu'));
    await tester.pumpAndSettle();
    expect(find.text('Settings'), findsNothing);
    expect(find.text('Sign in'), findsNothing);
    await tester.tapAt(const Offset(5, 5));
    await tester.pumpAndSettle();

    // The home page has a button for each kid and one for the parent portal.
    expect(find.byType(KidsHubSign), findsOneWidget);
    expect(find.text('Grown-ups only · PIN needed'), findsOneWidget);
    await tester.tap(find.text('Grown-ups only · PIN needed'));
    await tester.pumpAndSettle();
    expect(find.text('Unlock'), findsOneWidget);
    await tester.tap(find.text('Cancel'));
    await tester.pumpAndSettle();

    await tryPin('0000');
    expect(find.widgetWithText(AppBar, 'Parent portal'), findsNothing);
    expect(find.text('Wrong PIN'), findsOneWidget);
    await tryPin('1234');
    expect(find.widgetWithText(AppBar, 'Parent portal'), findsOneWidget);

    // In the parent portal it adds Settings and signing in (no login here).
    await tester.tap(find.byTooltip('Menu'));
    await tester.pumpAndSettle();
    expect(find.text('Settings'), findsOneWidget);
    expect(find.text('Sign in'), findsOneWidget);
    expect(find.text('Sign out'), findsNothing);
    await tester.tap(find.text('Settings'));
    await tester.pumpAndSettle();
    expect(find.text('Children'), findsOneWidget);
    await tester.pageBack();
    await tester.pumpAndSettle();

    await menu("Kids' dashboards");
    expect(find.widgetWithText(AppBar, 'Parent portal'), findsNothing);
    expect(find.text('Sam'), findsOneWidget);
  });

  testWidgets('forgot PIN on a device-only family erases it after typing ERASE', (tester) async {
    tester.view.physicalSize = phone;
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    final backend = HubBackend(PrefsStore());
    var signedOut = false;
    late AppState s;
    await tester.runAsync(() async {
      await backend.create(family, hashPin('1234'));
      s = AppState(const AppConfig(), backend, autoRefresh: false, onSignedOut: () => signedOut = true);
      await s.refresh();
    });
    addTearDown(s.dispose);
    await tester.pumpWidget(wrap(s, const TabletHome(), phone));
    await tester.pump();
    await tester.tap(find.text('Grown-ups only · PIN needed'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Forgot PIN?'));
    await tester.pumpAndSettle();
    expect(find.text('Forgot the parent PIN?'), findsOneWidget);
    // Without the word nothing is erased.
    await tester.tap(find.text('Erase and start again'));
    await tester.pumpAndSettle();
    expect(signedOut, isFalse);

    await tester.tap(find.text('Grown-ups only · PIN needed'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Forgot PIN?'));
    await tester.pumpAndSettle();
    await tester.enterText(find.widgetWithText(TextField, 'Type ERASE'), 'erase');
    await tester.runAsync(() async {
      await tester.tap(find.text('Erase and start again'));
      await Future<void>.delayed(const Duration(milliseconds: 100));
    });
    await tester.pumpAndSettle();
    await tester.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 200)));
    expect(signedOut, isTrue);
    expect((await tester.runAsync(() => PrefsStore().fetch()))!.data, isNull);
  });

  test('chores a child ticks wait for a grown-up to approve them', () async {
    var day = DateTime(2026, 10, 15, 9);
    final b = HubBackend(MemoryStore(), now: () => day);
    await b.create(family, hashPin('1'));
    var d = await b.load();
    final c = d.chores['k1']!.first;
    final pts = c.points!;
    expect(d.snap.approveChores, isTrue);

    await b.kidTick('k1', c);
    d = await b.load();
    expect((d.chores['k1']!.first.waiting, d.chores['k1']!.first.done, d.points('k1')), (true, false, 0));
    // Tapping again takes it back.
    await b.kidTick('k1', d.chores['k1']!.first);
    d = await b.load();
    expect(d.chores['k1']!.first.waiting, isFalse);

    await b.kidTick('k1', c);
    await b.approveChore('k1', c, false);
    d = await b.load();
    expect((d.chores['k1']!.first.waiting, d.points('k1')), (false, 0));

    await b.kidTick('k1', c);
    await b.approveChore('k1', c, true);
    d = await b.load();
    expect((d.chores['k1']!.first.done, d.chores['k1']!.first.waiting, d.points('k1')), (true, false, pts));
    expect(() => b.kidTick('k1', d.chores['k1']!.first), throwsA(isA<AppError>()));

    // Waiting chores clear with the morning reset.
    final c2 = d.chores['k1']![1];
    await b.kidTick('k1', c2);
    day = day.add(const Duration(days: 1));
    d = await b.load();
    expect(d.chores['k1']!.any((x) => x.waiting || x.done), isFalse);

    // With approvals off a tick counts straight away, and turning them off
    // counts anything already waiting.
    await b.kidTick('k1', c2);
    await b.setApproveChores(false);
    d = await b.load();
    expect((d.snap.approveChores, d.chores['k1']![1].done, d.points('k1')), (false, true, pts + c2.points!));
    await b.kidTick('k1', d.chores['k1']!.first);
    expect((await b.load()).chores['k1']!.first.done, isTrue);
  });

  test('Easter works out its date each year', () async {
    expect(
      [
        for (final y in [2024, 2025, 2026, 2027, 2038]) easterSunday(y),
      ],
      [
        DateTime(2024, 3, 31),
        DateTime(2025, 4, 20),
        DateTime(2026, 4, 5),
        DateTime(2027, 3, 28),
        DateTime(2038, 4, 25),
      ],
    );
    final e = easterCountdown('e').withDays(DateTime(2026, 10, 15));
    expect(
      (e.date, e.days),
      (DateTime(2027, 3, 28), DateTime(2027, 3, 28).difference(DateTime(2026, 10, 15)).inDays),
    );
    expect(easterCountdown('e').withDays(DateTime(2026, 4, 5)).days, 0);
    // New families start with it, and it stays Easter after saving.
    final b = HubBackend(MemoryStore());
    await b.create(family, hashPin('1'));
    final d = await b.load();
    expect(d.snap.countdowns.where((c) => c.easter).single.name, 'Easter');
    await b.saveCountdown(
      Countdown(id: '', emoji: '🐣', name: 'Easter 2', date: DateTime(2000), easter: true),
    );
    expect((await b.load()).snap.countdowns.where((c) => c.easter).length, 2);
  });

  test('the Supabase address works with or without /rest/v1', () {
    for (final u in ['https://x.supabase.co', 'https://x.supabase.co/', 'https://x.supabase.co/rest/v1/']) {
      expect(SupabaseAuth(url: u, anonKey: 'A').url, 'https://x.supabase.co');
    }
  });

  test('forgot PIN online: the login password sets a new PIN', () async {
    final client = MockClient((req) async {
      if (req.url.path == '/auth/v1/token') {
        final ok = jsonDecode(req.body)['password'] == 'secret1' || req.url.query.contains('refresh');
        return http.Response(
          jsonEncode(
            ok
                ? {
                    'access_token': 'AT',
                    'refresh_token': 'RT',
                    'expires_in': 3600,
                    'user': {'email': 'sam@example.com'},
                  }
                : {'error_description': 'Invalid login credentials'},
          ),
          ok ? 200 : 400,
          headers: {'content-type': 'application/json'},
        );
      }
      return http.Response('{}', 404);
    });
    final auth = SupabaseAuth(url: 'https://x.supabase.co', anonKey: 'ANON', client: client);
    await auth.signIn('sam@example.com', 'secret1');
    final backend = HubBackend(MemoryStore());
    await backend.create(family, hashPin('1234'));
    final s = AppState(const AppConfig(), backend, auth: auth, autoRefresh: false);
    await s.refresh();
    expect(await s.resetPin('wrong1', '5678'), 'That email and password don\'t match.');
    expect(s.checkPin('1234'), isTrue);
    expect(await s.resetPin('secret1', '5678'), isNull);
    expect((s.checkPin('5678'), s.checkPin('1234')), (true, false));
    s.dispose();
  });

  testWidgets('first run on a device without accounts needs a child and a PIN', (tester) async {
    tester.view.physicalSize = phone;
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    Backend? ready;
    await tester.pumpWidget(
      MaterialApp(home: WelcomeScreen(auth: null, onReady: (b, c, a) async => ready = b)),
    );
    await tester.tap(find.text('Set up your family'));
    await tester.pumpAndSettle();
    await tester.tap(find.widgetWithText(TextButton, 'Save'));
    await tester.pump();
    expect(find.text('Add at least one child.'), findsOneWidget);

    await tester.tap(find.text('Add a child'));
    await tester.pumpAndSettle();
    await tester.enterText(find.widgetWithText(TextField, 'Name'), 'Mary Jane');
    await tester.enterText(find.widgetWithText(TextField, 'Age'), '6');
    await tester.ensureVisible(find.text('Unicorn'));
    await tester.tap(find.text('Unicorn'));
    await tester.pump();
    await tester.tap(find.widgetWithText(TextButton, 'Save'));
    await tester.pumpAndSettle();
    expect(find.text('Mary Jane'), findsOneWidget);
    expect(find.text('Age 6 · Unicorn theme'), findsOneWidget);

    await tester.tap(find.widgetWithText(TextButton, 'Save'));
    await tester.pumpAndSettle();
    expect(ready, isNull);
    expect(find.text('Choose a parent PIN of 4 to 8 digits.'), findsOneWidget);
    await tester.enterText(find.widgetWithText(TextField, 'Parent PIN'), '2468');
    await tester.runAsync(() async {
      await tester.tap(find.widgetWithText(TextButton, 'Save'));
      await Future<void>.delayed(const Duration(milliseconds: 200));
    });
    expect(ready, isNotNull);
    final d = await tester.runAsync(() => ready!.load());
    expect(d!.family.children.single.name, 'Mary Jane');
    expect(d.family.children.single.theme, 'unicorn');
    expect(d.family.pinHash, hashPin('2468'));
  });

  testWidgets('after first-run setup the app opens on the kid picker', (tester) async {
    tester.view.physicalSize = phone;
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    await tester.pumpWidget(const KidsHubApp());
    await tester.tap(find.text('Set up your family'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Add a child'));
    await tester.pumpAndSettle();
    await tester.enterText(find.widgetWithText(TextField, 'Name'), 'Sam');
    await tester.enterText(find.widgetWithText(TextField, 'Age'), '6');
    await tester.tap(find.widgetWithText(TextButton, 'Save'));
    await tester.pumpAndSettle();
    await tester.enterText(find.widgetWithText(TextField, 'Parent PIN'), '2468');
    await tester.runAsync(() async {
      await tester.tap(find.widgetWithText(FilledButton, 'Start'));
      await Future<void>.delayed(const Duration(milliseconds: 300));
    });
    await tester.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 300)));
    await tester.pump();
    await tester.pump();
    expect(find.text('Set up your family'), findsNothing);
    expect(find.byType(TabletHome), findsOneWidget);
    expect(find.text('Sam'), findsOneWidget);
  });

  testWidgets('welcome screen offers sign in when accounts are on', (tester) async {
    tester.view.physicalSize = phone;
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    await tester.pumpWidget(
      MaterialApp(
        home: WelcomeScreen(
          auth: SupabaseAuth(url: 'https://x.supabase.co', anonKey: 'ANON'),
          onReady: (b, c, a) async {},
        ),
      ),
    );
    expect(find.text('Forgot password?'), findsOneWidget);
    expect(find.text('Use on this device only, without an account'), findsOneWidget);
    await tester.tap(find.text('Create account').first);
    await tester.pump();
    expect(find.text('At least 8 characters'), findsOneWidget);
  });

  testWidgets('signing in from the parent menu can move this device\'s family online', (tester) async {
    tester.view.physicalSize = phone;
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    Object? created;
    final client = MockClient((req) async {
      final body = switch (req.url.path) {
        '/auth/v1/token' => {'access_token': 'AT', 'refresh_token': 'RT', 'expires_in': 3600},
        '/rest/v1/rpc/my_family' => [],
        '/rest/v1/rpc/family_create' => () {
          created = jsonDecode(req.body)['p_data'];
          return [
            {'family_id': 'F1', 'code': 'ABCDE23456'},
          ];
        }(),
        _ => {},
      };
      return http.Response(jsonEncode(body), 200, headers: {'content-type': 'application/json'});
    });
    final device = {
      'family': {'children': [], 'pinHash': 'h'},
      'points': {'k1': 12},
    };
    Backend? ready;
    await tester.pumpWidget(
      MaterialApp(
        home: WelcomeScreen(
          auth: SupabaseAuth(url: 'https://x.supabase.co', anonKey: 'ANON', client: client),
          storeFor: (a) => SupabaseStore(a, client: client),
          onReady: (b, c, a) async => ready = b,
          deviceFamily: device,
        ),
      ),
    );
    expect(find.text('Use on this device only, without an account'), findsNothing);
    await tester.enterText(find.widgetWithText(TextField, 'Email'), 'sam@example.com');
    await tester.enterText(find.widgetWithText(TextField, 'Password'), 'secret1');
    await tester.runAsync(() async {
      await tester.tap(find.widgetWithText(FilledButton, 'Sign in'));
      await Future<void>.delayed(const Duration(milliseconds: 200));
    });
    await tester.pumpAndSettle();
    await tester.runAsync(() async {
      await tester.tap(find.text('Move this device\'s family online'));
      await Future<void>.delayed(const Duration(milliseconds: 200));
    });
    expect(created, device);
    expect(ready, isNotNull);
  });

  testWidgets('forgot password: email, passcode, then a new password', (tester) async {
    tester.view.physicalSize = phone;
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    final calls = <http.Request>[];
    final client = MockClient((req) async {
      calls.add(req);
      final body = switch (req.url.path) {
        '/auth/v1/verify' when jsonDecode(req.body)['token'] != '123456' => null,
        '/auth/v1/verify' => {'access_token': 'AT', 'refresh_token': 'RT', 'expires_in': 3600},
        _ => {},
      };
      return body == null
          ? http.Response(jsonEncode({'msg': 'Token has expired or is invalid'}), 403)
          : http.Response(jsonEncode(body), 200, headers: {'content-type': 'application/json'});
    });
    bool? result;
    await tester.pumpWidget(
      MaterialApp(
        home: Builder(
          builder: (context) => TextButton(
            onPressed: () async => result = await Navigator.push<bool>(
              context,
              MaterialPageRoute(
                builder: (_) => ResetPasswordScreen(
                  auth: SupabaseAuth(url: 'https://x.supabase.co', anonKey: 'A', client: client),
                ),
              ),
            ),
            child: const Text('go'),
          ),
        ),
      ),
    );
    await tester.tap(find.text('go'));
    await tester.pumpAndSettle();
    Future<void> press(String label) async {
      await tester.runAsync(() async {
        await tester.tap(find.widgetWithText(FilledButton, label));
        await Future<void>.delayed(const Duration(milliseconds: 100));
      });
      await tester.pump();
    }

    expect(find.text('Reset your password'), findsOneWidget);
    await tester.enterText(find.byType(TextField), 'sam@example.com');
    await press('Send passcode');
    expect(find.text('Check your email'), findsOneWidget);
    expect(find.text('Resend in 60s'), findsOneWidget);
    await tester.enterText(find.byType(TextField), '000000');
    await press('Continue');
    expect(find.textContaining('passcode didn'), findsOneWidget);
    await tester.enterText(find.byType(TextField), '123456');
    await press('Continue');
    expect(find.text('Choose a new password'), findsOneWidget);
    await tester.enterText(find.byType(TextField).at(0), 'newpass12');
    await tester.enterText(find.byType(TextField).at(1), 'newpass13');
    await press('Save and sign in');
    expect(find.text('The two passwords don\'t match.'), findsOneWidget);
    await tester.enterText(find.byType(TextField).at(1), 'newpass12');
    await press('Save and sign in');
    await tester.pumpAndSettle();
    expect(result, isTrue);
    expect(jsonDecode(calls.last.body), {'password': 'newpass12'});
    expect(calls.first.url.path, '/auth/v1/recover');
  });

  testWidgets('child editor won\'t take two children with the same name', (tester) async {
    tester.view.physicalSize = phone;
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    Object? result;
    await tester.pumpWidget(
      MaterialApp(
        home: Builder(
          builder: (context) => TextButton(
            onPressed: () async => result = await Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ChildEditor(others: family)),
            ),
            child: const Text('go'),
          ),
        ),
      ),
    );
    await tester.tap(find.text('go'));
    await tester.pumpAndSettle();
    await tester.enterText(find.widgetWithText(TextField, 'Name'), 'sam');
    await tester.tap(find.widgetWithText(TextButton, 'Save'));
    await tester.pump();
    expect(find.text('You already have a child called sam'), findsOneWidget);
    expect(result, isNull);
  });

  testWidgets('the loading page shows the Kids Hub sign and the mascots', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: SplashScreen()));
    await tester.pump(const Duration(seconds: 1));
    expect(find.byType(KidsHubSign), findsOneWidget);
    expect(find.text('CHORES ★ POINTS ★ REWARDS'), findsOneWidget);
    for (final t in KidTheme.all) {
      expect(find.text(t.mascot), findsOneWidget);
    }
    expect(find.text('Loading…'), findsOneWidget);
  });
  group('new features', () {
    late DateTime day;
    late HubBackend b;

    // 15 Oct 2026 is a Thursday.
    setUp(() async {
      day = DateTime(2026, 10, 15, 9);
      b = HubBackend(MemoryStore(), now: () => day);
      await b.create(family.take(2).toList(), hashPin('1'));
      await b.setApproveChores(false);
    });

    Future<void> doAll(String kid) async {
      final d = await b.load();
      for (final c in d.choresToday(kid)) {
        if (!c.done) await b.setChore(kid, c, true);
      }
    }

    Future<void> nextDay([int n = 1]) async {
      day = day.add(Duration(days: n));
      await b.load();
    }

    test('chores on certain days, and one-off bonus jobs', () async {
      await b.addChore('k1', 'Bins out (2 pts)', days: [DateTime.tuesday]);
      await b.addChore('k1', 'Wash the car (10 pts)', bonus: true);
      var d = await b.load();
      expect(d.choresToday('k1').map((c) => c.title), isNot(contains('Bins out')));
      expect(d.choresFor('k1').firstWhere((c) => c.title == 'Bins out').daysLabel, 'Tue');
      expect(d.bonusJobs('k1').map((c) => c.title), ['Wash the car']);
      await b.setChore('k1', d.bonusJobs('k1').first, true);
      expect((await b.load()).points('k1'), 10);
      // Next Tuesday the bins show; the finished bonus job has gone.
      await nextDay(5);
      d = await b.load();
      expect(d.weekday, DateTime.tuesday);
      expect(d.choresToday('k1').map((c) => c.title), contains('Bins out'));
      expect(d.bonusJobs('k1'), isEmpty);
    });

    test('streaks count days with every chore done, and badges follow', () async {
      var d = await b.load();
      expect(d.statsFor('k1').current, 0);
      await doAll('k1');
      d = await b.load();
      expect(d.statsFor('k1').current, 1, reason: 'today counts once it is all done');
      expect(badges.firstWhere((x) => x.name == 'First chore').earned(d.statsFor('k1')), isTrue);
      await nextDay();
      await doAll('k1');
      await nextDay();
      await doAll('k1');
      d = await b.load();
      expect(d.statsFor('k1').current, 3);
      expect(badges.firstWhere((x) => x.name == 'On a roll').earned(d.statsFor('k1')), isTrue);
      // Missing a day breaks it, but the best is kept.
      await nextDay(2);
      d = await b.load();
      expect((d.statsFor('k1').current, d.statsFor('k1').bestNow), (0, 3));
    });

    test('a whole week done earns the perfect week badge', () async {
      // Start on Monday 19 Oct and finish every day to Sunday.
      await nextDay(4);
      for (var i = 0; i < 7; i++) {
        await doAll('k1');
        await nextDay();
      }
      final st = (await b.load()).statsFor('k1');
      expect(st.weeks, 1);
      expect(badges.firstWhere((x) => x.name == 'Perfect week').earned(st), isTrue);
    });

    test('routines wait for a grown-up, then give their points', () async {
      await b.setApproveChores(true);
      var d = await b.load();
      final morning = d.routinesFor('k1').firstWhere((r) => r.name == 'Morning');
      expect(morning.steps.length, 4);
      await b.finishRoutine('k1', morning.id);
      d = await b.load();
      expect(d.routinesFor('k1').first.waiting, isTrue);
      expect(d.points('k1'), 0);
      await b.approveRoutine('k1', morning.id, true);
      d = await b.load();
      expect((d.routinesFor('k1').first.done, d.points('k1')), (true, morning.points));
      await nextDay();
      expect((await b.load()).routinesFor('k1').first.state, 'todo');
    });

    test('routines can be edited', () async {
      await b.saveRoutine(
        'k2',
        const Routine(id: '', name: 'After school', emoji: '🎒', steps: [RoutineStep('Bag away')]),
      );
      final r = (await b.load()).routinesFor('k2').last;
      expect(r.name, 'After school');
      await b.deleteRoutine('k2', r.id);
      expect((await b.load()).routinesFor('k2').map((x) => x.name), isNot(contains('After school')));
    });

    test('saving for a reward, then buying it', () async {
      final movie = (await b.load()).shop.firstWhere((r) => r.name == 'Pick the movie');
      await b.setSaving('k1', movie.key);
      var d = await b.load();
      expect(d.snap.savingFor('k1')?.name, 'Pick the movie');
      await b.adjustPoints('k1', 20);
      await b.buy('k1', movie);
      d = await b.load();
      expect(d.snap.savingFor('k1'), isNull);
      expect(badges.firstWhere((x) => x.name == 'Super saver').earned(d.statsFor('k1')), isTrue);
    });

    test('family goal: kids put points in until it is reached', () async {
      await b.setFamilyGoal(const FamilyGoal(name: 'Pizza night', emoji: '🍕', target: 10));
      await b.adjustPoints('k1', 8);
      await b.adjustPoints('k2', 8);
      await b.giveToFamily('k1', 6);
      await b.giveToFamily('k2', 6); // only 4 more were needed
      final d = await b.load();
      final g = d.snap.familyGoal!;
      expect((g.saved, g.reached, g.given['k1'], g.given['k2']), (10, true, 6, 4));
      expect((d.points('k1'), d.points('k2')), (2, 4));
      expect(() => b.giveToFamily('k1', 1), throwsA(isA<AppError>()));
    });

    test('challenge spinner: spins a day, approval, points and badge', () async {
      await b.setApproveChores(true);
      var d = await b.load();
      expect(d.snap.challenges.length, 120);
      expect(d.snap.spinCats.length, 6);
      await b.spinChallenge('k1', cat: 'lego');
      d = await b.load();
      final first = d.challengeFor('k1').current!;
      expect(first.cat, 'lego');
      expect(d.challengeFor('k1').left(d.snap.challenge), 2);
      // Spinning again gives a different one.
      await b.spinChallenge('k1', cat: 'lego');
      d = await b.load();
      expect(d.challengeFor('k1').current!.id, isNot(first.id));
      await b.finishChallenge('k1');
      d = await b.load();
      expect(d.challengeFor('k1').waiting, isTrue);
      await expectLater(b.spinChallenge('k1'), throwsA(isA<AppError>()));
      await b.approveChallenge('k1', true);
      d = await b.load();
      final c = d.challengeFor('k1').current!;
      expect((d.challengeFor('k1').done, d.points('k1')), (true, c.points));
      expect(d.log['k1']!.first.kind, 'challenge');
      expect(badges.firstWhere((x) => x.name == 'Challenge accepted').earned(d.statsFor('k1')), isTrue);
      await b.spinChallenge('k1');
      await expectLater(b.spinChallenge('k1'), throwsA(isA<AppError>()));
      // New spins the next day.
      await nextDay();
      d = await b.load();
      expect((d.challengeFor('k1').spins, d.challengeFor('k1').current), (0, null));
    });

    test('a challenge waiting for a grown-up is still there the next day', () async {
      await b.setApproveChores(true);
      await b.spinChallenge('k2');
      await b.finishChallenge('k2');
      await nextDay();
      final d = await b.load();
      expect(d.challengeFor('k2').waiting, isTrue);
      expect(d.challengeFor('k2').spins, 0);
    });

    test('parents edit challenges and switch kinds off', () async {
      await b.setChallengeSettings(
        const ChallengeSettings(spins: 5, offCats: ['lego', 'craft', 'draw', 'outdoor', 'kind']),
      );
      await b.saveChallenge(const Challenge(id: '', cat: 'cook', text: 'Make a cake', points: 9));
      var d = await b.load();
      expect(d.snap.spinCats.map((c) => c.id), ['cook']);
      final cake = d.snap.challenges.firstWhere((c) => c.text == 'Make a cake');
      expect(cake.points, 9);
      await b.spinChallenge('k1');
      d = await b.load();
      expect(d.challengeFor('k1').current!.cat, 'cook');
      expect(d.challengeFor('k1').left(d.snap.challenge), 4);
      await b.deleteChallenge(cake.id);
      expect((await b.load()).snap.challenges.any((c) => c.text == 'Make a cake'), isFalse);
      expect(ChallengeSettings.fromJson(const ChallengeSettings(photos: false).toJson()).photos, isFalse);
      await b.setChallengeSettings(const ChallengeSettings(on: false));
      await expectLater(b.spinChallenge('k1'), throwsA(isA<AppError>()));
    });

    test('points to pocket money', () async {
      expect(const Money(on: true, points: 10, cents: 100).of(34), r'$3.40');
      await b.setMoney(const Money(on: true, points: 10, cents: 100));
      await b.adjustPoints('k1', 25);
      await b.payOut('k1', 20);
      final d = await b.load();
      expect(d.points('k1'), 5);
      expect(d.log['k1']!.first.text, contains(r'Paid out $2.00'));
      expect(() => b.payOut('k1', 50), throwsA(isA<AppError>()));
    });
  });

  testWidgets('the board celebrates when a chore is approved', (tester) async {
    final s = await show(tester, const KidScreen(kid: 'k1'), tablet);
    expect(find.textContaining('day'), findsWidgets);
    final chores = s.data!.choresToday('k1');
    await tester.runAsync(() async {
      for (final c in chores) {
        await s.backend.setChore('k1', c, true);
      }
      await s.refresh();
    });
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.textContaining('All done today!'), findsOneWidget);
    await tester.pump(const Duration(seconds: 4));
    expect(find.textContaining('All done today!'), findsNothing);
  });

  testWidgets('a routine goes step by step with a timer', (tester) async {
    final s = await show(tester, const KidScreen(kid: 'k1'), phone);
    final r = s.data!.routinesFor('k1').first;
    await tester.pumpWidget(wrap(s, RoutineScreen(kid: 'k1', routineId: r.id), phone));
    await tester.pump();
    expect(find.text('STEP 1 OF ${r.steps.length}'), findsOneWidget);
    expect(find.text(r.steps.first.text), findsOneWidget);
    expect(find.text('${r.steps.first.minutes}:00'), findsOneWidget);
    await tester.tap(find.text('Tap to start'));
    await tester.pump(const Duration(seconds: 2));
    expect(find.text('Tap to pause'), findsOneWidget);
    for (var i = 1; i < r.steps.length; i++) {
      await tester.tap(find.textContaining('Next step'));
      await tester.pump(const Duration(seconds: 3));
    }
    await tester.runAsync(() async {
      await tester.tap(find.textContaining('Finish'));
      await Future<void>.delayed(const Duration(milliseconds: 100));
    });
    await tester.pump();
    await tester.pump(const Duration(seconds: 4));
    expect(find.text('All done!'), findsOneWidget);
    expect(s.data!.routinesFor('k1').first.waiting, isTrue);
  });

  testWidgets('parents see the week: points, chores and what was bought', (tester) async {
    final s = await show(tester, const ParentHome(), tablet, points: 30);
    await tester.runAsync(() async {
      final d = s.data!;
      await s.backend.setChore('k1', d.choresToday('k1').first, true);
      await s.backend.buy('k1', d.shop.firstWhere((r) => r.name == 'Extra snack'));
      await s.refresh();
    });
    await tester.tap(find.text('📊 This week'));
    await tester.pumpAndSettle();
    expect(find.text('points earned'), findsWidgets);
    expect(find.text('Bought: Extra snack'), findsOneWidget);
  });

  testWidgets('the board opens the challenge spinner, which spins a challenge', (tester) async {
    final s = await show(tester, const KidScreen(kid: 'k1'), phone);
    await tester.scrollUntilVisible(find.text('Challenge spinner'), 300);
    await tester.tap(find.text('Challenge spinner'));
    await tester.pumpAndSettle();
    expect(find.text('🎲 Surprise me'), findsOneWidget);
    await tester.tap(find.text('🧱 Bricks'));
    await tester.pump();
    await tester.runAsync(() async {
      await tester.tap(find.text('Spin! (3 left)'));
      await Future<void>.delayed(const Duration(milliseconds: 300));
    });
    // The spin waits on the store (real time) and then animates (test time).
    for (var i = 0; i < 50; i++) {
      await tester.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 10)));
      await tester.pump(const Duration(milliseconds: 100));
    }
    final c = s.data!.challengeFor('k1').current!;
    expect(c.cat, 'lego');
    expect(find.text(c.text), findsOneWidget);
    expect(find.text('Spin again (2 left)'), findsOneWidget);
    await tester.scrollUntilVisible(find.text('I did it! ✓'), 300);
    await tester.runAsync(() async {
      await tester.tap(find.text('I did it! ✓'));
      await Future<void>.delayed(const Duration(milliseconds: 100));
    });
    await tester.pump();
    await tester.pump(const Duration(seconds: 4));
    expect(s.data!.challengeFor('k1').waiting, isTrue);
    expect(find.text('Waiting for a grown-up to check ⏳'), findsOneWidget);
  });

  testWidgets('parents approve a challenge and edit the list', (tester) async {
    final s = await show(tester, const ParentHome(), tablet);
    await tester.runAsync(() async {
      await s.backend.spinChallenge('k1');
      await s.backend.finishChallenge('k1');
      await s.refresh();
    });
    await tester.pump();
    expect(find.text('⛏️ Sam ⏳1'), findsOneWidget);
    await tester.scrollUntilVisible(
      find.text('Challenge today'),
      300,
      scrollable: find.descendant(of: find.byType(ListView), matching: find.byType(Scrollable)).first,
    );
    await tester.runAsync(() async {
      await tester.tap(find.text('Approve'));
      await Future<void>.delayed(const Duration(milliseconds: 100));
    });
    await tester.pump();
    expect(s.data!.challengeFor('k1').done, isTrue);
    await tester.tap(find.text('🎡 Challenges'));
    await tester.pumpAndSettle();
    expect(find.text('Spins a day'), findsOneWidget);
    await tester.tap(find.text('Bricks'));
    await tester.pumpAndSettle();
    expect(find.text('Build a dinosaur'), findsOneWidget);

    // The editor starts from the catalog's steps; changing one keeps the family's own.
    Catalog.all = parseCatalog(File('assets/catalog/challenges.txt').readAsStringSync());
    await tester.ensureVisible(find.text('Build a dinosaur'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Build a dinosaur'));
    await tester.pumpAndSettle();
    expect(find.text('Edit challenge'), findsOneWidget);
    await tester.scrollUntilVisible(find.text('Step 1'), 300, scrollable: find.byType(Scrollable).last);
    expect(find.text('✨ Ask Claude'), findsNothing); // device-only family
    final step1 = find.widgetWithText(TextField, 'Step 1');
    await tester.enterText(step1, 'Pick a green brick for the body.');
    await tester.runAsync(() async {
      await tester.tap(find.widgetWithText(TextButton, 'Save'));
      await Future<void>.delayed(const Duration(milliseconds: 100));
    });
    await tester.pumpAndSettle();
    final saved = s.data!.snap.challenges.firstWhere((c) => c.text == 'Build a dinosaur');
    expect(saved.how!.steps.first, 'Pick a green brick for the body.');
    expect(saved.how!.steps.length, Catalog.of('Build a dinosaur')!.steps.length);
    expect(Catalog.forChallenge(saved)!.steps.first.image, 'build_a_dinosaur_1.webp');
    expect(Challenge.fromJson(saved.toJson()).how!.need, saved.how!.need);
  });

  group('ask Claude', () {
    const now = ChallengeDraft(text: 'Build a dinosaur', cat: 'lego', points: 3, minutes: 20);
    Future<ChallengeAi> ai(http.Response Function(http.Request) fn, List<http.Request> calls) async {
      final client = MockClient((req) async {
        calls.add(req);
        if (req.url.path == '/auth/v1/token') {
          return http.Response(
            jsonEncode({'access_token': 'AT', 'refresh_token': 'RT', 'expires_in': 3600}),
            200,
            headers: {'content-type': 'application/json'},
          );
        }
        return fn(req);
      });
      final auth = SupabaseAuth(url: 'https://x.supabase.co', anonKey: 'ANON', client: client);
      await auth.signIn('sam@example.com', 'secret1');
      expect(ChallengeAi.canUse(auth), isTrue);
      return ChallengeAi(auth, client: client);
    }

    test('sends the challenge with the login and reads the answer', () async {
      final calls = <http.Request>[];
      final a = await ai(
        (req) => http.Response(
          jsonEncode({
            'challenge': {
              'title': 'Build a tiny dinosaur.',
              'cat': 'nope',
              'pts': 99,
              'need': ['Toy bricks'],
              'steps': ['Pick green bricks.', 'Make a body.', 'Roar!'],
            },
          }),
          200,
        ),
        calls,
      );
      final got = await a.ask(now, 'Make it easier');
      final req = calls.last;
      expect(req.url.toString(), 'https://x.supabase.co/functions/v1/challenge-ai');
      expect(req.headers['Authorization'], 'Bearer AT');
      expect(jsonDecode(req.body)['request'], 'Make it easier');
      expect(jsonDecode(req.body)['challenge']['title'], 'Build a dinosaur');
      expect(got.text, 'Build a tiny dinosaur');
      expect(got.cat, 'lego'); // unknown kind keeps the old one
      expect(got.points, 20); // clamped
      expect(got.minutes, 20); // missing keeps the old one
      expect(got.steps, hasLength(3));
    });

    test('explains when it is not set up or the answer is odd', () async {
      final missing = await ai((req) => http.Response('{}', 404), []);
      await expectLater(
        missing.ask(now, 'x'),
        throwsA(isA<AppError>().having((e) => e.message, 'message', contains('isn\'t switched on'))),
      );
      final odd = await ai(
        (req) => http.Response(
          jsonEncode({
            'challenge': {'title': 'Hi'},
          }),
          200,
        ),
        [],
      );
      await expectLater(odd.ask(now, 'x'), throwsA(isA<AppError>()));
      expect(ChallengeAi.canUse(null), isFalse);
    });
  });

  test('every starter challenge has a kind, points, minutes and a how-to with picture prompts', () {
    final src = File('assets/catalog/challenges.txt').readAsStringSync();
    final all = parseCatalog(src);
    expect(all.length, 120);
    final totals = <String, List<int>>{};
    for (final h in all.values) {
      expect(h.isChallenge, isTrue, reason: h.title);
      expect(h.removed, isFalse, reason: h.title);
      // A reworded challenge keeps its old key with "id:".
      expect(h.key, matches(RegExp(r'^[a-z0-9_]{1,48}$')), reason: h.title);
      expect(h.steps.length, inInclusiveRange(3, 6), reason: h.title);
      expect(h.need, isNotEmpty, reason: h.title);
      expect(h.age, greaterThan(0), reason: h.title);
      final t = totals.putIfAbsent(h.cat, () => [0, 0, 0]);
      t[0]++;
      t[1] += h.points;
      t[2] += h.minutes;
    }
    // Count, points and minutes per kind, as they were when the list lived in
    // lib/challenges.dart. Change these when the catalog changes on purpose.
    expect(totals, {
      'lego': [20, 60, 375],
      'craft': [20, 52, 365],
      'draw': [20, 40, 280],
      'outdoor': [20, 41, 290],
      'kind': [20, 35, 0],
      'cook': [20, 54, 370],
    });
    final dino = all['build_a_dinosaur']!;
    expect((dino.cat, dino.points, dino.minutes), ('lego', 3, 20));
    expect(all.values.first.title, 'Build a bridge that can hold a toy car');
    expect(all.values.last.title, 'Make a drink for everyone at dinner');
    // Every step has a picture prompt after "||".
    final steps = src.split('\n').where((l) => RegExp(r'^\d+\. ').hasMatch(l));
    expect(steps.every((l) => l.split('||').length == 2 && l.split('||')[1].trim().isNotEmpty), isTrue);
    expect(howToKey("Build an animal that doesn't exist yet"), 'build_an_animal_that_doesn_t_exist_yet');
    expect(dino.steps[1].image, 'build_a_dinosaur_2.webp');
  });

  test('the catalog reads kind, points, minutes, id and removed', () {
    final all = parseCatalog('''
# A comment
## Build a T-rex!
id: Build a dinosaur
kind: lego
points: 5
minutes: 25
age: 6
need: Bricks, Green bricks
1. Pick green bricks. || hands holding green bricks
2. Roar! || a brick dinosaur

## Old one
kind: craft
removed: yes
1. Do it.
''');
    expect(all.keys, ['build_a_dinosaur', 'old_one']);
    final t = all['build_a_dinosaur']!;
    expect(
      (t.title, t.cat, t.points, t.minutes, t.age, t.removed),
      ('Build a T-rex!', 'lego', 5, 25, 6, false),
    );
    expect(t.need, ['Bricks', 'Green bricks']);
    // Pictures keep the key, so a reworded challenge keeps them.
    expect(t.steps.map((s) => s.image), ['build_a_dinosaur_1.webp', 'build_a_dinosaur_2.webp']);
    final old = all['old_one']!;
    expect((old.cat, old.points, old.minutes, old.removed), ('craft', 3, 0, true));
    expect(parseCatalog('## No kind\n1. Step.').values.single.isChallenge, isFalse);
  });

  group('online catalog', () {
    tearDown(() => Catalog.all = bundledCatalog());

    String edited() => File('assets/catalog/challenges.txt')
        .readAsStringSync()
        // Reworded, keeping its key.
        .replaceFirst(
          '## Build a bridge that can hold a toy car\n',
          '## Build a bridge for a toy car\nid: build_a_bridge_that_can_hold_a_toy_car\n',
        )
        // Reworded, but this family's parent changed it.
        .replaceFirst('## Build a dinosaur\n', '## Build a big dinosaur\nid: build_a_dinosaur\n')
        .replaceFirst(
          '## Make a car with as few bricks as you can\n',
          '## Make a car with as few bricks as you can\nremoved: yes\n',
        )
        .replaceFirst(
          '# ─── Craft',
          '## Build a marble run\nkind: lego\npoints: 4\nminutes: 25\nage: 6\nneed: Bricks, A marble\n'
              '1. Build a slope. || a slope\n2. Add walls. || walls\n3. Race the marble! || a marble\n\n'
              '# ─── Craft',
        );

    test('a new catalog adds, rewords and switches off challenges, but not ones a parent changed', () async {
      var body = edited();
      var status = 200;
      final urls = <Uri>[];
      final client = MockClient((req) async {
        urls.add(req.url);
        return http.Response.bytes(utf8.encode(body), status);
      });
      final backend = HubBackend(MemoryStore());
      await backend.create(family.take(1).toList(), hashPin('1234'));
      final s = AppState(const AppConfig(mode: DataMode.device), backend, autoRefresh: false);
      await s.refresh();
      List<Challenge> all() => s.data!.snap.challenges;
      Challenge? withSrc(String k) => all().where((c) => c.src == k).firstOrNull;
      expect(all(), hasLength(120));
      expect({for (final c in all()) c.src}, bundledCatalog().keys.toSet());
      expect(all().every((c) => !c.edited), isTrue);

      // A parent changes one and deletes another.
      final dino = withSrc('build_a_dinosaur')!;
      await s.saveChallenge(
        Challenge(id: dino.id, cat: dino.cat, text: dino.text, points: 5, minutes: dino.minutes),
      );
      expect(withSrc('build_a_dinosaur')!.edited, isTrue);
      await s.deleteChallenge(withSrc('make_a_flower_garden')!.id);
      // Saving one without changing it keeps it following the catalog.
      final house = withSrc('build_a_house_for_your_favourite_toy')!;
      await s.saveChallenge(
        Challenge(
          id: house.id,
          cat: house.cat,
          text: house.text,
          points: house.points,
          minutes: house.minutes,
        ),
      );
      expect(withSrc('build_a_house_for_your_favourite_toy')!.edited, isFalse);

      expect(await Catalog.fetch(client: client), isTrue);
      expect(urls.single.toString(), endsWith('/storage/v1/object/public/challenges/catalog.txt'));
      // The app hears about it and brings the family up to date.
      for (var i = 0; i < 5; i++) {
        await pumpEventQueue();
      }
      expect(all().where((c) => c.text == 'Build a marble run'), hasLength(1));
      final marble = withSrc('build_a_marble_run')!;
      expect((marble.cat, marble.points, marble.minutes, marble.on), ('lego', 4, 25, true));
      final bridge = withSrc('build_a_bridge_that_can_hold_a_toy_car')!;
      expect(bridge.text, 'Build a bridge for a toy car');
      expect(
        Catalog.forChallenge(bridge)!.steps.first.image,
        'build_a_bridge_that_can_hold_a_toy_car_1.webp',
      );
      final mine = withSrc('build_a_dinosaur')!;
      expect((mine.text, mine.points), ('Build a dinosaur', 5));
      expect(Catalog.forChallenge(mine)!.steps, isNotEmpty);
      expect(withSrc('make_a_flower_garden'), isNull);
      expect(withSrc('make_a_car_with_as_few_bricks_as_you_can')!.on, isFalse);
      expect(all(), hasLength(120)); // one added, one deleted

      // Again: nothing new. A deleted catalog challenge never comes back.
      await s.deleteChallenge(marble.id);
      expect(await Catalog.fetch(client: client), isTrue);
      await s.followCatalog();
      expect(withSrc('build_a_marble_run'), isNull);
      expect(all(), hasLength(119));

      // Offline, missing or broken catalogs change nothing.
      status = 404;
      expect(await Catalog.fetch(client: client), isFalse);
      status = 200;
      body = '<html>Not found</html>';
      expect(await Catalog.fetch(client: client), isFalse);
      expect(
        await Catalog.fetch(client: MockClient((_) async => throw const SocketException('offline'))),
        isFalse,
      );
      expect(Catalog.loaded!['build_a_marble_run'], isNotNull);
      s.dispose();
    });

    test('families from before the online catalog are linked by text, without duplicates', () async {
      final store = MemoryStore();
      final backend = HubBackend(store);
      await backend.create(family.take(1).toList(), hashPin('1234'));
      // Make it look like it was saved by the old app.
      final old = await store.fetch();
      final data = old.data!..remove('offered');
      for (final c in (data['challenges'] as List).cast<Map>()) {
        c.remove('src');
        if (c['text'] == 'Build a dinosaur') c['pts'] = 9;
      }
      (data['challenges'] as List).removeWhere((c) => (c as Map)['text'] == 'Make a flower garden');
      await store.save(data, old.version);

      // The app's own catalog first, then a newer one.
      await backend.followCatalog();
      expect((await backend.load()).snap.challenges, hasLength(119));
      Catalog.all = parseCatalog(edited());
      await backend.followCatalog();
      final all = (await backend.load()).snap.challenges;
      expect(all, hasLength(120)); // the marble run is new; the flower garden stays deleted
      expect(all.where((c) => c.src == 'build_a_marble_run'), hasLength(1));
      expect(
        all.firstWhere((c) => c.src == 'build_a_bridge_that_can_hold_a_toy_car').text,
        'Build a bridge for a toy car',
      );
      // Its points were changed by a parent, so it is theirs now.
      final dino = all.firstWhere((c) => c.src == 'build_a_dinosaur');
      expect((dino.text, dino.points, dino.edited), ('Build a dinosaur', 9, true));
    });
  });

  testWidgets('show me how: what you need, then each step', (tester) async {
    final s = await show(tester, const KidScreen(kid: 'k1'), tablet);
    Catalog.all = parseCatalog(File('assets/catalog/challenges.txt').readAsStringSync());
    const c = Challenge(id: 'x', cat: 'lego', text: 'Build a dinosaur', minutes: 20);
    await tester.pumpWidget(
      wrap(s, HowToScreen(kid: 'k1', challenge: c, howTo: Catalog.of(c.text)!), tablet),
    );
    await tester.pump();
    expect(find.text("You'll need"), findsOneWidget);
    await tester.tap(find.text("Let's go! →"));
    await tester.pump();
    await tester.pump(const Duration(seconds: 1));
    expect(find.textContaining('Choose your dinosaur'), findsOneWidget);
  });

  test('the device remembers being a parent\'s phone, and which notifications it wants', () async {
    // Saved before this setting existed: no role yet, every notification on.
    final old = AppConfig.fromJson({'mode': 'cloud'});
    expect(old.role, isNull);
    expect(old.alerts, {Alert.approve, Alert.shop});
    final c = old.copyWith(role: DeviceRole.parent, alerts: {Alert.shop});
    final back = AppConfig.fromJson(c.toJson());
    expect(back.mode, DataMode.cloud);
    expect(back.role, DeviceRole.parent);
    expect(back.alerts, {Alert.shop});
  });

  test('parents are told when a chore needs approving or something is bought', () async {
    final sent = <Map<String, dynamic>>[];
    final client = MockClient((req) async {
      if (req.url.path == '/functions/v1/notify') sent.add(jsonDecode(req.body) as Map<String, dynamic>);
      final body = req.url.path == '/auth/v1/token'
          ? {'access_token': 'AT', 'refresh_token': 'RT', 'expires_in': 3600}
          : {'sent': 1};
      return http.Response(jsonEncode(body), 200, headers: {'content-type': 'application/json'});
    });
    final auth = SupabaseAuth(url: 'https://x.supabase.co', anonKey: 'ANON', client: client);
    await auth.signIn('sam@example.com', 'secret1');
    final backend = HubBackend(MemoryStore());
    await backend.create(family.take(1).toList(), hashPin('1234'));
    final s = AppState(
      const AppConfig(mode: DataMode.cloud, role: DeviceRole.kids),
      backend,
      auth: auth,
      push: Push(auth, client: client),
      autoRefresh: false,
    );
    await s.refresh();
    expect(s.waitingCount, 0);

    final chore = s.data!.choresFor('k1').first;
    await s.kidTick('k1', chore);
    await pumpEventQueue();
    expect(sent.single['kind'], 'approve');
    expect(sent.single['body'], 'Sam did "${chore.title}". Tap to approve it.');
    expect(s.waitingCount, 1);

    // Tapping again takes it back: nothing more to tell.
    await s.kidTick('k1', chore);
    await pumpEventQueue();
    expect(sent, hasLength(1));
    expect(s.waitingCount, 0);

    await s.adjustPoints('k1', 100);
    final treat = s.data!.shop.firstWhere((r) => r.minutes == 0);
    await s.buy('k1', treat);
    await s.useReward('k1', s.data!.owned('k1').single);
    await pumpEventQueue();
    expect(sent.skip(1).map((m) => m['kind']), ['shop', 'shop']);
    expect(sent[1]['body'], 'Sam bought ${treat.name} from the shop.');
    expect(sent[2]['body'], 'Sam would like their ${treat.name} now.');
    expect(s.waitingCount, 1);
    s.dispose();
  });
}
