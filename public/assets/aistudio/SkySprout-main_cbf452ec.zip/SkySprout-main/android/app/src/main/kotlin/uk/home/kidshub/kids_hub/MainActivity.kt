package uk.home.kidshub.kids_hub

import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // The channel parents' notifications arrive on (see supabase/functions/notify).
        // High importance so they pop up on screen.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("parents", "Chores and shop", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "When a chore needs approving or something is bought in the shop"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
