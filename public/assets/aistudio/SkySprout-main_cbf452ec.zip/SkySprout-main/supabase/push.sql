-- Kids Hub notifications: run this once in your Supabase project, after setup.sql
-- (SQL Editor > New query > Run). It is safe to run again.
-- Each parent phone that wants notifications is one row here, holding its
-- Firebase push token and which notifications it wants. The app never reads
-- the table: it calls the functions below, and the `notify` Edge Function
-- reads it with the service key.

create table if not exists public.devices (
  token text primary key,               -- the phone's Firebase push token
  family_id uuid not null references public.families(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  kinds text[] not null default '{approve,shop}',  -- what this phone wants to hear about
  updated_at timestamptz not null default now()
);
create index if not exists devices_family on public.devices (family_id);

-- Row level security on, with no policies: nobody can read the table
-- directly, not even with the app's public key.
alter table public.devices enable row level security;

-- Adds or updates this phone for the caller's family.
create or replace function public.device_register(p_token text, p_kinds text[])
returns boolean
language plpgsql security definer set search_path = public as $$
declare fid uuid;
begin
  select family_id into fid from family_members where user_id = auth.uid();
  if fid is null then raise exception 'not in a family'; end if;
  if length(p_token) > 4096 then raise exception 'bad token'; end if;
  insert into devices (token, family_id, user_id, kinds, updated_at)
    values (p_token, fid, auth.uid(), p_kinds, now())
    on conflict (token) do update
      set family_id = excluded.family_id, user_id = excluded.user_id,
          kinds = excluded.kinds, updated_at = now();
  return true;
end $$;

-- Stops notifications to this phone (signing out, or it became a kids' tablet).
create or replace function public.device_forget(p_token text)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  delete from devices d
    using family_members m
    where d.token = p_token and m.family_id = d.family_id and m.user_id = auth.uid();
  return true;
end $$;

revoke all on function public.device_register(text, text[]) from public, anon;
revoke all on function public.device_forget(text) from public, anon;
grant execute on function public.device_register(text, text[]) to authenticated;
grant execute on function public.device_forget(text) to authenticated;
