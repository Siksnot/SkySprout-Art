// Kids Hub: sends a push notification to the family's parent phones.
//
// The app calls this (POST /functions/v1/notify, with the family login's
// token) when a child ticks a chore that needs approving, or buys or uses
// something from the shop. Body: {kind: "approve" | "shop", title, body, from?}
// where `from` is the calling phone's own push token, so it is skipped.
//
// Needs one secret, FCM_SERVICE_ACCOUNT: the Firebase service account JSON
// (Firebase console > Project settings > Service accounts > Generate new
// private key). SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are provided by
// Supabase automatically.

import { createClient } from "jsr:@supabase/supabase-js@2";
import { importPKCS8, SignJWT } from "npm:jose@5";

const admin = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

// A Google access token for FCM, reused until shortly before it runs out.
let google: { token: string; expires: number } | null = null;

async function googleToken(sa: { client_email: string; private_key: string }) {
  if (google && Date.now() < google.expires - 60_000) return google.token;
  const key = await importPKCS8(sa.private_key, "RS256");
  const assertion = await new SignJWT({ scope: "https://www.googleapis.com/auth/firebase.messaging" })
    .setProtectedHeader({ alg: "RS256", typ: "JWT" })
    .setIssuer(sa.client_email)
    .setAudience("https://oauth2.googleapis.com/token")
    .setIssuedAt()
    .setExpirationTime("1h")
    .sign(key);
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion }),
  });
  if (!r.ok) throw new Error(`Google sign-in failed (${r.status}): ${await r.text()}`);
  const j = await r.json();
  google = { token: j.access_token, expires: Date.now() + j.expires_in * 1000 };
  return google.token;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return json(405, { error: "POST only" });

  // Who is asking, and which family they belong to.
  const jwt = (req.headers.get("Authorization") ?? "").replace(/^Bearer /, "");
  const { data: who } = await admin.auth.getUser(jwt);
  if (!who?.user) return json(401, { error: "not signed in" });
  const { data: member } = await admin
    .from("family_members").select("family_id").eq("user_id", who.user.id).maybeSingle();
  if (!member) return json(403, { error: "not in a family" });

  let msg: { kind?: string; title?: string; body?: string; from?: string };
  try {
    msg = await req.json();
  } catch {
    return json(400, { error: "bad body" });
  }
  const kind = msg.kind === "shop" ? "shop" : "approve";
  const title = String(msg.title ?? "Kids Hub").slice(0, 80);
  const body = String(msg.body ?? "").slice(0, 200);

  const { data: devices } = await admin
    .from("devices").select("token").eq("family_id", member.family_id).contains("kinds", [kind]);
  const tokens = (devices ?? []).map((d) => d.token as string).filter((t) => t !== msg.from);
  if (tokens.length === 0) return json(200, { sent: 0 });

  const raw = Deno.env.get("FCM_SERVICE_ACCOUNT");
  if (!raw) return json(500, { error: "FCM_SERVICE_ACCOUNT secret is not set" });
  const sa = JSON.parse(raw);
  const access = await googleToken(sa);

  let sent = 0;
  await Promise.all(tokens.map(async (token) => {
    const r = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
      method: "POST",
      headers: { Authorization: `Bearer ${access}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        message: {
          token,
          notification: { title, body },
          data: { open: "parents", kind },
          android: { priority: "HIGH", notification: { channel_id: "parents" } },
        },
      }),
    });
    if (r.ok) {
      sent++;
    } else if (r.status === 404 || (await r.text()).includes("UNREGISTERED")) {
      // The app was removed or the token replaced: stop sending to it.
      await admin.from("devices").delete().eq("token", token);
    }
  }));
  return json(200, { sent });
});
