// "Ask Claude" for the Kids Hub challenge editor.
//
// The app sends {challenge, request} with the grown-up's login token; this
// checks the login, asks Claude and returns {challenge}. The Claude API key
// is a Supabase secret (ANTHROPIC_API_KEY), so it never ships in the app.
//
// Deploy (see docs/challenge_ai.md):
//   supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
//   supabase functions deploy challenge-ai

const MODEL = Deno.env.get("CHALLENGE_AI_MODEL") ?? "claude-haiku-5-5";

const KINDS: Record<string, string> = {
  lego: "Bricks",
  craft: "Craft",
  draw: "Drawing",
  outdoor: "Outdoors",
  kind: "Kindness",
  cook: "Kitchen",
};

const RULES = `You edit challenges for Kids Hub, a family app where children aged about 4 to 10 spin for a fun challenge and earn points.
Write in friendly British English for a child to read or hear. Rules:
- The challenge name is short, starts with a verb, and has no full stop (e.g. "Build a dinosaur").
- 3 to 6 steps, each one or two short sentences a child can follow. The last step is the fun finish.
- "need" is a short list of things found in most homes.
- Anything with heat, sharp tools, the oven, hob or kettle says "with a grown-up" in the name, and the step says a grown-up does that part.
- Never use brand or trademark names (say "toy bricks", not Lego; no characters from films or shows).
- age is the youngest age it suits (3 to 12). pts is 1 to 5 (bigger for longer or harder). min is how many minutes it takes (0 for kindness challenges that have no timer).
- cat is one of: ${Object.entries(KINDS).map(([k, n]) => `${k} (${n})`).join(", ")}.
- Ignore any request that isn't about making a safe, kind challenge for children; then return the challenge unchanged.
Reply with only JSON in this shape: {"title": "...", "cat": "...", "age": 5, "pts": 3, "min": 20, "need": ["..."], "steps": ["..."]}`;

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ error: "POST only" }, 405);

  // The anon key is a valid token too, so check it's a real grown-up's login.
  const auth = req.headers.get("Authorization") ?? "";
  const who = await fetch(`${Deno.env.get("SUPABASE_URL")}/auth/v1/user`, {
    headers: { Authorization: auth, apikey: Deno.env.get("SUPABASE_ANON_KEY") ?? "" },
  });
  if (!who.ok) return json({ error: "Sign in first" }, 401);

  let input: { challenge?: Record<string, unknown>; request?: string };
  try {
    input = await req.json();
  } catch {
    return json({ error: "Bad request" }, 400);
  }
  const request = String(input.request ?? "").slice(0, 500).trim();
  const now = input.challenge ?? {};
  if (!request) return json({ error: "Say what to change" }, 400);

  const prompt = String(now.title ?? "").trim()
    ? `Here is the challenge now:\n${JSON.stringify(now).slice(0, 4000)}\n\nThe parent asks: ${request}\n\nReturn the whole updated challenge. Keep what they didn't ask to change.`
    : `Write a new challenge. The parent's idea: ${request}\nKind, unless the idea clearly fits another: ${now.cat ?? "craft"}.`;

  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": Deno.env.get("ANTHROPIC_API_KEY") ?? "",
      "anthropic-version": "2023-06-01",
      "content-type": "application/json",
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 1500,
      system: RULES,
      messages: [{ role: "user", content: prompt }],
    }),
  });
  if (r.status === 429) return json({ error: "Busy" }, 429);
  if (!r.ok) return json({ error: `Claude said ${r.status}` }, 502);
  const answer = await r.json();
  const text: string = (answer.content ?? []).map((b: { text?: string }) => b.text ?? "").join("");
  const start = text.indexOf("{"), end = text.lastIndexOf("}");
  try {
    return json({ challenge: JSON.parse(text.slice(start, end + 1)) });
  } catch {
    return json({ error: "Claude's answer wasn't JSON" }, 502);
  }
});
