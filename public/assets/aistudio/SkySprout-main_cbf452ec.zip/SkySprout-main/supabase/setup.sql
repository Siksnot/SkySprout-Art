-- Kids Hub: run this once in your Supabase project (SQL Editor > New query > Run).
-- Each family's data is one row. Only grown-ups who belong to that family
-- (by their login) can read or change it. The app never touches the tables
-- directly: it calls the functions below, which check who is asking.

create table if not exists public.families (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,            -- for a second grown-up to join
  data jsonb not null,
  version int not null default 1,       -- stops two devices overwriting each other
  updated_at timestamptz not null default now()
);

create table if not exists public.family_members (
  family_id uuid not null references public.families(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  primary key (family_id, user_id),
  unique (user_id)                      -- one family per login
);

-- Row level security on, with no policies: nobody can read the tables
-- directly, not even with the app's public key.
alter table public.families enable row level security;
alter table public.family_members enable row level security;

-- The caller's family.
create or replace function public.my_family()
returns table (family_id uuid, code text, data jsonb, version int)
language sql stable security definer set search_path = public as $$
  select f.id, f.code, f.data, f.version
  from families f join family_members m on m.family_id = f.id
  where m.user_id = auth.uid();
$$;

-- Starts a family for the caller, with a random 10-character code.
create or replace function public.family_create(p_data jsonb)
returns table (family_id uuid, code text)
language plpgsql security definer set search_path = public as $$
declare
  chars constant text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  new_code text;
  new_id uuid;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  if exists (select 1 from family_members where user_id = auth.uid()) then
    raise exception 'already in a family';
  end if;
  loop
    new_code := '';
    for i in 1..10 loop
      new_code := new_code || substr(chars, 1 + floor(random() * length(chars))::int, 1);
    end loop;
    exit when not exists (select 1 from families f where f.code = new_code);
  end loop;
  insert into families (code, data) values (new_code, p_data) returning id into new_id;
  insert into family_members (family_id, user_id) values (new_id, auth.uid());
  return query select new_id, new_code;
end $$;

-- Saves the family's data if nobody saved since p_version.
-- Returns the new version, or -1 if another device saved first.
create or replace function public.family_save(p_family uuid, p_data jsonb, p_version int)
returns int
language plpgsql security definer set search_path = public as $$
declare v int;
begin
  if not exists (select 1 from family_members where family_id = p_family and user_id = auth.uid()) then
    raise exception 'not your family';
  end if;
  update families set data = p_data, version = version + 1, updated_at = now()
    where id = p_family and version = p_version
    returning version into v;
  return coalesce(v, -1);
end $$;

-- A second grown-up joins with the family code.
create or replace function public.family_join(p_code text)
returns boolean
language plpgsql security definer set search_path = public as $$
declare fid uuid;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  if exists (select 1 from family_members where user_id = auth.uid()) then
    raise exception 'already in a family';
  end if;
  select id into fid from families where code = upper(p_code);
  if fid is null then raise exception 'no family with that code'; end if;
  insert into family_members (family_id, user_id) values (fid, auth.uid());
  return true;
end $$;

-- Only signed-in users may call the functions.
revoke all on function public.my_family() from public, anon;
revoke all on function public.family_create(jsonb) from public, anon;
revoke all on function public.family_save(uuid, jsonb, int) from public, anon;
revoke all on function public.family_join(text) from public, anon;
grant execute on function public.my_family() to authenticated;
grant execute on function public.family_create(jsonb) to authenticated;
grant execute on function public.family_save(uuid, jsonb, int) to authenticated;
grant execute on function public.family_join(text) to authenticated;
