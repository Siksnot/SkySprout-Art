# Kids Hub

A Flutter app for a family's chores, points, reward shop, screen time and
countdowns. Each family has its own login, so friends can use the app with
their own families. Android first (phones and Amazon Fire tablets); the iOS
project is included for later.

## How it flows

1. **First run**: a grown-up signs in or creates an account (email and
   password), then sets up the family: the children (name, age or
   birthday, and a dashboard theme each) and a parent PIN. A second grown-up makes their own
   login and joins with the family code from Settings. For the kids' tablets,
   a grown-up signs in once with their login; the kids never need it.
   "Use on this device only" skips accounts and keeps everything on the device.
2. **Home page**: every device opens here: the ☰ menu, a "Kids Hub" header
   with a 12-hour clock, then a big themed button per child's dashboard and
   a Parent portal button. (Countdowns show on each child's board.) After 3 minutes untouched, or when the app is put in the
   background, it comes back here and the parent screens lock again.
3. **Child's board**: "Sam's Quest Board", "Sam's Job Site", "Sam's Castle"
   or "Sam's Rainbow Board", depending on the theme: daily progress bar,
   today's chores, points with a 10-block goal bar, "Spend points" and the
   countdowns. Ticking a chore adds its points straight away.
4. **Shop**: "Spend your stars!" with reward cards (Buy now / Need N more),
   My Rewards with Start for screen-time rewards, and the orders waiting for
   a parent to hand over.
5. **Parent portal**: behind the Parent portal button (or ☰ menu) and the PIN (3 wrong tries
   locks it for 30 seconds). There is no default PIN. "Forgot PIN?" in the PIN
   box sets a new one with the family login's password; a device-only family
   can only be erased and set up again (type ERASE to confirm).
   - A tab per child: points (−5/−1/+1/+5 or any amount), goal, screen-time
     timer, points log, chores (tick, add, edit name and points, delete),
     default chore points and rewards owned.
   - Rewards: add, edit (emoji, name, description, shop label, screen-time
     minutes, show in shop) or delete, and each reward's price (points to
     claim) for each child.
   - Orders: rewards to hand over, plus "Add item".
   - Countdowns: add holidays or one-off dates. Easter is included and works
     out its own date each year ("Add Easter" brings it back if deleted). Each child's birthday counts
     down automatically once it is set in Settings.
   - The ☰ menu: Kids' dashboards (goes back and locks the portal),
     Settings (children, the PIN, the login and the family code), and Sign
     out, or Sign in on a device-only family. Signing in offers to move this
     device's family online when the account has none yet.

When a child ticks a chore it shows "Waiting for a grown-up"; the points
land when a parent taps Approve in their tab of the parent portal (tabs show
⏳ and how many are waiting). Settings › "Grown-ups approve chores" turns
this off. Chores reset to not done each morning; points, rewards and orders carry over.
A new family starts with six rewards (tablet time, TV time, extra snack,
dessert, stay up late, pick the movie), Halloween and Christmas countdowns,
and three chores per child. Parents can change all of it.

**Extras on each board**

- *Savings goal*: in the shop a child taps "Save for this"; their points
  card then fills towards that reward, and the goal clears when they buy it.
- *Streaks and badges*: a day counts when every chore due that day is done
  (days with no chores don't break it). Twelve badges, from "First chore" to
  "Unstoppable" (30 days); tap the streak card to see them all.
- *Celebrations*: confetti and a chime when a chore is approved (or ticked,
  with approvals off), and a fanfare when the whole list is done.
- *Chores by day and bonus jobs*: a chore can be on certain weekdays only.
  A one-off bonus job sits under "Bonus jobs" for extra points, doesn't count
  towards the streak, and goes the morning after it is done.
- *Routines*: Morning and Bedtime to start with, step by step with a timer
  for each step. Finishing one waits for a grown-up's OK like a chore.
  Parents edit them in the child's tab.
- *Family goal*: set in the Rewards tab (pizza night, cinema…); the kids put
  their points in from their boards.
- *Pocket money*: turn on in the Rewards tab and set a rate (10 points =
  $1.00). Boards show what points are worth; "Pay out" in the child's tab
  spends the points.
- *Challenge spinner*: a purple tile on the board opens a wheel with six
  kinds of challenge (Bricks, Craft, Drawing, Outdoors, Kindness, Kitchen;
  "Bricks" rather than "Lego", which is a trademark).
  The child picks a kind or "Surprise me" and spins; the wheel lands on a
  challenge with points and an optional timer. "I did it!" waits for a
  grown-up's OK like a chore. Each child gets 3 spins a day (spinning again
  uses one). "Take a photo of it" saves a picture to the child's "My makes"
  gallery; photos stay on the device that took them and aren't synced or
  uploaded (parents can turn photos off). No camera or storage permission
  is needed: Android's own camera app and photo picker are used. A
  new family starts with 120 challenges; the Challenges tab in the parent
  portal turns the spinner off, sets spins a day, switches kinds off, and
  adds, edits or removes challenges.
- *Show me how*: each starter challenge has a step-by-step sheet with a
  picture per step. The starter challenges (kind, points, timer and steps)
  all live in `assets/catalog/challenges.txt`, and can be changed after
  release by uploading a new copy (see "Changing challenges after release" in
  the pictures doc); pictures
  come from the app or a public Supabase bucket (see
  [docs/challenge_pictures.md](docs/challenge_pictures.md)).
  `python3 tool/build_site.py` builds `site/index.html`, a website of the
  whole catalog to host anywhere.
- *Challenge editor*: parents change a challenge's name, kind, points, timer,
  age, what you need and its steps. Signed-in families can **Ask Claude** to
  rewrite or invent one (see [docs/challenge_ai.md](docs/challenge_ai.md)).
- *This week*: a parent tab with each child's points earned, chores and
  routines done, what they bought and their streak, for this week or last.

**Themes**: Quest (pixel, Jersey 25 font, bundled), Construction (yellow,
hazard stripes), Princess (pink, hearts, castle wall) and Unicorn (pastel
rainbow and sparkles). Add one in `lib/themes.dart` (`KidTheme.all`).

**Sharing between devices**: the family's data is one record in Supabase.
Every phone and tablet signed in to the family reloads it every 10 seconds.
Each change reads the latest copy and saves only if nobody else saved in
between (otherwise it tries again), so two tablets ticking chores at the same
time don't overwrite each other. Supabase only lets a login reach its own
family (`supabase/setup.sql`). The parent PIN is stored hashed.

`screenshots/` shows each screen.

## Set up Supabase (once)

1. Create a free project at supabase.com.
2. SQL Editor › New query: paste `supabase/setup.sql` and Run.
3. Authentication › Sign In / Providers › Email: turn off **Confirm email**,
   or set a Site URL. Otherwise new accounts get a confirmation email whose
   link goes nowhere useful, and the built-in email sender only allows a few
   emails an hour.
4. Forgot password emails a passcode (app: email › passcode › new password).
   Supabase only lets you edit its emails once you add your own sender:
   - Sender: a domain you own plus Resend (resend.com, free up to 3,000
     emails a month). Add the domain in Resend and the DNS records it shows,
     create an API key, then Supabase › Authentication › Emails › SMTP
     Settings: host `smtp.resend.com`, port `465`, username `resend`,
     password = the API key, sender `noreply@yourdomain`, name Kids Hub.
     (For testing only, Gmail works: host `smtp.gmail.com`, port `465`,
     your address, and a Google app password.)
   - Authentication › Emails › Reset Password: subject `Your Kids Hub
     passcode`; paste `supabase/email_reset_passcode.html` into Source.
   - Authentication › Rate Limits: raise emails per hour if needed.
5. Project Settings › API: copy the **Project URL** and the **anon public**
   key. The anon key is meant to be in apps; the SQL keeps each family's data
   private.

## Notifications for parents (once)

After signing in, each device is asked who uses it: **a parent's phone** or
**the kids' tablet** (changed later in Settings › This device). A parent's
phone gets a notification when a child ticks a chore or finishes a routine
that needs approving, buys something in the shop, or wants a reward handed
over. Tapping it opens the parent PIN. Each phone can turn either kind off in
Settings. Kids' tablets only send, so the Fire tablets don't need Google
services. The Parent portal button also shows how many things are waiting,
with or without notifications.

Notifications go through Firebase Cloud Messaging (free):

1. console.firebase.google.com › Add project (Google Analytics off).
2. Add an Android app with package name `uk.home.kidshub.kids_hub`, and
   download its `google-services.json`. You only read it; it doesn't go in
   the project. Skip the SDK steps.
3. From that file, copy into the four `defaultValue`s at the top of
   `lib/push.dart`: `api_key` › `current_key` (API key),
   `mobilesdk_app_id` (app ID), `project_number` (sender ID) and
   `project_id`. They identify the project and are fine to have in the
   app. While they're empty the app builds and runs with no notifications.
4. Project settings › Service accounts › Generate new private key. Keep the
   JSON file private.
5. Supabase › SQL Editor: paste `supabase/push.sql` and Run.
6. Supabase › Edge Functions › Secrets: add `FCM_SERVICE_ACCOUNT` with the
   whole JSON file as the value.
7. Supabase › Edge Functions › Deploy a new function › Via editor: name it
   `notify`, paste `supabase/functions/notify/index.ts`, Deploy. (Or with the
   Supabase CLI: `supabase functions deploy notify`.)

## Build the Android app

```
flutter pub get
flutter build apk --release
```

The Supabase project (https://vfkpybbxcwajzcnugxnm.supabase.co) and its anon
key are built in, in `lib/sync.dart`. `--dart-define=SUPABASE_URL=...` and
`--dart-define=SUPABASE_ANON_KEY=...` point a build at a different project;
`--dart-define=SUPABASE_ANON_KEY=` (empty) builds a device-only app with no
accounts. Settings shows the version from `version:` in `pubspec.yaml` (raise it
for each new build). The APK is in
`build/app/outputs/flutter-apk/app-release.apk`. On a Fire tablet, turn on
Settings › Security & Privacy › Apps from Unknown Sources for the app you
open the APK with.

## Code map

- `lib/models.dart`: children, rewards, chores, timers, countdowns, log
- `lib/backend.dart`: the family's data and every action on it, starter
  data, daily chore reset, retry when two devices save at once
- `lib/sync.dart`: where the data lives (device or Supabase), the login, family codes
- `lib/app_state.dart`: loads data and runs actions
- `lib/config.dart`: this device's settings (on the device or online, parent's phone or kids' tablet)
- `lib/push.dart`: notifications to parents' phones (Firebase), sent through `supabase/functions/notify`
- `lib/themes.dart`: the four themes and their backgrounds
- `lib/screens/`: welcome and sign-in, home page, kid board, routine, challenge spinner, shop, parent screens, settings, child editor
- `lib/catalog.dart`: the challenge catalog (from `assets/catalog/challenges.txt`, or the newer one downloaded), its how-to steps and pictures; `lib/photos.dart`: challenge photos on the device
- `lib/challenge_ai.dart`: Ask Claude, through `supabase/functions/challenge-ai`
- `tool/`: builds the challenges website and the picture prompts
- `lib/widgets/celebrate.dart`: confetti and sounds (`assets/sounds/`)
- `supabase/setup.sql`: tables and functions to run once in Supabase
- `lib/main.dart`: opens on the home page; idle and background lock

Checks: `flutter analyze` and `flutter test`.
