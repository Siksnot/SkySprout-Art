import 'dart:convert';
import 'dart:math';

import 'catalog.dart';
import 'models.dart';
import 'sync.dart';

/// The family set-up shared by every device: the children and the parent PIN.
class Family {
  final List<Child> children;

  /// `hashPin` of the parent PIN.
  final String pinHash;
  const Family(this.children, this.pinHash);

  Map<String, dynamic> toJson() => {
    'children': [for (final c in children) c.toJson()],
    'pinHash': pinHash,
  };

  factory Family.fromJson(Map<String, dynamic>? j) => Family([
    for (final c in (j?['children'] as List?) ?? const []) Child.fromJson((c as Map).cast()),
  ], j?['pinHash'] as String? ?? '');
}

/// Everything the screens show, read in one go.
class HubData {
  final Family family;
  final Snapshot snap;
  final Map<String, List<TodoItem>> chores;

  /// Rewards bought that a parent still has to hand over.
  final List<TodoItem> owed;

  /// Recent points log per child, newest first.
  final Map<String, List<LogEntry>> log;

  /// Each child's routines, with today's state.
  final Map<String, List<Routine>> routines;

  /// Streaks and badge counts per child.
  final Map<String, KidStats> stats;

  /// Today's weekday (1 = Monday), for chores on certain days.
  final int weekday;

  /// Each child's challenge spinner today.
  final Map<String, ChallengeDay> challengeDays;

  const HubData(
    this.family,
    this.snap,
    this.chores,
    this.owed, [
    this.log = const {},
    this.routines = const {},
    this.stats = const {},
    this.weekday = 1,
    this.challengeDays = const {},
  ]);

  int points(String kid) => snap.points[kid] ?? 0;

  /// Every chore, on any day, including bonus jobs.
  List<TodoItem> choresFor(String kid) => chores[kid] ?? const [];

  /// Today's list: chores due today, without bonus jobs.
  List<TodoItem> choresToday(String kid) => [
    for (final c in choresFor(kid))
      if (!c.bonus && c.dueOn(weekday)) c,
  ];

  /// One-off bonus jobs for extra points.
  List<TodoItem> bonusJobs(String kid) => [
    for (final c in choresFor(kid))
      if (c.bonus) c,
  ];
  List<Routine> routinesFor(String kid) => routines[kid] ?? const [];
  KidStats statsFor(String kid) => stats[kid] ?? const KidStats();
  ChallengeDay challengeFor(String kid) => challengeDays[kid] ?? const ChallengeDay();
  TimerInfo? timer(String kid) => snap.timers[kid];

  /// Rewards shown in the shop.
  List<Reward> get shop => snap.rewards.where((r) => r.on && r.name.isNotEmpty).toList();

  /// Every reward with a name.
  List<Reward> get slots => snap.rewards.where((r) => r.name.isNotEmpty).toList();

  /// Rewards this child owns at least one of.
  List<Reward> owned(String kid) =>
      snap.rewards.where((r) => (r.own[kid] ?? 0) > 0 && r.name.isNotEmpty).toList();
}

/// Reads and changes the family's chores, points and rewards.
abstract class Backend {
  Future<HubData> load();

  /// Starts a new family with these children and PIN hash.
  Future<void> create(List<Child> children, String pinHash);

  /// Changes the children, and the PIN when [pinHash] is given.
  Future<void> saveFamily(List<Child> children, {String? pinHash});

  /// A grown-up ticks or unticks a chore: points straight away.
  Future<void> setChore(String kid, TodoItem item, bool done);

  /// A child ticks a chore. With approvals on it waits for a grown-up
  /// ([approveChore]); otherwise it is done straight away.
  Future<void> kidTick(String kid, TodoItem item);

  /// A grown-up says yes (points land) or not yet (back on the list).
  Future<void> approveChore(String kid, TodoItem item, bool yes);
  Future<void> setApproveChores(bool on);
  Future<void> addChore(String kid, String summary, {List<int> days = const [], bool bonus = false});
  Future<void> renameChore(String kid, TodoItem item, String summary, {List<int>? days, bool? bonus});
  Future<void> removeChore(String kid, TodoItem item);
  Future<void> buy(String kid, Reward r);
  Future<void> useReward(String kid, Reward r);
  Future<void> adjustPoints(String kid, int amount);

  /// [action] is start, pause or cancel; or change with [by].
  Future<void> timer(String kid, String action, {Duration? by});
  Future<void> setOwedDone(TodoItem item, bool done);
  Future<void> addOrder(String text);
  Future<void> setDefaultPoints(String kid, int points);
  Future<void> setGoal(String kid, int goal);
  Future<void> setPrice(String kid, String key, int price);

  /// Adds or updates a reward (matched by key).
  Future<void> saveReward(Reward r, {required bool on});
  Future<void> deleteReward(String key);

  /// Adds or updates a countdown (matched by id).
  Future<void> saveCountdown(Countdown c);
  Future<void> deleteCountdown(String id);

  /// A child finished every step of a routine. With approvals on it waits
  /// for a grown-up, like a chore.
  Future<void> finishRoutine(String kid, String id);
  Future<void> approveRoutine(String kid, String id, bool yes);

  /// Adds or updates a routine (matched by id; a blank id adds one).
  Future<void> saveRoutine(String kid, Routine r);
  Future<void> deleteRoutine(String kid, String id);

  /// The reward a child is saving for, or null to stop.
  Future<void> setSaving(String kid, String? key);

  /// Starts a new family goal (null clears it).
  Future<void> setFamilyGoal(FamilyGoal? goal);

  /// A child puts some of their points into the family goal.
  Future<void> giveToFamily(String kid, int points);
  Future<void> setMoney(Money money);

  /// A grown-up pays out [points] as pocket money; the points are spent.
  Future<void> payOut(String kid, int points);

  /// Uses one of today's spins: picks a challenge at random from [cat]
  /// (any category when null) in place of the one being done.
  Future<void> spinChallenge(String kid, {String? cat});

  /// A child says they did today's challenge. With approvals on it waits
  /// for a grown-up, like a chore.
  Future<void> finishChallenge(String kid);
  Future<void> approveChallenge(String kid, bool yes);

  /// Adds or updates a challenge (matched by id; a blank id adds one).
  Future<void> saveChallenge(Challenge c);
  Future<void> deleteChallenge(String id);
  Future<void> setChallengeSettings(ChallengeSettings s);

  /// Brings the family's challenges up to date with the challenge catalog
  /// (see [HubBackend.catalog]) and saves, if anything changed.
  Future<void> followCatalog();
}

/// Countdowns made from a child's birthday start with this; they are
/// changed in Settings, not in the Countdowns tab.
const birthdayPrefix = 'birthday:';

/// "Tidy room" + 3 -> "Tidy room (3 pts)".
String choreSummary(String title, int? points) =>
    points == null ? title.trim() : '${title.trim()} ($points pts)';

/// "-00:05:00" style durations.
String formatHms(Duration d) {
  final neg = d.isNegative;
  final a = d.abs();
  String two(int n) => n.toString().padLeft(2, '0');
  return '${neg ? '-' : ''}${two(a.inHours)}:${two(a.inMinutes % 60)}:${two(a.inSeconds % 60)}';
}

/// Starter rewards for a new family. Parents can edit, hide or delete them.
const starterRewards = [
  ('📱', 'Tablet time', 'Play for 15 minutes', 'Screen time', 15, 10),
  ('📺', 'TV time', 'Watch for 30 minutes', 'Screen time', 30, 8),
  ('🍿', 'Extra snack', 'One extra snack, your pick', 'Treats', 0, 5),
  ('🍦', 'Dessert treat', 'A sweet treat after dinner', 'Treats', 0, 10),
  ('🌙', 'Stay up late', '15 extra minutes before bed', 'Special', 0, 8),
  ('🎬', 'Pick the movie', 'You choose family movie night', 'Special', 0, 12),
];

/// Chores a new child starts with.
const starterChores = ['Make your bed (2 pts)', 'Brush your teeth (1 pts)', 'Tidy your room (3 pts)'];

/// Routines a new child starts with: (emoji, name, points, steps).
const starterRoutines = [
  (
    '🌅',
    'Morning',
    2,
    [
      RoutineStep('Get dressed', 5),
      RoutineStep('Eat breakfast', 15),
      RoutineStep('Brush your teeth', 2),
      RoutineStep('Shoes and coat on', 3),
    ],
  ),
  (
    '🌙',
    'Bedtime',
    2,
    [
      RoutineStep('Bath or wash', 10),
      RoutineStep('Pyjamas on', 3),
      RoutineStep('Brush your teeth', 2),
      RoutineStep('Story time', 10),
    ],
  ),
];

/// Monday of the week [d] is in.
DateTime mondayOf(DateTime d) => DateTime(d.year, d.month, d.day - (d.weekday - 1));

/// The family's chores, points and rewards, kept in a [FamilyStore] (this
/// device, or Supabase). Every change reads the latest copy, applies the
/// change and saves it only if no other device saved in between; otherwise
/// it tries again. Chores reset each morning; points, rewards and orders
/// carry over.
class HubBackend implements Backend {
  final FamilyStore store;

  /// Today's date; tests can move it.
  DateTime Function() now;

  /// Picks challenges; tests can make it repeatable.
  final Random random;

  /// The challenge catalog families follow; null until it has loaded.
  final Map<String, HowTo>? Function() catalog;

  HubBackend(this.store, {DateTime Function()? now, Random? random, Map<String, HowTo>? Function()? catalog})
    : now = now ?? DateTime.now,
      random = random ?? Random(),
      catalog = catalog ?? (() => Catalog.loaded);

  Map<String, dynamic>? _d;
  int _v = 0;
  var _n = 0;

  String _id(String p) => '${newId(p)}${_n++}';

  static String _day(DateTime t) => '${t.year}-${t.month}-${t.day}';

  Map<String, dynamic> _fresh() {
    final y = now().year;
    return {
      'family': const Family([], '').toJson(),
      'day': _day(now()),
      'points': <String, dynamic>{},
      'defaultPts': <String, dynamic>{},
      'goals': <String, dynamic>{},
      'chores': <String, dynamic>{},
      'timers': <String, dynamic>{},
      'log': <String, dynamic>{},
      'orders': <dynamic>[],
      'routines': <String, dynamic>{},
      'routineDay': <String, dynamic>{},
      'stats': <String, dynamic>{},
      'saving': <String, dynamic>{},
      'challengeDay': <String, dynamic>{},
      // Challenges come from the catalog (see _followCatalog).
      'challenges': <dynamic>[],
      'offered': <dynamic>[],
      'rewards': [
        for (final (e, n, d, c, m, price) in starterRewards)
          {
            'key': _id('r'),
            'e': e,
            'n': n,
            'd': d,
            'c': c,
            'm': m,
            'on': true,
            'price': price,
            'cost': {},
            'own': {},
          },
      ],
      'countdowns': [
        Countdown(id: _id('d'), emoji: '🎃', name: 'Halloween', date: DateTime(y, 10, 31)).toJson(),
        Countdown(id: _id('d'), emoji: '🎄', name: 'Christmas', date: DateTime(y, 12, 25)).toJson(),
        easterCountdown(_id('d')).toJson(),
      ],
    };
  }

  /// Reads the latest copy from the store.
  Future<void> _pull() async {
    final r = await store.fetch();
    _d = r.data ?? _fresh();
    _v = r.version;
  }

  Family get _family => Family.fromJson((_d!['family'] as Map?)?.cast());
  List<String> get _kids => [for (final c in _family.children) c.id];
  String _name(String kid) => _family.children
      .firstWhere(
        (c) => c.id == kid,
        orElse: () => const Child(id: '', name: '', theme: ''),
      )
      .name;

  /// A top-level map, made if this family's data is from an older version.
  Map<String, dynamic> _map(String k) => ((_d![k] ??= <String, dynamic>{}) as Map).cast<String, dynamic>();
  List<dynamic> _list(String k) => _d![k] as List;
  List<dynamic> _choreList(String kid) => _map('chores')[kid] as List;
  int _int(String k, String kid, int def) => (_map(k)[kid] as num?)?.toInt() ?? def;

  /// Adds new children, drops removed ones, resets chores on a new day and
  /// stops timers that have run out.
  bool _tidy() {
    var changed = false;
    // Families from before the challenge spinner get the catalog's.
    if (_d!['challenges'] == null) {
      _d!['challenges'] = <dynamic>[];
      _d!['offered'] = <dynamic>[];
      changed = true;
    }
    if (_followCatalog()) changed = true;
    for (final kid in _kids) {
      if (!_map('chores').containsKey(kid)) {
        _map('chores')[kid] = [for (final s in starterChores) TodoItem(_id('c'), s, false).toJson()];
        changed = true;
      }
      if (!_map('routines').containsKey(kid)) {
        _map('routines')[kid] = [
          for (final (e, n, p, steps) in starterRoutines)
            Routine(id: _id('t'), name: n, emoji: e, points: p, steps: steps).toJson(),
        ];
        changed = true;
      }
    }
    for (final k in [
      'points',
      'defaultPts',
      'goals',
      'chores',
      'timers',
      'log',
      'routines',
      'routineDay',
      'stats',
      'saving',
      'challengeDay',
    ]) {
      final m = _map(k);
      final gone = m.keys.where((id) => !_kids.contains(id)).toList();
      for (final id in gone) {
        m.remove(id);
        changed = true;
      }
    }
    final today = _day(now());
    if (_d!['day'] != today) {
      _newDay();
      _d!['day'] = today;
      for (final l in _map('chores').values) {
        // Bonus jobs that were done are finished with.
        (l as List).removeWhere((c) => (c as Map)['bonus'] == true && c['done'] == true);
        for (final c in l) {
          (c as Map)['done'] = false;
          c.remove('waiting');
        }
      }
      _map('routineDay').clear();
      // New spins each day; a challenge waiting for a grown-up stays.
      final days = _map('challengeDay');
      for (final kid in days.keys.toList()) {
        final c = (days[kid] as Map).cast<String, dynamic>();
        if (c['state'] == 'waiting' && c['cur'] != null) {
          days[kid] = {'spins': 0, 'cur': c['cur'], 'state': 'waiting', 'recent': c['recent']};
        } else {
          days[kid] = {'spins': 0, 'recent': c['recent']};
        }
      }
      changed = true;
    }
    for (final e in _map('timers').entries.toList()) {
      final t = TimerInfo.fromJson((e.value as Map).cast());
      if (t.running && !(t.finishesAt?.isAfter(now()) ?? false)) {
        _map('timers')[e.key] = TimerInfo('idle', null, null).toJson();
        changed = true;
      }
    }
    return changed;
  }

  /// Brings the family's challenges up to date with the catalog: adds the
  /// ones it hasn't been offered yet (so one a parent deleted never comes
  /// back), and updates or switches off copies no parent has changed.
  bool _followCatalog() {
    final byKey = {
      for (final h in catalog()?.values ?? const <HowTo>[])
        if (h.isChallenge) h.key: h,
    };
    if (byKey.isEmpty) return false;
    var changed = false;
    final list = _list('challenges');
    bool same(Map c, HowTo h) =>
        c['text'] == h.title &&
        c['cat'] == h.cat &&
        (c['pts'] as num?)?.toInt() == h.points &&
        (c['min'] as num?)?.toInt() == h.minutes;
    // Families from before the catalog was online: their starters are
    // linked by text, and everything in the catalog counts as offered.
    if (_d!['offered'] is! List) {
      for (final c in list.cast<Map>()) {
        if (c['src'] != null) continue;
        final h = byKey[howToKey('${c['text']}')];
        if (h == null) continue;
        c['src'] = h.key;
        if (!same(c, h) || c['off'] == true || c['how'] != null) c['edited'] = true;
      }
      _d!['offered'] = [
        for (final h in byKey.values)
          if (!h.removed) h.key,
      ];
      changed = true;
    }
    final offered = _d!['offered'] as List;
    final have = <String>{};
    for (final c in list.cast<Map>()) {
      final src = c['src'];
      if (src is! String) continue;
      have.add(src);
      final h = byKey[src];
      if (h == null || c['edited'] == true) continue;
      if (!same(c, h)) {
        c
          ..['text'] = h.title
          ..['cat'] = h.cat
          ..['pts'] = h.points
          ..['min'] = h.minutes;
        changed = true;
      }
      if ((c['off'] == true) != h.removed) {
        h.removed ? c['off'] = true : c.remove('off');
        changed = true;
      }
    }
    for (final h in byKey.values) {
      if (h.removed || offered.contains(h.key)) continue;
      offered.add(h.key);
      changed = true;
      if (have.add(h.key)) {
        list.add(
          Challenge(
            id: _id('h'),
            cat: h.cat,
            text: h.title,
            points: h.points,
            minutes: h.minutes,
            src: h.key,
          ).toJson(),
        );
      }
    }
    return changed;
  }

  static DateTime? _parseDay(Object? s) {
    final p = (s as String?)?.split('-').map(int.tryParse).toList();
    if (p == null || p.length != 3 || p.contains(null)) return null;
    return DateTime(p[0]!, p[1]!, p[2]!);
  }

  Map<String, dynamic> _stats(String kid) =>
      ((_map('stats')[kid] ??= <String, dynamic>{}) as Map).cast<String, dynamic>();

  void _bump(String kid, String key, int by) {
    final st = _stats(kid);
    st[key] = ((st[key] as num?)?.toInt() ?? 0) + by;
  }

  /// Chores due on [weekday] for [kid], and how many of them are done.
  (int due, int done) _dayCount(String kid, int weekday) {
    var due = 0, done = 0;
    for (final c in _choreList(kid)) {
      final t = TodoItem.fromJson((c as Map).cast());
      if (t.bonus || !t.dueOn(weekday)) continue;
      due++;
      if (t.done) done++;
    }
    return (due, done);
  }

  /// Before the morning reset: adds the last day (and any days the app
  /// wasn't opened) to each child's streak and perfect-week record.
  void _newDay() {
    final last = _parseDay(_d!['day']);
    final t = now();
    final today = DateTime(t.year, t.month, t.day);
    if (last == null || !last.isBefore(today)) return;
    for (final kid in _kids) {
      final st = _stats(kid);
      // The last day used counts what was ticked; days skipped count as missed.
      for (var d = last; d.isBefore(today); d = DateTime(d.year, d.month, d.day + 1)) {
        final (due, done) = _dayCount(kid, d.weekday);
        final ticked = d == last ? done : 0;
        final week = _day(mondayOf(d));
        if (st['week'] != week) {
          st['week'] = week;
          st['weekOk'] = true;
        }
        if (due == 0) {
          // A day off: the streak carries on.
        } else if (ticked >= due) {
          final streak = ((st['streak'] as num?)?.toInt() ?? 0) + 1;
          st['streak'] = streak;
          if (streak > ((st['best'] as num?)?.toInt() ?? 0)) st['best'] = streak;
        } else {
          st['streak'] = 0;
          st['weekOk'] = false;
        }
        if (d.weekday == DateTime.sunday && st['weekOk'] == true) _bump(kid, 'weeks', 1);
        // Days long ago don't matter beyond breaking the streak.
        if (today.difference(d).inDays > 14) d = DateTime(today.year, today.month, today.day - 14);
      }
    }
  }

  int _points(String kid) => _int('points', kid, 0);

  void _addPoints(String kid, int delta, String why, {String? kind, String? what}) {
    final p = (_points(kid) + delta).clamp(0, 1 << 30);
    _map('points')[kid] = p;
    final log = (_map('log')[kid] as List?) ?? [];
    final sign = delta >= 0 ? '+' : '−';
    log.insert(
      0,
      LogEntry(now(), '$why ($sign${delta.abs()}) · now $p', delta: delta, kind: kind, what: what).toJson(),
    );
    // Enough for the weekly summary.
    if (log.length > 400) log.removeRange(400, log.length);
    _map('log')[kid] = log;
  }

  Map<String, dynamic>? _reward(String key) {
    for (final r in _list('rewards')) {
      if ((r as Map)['key'] == key) return r.cast<String, dynamic>();
    }
    return null;
  }

  int _cost(Map<String, dynamic> r, String kid) =>
      ((r['cost'] as Map)[kid] as num?)?.toInt() ?? (r['price'] as num?)?.toInt() ?? 10;

  TimerInfo _timer(String kid) => _map('timers')[kid] == null
      ? TimerInfo('idle', null, null)
      : TimerInfo.fromJson((_map('timers')[kid] as Map).cast());

  @override
  Future<HubData> load() async {
    await _pull();
    if (_tidy()) {
      // Another device may have saved first; the next load tidies again.
      final v = await store.save(_d!, _v);
      if (v != null) _v = v;
    }
    final today = now();
    final rewards = [
      for (final r in _list('rewards').cast<Map>())
        Reward(
          key: r['key'] as String,
          emoji: r['e'] as String? ?? '',
          name: r['n'] as String? ?? '',
          desc: r['d'] as String? ?? '',
          category: r['c'] as String? ?? 'Reward',
          minutes: (r['m'] as num?)?.toInt() ?? 0,
          on: r['on'] == true,
          cost: {for (final kid in _kids) kid: _cost(r.cast(), kid)},
          own: {for (final kid in _kids) kid: ((r['own'] as Map)[kid] as num?)?.toInt() ?? 0},
        ),
    ];
    return HubData(
      _family,
      Snapshot(
        {for (final kid in _kids) kid: _points(kid)},
        rewards,
        {for (final kid in _kids) kid: _timer(kid)},
        [
          for (final c in _list('countdowns')) Countdown.fromJson((c as Map).cast()).withDays(today),
          // Each child's birthday, from Settings.
          for (final k in _family.children)
            if (k.birthday != null)
              Countdown(
                id: '$birthdayPrefix${k.id}',
                emoji: '🎂',
                name: "${k.name}'s birthday",
                date: k.birthday!,
              ).withDays(today),
        ],
        defaultChorePoints: {for (final kid in _kids) kid: _int('defaultPts', kid, 1)},
        approveChores: _d!['approve'] as bool? ?? true,
        goals: {for (final kid in _kids) kid: _int('goals', kid, defaultGoal)},
        saving: {
          for (final e in _map('saving').entries)
            if (e.value is String) e.key: e.value as String,
        },
        familyGoal: _d!['familyGoal'] == null ? null : FamilyGoal.fromJson((_d!['familyGoal'] as Map).cast()),
        money: Money.fromJson((_d!['money'] as Map?)?.cast()),
        challenge: ChallengeSettings.fromJson((_d!['challenge'] as Map?)?.cast()),
        challenges: [for (final c in _list('challenges')) Challenge.fromJson((c as Map).cast())],
      ),
      {
        for (final kid in _kids) kid: [for (final c in _choreList(kid)) TodoItem.fromJson((c as Map).cast())],
      },
      [for (final o in _list('orders')) TodoItem.fromJson((o as Map).cast())],
      {
        for (final kid in _kids)
          kid: [for (final e in (_map('log')[kid] as List?) ?? []) LogEntry.fromJson((e as Map).cast())],
      },
      {
        for (final kid in _kids)
          kid: [
            for (final r in (_map('routines')[kid] as List?) ?? const [])
              Routine.fromJson(
                (r as Map).cast(),
                state: ((_map('routineDay')[kid] as Map?)?[r['id']] as String?) ?? 'todo',
              ),
          ],
      },
      {
        for (final kid in _kids)
          kid: KidStats.fromJson(
            (_map('stats')[kid] as Map?)?.cast(),
            today: switch (_dayCount(kid, today.weekday)) {
              (final due, final done) => due > 0 && done >= due,
            },
          ),
      },
      today.weekday,
      {for (final kid in _kids) kid: ChallengeDay.fromJson((_map('challengeDay')[kid] as Map?)?.cast())},
    );
  }

  /// Applies [f] to the latest data and saves it, trying again if another
  /// device saved at the same moment.
  Future<void> _change(void Function() f) async {
    for (var i = 0; i < 4; i++) {
      await _pull();
      _tidy();
      f();
      final v = await store.save(_d!, _v);
      if (v != null) {
        _v = v;
        return;
      }
    }
    throw AppError('Another device was changing things at the same time. Try again.');
  }

  @override
  Future<void> create(List<Child> children, String pinHash) async {
    _d = _fresh()..['family'] = Family(children, pinHash).toJson();
    _tidy();
    if (!await store.create(_d!)) throw AppError('That family already exists.');
    _v = 1;
  }

  @override
  Future<void> saveFamily(List<Child> children, {String? pinHash}) => _change(() {
    _d!['family'] = Family(children, pinHash ?? _family.pinHash).toJson();
    _tidy();
  });

  Map _chore(String kid, TodoItem item) =>
      _choreList(kid)
          .cast<Map>()
          .firstWhere((c) => c['id'] == item.uid, orElse: () => throw AppError('That chore was removed.'));

  @override
  Future<void> setChore(String kid, TodoItem item, bool done) =>
      _change(() => _setDone(kid, _chore(kid, item), done));

  void _setDone(String kid, Map c, bool done) {
    c.remove('waiting');
    if (c['done'] == done) return;
    c['done'] = done;
    final cur = TodoItem.fromJson(c.cast());
    final pts = cur.points ?? _int('defaultPts', kid, 1);
    _addPoints(
      kid,
      done ? pts : -pts,
      done ? '${cur.bonus ? 'Bonus job' : 'Chore'} done: ${cur.title}' : 'Chore unticked: ${cur.title}',
      kind: done ? 'chore' : 'unchore',
      what: cur.title,
    );
    _bump(kid, 'chores', done ? 1 : -1);
  }

  @override
  Future<void> kidTick(String kid, TodoItem item) => _change(() {
    final c = _chore(kid, item);
    if (!(_d!['approve'] as bool? ?? true)) return _setDone(kid, c, c['done'] != true);
    if (c['done'] == true) throw AppError('A grown-up can untick this one.');
    // Tapping again takes it back before a grown-up has looked.
    c['waiting'] == true ? c.remove('waiting') : c['waiting'] = true;
  });

  @override
  Future<void> approveChore(String kid, TodoItem item, bool yes) => _change(() {
    final c = _chore(kid, item);
    yes ? _setDone(kid, c, true) : c.remove('waiting');
  });

  @override
  Future<void> setApproveChores(bool on) => _change(() {
    _d!['approve'] = on;
    // Turning approvals off: anything waiting counts as done.
    if (on) return;
    for (final e in _map('chores').entries) {
      for (final c in e.value as List) {
        if ((c as Map)['waiting'] == true) _setDone(e.key, c, true);
      }
    }
  });

  @override
  Future<void> addChore(String kid, String summary, {List<int> days = const [], bool bonus = false}) =>
      _change(
        () => _choreList(kid).add(TodoItem(_id('c'), summary, false, days: days, bonus: bonus).toJson()),
      );

  @override
  Future<void> renameChore(String kid, TodoItem item, String summary, {List<int>? days, bool? bonus}) =>
      _change(() {
        final c = _chore(kid, item);
        c['text'] = summary;
        if (days != null) days.isEmpty || days.length == 7 ? c.remove('days') : c['days'] = days;
        if (bonus != null) bonus ? c['bonus'] = true : c.remove('bonus');
      });

  @override
  Future<void> removeChore(String kid, TodoItem item) =>
      _change(() => _choreList(kid).removeWhere((c) => (c as Map)['id'] == item.uid));

  @override
  Future<void> buy(String kid, Reward r) => _change(() {
    final m = _reward(r.key);
    if (m == null) throw AppError('That reward is gone.');
    final cost = _cost(m, kid);
    if (_points(kid) < cost) throw AppError('Not enough points yet.');
    _addPoints(kid, -cost, 'Bought ${m['n']}', kind: 'buy', what: m['n'] as String?);
    if (_map('saving')[kid] == r.key) {
      _map('saving').remove(kid);
      _bump(kid, 'saved', 1);
    }
    final own = (m['own'] as Map);
    own[kid] = ((own[kid] as num?)?.toInt() ?? 0) + 1;
  });

  @override
  Future<void> useReward(String kid, Reward r) => _change(() {
    final m = _reward(r.key);
    if (m == null) return;
    final own = (m['own'] as Map);
    final have = (own[kid] as num?)?.toInt() ?? 0;
    if (have <= 0) return;
    own[kid] = have - 1;
    final minutes = (m['m'] as num?)?.toInt() ?? 0;
    if (minutes > 0) {
      final t = _timer(kid);
      final base = t.left() ?? Duration.zero;
      _map('timers')[kid] = TimerInfo('active', now().add(base + Duration(minutes: minutes)), null).toJson();
    } else {
      _list('orders').add(TodoItem(_id('o'), '${_name(kid)}: ${m['n']}', false).toJson());
    }
  });

  @override
  Future<void> adjustPoints(String kid, int amount) =>
      _change(() => _addPoints(kid, amount, 'Changed by a parent', kind: 'adjust'));

  @override
  Future<void> timer(String kid, String action, {Duration? by}) => _change(() {
    final t = _timer(kid);
    final left = t.left() ?? Duration.zero;
    final next = switch (action) {
      'pause' when t.running => TimerInfo('paused', null, left),
      'start' => TimerInfo('active', now().add(t.paused ? left : const Duration(minutes: 30)), null),
      'cancel' => TimerInfo('idle', null, null),
      'change' when t.running => TimerInfo('active', t.finishesAt!.add(by ?? Duration.zero), null),
      'change' when t.paused => TimerInfo('paused', null, left + (by ?? Duration.zero)),
      _ => t,
    };
    _map('timers')[kid] = next.toJson();
  });

  @override
  Future<void> setOwedDone(TodoItem item, bool done) => _change(() {
    for (final o in _list('orders').cast<Map>()) {
      if (o['id'] == item.uid) o['done'] = done;
    }
  });

  @override
  Future<void> addOrder(String text) =>
      _change(() => _list('orders').add(TodoItem(_id('o'), text, false).toJson()));

  @override
  Future<void> setDefaultPoints(String kid, int points) => _change(() => _map('defaultPts')[kid] = points);

  @override
  Future<void> setGoal(String kid, int goal) => _change(() => _map('goals')[kid] = goal);

  @override
  Future<void> setPrice(String kid, String key, int price) => _change(() {
    final m = _reward(key);
    if (m != null) (m['cost'] as Map)[kid] = price;
  });

  @override
  Future<void> saveReward(Reward r, {required bool on}) => _change(() {
    final m = _reward(r.key);
    final fields = {'e': r.emoji, 'n': r.name, 'd': r.desc, 'c': r.category, 'm': r.minutes, 'on': on};
    if (m != null) {
      m.addAll(fields);
    } else {
      _list('rewards').add({
        'key': r.key.isEmpty ? _id('r') : r.key,
        ...fields,
        'price': 10,
        'cost': {...r.cost},
        'own': {},
      });
    }
  });

  @override
  Future<void> deleteReward(String key) =>
      _change(() => _list('rewards').removeWhere((r) => (r as Map)['key'] == key));

  @override
  Future<void> saveCountdown(Countdown c) => _change(() {
    final l = _list('countdowns');
    final i = l.indexWhere((x) => (x as Map)['id'] == c.id);
    final j =
        (c.id.isEmpty
                ? Countdown(
                    id: _id('d'),
                    emoji: c.emoji,
                    name: c.name,
                    date: c.date,
                    yearly: c.yearly,
                    easter: c.easter,
                  )
                : c)
            .toJson();
    i >= 0 ? l[i] = j : l.add(j);
  });

  @override
  Future<void> deleteCountdown(String id) =>
      _change(() => _list('countdowns').removeWhere((x) => (x as Map)['id'] == id));

  List<dynamic> _routineList(String kid) => (_map('routines')[kid] ??= <dynamic>[]) as List;

  Map _routine(String kid, String id) =>
      _routineList(kid)
          .cast<Map>()
          .firstWhere((r) => r['id'] == id, orElse: () => throw AppError('That routine was removed.'));

  Map<String, dynamic> _routineDay(String kid) =>
      ((_map('routineDay')[kid] ??= <String, dynamic>{}) as Map).cast<String, dynamic>();

  void _routineDone(String kid, Map r) {
    _routineDay(kid)[r['id'] as String] = 'done';
    final pts = (r['pts'] as num?)?.toInt() ?? 0;
    if (pts > 0) {
      _addPoints(kid, pts, 'Routine done: ${r['name']}', kind: 'routine', what: r['name'] as String?);
    }
  }

  @override
  Future<void> finishRoutine(String kid, String id) => _change(() {
    final r = _routine(kid, id);
    final day = _routineDay(kid);
    if (day[id] != null) return;
    (_d!['approve'] as bool? ?? true) ? day[id] = 'waiting' : _routineDone(kid, r);
  });

  @override
  Future<void> approveRoutine(String kid, String id, bool yes) => _change(() {
    final r = _routine(kid, id);
    if (_routineDay(kid)[id] != 'waiting') return;
    yes ? _routineDone(kid, r) : _routineDay(kid).remove(id);
  });

  @override
  Future<void> saveRoutine(String kid, Routine r) => _change(() {
    final l = _routineList(kid);
    final i = l.indexWhere((x) => (x as Map)['id'] == r.id);
    final j =
        (r.id.isEmpty
                ? Routine(id: _id('t'), name: r.name, emoji: r.emoji, points: r.points, steps: r.steps)
                : r)
            .toJson();
    i >= 0 ? l[i] = j : l.add(j);
  });

  @override
  Future<void> deleteRoutine(String kid, String id) => _change(() {
    _routineList(kid).removeWhere((x) => (x as Map)['id'] == id);
    _routineDay(kid).remove(id);
  });

  @override
  Future<void> setSaving(String kid, String? key) =>
      _change(() => key == null ? _map('saving').remove(kid) : _map('saving')[kid] = key);

  @override
  Future<void> setFamilyGoal(FamilyGoal? goal) => _change(() {
    _d!['familyGoal'] = goal == null
        ? null
        : {'name': goal.name, 'emoji': goal.emoji, 'target': goal.target, 'saved': 0, 'given': {}};
  });

  @override
  Future<void> giveToFamily(String kid, int points) => _change(() {
    final g = (_d!['familyGoal'] as Map?)?.cast<String, dynamic>();
    if (g == null) throw AppError('There is no family goal right now.');
    final goal = FamilyGoal.fromJson(g);
    if (goal.reached) throw AppError('The family goal is already reached! 🎉');
    final n = [points, _points(kid), goal.left].reduce((a, b) => a < b ? a : b);
    if (n <= 0) throw AppError('Not enough points yet.');
    _addPoints(kid, -n, 'Family goal: ${goal.name}', kind: 'family', what: goal.name);
    g['saved'] = goal.saved + n;
    final given = ((g['given'] ??= <String, dynamic>{}) as Map);
    given[kid] = ((given[kid] as num?)?.toInt() ?? 0) + n;
    _bump(kid, 'gave', n);
  });

  @override
  Future<void> setMoney(Money money) => _change(() => _d!['money'] = money.toJson());

  @override
  Future<void> payOut(String kid, int points) => _change(() {
    if (points <= 0) return;
    if (_points(kid) < points) throw AppError('${_name(kid)} only has ${_points(kid)} points.');
    final money = Money.fromJson((_d!['money'] as Map?)?.cast());
    _addPoints(kid, -points, 'Paid out ${money.of(points)}', kind: 'payout', what: money.of(points));
  });

  ChallengeSettings get _challengeSettings => ChallengeSettings.fromJson((_d!['challenge'] as Map?)?.cast());

  Map<String, dynamic> _challengeDay(String kid) =>
      ((_map('challengeDay')[kid] ??= <String, dynamic>{}) as Map).cast<String, dynamic>();

  @override
  Future<void> spinChallenge(String kid, {String? cat}) => _change(() {
    final settings = _challengeSettings;
    if (!settings.on) throw AppError('The challenge spinner is switched off.');
    final day = _challengeDay(kid);
    final spins = (day['spins'] as num?)?.toInt() ?? 0;
    if (day['state'] == 'waiting' && day['cur'] != null) {
      throw AppError('A grown-up needs to check your challenge first.');
    }
    if (spins >= settings.spins) throw AppError('No spins left today. Come back tomorrow!');
    final all = [
      for (final c in _list('challenges'))
        if (Challenge.fromJson((c as Map).cast()) case final ch
            when ch.on && settings.catOn(ch.cat) && (cat == null || ch.cat == cat))
          ch,
    ];
    if (all.isEmpty) throw AppError('There are no challenges to spin yet. Ask a grown-up to add some.');
    // Not the same as one done lately, when there's a choice.
    final recent = [for (final r in (day['recent'] as List?) ?? const []) r as String];
    final current = (day['cur'] as Map?)?['id'];
    var pool = [
      for (final c in all)
        if (!recent.contains(c.id) && c.id != current) c,
    ];
    if (pool.isEmpty) pool = all.where((c) => c.id != current).toList();
    if (pool.isEmpty) pool = all;
    final pick = pool[random.nextInt(pool.length)];
    recent.add(pick.id);
    if (recent.length > 30) recent.removeRange(0, recent.length - 30);
    day
      ..['spins'] = spins + 1
      ..['cur'] = pick.toJson()
      ..['state'] = 'doing'
      ..['recent'] = recent;
  });

  void _challengeDone(String kid, Map<String, dynamic> day) {
    final c = Challenge.fromJson((day['cur'] as Map).cast());
    day['state'] = 'done';
    _bump(kid, 'challenges', 1);
    if (c.points > 0) _addPoints(kid, c.points, 'Challenge done: ${c.text}', kind: 'challenge', what: c.text);
  }

  @override
  Future<void> finishChallenge(String kid) => _change(() {
    final day = _challengeDay(kid);
    if (day['cur'] == null || day['state'] != 'doing') return;
    (_d!['approve'] as bool? ?? true) ? day['state'] = 'waiting' : _challengeDone(kid, day);
  });

  @override
  Future<void> approveChallenge(String kid, bool yes) => _change(() {
    final day = _challengeDay(kid);
    if (day['cur'] == null || day['state'] != 'waiting') return;
    yes ? _challengeDone(kid, day) : day['state'] = 'doing';
  });

  @override
  Future<void> saveChallenge(Challenge c) => _change(() {
    final l = _list('challenges');
    final i = l.indexWhere((x) => (x as Map)['id'] == c.id);
    var n = c.id.isEmpty ? c.withId(_id('h')) : c;
    // One from the catalog stays linked to it; once a parent changes it,
    // catalog updates leave it alone.
    if (i >= 0) {
      final was = Challenge.fromJson((l[i] as Map).cast());
      if (was.src != null) {
        final same =
            was.text == n.text &&
            was.cat == n.cat &&
            was.points == n.points &&
            was.minutes == n.minutes &&
            was.on == n.on &&
            jsonEncode(was.how?.toJson()) == jsonEncode(n.how?.toJson());
        n = n.copyWith(src: was.src, edited: was.edited || !same);
      }
    }
    i >= 0 ? l[i] = n.toJson() : l.add(n.toJson());
  });

  @override
  Future<void> deleteChallenge(String id) =>
      _change(() => _list('challenges').removeWhere((x) => (x as Map)['id'] == id));

  @override
  Future<void> setChallengeSettings(ChallengeSettings s) => _change(() => _d!['challenge'] = s.toJson());

  @override
  Future<void> followCatalog() async {
    for (var i = 0; i < 4; i++) {
      await _pull();
      // Tidying follows the catalog; nothing to save when nothing changed.
      if (!_tidy()) return;
      final v = await store.save(_d!, _v);
      if (v != null) {
        _v = v;
        return;
      }
    }
  }
}
