import 'dart:async';

import 'package:flutter/foundation.dart';

import 'backend.dart';
import 'catalog.dart';
import 'config.dart';
import 'models.dart';
import 'push.dart';
import 'sync.dart';

/// Holds the latest family data and runs actions against the backend.
/// Screens listen to it through AppScope.
class AppState extends ChangeNotifier {
  /// This device's settings. Changes with [setRole] and [setAlerts].
  AppConfig config;
  final Backend _backend;

  /// The grown-up's login, when the family is online.
  final SupabaseAuth? auth;

  /// Notifications to and from parents' phones, when the family is online
  /// and this copy of the app has Firebase built in.
  final Push? push;

  /// Called after signing out, so the app can go back to the welcome screen.
  final VoidCallback? onSignedOut;

  /// Called after signing in from the parent menu on a device-only family,
  /// so the app can switch to the online family.
  final Future<void> Function(Backend backend, AppConfig config, SupabaseAuth? auth)? onSignedIn;

  HubData? data;
  String? error;
  bool loading = false;
  Timer? _timer;

  /// Set to false to skip the reload timer (used by tests).
  final bool autoRefresh;

  AppState(
    this.config,
    this._backend, {
    this.auth,
    this.onSignedOut,
    this.onSignedIn,
    this.autoRefresh = true,
    Push? push,
  }) : push = push ?? (auth != null && firebaseApiKey.isNotEmpty ? Push(auth) : null) {
    refresh();
    // The challenge catalog: the family follows it once loaded, and again
    // whenever a newer one is downloaded.
    Catalog.load().then((_) => followCatalog(), onError: (_) {});
    Catalog.changed.addListener(followCatalog);
    this.push?.onMessage = refresh;
    this.push?.apply(config);
    // Online, reload often so other devices' changes show. On the device,
    // once a minute is enough for timers and the morning chore reset.
    if (autoRefresh) {
      _timer = Timer.periodic(
        config.mode == DataMode.cloud ? const Duration(seconds: 10) : const Duration(minutes: 1),
        (_) => refresh(),
      );
    }
  }

  Backend get backend => _backend;

  /// The code a second grown-up types to join, when online.
  String? get familyCode => _backend is HubBackend && _backend.store is SupabaseStore
      ? (_backend.store as SupabaseStore).code
      : null;

  bool checkPin(String pin) {
    final h = data?.family.pinHash;
    return h != null && h.isNotEmpty && h == hashPin(pin);
  }

  Future<String?> saveFamily(List<Child> kids, {String? pin}) =>
      _run(() => _backend.saveFamily(kids, pinHash: pin == null ? null : hashPin(pin)));

  /// Device-only families: deletes everything on this device and goes back
  /// to the welcome screen (for a forgotten PIN).
  Future<void> eraseDevice() async {
    _timer?.cancel();
    await PrefsStore().erase();
    await AppConfig.clear();
    onSignedOut?.call();
  }

  /// Online families: checks the account password, then sets a new PIN.
  Future<String?> resetPin(String password, String pin) async {
    final a = auth;
    if (a == null || a.email == null) return 'Sign in first.';
    try {
      await a.signIn(a.email!, password);
    } on AppError catch (e) {
      return e.message;
    }
    return saveFamily(data?.family.children ?? children, pin: pin);
  }

  /// Says whether this device is a parent's phone or a kids' tablet.
  Future<void> setRole(DeviceRole role) => _setConfig(config.copyWith(role: role));

  /// Chooses which notifications this parent's phone gets.
  Future<void> setAlerts(Set<Alert> alerts) => _setConfig(config.copyWith(alerts: alerts));

  Future<void> _setConfig(AppConfig c) async {
    config = c;
    notifyListeners();
    await c.save();
    await push?.apply(c);
  }

  /// Things a grown-up still has to do: chores and routines to approve, and
  /// rewards to hand over.
  int get waitingCount {
    final d = data;
    if (d == null) return 0;
    var n = d.owed.where((o) => !o.done).length;
    for (final c in d.family.children) {
      n += d.choresFor(c.id).where((t) => t.waiting).length;
      n += d.routinesFor(c.id).where((r) => r.waiting).length;
    }
    return n;
  }

  Future<void> signOut() async {
    _timer?.cancel();
    await push?.forget();
    await auth?.signOut();
    await AppConfig.clear();
    onSignedOut?.call();
  }

  Future<void>? _inFlight;
  bool _again = false;

  /// Reloads everything. A call made while a load is running waits for it and
  /// then loads once more, so changes just made always show.
  Future<void> refresh() {
    if (_inFlight != null) {
      _again = true;
      return _inFlight!;
    }
    return _inFlight = _load().whenComplete(() => _inFlight = null);
  }

  Future<void> _load() async {
    loading = true;
    notifyListeners();
    do {
      _again = false;
      final backend = _backend;
      try {
        final d = await backend.load();
        data = d;
        children = d.family.children;
        error = null;
      } catch (e) {
        error = e.toString();
      }
    } while (_again);
    loading = false;
    notifyListeners();
  }

  /// Runs [action] then reloads. Returns an error message, or null.
  Future<String?> _run(Future<void> Function() action) async {
    try {
      await action();
    } catch (e) {
      return e.toString();
    }
    await refresh();
    return null;
  }

  Future<String?> setChore(String kid, TodoItem item, bool done) =>
      _run(() => _backend.setChore(kid, item, done));
  Future<String?> addChore(String kid, String summary, {List<int> days = const [], bool bonus = false}) =>
      _run(() => _backend.addChore(kid, summary, days: days, bonus: bonus));
  Future<String?> renameChore(String kid, TodoItem item, String summary, {List<int>? days, bool? bonus}) =>
      _run(() => _backend.renameChore(kid, item, summary, days: days, bonus: bonus));
  Future<String?> removeChore(String kid, TodoItem item) => _run(() => _backend.removeChore(kid, item));
  Future<String?> buy(String kid, Reward r) async {
    final err = await _run(() => _backend.buy(kid, r));
    if (err == null) push?.send(Alert.shop, '${nameOf(kid)} bought ${r.name} from the shop.');
    return err;
  }

  Future<String?> useReward(String kid, Reward r) async {
    final err = await _run(() => _backend.useReward(kid, r));
    // Screen time starts by itself; anything else a grown-up hands over.
    if (err == null && r.minutes == 0) {
      push?.send(Alert.shop, '${nameOf(kid)} would like their ${r.name} now.');
    }
    return err;
  }

  Future<String?> adjustPoints(String kid, int amount) => _run(() => _backend.adjustPoints(kid, amount));
  Future<String?> timer(String kid, String action, {Duration? by}) =>
      _run(() => _backend.timer(kid, action, by: by));
  Future<String?> setOwedDone(TodoItem item, bool done) => _run(() => _backend.setOwedDone(item, done));
  Future<String?> addOrder(String text) => _run(() => _backend.addOrder(text));
  Future<String?> setDefaultPoints(String kid, int points) =>
      _run(() => _backend.setDefaultPoints(kid, points));
  Future<String?> setPrice(String kid, String key, int price) =>
      _run(() => _backend.setPrice(kid, key, price));
  Future<String?> kidTick(String kid, TodoItem item) async {
    final err = await _run(() => _backend.kidTick(kid, item));
    final now = data?.choresFor(kid).where((c) => c.uid == item.uid).firstOrNull;
    if (err == null && now != null && now.waiting) {
      push?.send(Alert.approve, '${nameOf(kid)} did "${now.title}". Tap to approve it.');
    }
    return err;
  }

  Future<String?> approveChore(String kid, TodoItem item, bool yes) =>
      _run(() => _backend.approveChore(kid, item, yes));
  Future<String?> setApproveChores(bool on) => _run(() => _backend.setApproveChores(on));
  Future<String?> setGoal(String kid, int goal) => _run(() => _backend.setGoal(kid, goal));
  Future<String?> saveReward(Reward r, {required bool on}) => _run(() => _backend.saveReward(r, on: on));
  Future<String?> deleteReward(String key) => _run(() => _backend.deleteReward(key));
  Future<String?> saveCountdown(Countdown c) => _run(() => _backend.saveCountdown(c));
  Future<String?> deleteCountdown(String id) => _run(() => _backend.deleteCountdown(id));
  Future<String?> finishRoutine(String kid, String id) async {
    final err = await _run(() => _backend.finishRoutine(kid, id));
    final now = data?.routinesFor(kid).where((r) => r.id == id).firstOrNull;
    if (err == null && now != null && now.waiting) {
      push?.send(Alert.approve, '${nameOf(kid)} finished ${now.name}. Tap to approve it.');
    }
    return err;
  }

  Future<String?> approveRoutine(String kid, String id, bool yes) =>
      _run(() => _backend.approveRoutine(kid, id, yes));
  Future<String?> saveRoutine(String kid, Routine r) => _run(() => _backend.saveRoutine(kid, r));
  Future<String?> deleteRoutine(String kid, String id) => _run(() => _backend.deleteRoutine(kid, id));
  Future<String?> setSaving(String kid, String? key) => _run(() => _backend.setSaving(kid, key));
  Future<String?> setFamilyGoal(FamilyGoal? goal) => _run(() => _backend.setFamilyGoal(goal));
  Future<String?> giveToFamily(String kid, int points) => _run(() => _backend.giveToFamily(kid, points));
  Future<String?> setMoney(Money money) => _run(() => _backend.setMoney(money));
  Future<String?> payOut(String kid, int points) => _run(() => _backend.payOut(kid, points));
  Future<String?> spinChallenge(String kid, {String? cat}) =>
      _run(() => _backend.spinChallenge(kid, cat: cat));
  Future<String?> finishChallenge(String kid) => _run(() => _backend.finishChallenge(kid));
  Future<String?> approveChallenge(String kid, bool yes) => _run(() => _backend.approveChallenge(kid, yes));
  Future<String?> saveChallenge(Challenge c) => _run(() => _backend.saveChallenge(c));
  Future<String?> deleteChallenge(String id) => _run(() => _backend.deleteChallenge(id));
  Future<String?> setChallengeSettings(ChallengeSettings s) => _run(() => _backend.setChallengeSettings(s));

  /// Adds new catalog challenges to the family and updates unchanged ones.
  Future<String?> followCatalog() => _run(_backend.followCatalog);

  @override
  void dispose() {
    _timer?.cancel();
    Catalog.changed.removeListener(followCatalog);
    push?.dispose();
    super.dispose();
  }
}
