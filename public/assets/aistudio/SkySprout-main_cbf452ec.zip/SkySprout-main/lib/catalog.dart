import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import 'models.dart';
import 'sync.dart';

/// One step of a challenge's how-to: what to do, and its picture's name.
class HowStep {
  final String text;

  /// Picture file name, like "build_a_dinosaur_2.webp".
  final String image;
  const HowStep(this.text, this.image);
}

/// One challenge in the catalog: what a family's copy starts as (kind,
/// points, minutes) and its how-to (age, what you need and the steps).
class HowTo {
  final String title;
  final int age;
  final List<String> need;
  final List<HowStep> steps;

  /// Links families' copies and names the step pictures: the "id:" line, or
  /// [howToKey] of the title.
  final String key;

  /// Category id, like "lego"; empty when the catalog doesn't say.
  final String cat;
  final int points, minutes;

  /// "removed: yes": new families don't get it, and copies nobody changed
  /// are switched off.
  final bool removed;
  const HowTo(
    this.title,
    this.age,
    this.need,
    this.steps, {
    this.key = '',
    this.cat = '',
    this.points = 3,
    this.minutes = 0,
    this.removed = false,
  });

  /// It can go on a family's list: it has a text and a known category.
  bool get isChallenge => title.isNotEmpty && challengeCats.any((c) => c.id == cat);
}

/// "Build a dinosaur!" -> "build_a_dinosaur". Pictures and how-tos are
/// matched to challenges by this (or by a catalog "id:").
String howToKey(String text) {
  final s = text.toLowerCase().replaceAll(RegExp('[^a-z0-9]+'), '_').replaceAll(RegExp(r'^_+|_+$'), '');
  return s.length > 48 ? s.substring(0, 48) : s;
}

/// Reads `assets/catalog/challenges.txt` (its format is described at the top
/// of that file), keyed by each challenge's key, in the file's order.
Map<String, HowTo> parseCatalog(String src) {
  final out = <String, HowTo>{};
  String? title;
  String? id;
  var age = 0, points = 3, minutes = 0;
  var cat = '';
  var removed = false;
  var need = <String>[];
  var steps = <(int, String)>[];
  void flush() {
    final t = title;
    if (t == null) return;
    final key = id ?? howToKey(t);
    out[key] = HowTo(
      t,
      age,
      need,
      [for (final (n, text) in steps) HowStep(text, '${key}_$n.webp')],
      key: key,
      cat: cat,
      points: points,
      minutes: minutes,
      removed: removed,
    );
  }

  final stepLine = RegExp(r'^(\d+)\.\s*(.*)$');
  final field = RegExp(r'^(id|kind|points|minutes|removed|age|need):\s*(.*)$');
  for (final raw in src.split('\n')) {
    final line = raw.trim();
    if (line.startsWith('## ')) {
      flush();
      title = line.substring(3).trim();
      id = null;
      age = 0;
      points = 3;
      minutes = 0;
      cat = '';
      removed = false;
      need = [];
      steps = [];
    } else if (title == null || line.isEmpty || line.startsWith('#')) {
      continue;
    } else if (field.firstMatch(line) case final m?) {
      final v = m.group(2)!.trim();
      switch (m.group(1)) {
        case 'id':
          if (howToKey(v).isNotEmpty) id = howToKey(v);
        case 'kind':
          cat = v;
        case 'points':
          points = int.tryParse(v) ?? points;
        case 'minutes':
          minutes = int.tryParse(v) ?? minutes;
        case 'removed':
          removed = const ['yes', 'true'].contains(v.toLowerCase());
        case 'age':
          age = int.tryParse(v) ?? 0;
        case 'need':
          need = [
            for (final n in v.split(','))
              if (n.trim().isNotEmpty) n.trim(),
          ];
      }
    } else if (stepLine.firstMatch(line) case final m?) {
      steps.add((int.parse(m.group(1)!), m.group(2)!.split('||').first.trim()));
    }
  }
  flush();
  return out;
}

/// The challenge catalog: the copy on the device (the last one downloaded,
/// else the one built into the app), then the online one when it can be had.
class Catalog {
  static Map<String, HowTo>? _all;
  static Future<void>? _loading;
  static bool _fetched = false;

  /// Goes up each time a downloaded catalog replaces the one in use, so the
  /// app can bring families up to date and redraw.
  static final changed = ValueNotifier<int>(0);

  /// Tests can set this instead of loading the asset (it is not then
  /// downloaded either).
  @visibleForTesting
  static set all(Map<String, HowTo> v) {
    _all = v;
    _fetched = true;
  }

  /// Where the online catalog is: catalog.txt in the public "challenges" bucket.
  static String get onlineUrl => pictureUrl('catalog.txt');

  /// The catalog, or null while it hasn't loaded yet.
  static Map<String, HowTo>? get loaded => _all;

  /// Loads the catalog once: the copy kept on the device if there is one,
  /// else the app's own. Then, online, checks for a newer one in the
  /// background (see [fetch]).
  static Future<Map<String, HowTo>> load() async {
    await (_loading ??= _load().catchError((Object e) {
      _loading = null;
      throw e;
    }));
    return _all!;
  }

  static Future<void> _load() async {
    if (_all == null) {
      Map<String, HowTo>? got;
      try {
        if (await _cacheFile() case final f? when f.existsSync()) got = parseCatalog(await f.readAsString());
      } catch (_) {}
      if (got == null || !got.values.any((h) => h.isChallenge)) {
        got = parseCatalog(await rootBundle.loadString('assets/catalog/challenges.txt'));
      }
      _all ??= got;
    }
    if (!_fetched && supabaseUrl.isNotEmpty) {
      _fetched = true;
      unawaited(fetch());
    }
  }

  /// Downloads the online catalog. A good one (at least one challenge)
  /// replaces the one in use, is kept on the device for next time, and
  /// bumps [changed]. Offline, missing or broken: nothing changes. Says
  /// whether it changed anything.
  static Future<bool> fetch({http.Client? client, String? url}) async {
    if (supabaseUrl.isEmpty && url == null) return false;
    final String src;
    try {
      final get = client?.get ?? http.get;
      final r = await get(Uri.parse(url ?? onlineUrl)).timeout(const Duration(seconds: 15));
      if (r.statusCode != 200) return false;
      src = utf8.decode(r.bodyBytes, allowMalformed: true);
    } catch (_) {
      return false;
    }
    final got = parseCatalog(src);
    if (!got.values.any((h) => h.isChallenge)) return false;
    try {
      if (await _cacheFile() case final f?) {
        await f.parent.create(recursive: true);
        await f.writeAsString(src);
      }
    } catch (_) {}
    _all = got;
    changed.value++;
    return true;
  }

  static Future<File?> _cacheFile() async {
    if (kIsWeb) return null;
    try {
      return File('${(await getApplicationSupportDirectory()).path}/challenge_catalog.txt');
    } catch (_) {
      return null;
    }
  }

  /// The how-to for a challenge's text, once loaded; null for challenges a
  /// parent wrote.
  static HowTo? of(String text) => _all?[howToKey(text)];

  /// The catalog challenge a family's copy came from ([src]), else the one
  /// with this text.
  static HowTo? entry({String? src, required String text}) => _all?[src] ?? of(text);

  /// A challenge's how-to: the steps a parent wrote, or the catalog's.
  static HowTo? forChallenge(Challenge c) {
    final how = c.how;
    final starter = entry(src: c.src, text: c.text);
    if (how == null || how.steps.isEmpty) return starter;
    final key = starter?.key ?? howToKey(c.text);
    return HowTo(c.text, how.age, how.need, [
      for (final (i, s) in how.steps.indexed) HowStep(s, '${key}_${i + 1}.webp'),
    ], key: key);
  }
}

/// Where step pictures are downloaded from: a public Supabase Storage bucket
/// called "challenges" (see docs/challenge_pictures.md).
String pictureUrl(String image) => '$supabaseUrl/storage/v1/object/public/challenges/$image';

/// A step picture: from the app's assets when bundled, otherwise downloaded
/// once and kept on the device. Null when there isn't one (yet).
class Pictures {
  static Set<String>? _bundled;
  static final _mem = <String, Uint8List>{};

  static Future<Uint8List?> get(String image) async {
    if (_mem[image] case final m?) return m;
    // Not kept when missing, so it is tried again once online.
    final got = await _find(image);
    if (got != null) _mem[image] = got;
    return got;
  }

  static Future<Uint8List?> _find(String image) async {
    final asset = 'assets/catalog/img/$image';
    try {
      _bundled ??= (await AssetManifest.loadFromAssetBundle(rootBundle)).listAssets().toSet();
      if (_bundled!.contains(asset)) return (await rootBundle.load(asset)).buffer.asUint8List();
    } catch (_) {}
    if (supabaseUrl.isEmpty) return null;
    File? file;
    if (!kIsWeb) {
      try {
        file = File('${(await getApplicationSupportDirectory()).path}/challenge_pictures/$image');
        if (file.existsSync()) return await file.readAsBytes();
      } catch (_) {
        file = null;
      }
    }
    try {
      final r = await http.get(Uri.parse(pictureUrl(image))).timeout(const Duration(seconds: 15));
      if (r.statusCode != 200 || r.bodyBytes.isEmpty) return null;
      if (file != null) {
        await file.parent.create(recursive: true);
        await file.writeAsBytes(r.bodyBytes);
      }
      return r.bodyBytes;
    } catch (_) {
      return null;
    }
  }
}
