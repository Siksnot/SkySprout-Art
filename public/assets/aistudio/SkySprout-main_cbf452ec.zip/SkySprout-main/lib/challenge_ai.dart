import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'models.dart';
import 'sync.dart';

/// A challenge as the editor holds it, and as "Ask Claude" sends and returns it.
class ChallengeDraft {
  final String text, cat;
  final int points, minutes, age;
  final List<String> need, steps;
  const ChallengeDraft({
    required this.text,
    required this.cat,
    this.points = 3,
    this.minutes = 0,
    this.age = 5,
    this.need = const [],
    this.steps = const [],
  });

  Map<String, dynamic> toJson() => {
    'title': text,
    'cat': cat,
    'pts': points,
    'min': minutes,
    'age': age,
    'need': need,
    'steps': steps,
  };

  /// Reads an answer, keeping [before]'s values for anything missing or odd.
  static ChallengeDraft? fromAnswer(Object? j, ChallengeDraft before) {
    if (j is! Map) return null;
    int n(Object? v, int lo, int hi, int d) => v is num ? v.toInt().clamp(lo, hi) : d;
    List<String> strings(Object? v, int max) => v is List
        ? [
            for (final x in v.take(max))
              if ('${x is Map ? x['text'] : x}'.trim() case final s when s.isNotEmpty) s,
          ]
        : const [];
    final text = '${j['title'] ?? ''}'.trim().replaceAll(RegExp(r'[.!]+$'), '');
    final steps = strings(j['steps'], 6);
    if (text.isEmpty || steps.length < 2) return null;
    final cat = '${j['cat']}';
    return ChallengeDraft(
      text: text,
      cat: challengeCats.any((c) => c.id == cat) ? cat : before.cat,
      points: n(j['pts'], 1, 20, before.points),
      minutes: n(j['min'], 0, 120, before.minutes),
      age: n(j['age'], 2, 14, before.age),
      need: j['need'] is List ? strings(j['need'], 10) : before.need,
      steps: steps,
    );
  }
}

/// "Ask Claude" in the challenge editor. It goes through the family's
/// Kids Hub online account to the `challenge-ai` function in Supabase
/// (supabase/functions/challenge-ai), which holds the Claude API key, so
/// the key never ships in the app.
class ChallengeAi {
  final SupabaseAuth auth;
  final http.Client _http;
  ChallengeAi(this.auth, {http.Client? client}) : _http = client ?? http.Client();

  /// Only signed-in families can ask, so strangers can't run up the bill.
  static bool canUse(SupabaseAuth? auth) => auth != null && auth.signedIn;

  /// Asks Claude to change [now] as the parent [request]s, or to write a
  /// new challenge when [now] has no text yet.
  Future<ChallengeDraft> ask(ChallengeDraft now, String request) async {
    final token = await auth.token();
    http.Response r;
    try {
      r = await _http
          .post(
            Uri.parse('${auth.url}/functions/v1/challenge-ai'),
            headers: {
              'apikey': auth.anonKey,
              'Authorization': 'Bearer $token',
              'Content-Type': 'application/json',
            },
            body: jsonEncode({'challenge': now.toJson(), 'request': request}),
          )
          .timeout(const Duration(seconds: 60));
    } on TimeoutException {
      throw AppError('Claude took too long. Try again.');
    } catch (_) {
      throw AppError('Can\'t reach Claude. Check the internet connection.');
    }
    if (r.statusCode == 404) throw AppError('Ask Claude isn\'t switched on for Kids Hub online yet.');
    if (r.statusCode == 429) throw AppError('That\'s a lot of asking today. Try again tomorrow.');
    if (r.statusCode >= 300) throw AppError('Claude couldn\'t help just now (${r.statusCode}). Try again.');
    Object? body;
    try {
      body = jsonDecode(utf8.decode(r.bodyBytes));
    } catch (_) {}
    final out = ChallengeDraft.fromAnswer(body is Map ? body['challenge'] : null, now);
    if (out == null) throw AppError('Claude\'s answer didn\'t fit. Try asking a different way.');
    return out;
  }
}
