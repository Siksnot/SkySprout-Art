import 'dart:async';
import 'dart:convert';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'config.dart';
import 'models.dart';
import 'sync.dart';

/// The Firebase project that sends notifications to parents' phones.
/// Copy these from the Firebase console (Project settings > General > Your
/// apps > the Android app), or pass them with `--dart-define`. While the API
/// key is empty the app has no notifications; everything else still works.
const firebaseApiKey = String.fromEnvironment('FIREBASE_API_KEY', defaultValue: '');
const firebaseAppId = String.fromEnvironment('FIREBASE_APP_ID', defaultValue: '');
const firebaseSenderId = String.fromEnvironment('FIREBASE_SENDER_ID', defaultValue: '');
const firebaseProjectId = String.fromEnvironment('FIREBASE_PROJECT_ID', defaultValue: '');

/// Notifications are built in, and this is an Android phone (Kids Hub's
/// iPhone version will need Apple's push set up first).
bool get pushAvailable =>
    firebaseApiKey.isNotEmpty && !kIsWeb && defaultTargetPlatform == TargetPlatform.android;

/// Sends and receives the family's notifications.
///
/// Every device that is signed in can send one (a child ticks a chore on the
/// kids' tablet). Only a parent's phone registers to receive them, so the
/// Fire tablets, which have no Google services, never need Firebase to work.
class Push {
  final SupabaseAuth auth;
  final http.Client _http;
  Push(this.auth, {http.Client? client}) : _http = client ?? http.Client();

  static const _tokenKey = 'kids_hub_push_token_v1';
  static Future<void>? _started;

  /// This phone's push token, once registered.
  String? _token;

  /// Called when the parent taps a notification.
  void Function()? onOpen;

  /// Called when a notification arrives while the app is open.
  void Function()? onMessage;

  final _subs = <StreamSubscription>[];

  static Future<void> _start() => _started ??= Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: firebaseApiKey,
      appId: firebaseAppId,
      messagingSenderId: firebaseSenderId,
      projectId: firebaseProjectId,
    ),
  );

  /// Matches this device's role and choices: a parent's phone asks for
  /// permission and registers; anything else stops getting notifications.
  Future<void> apply(AppConfig c) async {
    if (!pushAvailable) return;
    try {
      if (c.role == DeviceRole.parent && c.alerts.isNotEmpty) {
        await _register(c.alerts);
      } else {
        await forget();
      }
    } catch (e) {
      debugPrint('Notifications: $e');
    }
  }

  Future<void> _register(Set<Alert> alerts) async {
    await _start();
    final fm = FirebaseMessaging.instance;
    final allowed = await fm.requestPermission();
    if (allowed.authorizationStatus == AuthorizationStatus.denied) return;
    // The push token, which the server's FCM send takes as its target. The
    // newer register() hands out an installation ID for a different send API.
    // ignore: deprecated_member_use
    final token = await fm.getToken();
    if (token == null) return;
    await _rpc('device_register', {
      'p_token': token,
      'p_kinds': [for (final a in alerts) a.name],
    });
    _token = token;
    await (await SharedPreferences.getInstance()).setString(_tokenKey, token);
    if (_subs.isEmpty) {
      // ignore: deprecated_member_use
      _subs.add(fm.onTokenRefresh.listen((_) => _register(alerts)));
      _subs.add(FirebaseMessaging.onMessage.listen((_) => onMessage?.call()));
      _subs.add(FirebaseMessaging.onMessageOpenedApp.listen((_) => onOpen?.call()));
      // Opened from a notification while the app was closed.
      if (await fm.getInitialMessage() != null) onOpen?.call();
    }
  }

  /// Stops notifications to this device, if it had them. Call before signing out.
  Future<void> forget() async {
    final prefs = await SharedPreferences.getInstance();
    final token = _token ?? prefs.getString(_tokenKey);
    if (token == null) return;
    for (final s in _subs) {
      await s.cancel();
    }
    _subs.clear();
    try {
      await _rpc('device_forget', {'p_token': token});
    } catch (_) {}
    _token = null;
    await prefs.remove(_tokenKey);
  }

  /// Tells the family's parent phones. Never throws: a notification that
  /// can't be sent mustn't stop a child ticking a chore.
  Future<void> send(Alert kind, String body) async {
    try {
      final from = _token ?? (await SharedPreferences.getInstance()).getString(_tokenKey);
      await _http
          .post(
            Uri.parse('${auth.url}/functions/v1/notify'),
            headers: {
              'apikey': auth.anonKey,
              'Authorization': 'Bearer ${await auth.token()}',
              'Content-Type': 'application/json',
            },
            body: jsonEncode({
              'kind': kind.name,
              'title': 'Kids Hub',
              'body': body,
              'from': ?from,
            }),
          )
          .timeout(const Duration(seconds: 15));
    } catch (e) {
      debugPrint('Notifications: $e');
    }
  }

  Future<void> _rpc(String fn, Map<String, dynamic> args) async {
    final r = await _http
        .post(
          Uri.parse('${auth.url}/rest/v1/rpc/$fn'),
          headers: {
            'apikey': auth.anonKey,
            'Authorization': 'Bearer ${await auth.token()}',
            'Content-Type': 'application/json',
          },
          body: jsonEncode(args),
        )
        .timeout(const Duration(seconds: 15));
    if (r.statusCode >= 300) throw AppError('Notifications: $fn said ${r.statusCode}');
  }

  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
  }
}
