import 'dart:math';

String cap(String s) => s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);

/// A short random id for children, rewards and countdowns.
String newId(String prefix) =>
    '$prefix${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}${Random().nextInt(1296).toRadixString(36)}';

/// One child, as set up by a parent.
class Child {
  final String id, name;

  /// Age as typed in, for when there is no [birthday].
  final int? age;

  /// Shown as a countdown on the boards, and keeps the age up to date.
  final DateTime? birthday;

  /// Dashboard theme: an id from `KidTheme.all`.
  final String theme;

  const Child({required this.id, required this.name, this.age, this.birthday, required this.theme});

  /// Age today: from the birthday when there is one.
  int? ageOn(DateTime today) {
    final b = birthday;
    if (b == null) return age;
    final had = today.month > b.month || (today.month == b.month && today.day >= b.day);
    return today.year - b.year - (had ? 0 : 1);
  }

  int? get ageNow => ageOn(DateTime.now());

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'age': age,
    if (birthday != null) 'birthday': '${birthday!.year}-${birthday!.month}-${birthday!.day}',
    'theme': theme,
  };

  static DateTime? _date(Object? s) {
    final p = (s as String?)?.split('-');
    if (p == null || p.length != 3) return null;
    final n = p.map(int.tryParse).toList();
    return n.contains(null) ? null : DateTime(n[0]!, n[1]!, n[2]!);
  }

  factory Child.fromJson(Map<String, dynamic> j) => Child(
    id: j['id'] as String,
    name: j['name'] as String? ?? '',
    age: (j['age'] as num?)?.toInt(),
    birthday: _date(j['birthday']),
    theme: j['theme'] as String? ?? 'quest',
  );
}

/// The children this app is set up for. Set from the saved config.
List<Child> children = const [];

/// Child ids, in the order the parent set them up.
List<String> get kids => [for (final c in children) c.id];

Child? childOf(String id) {
  for (final c in children) {
    if (c.id == id) return c;
  }
  return null;
}

/// The child's display name.
String nameOf(String id) => childOf(id)?.name ?? '';

/// An error with a message a parent or child can read.
class AppError implements Exception {
  final String message;
  AppError(this.message);
  @override
  String toString() => message;
}

const rewardCategories = ['Screen time', 'Treats', 'Special', 'Reward'];

class Reward {
  final String key, emoji, name, desc, category;

  /// Minutes of screen time it gives when used; 0 for rewards a parent hands over.
  final int minutes;

  /// Shown in the shop.
  final bool on;

  /// Price and number owned, per child.
  final Map<String, int> cost, own;

  Reward({
    required this.key,
    required this.emoji,
    required this.name,
    required this.desc,
    this.category = 'Reward',
    required this.minutes,
    required this.on,
    required this.cost,
    required this.own,
  });
}

class TimerInfo {
  final String state; // idle | active | paused
  final DateTime? finishesAt;
  final Duration? remaining;
  TimerInfo(this.state, this.finishesAt, this.remaining);

  bool get running => state == 'active';
  bool get paused => state == 'paused';
  Duration? left() {
    if (running && finishesAt != null) {
      final d = finishesAt!.difference(DateTime.now());
      return d.isNegative ? Duration.zero : d;
    }
    if (paused) return remaining;
    return null;
  }

  Map<String, dynamic> toJson() => {
    'state': state,
    'finishesAt': finishesAt?.toIso8601String(),
    'remaining': remaining?.inSeconds,
  };

  factory TimerInfo.fromJson(Map<String, dynamic> j) => TimerInfo(
    j['state'] as String? ?? 'idle',
    DateTime.tryParse(j['finishesAt'] as String? ?? ''),
    j['remaining'] == null ? null : Duration(seconds: (j['remaining'] as num).toInt()),
  );
}

/// A date the kids are counting down to. [days] is worked out from [date]
/// each time the data loads.
class Countdown {
  final String id, emoji, name;
  final DateTime date;

  /// Comes round every year, like a birthday.
  final bool yearly;

  /// Easter Sunday, which moves each year: [date] is worked out too.
  final bool easter;
  final int days;

  Countdown({
    required this.id,
    required this.emoji,
    required this.name,
    required this.date,
    this.yearly = true,
    this.easter = false,
    this.days = 0,
  });

  /// The date it next falls on, from [today].
  DateTime nextFrom(DateTime today) {
    final t = DateTime(today.year, today.month, today.day);
    if (easter) {
      final e = easterSunday(t.year);
      return e.isBefore(t) ? easterSunday(t.year + 1) : e;
    }
    var d = DateTime(date.year, date.month, date.day);
    if (yearly) {
      d = DateTime(t.year, date.month, date.day);
      if (d.isBefore(t)) d = DateTime(t.year + 1, date.month, date.day);
    }
    return d;
  }

  /// Days from [today] to the next occurrence; negative once a one-off date has passed.
  int daysFrom(DateTime today) =>
      nextFrom(today).difference(DateTime(today.year, today.month, today.day)).inDays;

  Countdown withDays(DateTime today) => Countdown(
    id: id,
    emoji: emoji,
    name: name,
    date: easter ? nextFrom(today) : date,
    yearly: yearly,
    easter: easter,
    days: daysFrom(today),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'emoji': emoji,
    'name': name,
    'date': date.toIso8601String(),
    'yearly': yearly,
    if (easter) 'easter': true,
  };

  factory Countdown.fromJson(Map<String, dynamic> j) => Countdown(
    id: j['id'] as String,
    emoji: j['emoji'] as String? ?? '📅',
    name: j['name'] as String? ?? '',
    date: DateTime.tryParse(j['date'] as String? ?? '') ?? DateTime.now(),
    yearly: j['yearly'] as bool? ?? true,
    easter: j['easter'] as bool? ?? false,
  );
}

/// Easter Sunday in [year] (Western churches), by the Meeus/Jones/Butcher method.
DateTime easterSunday(int year) {
  final a = year % 19, b = year ~/ 100, c = year % 100;
  final d = b ~/ 4, e = b % 4, f = (b + 8) ~/ 25, g = (b - f + 1) ~/ 3;
  final h = (19 * a + b - d - g + 15) % 30;
  final i = c ~/ 4, k = c % 4;
  final l = (32 + 2 * e + 2 * i - h - k) % 7;
  final m = (a + 11 * h + 22 * l) ~/ 451;
  final month = (h + l - 7 * m + 114) ~/ 31;
  final day = (h + l - 7 * m + 114) % 31 + 1;
  return DateTime(year, month, day);
}

/// A new Easter countdown.
Countdown easterCountdown(String id) =>
    Countdown(id: id, emoji: '🐣', name: 'Easter', date: easterSunday(DateTime.now().year), easter: true);

class Snapshot {
  final Map<String, int> points;
  final List<Reward> rewards;
  final Map<String, TimerInfo> timers;
  final List<Countdown> countdowns;

  /// Points for a chore that has none of its own, per child.
  final Map<String, int> defaultChorePoints;

  /// Points goal per child, shown as the goal bar.
  final Map<String, int> goals;

  /// Chores a child ticks wait for a grown-up's OK before the points land.
  final bool approveChores;

  /// The reward each child is saving up for, by key.
  final Map<String, String> saving;
  final FamilyGoal? familyGoal;
  final Money money;
  final ChallengeSettings challenge;

  /// The family's challenge list, every category.
  final List<Challenge> challenges;

  Snapshot(
    this.points,
    this.rewards,
    this.timers,
    this.countdowns, {
    this.defaultChorePoints = const {},
    this.goals = const {},
    this.approveChores = true,
    this.saving = const {},
    this.familyGoal,
    this.money = const Money(),
    this.challenge = const ChallengeSettings(),
    this.challenges = const [],
  });

  /// Challenges the spinner can pick: switched on, in a category that is on.
  List<Challenge> challengesIn(String? cat) => [
    for (final c in challenges)
      if (c.on && challenge.catOn(c.cat) && (cat == null || c.cat == cat)) c,
  ];

  /// Categories with at least one challenge the spinner can pick.
  List<ChallengeCat> get spinCats => [
    for (final c in challengeCats)
      if (challengesIn(c.id).isNotEmpty) c,
  ];

  /// The reward [kid] is saving for, if it is still in the shop.
  Reward? savingFor(String kid) {
    for (final r in rewards) {
      if (r.key == saving[kid] && r.on && r.name.isNotEmpty) return r;
    }
    return null;
  }

  int defaultPoints(String kid) => defaultChorePoints[kid] ?? 1;
  int goal(String kid) => goals[kid] ?? defaultGoal;
}

/// A chore or an order. A chore's points are kept in its text as "(N pts)".
class TodoItem {
  final String uid, summary;
  final bool done;

  /// Ticked by a child, waiting for a grown-up to approve it.
  final bool waiting;

  /// Weekdays it is on (1 = Monday … 7 = Sunday); empty means every day.
  final List<int> days;

  /// A one-off bonus job: extra points, not part of the daily list, and
  /// gone the morning after it is done.
  final bool bonus;
  TodoItem(
    this.uid,
    this.summary,
    this.done, {
    this.waiting = false,
    this.days = const [],
    this.bonus = false,
  });

  static final _pts = RegExp(r'\((\d+)\s*pts?\)', caseSensitive: false);
  String get title => summary.replaceAll(_pts, '').trim();
  int? get points {
    final m = _pts.firstMatch(summary);
    return m == null ? null : int.tryParse(m.group(1)!);
  }

  /// On the list on this weekday.
  bool dueOn(int weekday) => days.isEmpty || days.contains(weekday);

  /// "Mon, Wed" or "Every day".
  String get daysLabel => days.isEmpty || days.length == 7
      ? 'Every day'
      : days.length == 5 && !days.contains(6) && !days.contains(7)
      ? 'Weekdays'
      : days.length == 2 && days.contains(6) && days.contains(7)
      ? 'Weekends'
      : ([...days]..sort()).map((d) => weekdayShort[d - 1]).join(', ');

  Map<String, dynamic> toJson() => {
    'id': uid,
    'text': summary,
    'done': done,
    if (waiting) 'waiting': true,
    if (days.isNotEmpty) 'days': days,
    if (bonus) 'bonus': true,
  };
  factory TodoItem.fromJson(Map<String, dynamic> j) => TodoItem(
    j['id'] as String,
    j['text'] as String? ?? '',
    j['done'] as bool? ?? false,
    waiting: j['waiting'] as bool? ?? false,
    days: [for (final d in (j['days'] as List?) ?? const []) (d as num).toInt()],
    bonus: j['bonus'] as bool? ?? false,
  );
}

const weekdayShort = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

/// One step of a routine, with minutes for its timer (0 for none).
class RoutineStep {
  final String text;
  final int minutes;
  const RoutineStep(this.text, [this.minutes = 0]);

  Map<String, dynamic> toJson() => {'t': text, 'm': minutes};
  factory RoutineStep.fromJson(Map<String, dynamic> j) =>
      RoutineStep(j['t'] as String? ?? '', (j['m'] as num?)?.toInt() ?? 0);
}

/// A morning or bedtime routine: steps in order, each with a timer.
class Routine {
  final String id, name, emoji;
  final List<RoutineStep> steps;
  final int points;

  /// Today: todo, waiting (for a grown-up) or done.
  final String state;

  const Routine({
    required this.id,
    required this.name,
    required this.emoji,
    required this.steps,
    this.points = 2,
    this.state = 'todo',
  });

  bool get done => state == 'done';
  bool get waiting => state == 'waiting';

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'emoji': emoji,
    'pts': points,
    'steps': [for (final s in steps) s.toJson()],
  };
  factory Routine.fromJson(Map<String, dynamic> j, {String state = 'todo'}) => Routine(
    id: j['id'] as String,
    name: j['name'] as String? ?? '',
    emoji: j['emoji'] as String? ?? '✅',
    points: (j['pts'] as num?)?.toInt() ?? 0,
    steps: [for (final s in (j['steps'] as List?) ?? const []) RoutineStep.fromJson((s as Map).cast())],
    state: state,
  );
}

/// Something the whole family saves points towards together.
class FamilyGoal {
  final String name, emoji;
  final int target, saved;

  /// Points each child has put in.
  final Map<String, int> given;
  const FamilyGoal({
    required this.name,
    required this.emoji,
    required this.target,
    this.saved = 0,
    this.given = const {},
  });

  bool get reached => saved >= target;
  int get left => (target - saved).clamp(0, target);

  factory FamilyGoal.fromJson(Map<String, dynamic> j) => FamilyGoal(
    name: j['name'] as String? ?? '',
    emoji: j['emoji'] as String? ?? '🎉',
    target: (j['target'] as num?)?.toInt() ?? 100,
    saved: (j['saved'] as num?)?.toInt() ?? 0,
    given: {
      for (final e in ((j['given'] as Map?) ?? const {}).entries) e.key as String: (e.value as num).toInt(),
    },
  );
}

/// Points as pocket money: [points] points are worth [cents] cents.
class Money {
  final bool on;
  final int points, cents;
  final String symbol;
  const Money({this.on = false, this.points = 10, this.cents = 100, this.symbol = r'$'});

  /// "$1.40" for this many points.
  String of(int pts) {
    final c = points <= 0 ? 0 : (pts * cents / points).floor();
    return '$symbol${c ~/ 100}.${(c % 100).toString().padLeft(2, '0')}';
  }

  /// "10 points = $1.00".
  String get rate => '$points points = ${of(points)}';

  Map<String, dynamic> toJson() => {'on': on, 'points': points, 'cents': cents, 'symbol': symbol};
  factory Money.fromJson(Map<String, dynamic>? j) => Money(
    on: j?['on'] as bool? ?? false,
    points: (j?['points'] as num?)?.toInt() ?? 10,
    cents: (j?['cents'] as num?)?.toInt() ?? 100,
    symbol: j?['symbol'] as String? ?? r'$',
  );
}

/// A child's record, for streaks and badges.
class KidStats {
  /// Days in a row with every chore done, up to yesterday.
  final int streak;

  /// Today's chores are all done too.
  final bool today;
  final int best, weeks, chores, saved, gave, challenges;
  const KidStats({
    this.streak = 0,
    this.today = false,
    this.best = 0,
    this.weeks = 0,
    this.chores = 0,
    this.saved = 0,
    this.gave = 0,
    this.challenges = 0,
  });

  /// The streak shown on the board: today counts once it's all done.
  int get current => streak + (today ? 1 : 0);
  int get bestNow => current > best ? current : best;

  factory KidStats.fromJson(Map<String, dynamic>? j, {bool today = false}) => KidStats(
    streak: (j?['streak'] as num?)?.toInt() ?? 0,
    today: today,
    best: (j?['best'] as num?)?.toInt() ?? 0,
    weeks: (j?['weeks'] as num?)?.toInt() ?? 0,
    chores: (j?['chores'] as num?)?.toInt() ?? 0,
    saved: (j?['saved'] as num?)?.toInt() ?? 0,
    gave: (j?['gave'] as num?)?.toInt() ?? 0,
    challenges: (j?['challenges'] as num?)?.toInt() ?? 0,
  );
}

/// A badge a child can earn.
class KidBadge {
  final String emoji, name, how;
  final bool Function(KidStats s) earned;
  const KidBadge(this.emoji, this.name, this.how, this.earned);
}

final badges = <KidBadge>[
  KidBadge('🌱', 'First chore', 'Finish your first chore', (s) => s.chores >= 1),
  KidBadge('🔥', 'On a roll', 'Every chore done 3 days in a row', (s) => s.bestNow >= 3),
  KidBadge('⚡', 'Super week', 'Every chore done 7 days in a row', (s) => s.bestNow >= 7),
  KidBadge('🏆', 'Perfect week', 'Every chore done Monday to Sunday', (s) => s.weeks >= 1),
  KidBadge('💪', 'Hard worker', 'Finish 50 chores', (s) => s.chores >= 50),
  KidBadge('🐷', 'Super saver', 'Save up for a goal and buy it', (s) => s.saved >= 1),
  KidBadge('🤝', 'Team player', 'Put points into the family goal', (s) => s.gave >= 1),
  KidBadge('🎡', 'Challenge accepted', 'Finish your first challenge', (s) => s.challenges >= 1),
  KidBadge('🧠', 'Master maker', 'Finish 10 challenges', (s) => s.challenges >= 10),
  KidBadge('🌟', 'Two weeks strong', 'Every chore done 14 days in a row', (s) => s.bestNow >= 14),
  KidBadge('👑', 'Chore champion', 'Finish 200 chores', (s) => s.chores >= 200),
  KidBadge('🚀', 'Unstoppable', 'Every chore done 30 days in a row', (s) => s.bestNow >= 30),
];

const defaultGoal = 40;

/// One line of the points log.
class LogEntry {
  final DateTime when;
  final String text;

  /// Points added or taken, and what for: chore, unchore, buy, adjust,
  /// routine, challenge, family or payout. Missing on entries from older versions.
  final int? delta;
  final String? kind;

  /// The chore or reward's name.
  final String? what;
  LogEntry(this.when, this.text, {this.delta, this.kind, this.what});

  Map<String, dynamic> toJson() => {
    'when': when.toIso8601String(),
    'text': text,
    if (delta != null) 'd': delta,
    if (kind != null) 'k': kind,
    if (what != null) 'w': what,
  };
  factory LogEntry.fromJson(Map<String, dynamic> j) => LogEntry(
    DateTime.tryParse(j['when'] as String? ?? '') ?? DateTime.now(),
    j['text'] as String? ?? '',
    delta: (j['d'] as num?)?.toInt(),
    kind: j['k'] as String?,
    what: j['w'] as String?,
  );
}

/// A kind of challenge, shown as a slice of the spinner.
class ChallengeCat {
  final String id, emoji, name;

  /// Slice colour on the wheel.
  final int color;
  const ChallengeCat(this.id, this.emoji, this.name, this.color);
}

const challengeCats = [
  ChallengeCat('lego', '🧱', 'Bricks', 0xFFE53935),
  ChallengeCat('craft', '✂️', 'Craft', 0xFF8E24AA),
  ChallengeCat('draw', '🎨', 'Drawing', 0xFF1E88E5),
  ChallengeCat('outdoor', '🌳', 'Outdoors', 0xFF43A047),
  ChallengeCat('kind', '💛', 'Kindness', 0xFFFFB300),
  ChallengeCat('cook', '🍳', 'Kitchen', 0xFFFB8C00),
];

ChallengeCat catOf(String id) =>
    challengeCats.firstWhere((c) => c.id == id, orElse: () => challengeCats.first);

/// Something fun to make or do, from the challenge spinner.
class Challenge {
  final String id, cat, text;
  final int points;

  /// Minutes for its timer; 0 for no timer.
  final int minutes;

  /// The spinner can pick it.
  final bool on;

  /// Steps a parent wrote; null to use the catalog's, if it has any.
  final ChallengeHow? how;

  /// The catalog challenge's key, for one that came from the catalog.
  final String? src;

  /// A parent has changed it, so catalog updates leave it alone.
  final bool edited;
  const Challenge({
    required this.id,
    required this.cat,
    required this.text,
    this.points = 3,
    this.minutes = 0,
    this.on = true,
    this.how,
    this.src,
    this.edited = false,
  });

  Challenge withId(String id) => copyWith(id: id);

  Challenge copyWith({String? id, String? src, bool? edited}) => Challenge(
    id: id ?? this.id,
    cat: cat,
    text: text,
    points: points,
    minutes: minutes,
    on: on,
    how: how,
    src: src ?? this.src,
    edited: edited ?? this.edited,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'cat': cat,
    'text': text,
    'pts': points,
    'min': minutes,
    if (!on) 'off': true,
    if (how != null) 'how': how!.toJson(),
    if (src != null) 'src': src,
    if (edited) 'edited': true,
  };
  factory Challenge.fromJson(Map<String, dynamic> j) => Challenge(
    id: j['id'] as String,
    cat: j['cat'] as String? ?? 'lego',
    text: j['text'] as String? ?? '',
    points: (j['pts'] as num?)?.toInt() ?? 3,
    minutes: (j['min'] as num?)?.toInt() ?? 0,
    on: j['off'] != true,
    how: j['how'] is Map ? ChallengeHow.fromJson((j['how'] as Map).cast()) : null,
    src: j['src'] as String?,
    edited: j['edited'] == true,
  );
}

/// A challenge's "Show me how": the youngest age it suits, what you need
/// and the steps.
class ChallengeHow {
  final int age;
  final List<String> need, steps;
  const ChallengeHow({this.age = 0, this.need = const [], this.steps = const []});

  Map<String, dynamic> toJson() => {'age': age, 'need': need, 'steps': steps};
  factory ChallengeHow.fromJson(Map<String, dynamic> j) => ChallengeHow(
    age: (j['age'] as num?)?.toInt() ?? 0,
    need: [for (final n in j['need'] as List? ?? const []) '$n'],
    steps: [for (final n in j['steps'] as List? ?? const []) '$n'],
  );
}

/// How the challenge spinner works for this family.
class ChallengeSettings {
  /// Shown on the boards.
  final bool on;

  /// Spins each child gets a day.
  final int spins;

  /// Category ids switched off.
  final List<String> offCats;

  /// Kids can take photos of what they made (kept on their device only).
  final bool photos;
  const ChallengeSettings({this.on = true, this.spins = 3, this.offCats = const [], this.photos = true});

  bool catOn(String id) => !offCats.contains(id);

  ChallengeSettings copyWith({bool? on, int? spins, List<String>? offCats, bool? photos}) =>
      ChallengeSettings(
        on: on ?? this.on,
        spins: spins ?? this.spins,
        offCats: offCats ?? this.offCats,
        photos: photos ?? this.photos,
      );

  Map<String, dynamic> toJson() => {'on': on, 'spins': spins, 'off': offCats, 'photos': photos};
  factory ChallengeSettings.fromJson(Map<String, dynamic>? j) => ChallengeSettings(
    on: j?['on'] as bool? ?? true,
    spins: (j?['spins'] as num?)?.toInt() ?? 3,
    offCats: [for (final c in (j?['off'] as List?) ?? const []) c as String],
    photos: j?['photos'] as bool? ?? true,
  );
}

/// A child's challenge today: what they spun and how many spins are used.
class ChallengeDay {
  final int spins;

  /// The challenge spun, if any.
  final Challenge? current;

  /// doing, waiting (for a grown-up) or done.
  final String state;
  const ChallengeDay({this.spins = 0, this.current, this.state = 'doing'});

  bool get doing => current != null && state == 'doing';
  bool get waiting => current != null && state == 'waiting';
  bool get done => current != null && state == 'done';
  int left(ChallengeSettings s) => (s.spins - spins).clamp(0, s.spins);

  factory ChallengeDay.fromJson(Map<String, dynamic>? j) => ChallengeDay(
    spins: (j?['spins'] as num?)?.toInt() ?? 0,
    current: j?['cur'] == null ? null : Challenge.fromJson((j!['cur'] as Map).cast()),
    state: j?['state'] as String? ?? 'doing',
  );
}
