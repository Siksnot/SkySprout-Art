import 'package:flutter/material.dart';

import '../app_state.dart';
import '../config.dart';
import '../screens/parent_home.dart';
import '../screens/setup_screen.dart';
import '../screens/welcome_screen.dart';
import '../sync.dart';
import '../themes.dart';
import 'common.dart';

/// Where the menu is shown.
enum HubPlace { kids, parents }

/// The ☰ menu: switches between the kids' dashboards and the parent portal.
/// In the parent portal it also has Settings and signing in or out.
class HubMenu extends StatelessWidget {
  final HubPlace place;
  final Color? color;
  final double? iconSize;
  const HubMenu({super.key, required this.place, this.color, this.iconSize});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final parents = place == HubPlace.parents;
    final signedIn = state.auth != null;
    return PopupMenuButton<String>(
      tooltip: 'Menu',
      icon: Icon(Icons.menu, color: color),
      iconSize: iconSize,
      position: PopupMenuPosition.under,
      onSelected: (v) => _go(context, v),
      itemBuilder: (_) => [
        _item('kids', Icons.dashboard_rounded, "Kids' dashboards", current: !parents),
        _item('parents', Icons.lock_rounded, 'Parent portal', current: parents),
        if (parents) ...[
          const PopupMenuDivider(),
          _item('settings', Icons.settings, 'Settings'),
          signedIn ? _item('signout', Icons.logout, 'Sign out') : _item('signin', Icons.login, 'Sign in'),
        ],
      ],
    );
  }

  PopupMenuItem<String> _item(String value, IconData icon, String text, {bool current = false}) =>
      PopupMenuItem(
        value: value,
        enabled: !current,
        child: ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Icon(icon),
          title: Text(text),
          trailing: current ? const Icon(Icons.check) : null,
        ),
      );

  Future<void> _go(BuildContext context, String v) async {
    final state = AppScope.read(context);
    switch (v) {
      case 'kids':
        // Leaving the parent portal locks it again.
        Navigator.popUntil(context, (r) => r.isFirst);
      case 'parents':
        await openParentPortal(context);
      case 'settings':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const SetupScreen()));
      case 'signout':
        await signOutWithCheck(context);
      case 'signin':
        if (!syncAvailable) {
          showResult(
            context,
            'Online accounts aren\'t switched on in this copy of the app. '
            'See "Online accounts" in the README.',
          );
          return;
        }
        final device = (await PrefsStore().fetch()).data;
        if (!context.mounted) return;
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) =>
                WelcomeScreen(auth: SupabaseAuth(), onReady: state.onSignedIn!, deviceFamily: device),
          ),
        );
    }
  }
}

/// Asks for the parent PIN, then opens the parent portal.
Future<void> openParentPortal(BuildContext context) async {
  final unlocked = await askParentPin(
    context,
    AppScope.read(context).checkPin,
    onForgot: () => forgotPin(context),
  );
  if (unlocked && context.mounted) {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const ParentHome()));
  }
}

/// A forgotten parent PIN. Online, the family login's password sets a new
/// one. On a device-only family there is nothing else to check, so the only
/// way back in is to erase this device and set it up again.
Future<void> forgotPin(BuildContext context) async {
  final state = AppScope.read(context);
  if (state.auth != null) {
    final changed = await showDialog<bool>(
      context: context,
      builder: (_) => Theme(
        data: parentTheme(Brightness.light),
        child: _ResetPinDialog(state: state),
      ),
    );
    if (changed == true && context.mounted) {
      showResult(context, null, ok: 'Parent PIN changed on every device');
      await Navigator.push(context, MaterialPageRoute(builder: (_) => const ParentHome()));
    }
    return;
  }
  final word = TextEditingController();
  final erase = await showDialog<bool>(
    context: context,
    builder: (ctx) => Theme(
      data: parentTheme(Brightness.light),
      child: AlertDialog(
        title: const Text('Forgot the parent PIN?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'This family is only kept on this device, with no login to check instead, '
              'so the PIN can\'t be reset.\n\n'
              'You can erase everything on this device (children, points, chores and rewards) '
              'and set it up again. To do that, type ERASE below.',
            ),
            const SizedBox(height: 12),
            TextField(
              controller: word,
              textCapitalization: TextCapitalization.characters,
              decoration: const InputDecoration(labelText: 'Type ERASE'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red.shade700),
            onPressed: () => Navigator.pop(ctx, word.text.trim().toUpperCase() == 'ERASE'),
            child: const Text('Erase and start again'),
          ),
        ],
      ),
    ),
  );
  if (erase == true) await state.eraseDevice();
}

class _ResetPinDialog extends StatefulWidget {
  final AppState state;
  const _ResetPinDialog({required this.state});

  @override
  State<_ResetPinDialog> createState() => _ResetPinDialogState();
}

class _ResetPinDialogState extends State<_ResetPinDialog> {
  final _password = TextEditingController();
  final _pin = TextEditingController();
  String? _error;
  bool _busy = false;

  @override
  void dispose() {
    _password.dispose();
    _pin.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!AppConfig.validPin(_pin.text.trim())) {
      setState(() => _error = 'Choose a new PIN of 4 to 8 digits.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final err = await widget.state.resetPin(_password.text, _pin.text.trim());
    if (!mounted) return;
    if (err == null) {
      Navigator.pop(context, true);
    } else {
      setState(() {
        _busy = false;
        _error = err;
      });
    }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('Reset the parent PIN'),
    content: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          'Enter the password for ${widget.state.auth?.email ?? 'the family login'}, '
          'then choose a new PIN.',
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _password,
          obscureText: true,
          decoration: const InputDecoration(labelText: 'Password'),
        ),
        TextField(
          controller: _pin,
          obscureText: true,
          keyboardType: TextInputType.number,
          maxLength: 8,
          decoration: const InputDecoration(labelText: 'New parent PIN'),
          onSubmitted: (_) => _save(),
        ),
        if (_error != null) Text(_error!, style: TextStyle(color: Colors.red.shade700)),
      ],
    ),
    actions: [
      TextButton(onPressed: _busy ? null : () => Navigator.pop(context, false), child: const Text('Cancel')),
      FilledButton(onPressed: _busy ? null : _save, child: const Text('Save')),
    ],
  );
}

/// Asks first, then signs this device out of the family's login.
Future<void> signOutWithCheck(BuildContext context) async {
  final state = AppScope.read(context);
  if (!await confirm(
    context,
    'Sign out of this device?',
    'The family\'s data stays safe online. Sign in again to see it here.',
    yes: 'Sign out',
    no: 'Cancel',
  )) {
    return;
  }
  await state.signOut();
}
