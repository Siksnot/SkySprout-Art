import 'dart:async';

import 'package:flutter/material.dart';

import '../app_state.dart';
import '../models.dart';
import '../themes.dart';

/// Makes [AppState] available to every screen and rebuilds them on change.
class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required AppState state, required super.child}) : super(notifier: state);

  static AppState of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<AppScope>()!.notifier!;

  /// Read without subscribing (for callbacks).
  static AppState read(BuildContext context) => context.getInheritedWidgetOfExactType<AppScope>()!.notifier!;
}

/// A kid's points in their theme.
class PointsBadge extends StatelessWidget {
  final KidTheme theme;
  final int points;
  final double size;
  const PointsBadge({super.key, required this.theme, required this.points, this.size = 22});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: size * 0.6, vertical: size * 0.25),
      decoration: theme.box(color: theme.accent),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('⭐', style: TextStyle(fontSize: size)),
          SizedBox(width: size * 0.3),
          Text('$points', style: theme.text(size, color: theme.onAccent)),
        ],
      ),
    );
  }
}

/// Shows a snack bar for an action result: [error] if it failed, else [ok].
void showResult(BuildContext context, String? error, {String? ok}) {
  final messenger = ScaffoldMessenger.maybeOf(context);
  if (messenger == null || (error == null && ok == null)) return;
  messenger
    ..hideCurrentSnackBar()
    ..showSnackBar(
      SnackBar(
        content: Text(error ?? ok!),
        backgroundColor: error != null ? Colors.red.shade700 : null,
        behavior: SnackBarBehavior.floating,
      ),
    );
}

Future<bool> confirm(
  BuildContext context,
  String title,
  String body, {
  String yes = 'Yes',
  String no = 'Not yet',
}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(body, style: const TextStyle(fontSize: 18)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(no)),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(yes)),
      ],
    ),
  );
  return r ?? false;
}

/// Asks for the parent PIN. Returns true when it matches.
int _wrongPins = 0;
DateTime? _pinLockedUntil;

/// Asks for the parent PIN. After 3 wrong tries it locks for 30 seconds,
/// so guessing takes a long time.
///
/// [onForgot], when set, adds a "Forgot PIN?" button that closes the dialog
/// and calls it.
Future<bool> askParentPin(
  BuildContext context,
  bool Function(String pin) check, {
  Future<void> Function()? onForgot,
}) async {
  final until = _pinLockedUntil;
  if (until != null && DateTime.now().isBefore(until)) {
    showResult(context, 'Too many tries. Wait ${until.difference(DateTime.now()).inSeconds + 1} seconds.');
    return false;
  }
  final controller = TextEditingController();
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => Theme(
      data: parentTheme(Brightness.light),
      child: AlertDialog(
        title: const Text('Grown-ups only'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: controller,
              autofocus: true,
              obscureText: true,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Parent PIN'),
              onSubmitted: (v) => Navigator.pop(ctx, check(v)),
            ),
            if (onForgot != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: TextButton(
                  style: TextButton.styleFrom(padding: EdgeInsets.zero),
                  onPressed: () => Navigator.pop(ctx, null),
                  child: const Text('Forgot PIN?'),
                ),
              ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, check(controller.text)),
            child: const Text('Unlock'),
          ),
        ],
      ),
    ),
  );
  if (ok == true) {
    _wrongPins = 0;
  } else if (ok == false && controller.text.isNotEmpty) {
    if (++_wrongPins >= 3) {
      _wrongPins = 0;
      _pinLockedUntil = DateTime.now().add(const Duration(seconds: 30));
    }
    if (context.mounted) showResult(context, 'Wrong PIN');
  } else if (ok == null && onForgot != null && context.mounted) {
    await onForgot();
  }
  return ok ?? false;
}

/// Error/offline banner shown above dashboards. Tap to retry.
class StatusBanner extends StatelessWidget {
  const StatusBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (s.error == null) return const SizedBox.shrink();
    return Material(
      color: Colors.red.shade700,
      child: InkWell(
        onTap: s.refresh,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(
            children: [
              const Icon(Icons.wifi_off, color: Colors.white),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  s.data == null ? s.error! : 'Showing older data. ${s.error}',
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
              const Text(
                'Retry',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Countdowns with a value, soonest first.
List<Countdown> activeCountdowns(List<Countdown> all) =>
    all.where((c) => c.days >= 0).toList()..sort((a, b) => a.days.compareTo(b.days));

String daysText(int d) => switch (d) {
  0 => 'Today!',
  1 => 'Tomorrow',
  _ => '$d days',
};

String formatLeft(Duration d) {
  final m = d.inMinutes;
  final s = (d.inSeconds % 60).toString().padLeft(2, '0');
  return m >= 60 ? '${d.inHours}:${(m % 60).toString().padLeft(2, '0')}:$s' : '$m:$s';
}

/// Rebuilds every second while a timer is running, to show time left.
class Ticker extends StatefulWidget {
  final Widget Function(BuildContext) builder;
  const Ticker({super.key, required this.builder});

  @override
  State<Ticker> createState() => _TickerState();
}

class _TickerState extends State<Ticker> {
  late final Timer _t = Timer.periodic(const Duration(seconds: 1), (_) => setState(() {}));

  @override
  void dispose() {
    _t.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.builder(context);
}

/// "📱 Screen time 17:30 left" pill, or nothing when the timer is idle.
class ScreenTimePill extends StatelessWidget {
  final KidTheme theme;
  final TimerInfo? timer;
  final double size;
  const ScreenTimePill({super.key, required this.theme, required this.timer, this.size = 20});

  @override
  Widget build(BuildContext context) {
    final t = timer;
    if (t == null || !(t.running || t.paused)) return const SizedBox.shrink();
    return Ticker(
      builder: (context) {
        final left = t.left() ?? Duration.zero;
        return Container(
          padding: EdgeInsets.symmetric(horizontal: size * 0.6, vertical: size * 0.3),
          decoration: theme.box(color: t.paused ? theme.card : theme.dark),
          child: Text(
            '${t.paused ? '⏸️' : '⏱️'} Screen time ${formatLeft(left)}${t.paused ? ' (paused)' : ' left'}',
            style: theme.text(size, color: t.paused ? theme.dark : Colors.white),
          ),
        );
      },
    );
  }
}
