import 'dart:math' as math;

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

/// Tests turn sounds off (there is no audio plugin there).
bool celebrationSounds = true;

final _player = AudioPlayer();

/// Confetti over the whole screen, with a chime. [big] is for finishing the
/// whole list: more confetti, a fanfare and a banner.
void celebrate(BuildContext context, {bool big = false, String? message}) {
  final overlay = Overlay.maybeOf(context, rootOverlay: true);
  if (overlay == null) return;
  late OverlayEntry entry;
  entry = OverlayEntry(
    builder: (_) => IgnorePointer(
      child: _Confetti(big: big, message: message, onDone: () => entry.remove()),
    ),
  );
  overlay.insert(entry);
  if (celebrationSounds) {
    _player.play(AssetSource(big ? 'sounds/fanfare.wav' : 'sounds/chime.wav')).catchError((_) {});
  }
}

class _Confetti extends StatefulWidget {
  final bool big;
  final String? message;
  final VoidCallback onDone;
  const _Confetti({required this.big, required this.message, required this.onDone});

  @override
  State<_Confetti> createState() => _ConfettiState();
}

class _Piece {
  final double x, speed, drift, spin, size, delay;
  final Color color;
  final bool round;
  _Piece(math.Random r)
    : x = r.nextDouble(),
      speed = 0.6 + r.nextDouble() * 0.7,
      drift = (r.nextDouble() - 0.5) * 0.3,
      spin = (r.nextDouble() - 0.5) * 14,
      size = 7 + r.nextDouble() * 8,
      delay = r.nextDouble() * 0.35,
      color = _colors[r.nextInt(_colors.length)],
      round = r.nextInt(4) == 0;

  static const _colors = [
    Color(0xFFFFD43B),
    Color(0xFF8EC9F5),
    Color(0xFFF7A8CB),
    Color(0xFFC9B6FF),
    Color(0xFF5DAA3C),
    Color(0xFFFF9A3C),
    Color(0xFFD63384),
  ];
}

class _ConfettiState extends State<_Confetti> with SingleTickerProviderStateMixin {
  late final _c = AnimationController(
    vsync: this,
    duration: Duration(milliseconds: widget.big ? 3400 : 2200),
  )..forward().whenComplete(widget.onDone);
  late final _pieces = List.generate(widget.big ? 160 : 70, (_) => _Piece(math.Random()));

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _c,
    builder: (context, _) {
      final t = _c.value;
      return Stack(
        fit: StackFit.expand,
        children: [
          CustomPaint(painter: _ConfettiPainter(_pieces, t)),
          if (widget.message != null)
            Center(
              child: Opacity(
                opacity: (t < 0.1 ? t * 10 : (t > 0.85 ? (1 - t) / 0.15 : 1.0)).clamp(0.0, 1.0),
                child: Transform.scale(
                  scale: Curves.elasticOut.transform((t * 3).clamp(0, 1)),
                  child: Material(
                    color: Colors.transparent,
                    child: Container(
                      margin: const EdgeInsets.all(24),
                      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 18),
                      decoration: BoxDecoration(
                        color: const Color(0xFF2F2F2F),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: Colors.white, width: 5),
                        boxShadow: const [
                          BoxShadow(color: Color(0x55000000), offset: Offset(0, 8), blurRadius: 8),
                        ],
                      ),
                      child: Text(
                        widget.message!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontFamily: 'Fredoka',
                          fontWeight: FontWeight.w700,
                          fontSize: 30,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      );
    },
  );
}

class _ConfettiPainter extends CustomPainter {
  final List<_Piece> pieces;
  final double t;
  _ConfettiPainter(this.pieces, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();
    for (final p in pieces) {
      final local = ((t - p.delay) / (1 - p.delay)).clamp(0.0, 1.0);
      if (local <= 0) continue;
      final y = -20 + local * p.speed * (size.height + 60) * 1.3;
      final x = (p.x + p.drift * local + 0.02 * math.sin(local * 12 + p.x * 10)) * size.width;
      paint.color = p.color.withValues(alpha: local > 0.85 ? (1 - local) / 0.15 : 1);
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(p.spin * local);
      if (p.round) {
        canvas.drawCircle(Offset.zero, p.size / 2.5, paint);
      } else {
        // A strip that flips as it falls.
        final flip = math.cos(local * 20 + p.x * 6).abs().clamp(0.2, 1.0);
        canvas.drawRect(
          Rect.fromCenter(center: Offset.zero, width: p.size, height: p.size * 0.5 * flip),
          paint,
        );
      }
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_ConfettiPainter old) => old.t != t;
}
