import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../themes.dart';

const _ink = Color(0xFF2F2F2F);

/// One colour per letter of "Kids Hub", taken from the four kid themes.
const _letters = [
  ('K', Color(0xFFFFD43B)),
  ('i', Color(0xFF8EC9F5)),
  ('d', Color(0xFFF7A8CB)),
  ('s', Color(0xFFC9B6FF)),
  (' ', Colors.white),
  ('H', Color(0xFF5DAA3C)),
  ('u', Color(0xFFFF9A3C)),
  ('b', Color(0xFFB48CFF)),
];

/// The Kids Hub sign: rainbow letters on a dark board with a white rim,
/// tilted a little. Scales to fit [height] (or the space it is given).
class KidsHubSign extends StatelessWidget {
  final double? height;

  /// The "Chores ★ Points ★ Rewards" line under the name.
  final bool tagline;
  const KidsHubSign({super.key, this.height, this.tagline = true});

  @override
  Widget build(BuildContext context) {
    const font = 'Fredoka';
    final sign = Transform.rotate(
      angle: -2 * math.pi / 180,
      child: Container(
        margin: const EdgeInsets.fromLTRB(10, 10, 10, 26),
        padding: EdgeInsets.fromLTRB(70, 22, 70, tagline ? 28 : 34),
        decoration: BoxDecoration(
          color: _ink,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.white, width: 8),
          boxShadow: const [
            BoxShadow(color: _ink, spreadRadius: 8),
            BoxShadow(color: Color(0x59000000), offset: Offset(0, 16), spreadRadius: 8),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (final (i, (ch, colour)) in _letters.indexed)
                  Transform.translate(
                    offset: Offset(0, i.isEven ? -6 : 6),
                    child: Transform.rotate(
                      angle: (i.isEven ? -3 : 3) * math.pi / 180,
                      child: Text(
                        ch == ' ' ? '  ' : ch,
                        style: TextStyle(
                          fontFamily: font,
                          fontWeight: FontWeight.w700,
                          fontSize: 150,
                          height: 1.05,
                          color: colour,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            if (tagline)
              const Text.rich(
                TextSpan(
                  children: [
                    TextSpan(text: 'CHORES '),
                    TextSpan(
                      text: '★',
                      style: TextStyle(color: Color(0xFFFFD43B)),
                    ),
                    TextSpan(text: ' POINTS '),
                    TextSpan(
                      text: '★',
                      style: TextStyle(color: Color(0xFFFFD43B)),
                    ),
                    TextSpan(text: ' REWARDS'),
                  ],
                ),
                style: TextStyle(
                  fontFamily: font,
                  fontWeight: FontWeight.w700,
                  fontSize: 34,
                  letterSpacing: 4,
                  color: Colors.white,
                ),
              ),
          ],
        ),
      ),
    );
    return Semantics(
      label: 'Kids Hub',
      excludeSemantics: true,
      child: SizedBox(
        height: height,
        child: FittedBox(fit: BoxFit.contain, child: sign),
      ),
    );
  }
}

/// Shown while the app starts and while the family loads: the sign, with
/// the four theme mascots hopping in turn underneath.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  late final _intro = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))..forward();
  late final _hop = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..repeat();

  @override
  void dispose() {
    _intro.dispose();
    _hop.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final signWidth = math.min(size.width * 0.82, 720.0);
    return Material(
      color: const Color(0xFFF4EFE6),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ScaleTransition(
              scale: CurvedAnimation(parent: _intro, curve: Curves.elasticOut),
              child: SizedBox(width: signWidth, child: const KidsHubSign()),
            ),
            const SizedBox(height: 28),
            AnimatedBuilder(
              animation: _hop,
              builder: (context, _) => Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (final (i, t) in KidTheme.all.indexed)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Transform.translate(
                        offset: Offset(0, -18 * _bounce(_hop.value * KidTheme.all.length - i)),
                        child: Text(t.mascot, style: const TextStyle(fontSize: 40)),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            const Text(
              'Loading…',
              style: TextStyle(fontFamily: 'Fredoka', fontWeight: FontWeight.w700, fontSize: 20, color: _ink),
            ),
          ],
        ),
      ),
    );
  }

  /// A hop that lasts one step: up and back down while t runs 0 to 1.
  static double _bounce(double t) => t < 0 || t > 1 ? 0 : math.sin(t * math.pi);
}
