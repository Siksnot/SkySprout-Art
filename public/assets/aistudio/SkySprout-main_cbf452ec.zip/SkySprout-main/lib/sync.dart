import 'dart:async';
import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

/// The Supabase project behind Kids Hub. Either can be swapped at build
/// time with `--dart-define=SUPABASE_URL=...` / `--dart-define=SUPABASE_ANON_KEY=...`.
/// Building with an empty anon key gives an app with no accounts, kept on the device.
const supabaseUrl = String.fromEnvironment(
  'SUPABASE_URL',
  defaultValue: 'https://vfkpybbxcwajzcnugxnm.supabase.co',
);

/// The project's anon key: public by design, made to ship inside apps.
/// `supabase/setup.sql` keeps each family's data private to its login.
const supabaseAnonKey = String.fromEnvironment(
  'SUPABASE_ANON_KEY',
  defaultValue: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZma3B5YmJ4Y3dhanpjbnVneG5tIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTIwNDI5MTcsImV4cCI6MjEwNzYxODkxN30.lvzn7nGK95kzxWbz0B72YKy4QMz5SidruNmymsSO_Ow',
);
bool get syncAvailable => supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;

/// The family's data and the version it was saved as.
class Versioned {
  /// Null when there is no family yet.
  final Map<String, dynamic>? data;
  final int version;
  const Versioned(this.data, this.version);
}

/// Where the family's data lives: on this device, or in Supabase under the
/// family's login.
abstract class FamilyStore {
  Future<Versioned> fetch();

  /// Saves [data] if nobody has saved since [version]. Returns the new
  /// version, or null when another device saved first.
  Future<int?> save(Map<String, dynamic> data, int version);

  /// Starts a new family. False if one already exists here.
  Future<bool> create(Map<String, dynamic> data);
}

/// Keeps the family on this device only.
class PrefsStore implements FamilyStore {
  static const _key = 'kids_hub_family_v1';

  @override
  Future<Versioned> fetch() async {
    final raw = (await SharedPreferences.getInstance()).getString(_key);
    if (raw == null) return const Versioned(null, 0);
    final j = jsonDecode(raw) as Map<String, dynamic>;
    return Versioned((j['data'] as Map).cast(), (j['version'] as num).toInt());
  }

  @override
  Future<int?> save(Map<String, dynamic> data, int version) async {
    await (await SharedPreferences.getInstance()).setString(
      _key,
      jsonEncode({'data': data, 'version': version + 1}),
    );
    return version + 1;
  }

  @override
  Future<bool> create(Map<String, dynamic> data) async {
    await save(data, 0);
    return true;
  }

  /// Deletes the family from this device.
  Future<void> erase() async => (await SharedPreferences.getInstance()).remove(_key);
}

/// In memory, with the same version check as Supabase. Several backends can
/// share one to act like several devices (used by tests).
class MemoryStore implements FamilyStore {
  Map<String, dynamic>? _data;
  int _version = 0;

  @override
  Future<Versioned> fetch() async =>
      Versioned(_data == null ? null : jsonDecode(jsonEncode(_data)) as Map<String, dynamic>, _version);

  @override
  Future<int?> save(Map<String, dynamic> data, int version) async {
    if (version != _version) return null;
    _data = jsonDecode(jsonEncode(data)) as Map<String, dynamic>;
    return ++_version;
  }

  @override
  Future<bool> create(Map<String, dynamic> data) async {
    if (_data != null) return false;
    _data = jsonDecode(jsonEncode(data)) as Map<String, dynamic>;
    _version = 1;
    return true;
  }
}

/// A grown-up's Supabase login. Stays signed in by keeping the refresh
/// token on the device.
class SupabaseAuth {
  final String url, anonKey;
  final http.Client _http;
  SupabaseAuth({String? url, String? anonKey, http.Client? client})
    // Accept the project URL with or without a trailing /rest/v1/.
    : url = (url ?? supabaseUrl).replaceAll(RegExp(r'(/rest/v1)?/*$'), ''),
      anonKey = anonKey ?? supabaseAnonKey,
      _http = client ?? http.Client();

  static const _key = 'kids_hub_session_v1';

  String? _access, _refresh, email;
  DateTime _expires = DateTime(2000);

  bool get signedIn => _refresh != null;

  /// Reads the saved login, if any.
  Future<void> restore() async {
    final raw = (await SharedPreferences.getInstance()).getString(_key);
    if (raw == null) return;
    final j = jsonDecode(raw) as Map<String, dynamic>;
    _refresh = j['refresh'] as String?;
    email = j['email'] as String?;
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    if (_refresh == null) {
      await prefs.remove(_key);
    } else {
      await prefs.setString(_key, jsonEncode({'refresh': _refresh, 'email': email}));
    }
  }

  Future<Map<String, dynamic>> _post(
    String path,
    Map<String, dynamic> body, {
    String? token,
    bool put = false,
  }) async {
    http.Response r;
    try {
      final uri = Uri.parse('$url/auth/v1/$path');
      final headers = {
        'apikey': anonKey,
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };
      r =
          await (put
                  ? _http.put(uri, headers: headers, body: jsonEncode(body))
                  : _http.post(uri, headers: headers, body: jsonEncode(body)))
              .timeout(const Duration(seconds: 15));
    } catch (_) {
      throw AppError('Can\'t reach Kids Hub online. Check the internet connection.');
    }
    final j = r.body.isEmpty
        ? <String, dynamic>{}
        : (jsonDecode(utf8.decode(r.bodyBytes)) as Map).cast<String, dynamic>();
    if (r.statusCode >= 300) {
      final msg = (j['msg'] ?? j['error_description'] ?? j['message'] ?? '').toString();
      throw AppError(switch (msg) {
        'Invalid login credentials' => 'That email and password don\'t match.',
        'Email not confirmed' => 'Confirm your email first: open the link we sent, then sign in.',
        'User already registered' => 'There\'s already an account with that email. Sign in instead.',
        '' => 'Sign-in failed (${r.statusCode}).',
        _ => msg,
      });
    }
    return j;
  }

  Future<void> _take(Map<String, dynamic> j) async {
    _access = j['access_token'] as String?;
    _refresh = j['refresh_token'] as String?;
    _expires = DateTime.now().add(Duration(seconds: (j['expires_in'] as num?)?.toInt() ?? 3600));
    email = ((j['user'] as Map?)?['email'] as String?) ?? email;
    await _persist();
  }

  Future<void> signIn(String email, String password) async =>
      _take(await _post('token?grant_type=password', {'email': email.trim(), 'password': password}));

  /// Returns false when Supabase wants the email confirmed before signing in.
  Future<bool> signUp(String email, String password) async {
    final j = await _post('signup', {'email': email.trim(), 'password': password});
    if (j['access_token'] == null) return false;
    await _take(j);
    return true;
  }

  /// Emails a reset link, or a code if the Reset Password email shows `{{ .Token }}`.
  Future<void> resetPassword(String email) => _post('recover', {'email': email.trim()});

  /// Signs in with the passcode from the reset email. [code] can also be the
  /// email's link, or the web address that link opened.
  Future<void> verifyResetCode(String email, String code) async {
    final c = code.trim();
    try {
      final link = Uri.tryParse(c);
      final landed = link == null ? const <String, String>{} : Uri.splitQueryString(link.fragment);
      if (landed['refresh_token'] != null) {
        // The address the link opened: it already holds a sign-in.
        await _take(
          await _post('token?grant_type=refresh_token', {'refresh_token': landed['refresh_token']}),
        );
      } else if (link?.queryParameters['token'] case final hash? when c.startsWith('http')) {
        await _take(await _post('verify', {'type': 'recovery', 'token_hash': hash}));
      } else {
        await _take(await _post('verify', {'type': 'recovery', 'email': email.trim(), 'token': c}));
      }
    } on AppError catch (e) {
      if (e.message.startsWith('Can\'t reach')) rethrow;
      throw AppError('That passcode didn\'t work. Check it, or send a new one.');
    }
  }

  /// Changes the signed-in grown-up's password.
  Future<void> setPassword(String newPassword) async =>
      _post('user', {'password': newPassword}, token: await token(), put: true);

  /// [verifyResetCode], then [setPassword].
  Future<void> resetWithCode(String email, String code, String newPassword) async {
    await verifyResetCode(email, code);
    await setPassword(newPassword);
  }

  Future<void> signOut() async {
    final t = _access;
    _access = _refresh = email = null;
    await _persist();
    if (t != null) {
      try {
        await _post('logout', {}, token: t);
      } catch (_) {}
    }
  }

  /// A current access token, refreshed when it is about to run out.
  Future<String> token() async {
    if (_refresh == null) throw AppError('Please sign in again.');
    if (_access == null || DateTime.now().isAfter(_expires.subtract(const Duration(minutes: 1)))) {
      try {
        await _take(await _post('token?grant_type=refresh_token', {'refresh_token': _refresh}));
      } on AppError catch (e) {
        if (e.message.startsWith('Can\'t reach')) rethrow;
        _access = _refresh = null;
        await _persist();
        throw AppError('Please sign in again.');
      }
    }
    return _access!;
  }
}

/// The signed-in family's data in Supabase. Talks to the functions in
/// `supabase/setup.sql`, which only let a grown-up reach their own family.
class SupabaseStore implements FamilyStore {
  final SupabaseAuth auth;
  final http.Client _http;
  SupabaseStore(this.auth, {http.Client? client}) : _http = client ?? http.Client();

  String? familyId;

  /// The code another grown-up types to join this family.
  String? code;

  Future<dynamic> _rpc(String fn, Map<String, dynamic> args) async {
    final token = await auth.token();
    http.Response r;
    try {
      r = await _http
          .post(
            Uri.parse('${auth.url}/rest/v1/rpc/$fn'),
            headers: {
              'apikey': auth.anonKey,
              'Authorization': 'Bearer $token',
              'Content-Type': 'application/json',
            },
            body: jsonEncode(args),
          )
          .timeout(const Duration(seconds: 15));
    } on TimeoutException {
      throw AppError('Kids Hub online didn\'t answer. Check the internet connection.');
    } catch (_) {
      throw AppError('Can\'t reach Kids Hub online. Check the internet connection.');
    }
    if (r.statusCode >= 300) {
      final body = r.body.toLowerCase();
      if (body.contains('no family with that code')) {
        throw AppError('No family has that code. Check it and try again.');
      }
      if (body.contains('already in a family')) throw AppError('This account already has a family.');
      throw AppError('Kids Hub online said no (${r.statusCode}).');
    }
    return r.body.isEmpty ? null : jsonDecode(utf8.decode(r.bodyBytes));
  }

  @override
  Future<Versioned> fetch() async {
    final rows = await _rpc('my_family', {}) as List;
    if (rows.isEmpty) return const Versioned(null, 0);
    final row = rows.first as Map;
    familyId = row['family_id'] as String;
    code = row['code'] as String?;
    return Versioned((row['data'] as Map).cast(), (row['version'] as num).toInt());
  }

  @override
  Future<int?> save(Map<String, dynamic> data, int version) async {
    if (familyId == null) await fetch();
    final v = (await _rpc('family_save', {'p_family': familyId, 'p_data': data, 'p_version': version}) as num)
        .toInt();
    return v < 0 ? null : v;
  }

  @override
  Future<bool> create(Map<String, dynamic> data) async {
    final rows = await _rpc('family_create', {'p_data': data}) as List;
    final row = rows.first as Map;
    familyId = row['family_id'] as String;
    code = row['code'] as String?;
    return true;
  }

  /// Joins the family with this code (for a second grown-up).
  Future<void> join(String code) async {
    await _rpc('family_join', {'p_code': normalizeCode(code)});
    await fetch();
  }
}

/// Letters and digits that can't be mixed up when read aloud or typed.
const _codeChars = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

/// "abcde-fghij " -> "ABCDEFGHIJ".
String normalizeCode(String code) => code.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');

/// "ABCDEFGHIJ" -> "ABCDE-FGHIJ".
String showCode(String code) {
  final c = normalizeCode(code);
  return c.length == 10 ? '${c.substring(0, 5)}-${c.substring(5)}' : c;
}

bool validCode(String code) => RegExp('^[$_codeChars]{10}\$').hasMatch(normalizeCode(code));

/// The parent PIN is stored hashed, so it isn't readable in the family data.
String hashPin(String pin) => sha256.convert(utf8.encode('kids-hub-pin:$pin')).toString();
