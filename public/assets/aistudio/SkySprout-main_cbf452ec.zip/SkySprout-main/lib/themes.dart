import 'package:flutter/material.dart';

import 'models.dart';

/// A dashboard look a parent can pick for each child: Quest (pixel/blocky),
/// Construction, Princess or Unicorn.
class KidTheme {
  /// Saved in the child's settings.
  final String id;

  /// Shown in the theme picker.
  final String label;
  final String mascot;
  final Color bg, card, border, accent, dark, onAccent;
  final double radius, borderWidth;
  final String? font;
  final FontWeight heavy;

  /// Bigger text for fonts that run small (Jersey 25 is condensed).
  final double scale;

  /// Board wording: "Sam's Quest Board", "Today's Quests", "Daily quest".
  final String boardEmoji, boardName, listName, dailyName;

  /// Colour of the soonest countdown and other highlights.
  final Color highlight;

  /// Colour of the small section labels ("Daily quest", "Days to go").
  final Color labelColor;

  const KidTheme({
    required this.id,
    required this.label,
    required this.labelColor,
    required this.mascot,
    required this.bg,
    required this.card,
    required this.border,
    required this.accent,
    required this.dark,
    required this.onAccent,
    required this.radius,
    required this.borderWidth,
    required this.heavy,
    required this.boardEmoji,
    required this.boardName,
    required this.listName,
    required this.dailyName,
    required this.highlight,
    this.font,
    this.scale = 1,
  });

  static const quest = KidTheme(
    id: 'quest',
    label: 'Quest',
    labelColor: Color(0xFF8BD66B),
    mascot: '⛏️',
    bg: Color(0xFF8EC9F5),
    card: Color(0xFFE3DCC8),
    border: Color(0xFF2F2F2F),
    accent: Color(0xFF5DAA3C),
    dark: Color(0xFF3B3B3B),
    onAccent: Colors.white,
    radius: 0,
    borderWidth: 4,
    font: 'Jersey25',
    heavy: FontWeight.w400,
    scale: 1.3,
    boardEmoji: '⚔️',
    boardName: 'Quest Board',
    listName: "Today's Quests",
    dailyName: 'Daily quest',
    highlight: Color(0xFFFFF59D),
  );

  static const construction = KidTheme(
    id: 'construction',
    label: 'Construction',
    labelColor: Color(0xFFFFD43B),
    mascot: '🚜',
    bg: Color(0xFFFFD43B),
    card: Colors.white,
    border: Color(0xFF1C1C1C),
    accent: Color(0xFFFF7A00),
    dark: Color(0xFF1C1C1C),
    onAccent: Colors.white,
    radius: 12,
    borderWidth: 3,
    heavy: FontWeight.w900,
    boardEmoji: '🚧',
    boardName: 'Job Site',
    listName: "Today's Jobs",
    dailyName: 'Daily jobs',
    highlight: Color(0xFFFFD43B),
  );

  static const princess = KidTheme(
    id: 'princess',
    label: 'Princess',
    labelColor: Color(0xFFFFC2DD),
    mascot: '👸',
    bg: Color(0xFFFFD6E7),
    card: Color(0xFFFFF7FB),
    border: Color(0xFF8E2C64),
    accent: Color(0xFFD63384),
    dark: Color(0xFF5A1740),
    onAccent: Colors.white,
    radius: 22,
    borderWidth: 3,
    heavy: FontWeight.w800,
    boardEmoji: '🏰',
    boardName: 'Castle',
    listName: "Today's Royal Tasks",
    dailyName: 'Royal tasks',
    highlight: Color(0xFFFFE08A),
  );

  static const unicorn = KidTheme(
    id: 'unicorn',
    label: 'Unicorn',
    labelColor: Color(0xFFB8F2E6),
    mascot: '🦄',
    bg: Color(0xFFE4D9FF),
    card: Colors.white,
    border: Color(0xFF6A4C93),
    accent: Color(0xFF9B5DE5),
    dark: Color(0xFF3D2A5C),
    onAccent: Colors.white,
    radius: 26,
    borderWidth: 3,
    heavy: FontWeight.w800,
    boardEmoji: '🌈',
    boardName: 'Rainbow Board',
    listName: "Today's Magic Tasks",
    dailyName: 'Daily magic',
    highlight: Color(0xFFFFF3B0),
  );

  /// The themes a parent can choose from, in picker order.
  static const all = [quest, construction, princess, unicorn];

  static KidTheme byId(String id) => all.firstWhere((t) => t.id == id, orElse: () => quest);

  /// The theme the parent picked for this child.
  static KidTheme of(String kid) => byId(childOf(kid)?.theme ?? 'quest');

  TextStyle text(double size, {bool bold = true, Color? color}) => TextStyle(
    fontFamily: font,
    fontSize: size * scale,
    fontWeight: bold ? heavy : FontWeight.w500,
    color: color ?? dark,
    height: 1.1,
  );

  BorderRadius get br => BorderRadius.circular(radius);

  /// Card with a hard offset shadow: blocky for Quest, chunky for the rest.
  BoxDecoration box({Color? color, bool shadow = true}) => BoxDecoration(
    color: color ?? card,
    borderRadius: br,
    border: Border.all(color: border, width: borderWidth),
    boxShadow: shadow ? [BoxShadow(color: border, offset: const Offset(4, 4))] : null,
  );

  ThemeData get theme {
    final scheme = ColorScheme.fromSeed(
      seedColor: accent,
      primary: accent,
      onPrimary: onAccent,
      surface: card,
      onSurface: dark,
    );
    final shape = RoundedRectangleBorder(
      borderRadius: br,
      side: BorderSide(color: border, width: borderWidth),
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      fontFamily: font,
      scaffoldBackgroundColor: bg,
      dialogTheme: DialogThemeData(backgroundColor: card, shape: shape),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: accent,
          foregroundColor: onAccent,
          disabledBackgroundColor: dark.withValues(alpha: 0.12),
          minimumSize: const Size(64, 52),
          textStyle: text(18),
          shape: shape,
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(foregroundColor: dark, textStyle: text(18)),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: dark,
        contentTextStyle: text(18, color: Colors.white),
      ),
    );
  }
}

/// Neutral theme for the parent and setup screens.
ThemeData parentTheme(Brightness b) => ThemeData(
  useMaterial3: true,
  colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF00796B), brightness: b),
);

/// The kid's background: drawn to match the theme (pixel sky, hazard
/// stripes, hearts and castle wall, or rainbow).
class KidBackground extends StatelessWidget {
  final KidTheme theme;
  final Widget child;
  const KidBackground({super.key, required this.theme, required this.child});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: switch (theme.id) {
        'construction' => _HazardPainter(theme),
        'princess' => _PrincessPainter(theme),
        'unicorn' => _UnicornPainter(theme),
        _ => _PixelPainter(theme),
      },
      child: child,
    );
  }
}

class _PixelPainter extends CustomPainter {
  final KidTheme t;
  _PixelPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = t.bg);
    const px = 16.0;
    final cloud = Paint()..color = Colors.white.withValues(alpha: 0.85);
    // Blocky clouds at fixed spots.
    for (final (fx, fy) in const [(0.08, 0.1), (0.55, 0.05), (0.8, 0.22), (0.3, 0.3)]) {
      final x = (size.width * fx / px).floor() * px;
      final y = (size.height * fy / px).floor() * px;
      for (final (cx, cy, w) in const [(1, 0, 3), (0, 1, 6), (2, -1, 2)]) {
        canvas.drawRect(Rect.fromLTWH(x + cx * px, y + cy * px, w * px, px), cloud);
      }
    }
    // Grass and dirt blocks along the bottom.
    final top = size.height - px * 3;
    canvas.drawRect(Rect.fromLTWH(0, top, size.width, px), Paint()..color = t.accent);
    canvas.drawRect(Rect.fromLTWH(0, top + px, size.width, px * 2), Paint()..color = const Color(0xFF8B5A2B));
    final speck = Paint()..color = const Color(0xFF6B4220);
    for (var x = 0.0; x < size.width; x += px * 2) {
      canvas.drawRect(Rect.fromLTWH(x + ((x / px) % 3) * 4, top + px * 1.5, px / 2, px / 2), speck);
      canvas.drawRect(Rect.fromLTWH(x + px, top + px, px / 2, px / 2), Paint()..color = t.accent);
    }
  }

  @override
  bool shouldRepaint(_PixelPainter old) => old.t != t;
}

class _HazardPainter extends CustomPainter {
  final KidTheme t;
  _HazardPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = t.bg);
    const band = 18.0;
    final dark = Paint()..color = t.dark;
    for (final y in [0.0, size.height - band]) {
      canvas.save();
      canvas.clipRect(Rect.fromLTWH(0, y, size.width, band));
      for (var x = -band * 2; x < size.width + band; x += band * 2) {
        canvas.drawPath(
          Path()
            ..moveTo(x, y + band)
            ..lineTo(x + band, y)
            ..lineTo(x + band * 2, y)
            ..lineTo(x + band, y + band)
            ..close(),
          dark,
        );
      }
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_HazardPainter old) => old.t != t;
}

/// Pink with soft polka dots, little hearts and a scalloped castle-wall edge.
class _PrincessPainter extends CustomPainter {
  final KidTheme t;
  _PrincessPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = t.bg);
    final dot = Paint()..color = Colors.white.withValues(alpha: 0.55);
    const gap = 44.0;
    for (var y = 0.0, row = 0; y < size.height; y += gap, row++) {
      for (var x = (row.isOdd ? gap / 2 : 0.0); x < size.width; x += gap) {
        canvas.drawCircle(Offset(x, y), 5, dot);
      }
    }
    final heart = Paint()..color = t.accent.withValues(alpha: 0.18);
    for (final (fx, fy, r) in const [
      (0.1, 0.18, 22.0),
      (0.85, 0.12, 28.0),
      (0.7, 0.55, 18.0),
      (0.2, 0.75, 26.0),
    ]) {
      final c = Offset(size.width * fx, size.height * fy);
      final p = Path()
        ..moveTo(c.dx, c.dy + r * 0.9)
        ..cubicTo(c.dx - r * 1.4, c.dy, c.dx - r * 0.6, c.dy - r, c.dx, c.dy - r * 0.35)
        ..cubicTo(c.dx + r * 0.6, c.dy - r, c.dx + r * 1.4, c.dy, c.dx, c.dy + r * 0.9)
        ..close();
      canvas.drawPath(p, heart);
    }
    // Castle-wall battlements along the bottom.
    const h = 26.0, w = 24.0;
    final wall = Paint()..color = t.accent.withValues(alpha: 0.35);
    canvas.drawRect(Rect.fromLTWH(0, size.height - h, size.width, h), wall);
    for (var x = 0.0; x < size.width; x += w * 2) {
      canvas.drawRect(Rect.fromLTWH(x, size.height - h - 12, w, 12), wall);
    }
  }

  @override
  bool shouldRepaint(_PrincessPainter old) => old.t != t;
}

/// Lavender sky with a rainbow and sparkly stars.
class _UnicornPainter extends CustomPainter {
  final KidTheme t;
  _UnicornPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFE4D9FF), Color(0xFFFDE2F3), Color(0xFFD6F5EE)],
        ).createShader(rect),
    );
    // Rainbow arc rising from the bottom right corner.
    const bands = [
      Color(0xFFFF8FAB),
      Color(0xFFFFC971),
      Color(0xFFFFF27A),
      Color(0xFF9BE59B),
      Color(0xFF8EC5FF),
      Color(0xFFC3A6FF),
    ];
    final r0 = size.shortestSide * 0.55;
    final centre = Offset(size.width, size.height);
    for (final (i, c) in bands.indexed) {
      canvas.drawCircle(
        centre,
        r0 - i * 14,
        Paint()
          ..color = c.withValues(alpha: 0.55)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 14,
      );
    }
    final star = Paint()..color = Colors.white.withValues(alpha: 0.9);
    for (final (fx, fy, r) in const [
      (0.08, 0.1, 9.0),
      (0.4, 0.06, 6.0),
      (0.62, 0.2, 10.0),
      (0.9, 0.08, 7.0),
      (0.25, 0.4, 6.0),
      (0.12, 0.7, 8.0),
    ]) {
      final c = Offset(size.width * fx, size.height * fy);
      final p = Path()
        ..moveTo(c.dx, c.dy - r)
        ..quadraticBezierTo(c.dx, c.dy, c.dx + r, c.dy)
        ..quadraticBezierTo(c.dx, c.dy, c.dx, c.dy + r)
        ..quadraticBezierTo(c.dx, c.dy, c.dx - r, c.dy)
        ..quadraticBezierTo(c.dx, c.dy, c.dx, c.dy - r)
        ..close();
      canvas.drawPath(p, star);
    }
  }

  @override
  bool shouldRepaint(_UnicornPainter old) => old.t != t;
}
