import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

/// A photo of something a child made for a challenge. Photos stay on the
/// device that took them; they are not synced.
class ChallengePhoto {
  final String kid, path, text, cat;
  final DateTime when;
  const ChallengePhoto({
    required this.kid,
    required this.path,
    required this.text,
    required this.cat,
    required this.when,
  });

  Map<String, dynamic> toJson() => {
    'kid': kid,
    'path': path,
    'text': text,
    'cat': cat,
    'when': when.toIso8601String(),
  };
  factory ChallengePhoto.fromJson(Map<String, dynamic> j) => ChallengePhoto(
    kid: j['kid'] as String? ?? '',
    path: j['path'] as String? ?? '',
    text: j['text'] as String? ?? '',
    cat: j['cat'] as String? ?? '',
    when: DateTime.tryParse(j['when'] as String? ?? '') ?? DateTime.now(),
  );
}

/// The gallery of challenge photos on this device.
class Photos {
  static const _key = 'kids_hub_photos_v1';

  /// Photos need a camera and files; not on the web build.
  static bool get supported => !kIsWeb;

  static Future<List<ChallengePhoto>> _all() async {
    final raw = (await SharedPreferences.getInstance()).getString(_key);
    if (raw == null) return [];
    return [for (final p in jsonDecode(raw) as List) ChallengePhoto.fromJson((p as Map).cast())];
  }

  static Future<void> _save(List<ChallengePhoto> all) async =>
      (await SharedPreferences.getInstance()).setString(_key, jsonEncode([for (final p in all) p.toJson()]));

  /// [kid]'s photos, newest first, leaving out any whose file has gone.
  static Future<List<ChallengePhoto>> of(String kid) async => [
    for (final p in (await _all()).reversed)
      if (p.kid == kid && File(p.path).existsSync()) p,
  ];

  /// Opens the camera (or the photo library, when [camera] is false) and
  /// keeps the picture for [c]. Null when nothing was taken.
  static Future<ChallengePhoto?> take(String kid, Challenge c, {bool camera = true}) async {
    final x = await ImagePicker().pickImage(
      source: camera ? ImageSource.camera : ImageSource.gallery,
      maxWidth: 1600,
      maxHeight: 1600,
      imageQuality: 80,
    );
    if (x == null) return null;
    final dir = Directory('${(await getApplicationDocumentsDirectory()).path}/challenge_photos');
    await dir.create(recursive: true);
    final when = DateTime.now();
    final file = await File(x.path).copy('${dir.path}/${kid}_${when.millisecondsSinceEpoch}.jpg');
    final p = ChallengePhoto(kid: kid, path: file.path, text: c.text, cat: c.cat, when: when);
    await _save([...await _all(), p]);
    return p;
  }

  static Future<void> delete(ChallengePhoto p) async {
    await _save([
      for (final x in await _all())
        if (x.path != p.path) x,
    ]);
    try {
      await File(p.path).delete();
    } catch (_) {}
  }
}
