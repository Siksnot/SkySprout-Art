import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../config.dart';
import '../models.dart';
import '../push.dart';
import '../sync.dart';
import '../themes.dart';
import '../widgets/common.dart';
import '../widgets/hub_menu.dart';
import 'children_screen.dart';

/// The children and the parent PIN. On first run ([onCreate] set) it starts
/// a new family; from the parent screens it is Settings, which also shows
/// the login and the family code.
class SetupScreen extends StatefulWidget {
  /// First run: called with the children and the chosen PIN.
  final Future<void> Function(List<Child> children, String pin)? onCreate;
  const SetupScreen({super.key, this.onCreate});

  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  List<Child> _children = [];
  final _pin = TextEditingController();
  bool _init = false;
  bool _busy = false;

  bool get _firstRun => widget.onCreate != null;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_init) return;
    _init = true;
    if (!_firstRun) _children = List.of(AppScope.read(context).data?.family.children ?? const []);
  }

  @override
  void dispose() {
    _pin.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final pin = _pin.text.trim();
    if (_children.isEmpty) {
      showResult(context, 'Add at least one child.');
      return;
    }
    // In Settings an empty PIN box keeps the current PIN.
    if ((_firstRun || pin.isNotEmpty) && !AppConfig.validPin(pin)) {
      showResult(context, 'Choose a parent PIN of 4 to 8 digits.');
      return;
    }
    setState(() => _busy = true);
    try {
      if (_firstRun) {
        await widget.onCreate!(_children, pin);
      } else {
        final err = await AppScope.read(context).saveFamily(_children, pin: pin.isEmpty ? null : pin);
        if (!mounted) return;
        if (err != null) {
          showResult(context, err);
        } else {
          Navigator.pop(context);
        }
      }
    } catch (e) {
      if (mounted) showResult(context, e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = _firstRun ? null : AppScope.of(context);
    final code = state?.familyCode;
    return Theme(
      data: parentTheme(MediaQuery.platformBrightnessOf(context)),
      child: Builder(
        builder: (context) {
          return Scaffold(
            appBar: AppBar(
              title: Text(_firstRun ? 'Set up your family' : 'Settings'),
              actions: [TextButton(onPressed: _busy ? null : _save, child: const Text('Save'))],
            ),
            body: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 640),
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    if (_firstRun)
                      const Text(
                        'Add your children and pick a theme for each, then choose a parent PIN. '
                        'You can change these later in the parent screens.',
                      ),
                    const _H('Children'),
                    ChildrenSection(value: _children, onChanged: (list) => setState(() => _children = list)),
                    const _H('Grown-ups'),
                    TextField(
                      controller: _pin,
                      obscureText: true,
                      keyboardType: TextInputType.number,
                      maxLength: 8,
                      decoration: InputDecoration(
                        labelText: _firstRun ? 'Parent PIN' : 'New parent PIN',
                        helperText: _firstRun
                            ? '4 to 8 digits. Only someone with the PIN can open the parent screens.'
                            : 'Leave empty to keep the current PIN. It changes on every device.',
                        helperMaxLines: 2,
                      ),
                    ),
                    if (state != null)
                      SwitchListTile(
                        contentPadding: EdgeInsets.zero,
                        title: const Text('Grown-ups approve chores'),
                        subtitle: const Text(
                          'Points for a ticked chore land once a grown-up approves it '
                          'in the parent portal. Turn off to give points straight away.',
                        ),
                        value: state.data?.snap.approveChores ?? true,
                        onChanged: (v) async {
                          final err = await state.setApproveChores(v);
                          if (context.mounted) showResult(context, err);
                        },
                      ),
                    if (state != null && state.config.mode == DataMode.cloud) ...[
                      const _H('This device'),
                      SegmentedButton<DeviceRole>(
                        segments: const [
                          ButtonSegment(
                            value: DeviceRole.parent,
                            icon: Icon(Icons.phone_android_rounded),
                            label: Text('Parent\'s phone'),
                          ),
                          ButtonSegment(
                            value: DeviceRole.kids,
                            icon: Icon(Icons.tablet_android_rounded),
                            label: Text('Kids\' tablet'),
                          ),
                        ],
                        selected: {?state.config.role},
                        emptySelectionAllowed: true,
                        onSelectionChanged: (v) {
                          if (v.isNotEmpty) state.setRole(v.first);
                        },
                      ),
                      if (state.config.role == DeviceRole.parent)
                        if (!pushAvailable)
                          const ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: Icon(Icons.notifications_off_outlined),
                            title: Text('Notifications aren\'t switched on in this copy of the app'),
                            subtitle: Text('See "Notifications" in the README.'),
                          )
                        else
                          for (final (alert, title, text) in [
                            (
                              Alert.approve,
                              'Chores to approve',
                              'When a child ticks a chore or finishes a routine.',
                            ),
                            (Alert.shop, 'Shop', 'When a child buys a reward, or wants one handed over.'),
                          ])
                            SwitchListTile(
                              contentPadding: EdgeInsets.zero,
                              secondary: const Icon(Icons.notifications_outlined),
                              title: Text(title),
                              subtitle: Text(text),
                              value: state.config.alerts.contains(alert),
                              onChanged: (on) => state.setAlerts(
                                on
                                    ? {...state.config.alerts, alert}
                                    : ({...state.config.alerts}..remove(alert)),
                              ),
                            ),
                    ],
                    const SizedBox(height: 24),
                    FilledButton(onPressed: _busy ? null : _save, child: Text(_firstRun ? 'Start' : 'Save')),
                    if (state?.auth != null) ...[
                      const _H('Account'),
                      Card(
                        child: Column(
                          children: [
                            ListTile(
                              leading: const Icon(Icons.account_circle_outlined),
                              title: Text(state!.auth!.email ?? 'Signed in'),
                              subtitle: const Text('Signed in on this device'),
                            ),
                            if (code != null)
                              ListTile(
                                leading: const Icon(Icons.group_add_outlined),
                                title: Text(
                                  showCode(code),
                                  style: const TextStyle(
                                    fontSize: 20,
                                    letterSpacing: 2,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                subtitle: const Text(
                                  'Family code. Another grown-up makes their own login, then joins with this code. '
                                  'For the kids\' tablets, just sign in with your login.',
                                ),
                                trailing: IconButton(
                                  tooltip: 'Copy',
                                  icon: const Icon(Icons.copy),
                                  onPressed: () {
                                    Clipboard.setData(ClipboardData(text: showCode(code)));
                                    showResult(context, null, ok: 'Family code copied');
                                  },
                                ),
                              ),
                            ListTile(
                              leading: const Icon(Icons.logout),
                              title: const Text('Sign out of this device'),
                              onTap: () => signOutWithCheck(context),
                            ),
                          ],
                        ),
                      ),
                    ],
                    const SizedBox(height: 24),
                    const _Version(),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _H extends StatelessWidget {
  final String text;
  const _H(this.text);

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(0, 24, 0, 8),
    child: Text(
      text,
      style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Theme.of(context).colorScheme.primary),
    ),
  );
}

/// "Version 1.0.1 (build 2)", from pubspec.yaml, so it's clear which build is on a device.
class _Version extends StatelessWidget {
  const _Version();

  @override
  Widget build(BuildContext context) => FutureBuilder<PackageInfo>(
    future: PackageInfo.fromPlatform(),
    builder: (context, snap) => Text(
      snap.hasData ? 'Version ${snap.data!.version} (build ${snap.data!.buildNumber})' : '',
      textAlign: TextAlign.center,
      style: Theme.of(context).textTheme.bodySmall,
    ),
  );
}
