import 'package:flutter/material.dart';

import '../models.dart';
import '../themes.dart';

/// The "Children" part of settings: one row per child with their theme,
/// and a button to add another.
class ChildrenSection extends StatelessWidget {
  final List<Child> value;
  final ValueChanged<List<Child>> onChanged;
  const ChildrenSection({super.key, required this.value, required this.onChanged});

  Future<void> _edit(BuildContext context, int? index) async {
    final res = await Navigator.push<Object>(
      context,
      MaterialPageRoute(
        builder: (_) => ChildEditor(
          child: index == null ? null : value[index],
          others: [
            for (final (i, c) in value.indexed)
              if (i != index) c,
          ],
        ),
      ),
    );
    if (res == null) return;
    final list = List.of(value);
    if (res == ChildEditor.delete && index != null) {
      list.removeAt(index);
    } else if (res is Child) {
      index == null ? list.add(res) : list[index] = res;
    }
    onChanged(list);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (final (i, c) in value.indexed)
          Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: _ThemeDot(theme: KidTheme.byId(c.theme)),
              title: Text(c.name),
              subtitle: Text(
                [
                  if (c.ageNow != null) 'Age ${c.ageNow}',
                  if (c.birthday != null) '🎂 ${_dayMonth(c.birthday!)}',
                  '${KidTheme.byId(c.theme).label} theme',
                ].join(' · '),
              ),
              trailing: const Icon(Icons.edit),
              onTap: () => _edit(context, i),
            ),
          ),
        OutlinedButton.icon(
          onPressed: () => _edit(context, null),
          icon: const Icon(Icons.person_add),
          label: const Text('Add a child'),
        ),
      ],
    );
  }
}

class _ThemeDot extends StatelessWidget {
  final KidTheme theme;
  const _ThemeDot({required this.theme});

  @override
  Widget build(BuildContext context) => Container(
    width: 44,
    height: 44,
    alignment: Alignment.center,
    decoration: BoxDecoration(
      color: theme.bg,
      shape: BoxShape.circle,
      border: Border.all(color: theme.border, width: 2),
    ),
    child: Text(theme.mascot, style: const TextStyle(fontSize: 22)),
  );
}

const _months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
String _dayMonth(DateTime d) => '${d.day} ${_months[d.month - 1]}';

/// Sets up one child: name, birthday (or age) and dashboard theme. Pops a [Child], or
/// [delete].
class ChildEditor extends StatefulWidget {
  /// Null to add a new child.
  final Child? child;

  /// The other children, so a new child gets a theme nobody has yet.
  final List<Child> others;
  const ChildEditor({super.key, this.child, required this.others});

  static const delete = 'delete';

  @override
  State<ChildEditor> createState() => _ChildEditorState();
}

class _ChildEditorState extends State<ChildEditor> {
  late final _name = TextEditingController(text: widget.child?.name ?? '');
  late final _age = TextEditingController(text: widget.child?.ageNow?.toString() ?? '');
  late DateTime? _birthday = widget.child?.birthday;

  Future<void> _pickBirthday() async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: _birthday ?? DateTime(now.year - 6, now.month, now.day),
      firstDate: DateTime(now.year - 25),
      lastDate: now,
      helpText: 'Birthday',
    );
    if (d == null) return;
    setState(() {
      _birthday = d;
      _age.text = Child(id: '', name: '', birthday: d, theme: '').ageNow.toString();
    });
  }

  late String _theme = widget.child?.theme ?? _unusedTheme();

  String _unusedTheme() {
    final used = {for (final c in widget.others) c.theme};
    return KidTheme.all.firstWhere((t) => !used.contains(t.id), orElse: () => KidTheme.quest).id;
  }

  @override
  void dispose() {
    for (final c in [_name, _age]) {
      c.dispose();
    }
    super.dispose();
  }

  String? get _error {
    if (_name.text.trim().isEmpty) return 'Add a name';
    final name = _name.text.trim().toLowerCase();
    if (widget.others.any((c) => c.name.toLowerCase() == name)) {
      return 'You already have a child called ${_name.text.trim()}';
    }
    final age = _age.text.trim();
    if (age.isNotEmpty && (int.tryParse(age) == null || int.parse(age) < 0 || int.parse(age) > 25)) {
      return 'Age should be a number';
    }
    return null;
  }

  void _save() {
    final err = _error;
    if (err != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
      return;
    }
    Navigator.pop(
      context,
      Child(
        id: widget.child?.id ?? newId('k'),
        name: _name.text.trim(),
        age: int.tryParse(_age.text.trim()),
        birthday: _birthday,
        theme: _theme,
      ),
    );
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Remove ${widget.child!.name}?'),
        content: const Text('Their chores, points and rewards are deleted too.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Remove')),
        ],
      ),
    );
    if (ok == true && mounted) Navigator.pop(context, ChildEditor.delete);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.child == null ? 'Add a child' : 'Edit ${widget.child!.name}'),
        actions: [TextButton(onPressed: _save, child: const Text('Save'))],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 640),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    flex: 3,
                    child: TextField(
                      controller: _name,
                      textCapitalization: TextCapitalization.words,
                      decoration: const InputDecoration(labelText: 'Name'),
                      onChanged: (_) => setState(() {}),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextField(
                      controller: _age,
                      enabled: _birthday == null,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Age'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Text('🎂', style: TextStyle(fontSize: 26)),
                title: Text(
                  _birthday == null
                      ? 'Add birthday'
                      : 'Birthday: ${_birthday!.day} ${_months[_birthday!.month - 1]} ${_birthday!.year}',
                ),
                subtitle: const Text('Counts down on the kids\' boards, and keeps the age up to date'),
                trailing: _birthday == null
                    ? const Icon(Icons.edit_calendar)
                    : IconButton(
                        tooltip: 'Remove birthday',
                        icon: const Icon(Icons.close),
                        onPressed: () => setState(() => _birthday = null),
                      ),
                onTap: _pickBirthday,
              ),
              const SizedBox(height: 24),
              Text('Dashboard theme', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              LayoutBuilder(
                builder: (context, c) {
                  final cols = c.maxWidth > 520 ? 4 : 2;
                  return GridView.count(
                    crossAxisCount: cols,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 0.8,
                    children: [
                      for (final t in KidTheme.all)
                        ThemePreview(
                          theme: t,
                          name: _name.text.trim().isEmpty ? 'Your' : '${_name.text.trim()}\'s',
                          selected: t.id == _theme,
                          onTap: () => setState(() => _theme = t.id),
                        ),
                    ],
                  );
                },
              ),
              const SizedBox(height: 16),
              FilledButton(onPressed: _save, child: const Text('Save')),
              if (widget.child != null && widget.others.isNotEmpty) ...[
                const SizedBox(height: 8),
                TextButton.icon(
                  onPressed: _delete,
                  icon: const Icon(Icons.delete_outline),
                  label: Text('Remove ${widget.child!.name}'),
                ),
              ],
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}

/// A small picture of a theme: its background, mascot and board title.
class ThemePreview extends StatelessWidget {
  final KidTheme theme;
  final String name;
  final bool selected;
  final VoidCallback onTap;
  const ThemePreview({
    super.key,
    required this.theme,
    required this.name,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final t = theme;
    final ring = Theme.of(context).colorScheme.primary;
    return Semantics(
      selected: selected,
      button: true,
      label: '${t.label} theme',
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: selected ? ring : Colors.transparent, width: 3),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: KidBackground(
              theme: t,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 10, 10, 34),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                      decoration: BoxDecoration(
                        color: t.dark,
                        borderRadius: BorderRadius.circular(t.radius.clamp(0, 10)),
                      ),
                      child: Text(
                        '${t.boardEmoji} $name ${t.boardName}',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: t.text(11, color: Colors.white),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: t.box(shadow: false),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(t.listName, maxLines: 1, overflow: TextOverflow.ellipsis, style: t.text(9)),
                          const SizedBox(height: 4),
                          Container(height: 6, color: t.accent),
                        ],
                      ),
                    ),
                    const Spacer(),
                    Row(
                      children: [
                        Text(t.mascot, style: const TextStyle(fontSize: 26)),
                        const SizedBox(width: 6),
                        Expanded(
                          child: FittedBox(
                            fit: BoxFit.scaleDown,
                            alignment: Alignment.centerLeft,
                            child: Text(t.label, style: t.text(15)),
                          ),
                        ),
                        if (selected) Icon(Icons.check_circle, color: ring),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
