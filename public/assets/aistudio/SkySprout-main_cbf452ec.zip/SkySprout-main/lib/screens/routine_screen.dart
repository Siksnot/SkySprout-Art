import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models.dart';
import '../themes.dart';
import '../widgets/celebrate.dart';
import '../widgets/common.dart';

/// Walks a child through a routine one step at a time, with a timer for
/// each step that has minutes. At the end the routine goes to a grown-up
/// to check (or the points land, with approvals off).
class RoutineScreen extends StatefulWidget {
  final String kid, routineId;
  const RoutineScreen({super.key, required this.kid, required this.routineId});

  @override
  State<RoutineScreen> createState() => _RoutineScreenState();
}

class _RoutineScreenState extends State<RoutineScreen> {
  int _step = 0;

  /// Seconds left on this step's timer, and whether it is counting down.
  int _left = 0;
  bool _running = false;
  Timer? _tick;
  bool _finished = false, _busy = false, _ready = false;

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  Routine? _routine(BuildContext context) {
    for (final r in AppScope.of(context).data?.routinesFor(widget.kid) ?? const <Routine>[]) {
      if (r.id == widget.routineId) return r;
    }
    return null;
  }

  void _startStep(RoutineStep s) {
    _tick?.cancel();
    setState(() {
      _left = s.minutes * 60;
      _running = false;
    });
  }

  void _toggleTimer() {
    if (_running) {
      _tick?.cancel();
      setState(() => _running = false);
      return;
    }
    setState(() => _running = true);
    _tick = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return t.cancel();
      setState(() => _left--);
      if (_left <= 0) {
        t.cancel();
        setState(() => _running = false);
      }
    });
  }

  Future<void> _next(Routine r) async {
    if (_step < r.steps.length - 1) {
      celebrate(context);
      setState(() => _step++);
      _startStep(r.steps[_step]);
      return;
    }
    setState(() => _busy = true);
    final state = AppScope.read(context);
    final approve = state.data?.snap.approveChores ?? true;
    final err = await state.finishRoutine(widget.kid, r.id);
    if (!mounted) return;
    setState(() => _busy = false);
    if (err != null) return showResult(context, err);
    _tick?.cancel();
    setState(() => _finished = true);
    celebrate(
      context,
      big: true,
      message: approve
          ? '${r.name} routine done!\nA grown-up will check it ⏳'
          : '${r.name} routine done!${r.points > 0 ? '\n+${r.points} ⭐' : ''}',
    );
  }

  @override
  Widget build(BuildContext context) {
    final kt = KidTheme.of(widget.kid);
    final r = _routine(context);
    final narrow = MediaQuery.sizeOf(context).width < 600;
    return Theme(
      data: kt.theme,
      child: Scaffold(
        body: KidBackground(
          theme: kt,
          child: SafeArea(
            child: r == null || r.steps.isEmpty
                ? const Center(child: CircularProgressIndicator())
                : _body(context, kt, r, narrow),
          ),
        ),
      ),
    );
  }

  Widget _body(BuildContext context, KidTheme kt, Routine r, bool narrow) {
    // The first step's timer, once the routine has loaded.
    if (!_ready) {
      _ready = true;
      _left = r.steps.first.minutes * 60;
    }
    final step = r.steps[_step.clamp(0, r.steps.length - 1)];
    final total = step.minutes * 60;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Container(
            decoration: kt.box(),
            padding: const EdgeInsets.fromLTRB(4, 8, 16, 8),
            child: Row(
              children: [
                IconButton(
                  iconSize: 30,
                  color: kt.dark,
                  tooltip: 'Back',
                  icon: const Icon(Icons.arrow_back_rounded),
                  onPressed: () => Navigator.maybePop(context),
                ),
                Text(r.emoji, style: TextStyle(fontSize: narrow ? 26 : 34)),
                const SizedBox(width: 10),
                Expanded(child: Text('${r.name} routine', style: kt.text(narrow ? 22 : 30))),
              ],
            ),
          ),
        ),
        // One block per step.
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            children: [
              for (var i = 0; i < r.steps.length; i++)
                Expanded(
                  child: Container(
                    height: 16,
                    margin: EdgeInsets.only(right: i == r.steps.length - 1 ? 0 : 6),
                    decoration: BoxDecoration(
                      color: _finished || i < _step
                          ? kt.accent
                          : i == _step
                          ? kt.accent.withValues(alpha: 0.45)
                          : Colors.white,
                      border: Border.all(color: kt.border, width: 2),
                      borderRadius: BorderRadius.circular(kt.radius / 3),
                    ),
                  ),
                ),
            ],
          ),
        ),
        Expanded(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 560),
                child: Container(
                  decoration: kt.box(),
                  padding: const EdgeInsets.all(24),
                  child: _finished
                      ? Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Text('🎉', style: TextStyle(fontSize: 80)),
                            Text('All done!', style: kt.text(36)),
                            const SizedBox(height: 20),
                            BigButton(
                              kt: kt,
                              label: 'Back to my board',
                              onTap: () => Navigator.maybePop(context),
                            ),
                          ],
                        )
                      : Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'STEP ${_step + 1} OF ${r.steps.length}',
                              style: kt
                                  .text(15, color: kt.dark.withValues(alpha: 0.7))
                                  .copyWith(letterSpacing: 2),
                            ),
                            const SizedBox(height: 8),
                            Text(step.text, textAlign: TextAlign.center, style: kt.text(narrow ? 32 : 40)),
                            if (step.minutes > 0) ...[
                              const SizedBox(height: 20),
                              GestureDetector(
                                onTap: _toggleTimer,
                                child: SizedBox(
                                  width: 180,
                                  height: 180,
                                  child: CustomPaint(
                                    painter: TimerRing(
                                      total <= 0 ? 0 : _left / total,
                                      kt.accent,
                                      kt.dark.withValues(alpha: 0.12),
                                    ),
                                    child: Center(
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            _left <= 0
                                                ? "Time's up!"
                                                : '${_left ~/ 60}:${(_left % 60).toString().padLeft(2, '0')}',
                                            style: kt.text(_left <= 0 ? 24 : 40),
                                          ),
                                          if (_left > 0)
                                            Text(
                                              _running ? 'Tap to pause' : 'Tap to start',
                                              style: kt.text(14, bold: false),
                                            ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                            const SizedBox(height: 24),
                            BigButton(
                              kt: kt,
                              label: _step == r.steps.length - 1 ? 'Done! Finish ✓' : 'Done! Next step →',
                              onTap: _busy ? null : () => _next(r),
                            ),
                          ],
                        ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class BigButton extends StatelessWidget {
  final KidTheme kt;
  final String label;
  final VoidCallback? onTap;
  const BigButton({super.key, required this.kt, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) => SizedBox(
    width: double.infinity,
    child: Material(
      color: kt.accent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(kt.radius),
        side: BorderSide(color: kt.border, width: 3),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(kt.radius),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 18),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: kt.text(24, color: kt.onAccent),
          ),
        ),
      ),
    ),
  );
}

/// The timer ring: [fraction] of the circle still to go.
class TimerRing extends CustomPainter {
  final double fraction;
  final Color on, off;
  TimerRing(this.fraction, this.on, this.off);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 16
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(rect.deflate(10), 0, math.pi * 2, false, p..color = off);
    canvas.drawArc(rect.deflate(10), -math.pi / 2, math.pi * 2 * fraction.clamp(0, 1), false, p..color = on);
  }

  @override
  bool shouldRepaint(TimerRing old) => old.fraction != fraction;
}
