import 'package:flutter/material.dart';

import '../backend.dart';
import '../models.dart';
import '../widgets/common.dart';

const _purple = Color(0xFF7C4DFF);
const _ink = Color(0xFF1F1F2E);
const _muted = Color(0xFF6B6B80);
const _page = Color(0xFFF1F2F7);

/// Pastel tops for the reward cards, one per slot.
const _tints = [
  Color(0xFFE3F0FD),
  Color(0xFFFCE4EC),
  Color(0xFFFFF1DF),
  Color(0xFFF3E5F5),
  Color(0xFFE8EAF6),
  Color(0xFFFFEBEE),
  Color(0xFFE8F5E9),
  Color(0xFFFFFDE7),
  Color(0xFFE0F7FA),
  Color(0xFFF1F8E9),
];

/// The kids' shop: a grid of reward
/// cards, the kid's own rewards on the side, and orders waiting for parents.
class ShopScreen extends StatelessWidget {
  final String kid;
  const ShopScreen({super.key, required this.kid});

  @override
  Widget build(BuildContext context) {
    final data = AppScope.of(context).data;
    final wide = MediaQuery.sizeOf(context).width >= 900;
    return Theme(
      data: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: _purple)),
      child: Scaffold(
        backgroundColor: _page,
        body: SafeArea(
          child: Column(
            children: [
              const StatusBanner(),
              Expanded(
                child: data == null
                    ? const Center(child: CircularProgressIndicator())
                    : ListView(
                        padding: const EdgeInsets.all(16),
                        children: [
                          _TitleBar(kid: kid, points: data.points(kid)),
                          const SizedBox(height: 12),
                          const _Banner(),
                          const SizedBox(height: 18),
                          if (wide)
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: _Grid(kid: kid, data: data, columns: 2),
                                ),
                                const SizedBox(width: 20),
                                Expanded(
                                  child: _MyRewards(kid: kid, data: data),
                                ),
                              ],
                            )
                          else ...[
                            _MyRewards(kid: kid, data: data),
                            const SizedBox(height: 12),
                            _Grid(
                              kid: kid,
                              data: data,
                              columns: MediaQuery.sizeOf(context).width >= 560 ? 2 : 1,
                            ),
                          ],
                          const SizedBox(height: 16),
                          _Orders(data: data),
                        ],
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

BoxDecoration _card([Color color = Colors.white]) => BoxDecoration(
  color: color,
  borderRadius: BorderRadius.circular(18),
  boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 10, offset: Offset(0, 3))],
);

Widget _heading(IconData icon, String text) => Padding(
  padding: const EdgeInsets.fromLTRB(4, 0, 0, 10),
  child: Row(
    children: [
      Icon(icon, size: 20, color: _ink),
      const SizedBox(width: 8),
      Text(
        text,
        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: _ink),
      ),
    ],
  ),
);

class _Pill extends StatelessWidget {
  final String text;
  final bool active;
  final VoidCallback? onTap;
  const _Pill(this.text, {this.active = true, this.onTap});

  @override
  Widget build(BuildContext context) => Material(
    color: active ? _purple : const Color(0xFFE6E6EC),
    shape: const StadiumBorder(),
    child: InkWell(
      customBorder: const StadiumBorder(),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 11),
        child: Text(
          text,
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: active ? Colors.white : _muted),
        ),
      ),
    ),
  );
}

class _TitleBar extends StatelessWidget {
  final String kid;
  final int points;
  const _TitleBar({required this.kid, required this.points});

  @override
  Widget build(BuildContext context) => Container(
    decoration: _card(),
    padding: const EdgeInsets.fromLTRB(6, 10, 14, 10),
    child: Row(
      children: [
        IconButton(
          tooltip: 'Back',
          icon: const Icon(Icons.arrow_back_rounded, size: 28),
          onPressed: () => Navigator.maybePop(context),
        ),
        const Text('🛍️', style: TextStyle(fontSize: 30)),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            "${nameOf(kid)}'s Shop",
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: _ink),
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
          decoration: const ShapeDecoration(color: _purple, shape: StadiumBorder()),
          child: Text(
            '⭐ $points',
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white),
          ),
        ),
      ],
    ),
  );
}

class _Banner extends StatelessWidget {
  const _Banner();

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.fromLTRB(28, 24, 28, 26),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(18),
      gradient: const LinearGradient(colors: [Color(0xFF8B4DF0), Color(0xFFFF6FB5)]),
    ),
    child: const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Spend your stars! ⭐',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: Colors.white),
        ),
        SizedBox(height: 4),
        Text(
          'Earn stars by doing chores, then treat yourself to something awesome.',
          style: TextStyle(fontSize: 17, color: Colors.white),
        ),
      ],
    ),
  );
}

class _Grid extends StatelessWidget {
  final String kid;
  final HubData data;
  final int columns;
  const _Grid({required this.kid, required this.data, required this.columns});

  @override
  Widget build(BuildContext context) {
    final shop = data.shop;
    final rows = <Widget>[];
    for (var i = 0; i < shop.length; i += columns) {
      rows.add(
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                for (var j = 0; j < columns; j++) ...[
                  if (j > 0) const SizedBox(width: 12),
                  Expanded(
                    child: i + j < shop.length
                        ? _RewardCard(kid: kid, reward: shop[i + j], points: data.points(kid))
                        : const SizedBox(),
                  ),
                ],
              ],
            ),
          ),
        ),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _heading(Icons.storefront_outlined, 'All rewards'),
        if (shop.isEmpty)
          Container(
            decoration: _card(),
            padding: const EdgeInsets.all(24),
            child: const Text('The shop is closed right now.', style: TextStyle(fontSize: 18)),
          ),
        ...rows,
      ],
    );
  }
}

class _RewardCard extends StatelessWidget {
  final String kid;
  final Reward reward;
  final int points;
  const _RewardCard({required this.kid, required this.reward, required this.points});

  @override
  Widget build(BuildContext context) {
    final cost = reward.cost[kid] ?? 0;
    final canBuy = points >= cost;
    final tint = _tints[reward.key.codeUnits.fold(0, (a, b) => a + b) % _tints.length];
    return Container(
      decoration: _card(),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            color: tint,
            height: 120,
            alignment: Alignment.center,
            child: Text(reward.emoji.isEmpty ? '🎁' : reward.emoji, style: const TextStyle(fontSize: 64)),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 16, 16, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  reward.category.toUpperCase(),
                  style: const TextStyle(
                    fontSize: 12,
                    letterSpacing: 1,
                    fontWeight: FontWeight.w700,
                    color: _muted,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  reward.name,
                  style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: _ink),
                ),
                if (reward.desc.isNotEmpty)
                  Text(reward.desc, style: const TextStyle(fontSize: 15, color: _muted)),
                const SizedBox(height: 14),
                Row(
                  children: [
                    const Text('⭐', style: TextStyle(fontSize: 22)),
                    const SizedBox(width: 8),
                    Text(
                      '$cost',
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: _ink),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: _Pill(
                            canBuy ? 'Buy now' : 'Need ${cost - points} more',
                            active: canBuy,
                            onTap: canBuy ? () => _buy(context, cost) : null,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Builder(
                  builder: (context) {
                    final saving = AppScope.of(context).data?.snap.saving[kid] == reward.key;
                    return Align(
                      alignment: Alignment.centerLeft,
                      child: TextButton(
                        style: TextButton.styleFrom(
                          foregroundColor: _ink,
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          visualDensity: VisualDensity.compact,
                        ),
                        onPressed: () async {
                          final err = await AppScope.read(context).setSaving(kid, saving ? null : reward.key);
                          if (context.mounted) {
                            showResult(
                              context,
                              err,
                              ok: saving
                                  ? 'Stopped saving for ${reward.name}'
                                  : '🐷 Saving for ${reward.name}! Watch your board fill up.',
                            );
                          }
                        },
                        child: Text(
                          saving ? '🐷 Saving for this ✓' : '🐷 Save for this',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: saving ? FontWeight.w800 : FontWeight.w600,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _buy(BuildContext context, int cost) async {
    if (!await confirm(
      context,
      'Buy ${reward.name}?',
      'It costs $cost ⭐. You will have ${points - cost} ⭐ left.',
      yes: 'Yes, buy it!',
    )) {
      return;
    }
    if (!context.mounted) return;
    final err = await AppScope.read(context).buy(kid, reward);
    if (context.mounted) showResult(context, err, ok: '🎉 You bought ${reward.name}! It\'s in My Rewards.');
  }
}

class _MyRewards extends StatelessWidget {
  final String kid;
  final HubData data;
  const _MyRewards({required this.kid, required this.data});

  @override
  Widget build(BuildContext context) {
    final owned = data.owned(kid);
    final t = data.timer(kid);
    final timerBusy = t != null && (t.running || t.paused);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _heading(Icons.backpack_outlined, 'My Rewards'),
        Container(
          decoration: _card(),
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(
            children: [
              if (timerBusy)
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                  child: Ticker(
                    builder: (_) => Text(
                      '⏱️ Screen time ${formatLeft(t.left() ?? Duration.zero)}${t.paused ? ' (paused)' : ' left'}',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: _purple),
                    ),
                  ),
                ),
              if (owned.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(18),
                  child: Text('Nothing yet. Buy something from the shop!', style: TextStyle(color: _muted)),
                ),
              for (final r in owned)
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
                  child: Row(
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: const Color(0xFFE8F0FE),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(r.emoji.isEmpty ? '🎁' : r.emoji, style: const TextStyle(fontSize: 28)),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              r.name,
                              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: _ink),
                            ),
                            Text(
                              r.minutes > 0 ? '${r.minutes} min · tap to start' : 'Ask a grown-up',
                              style: const TextStyle(color: _muted),
                            ),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            '×${r.own[kid]}',
                            style: const TextStyle(fontWeight: FontWeight.w700, color: _ink),
                          ),
                          const SizedBox(height: 2),
                          _Pill(
                            r.minutes > 0 ? (timerBusy ? 'Timer on' : 'Start') : 'Use',
                            active: !(r.minutes > 0 && timerBusy),
                            onTap: r.minutes > 0 && timerBusy ? null : () => _use(context, r),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _use(BuildContext context, Reward r) async {
    final body = r.minutes > 0
        ? 'This starts ${r.minutes} minutes of screen time now.'
        : 'A grown-up will see it in their orders and give you ${r.name}.';
    if (!await confirm(context, 'Use ${r.name}?', body, yes: 'Use it!')) return;
    if (!context.mounted) return;
    final err = await AppScope.read(context).useReward(kid, r);
    if (context.mounted) showResult(context, err, ok: 'Enjoy! ${r.emoji}');
  }
}

class _Orders extends StatelessWidget {
  final HubData data;
  const _Orders({required this.data});

  @override
  Widget build(BuildContext context) {
    final waiting = data.owed.where((o) => !o.done).toList();
    return Container(
      decoration: _card(const Color(0xFFF8F8FC)),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _heading(Icons.inventory_2_outlined, 'Orders to deliver (parents)'),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFE9EBF5),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.lock_outline, color: _muted),
                const SizedBox(height: 6),
                if (waiting.isEmpty) const Text('Nothing waiting to be handed over.'),
                for (final o in waiting)
                  Padding(padding: const EdgeInsets.only(top: 4), child: Text('• ${o.summary}')),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
