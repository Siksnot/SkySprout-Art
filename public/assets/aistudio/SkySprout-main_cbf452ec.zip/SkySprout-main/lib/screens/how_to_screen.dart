import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../catalog.dart';
import '../models.dart';
import '../themes.dart';
import 'routine_screen.dart';

/// "Show me how": a challenge's steps one at a time, each with its picture,
/// after a page of what you need.
class HowToScreen extends StatefulWidget {
  final String kid;
  final Challenge challenge;
  final HowTo howTo;
  const HowToScreen({super.key, required this.kid, required this.challenge, required this.howTo});

  @override
  State<HowToScreen> createState() => _HowToScreenState();
}

class _HowToScreenState extends State<HowToScreen> {
  final _pages = PageController();
  int _page = 0;

  @override
  void dispose() {
    _pages.dispose();
    super.dispose();
  }

  void _go(int to) =>
      _pages.animateToPage(to, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);

  @override
  Widget build(BuildContext context) {
    final kt = KidTheme.of(widget.kid);
    final h = widget.howTo;
    final cat = catOf(widget.challenge.cat);
    final narrow = MediaQuery.sizeOf(context).width < 600;
    final count = h.steps.length + 1;
    return Theme(
      data: kt.theme,
      child: Scaffold(
        body: KidBackground(
          theme: kt,
          child: SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Container(
                    decoration: kt.box(),
                    padding: const EdgeInsets.fromLTRB(4, 8, 16, 8),
                    child: Row(
                      children: [
                        IconButton(
                          iconSize: 30,
                          color: kt.dark,
                          tooltip: 'Back',
                          icon: const Icon(Icons.arrow_back_rounded),
                          onPressed: () => Navigator.maybePop(context),
                        ),
                        Text(cat.emoji, style: TextStyle(fontSize: narrow ? 24 : 30)),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            h.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: kt.text(narrow ? 18 : 24),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                // A dot per page.
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    for (var i = 0; i < count; i++)
                      Container(
                        width: i == _page ? 22 : 12,
                        height: 12,
                        margin: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: i == _page ? kt.accent : Colors.white,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: kt.border, width: 2),
                        ),
                      ),
                  ],
                ),
                Expanded(
                  child: PageView(
                    controller: _pages,
                    onPageChanged: (p) => setState(() => _page = p),
                    children: [
                      _page0(kt, h),
                      for (final (i, s) in h.steps.indexed) _step(kt, cat, i + 1, s, narrow),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 600),
                    child: Row(
                      children: [
                        if (_page > 0) ...[
                          Expanded(
                            child: BigButton(kt: kt, label: '← Back', onTap: () => _go(_page - 1)),
                          ),
                          const SizedBox(width: 12),
                        ],
                        Expanded(
                          flex: 2,
                          child: BigButton(
                            kt: kt,
                            label: _page == 0
                                ? "Let's go! →"
                                : _page == count - 1
                                ? 'All done ✓'
                                : 'Next step →',
                            onTap: _page == count - 1
                                ? () => Navigator.maybePop(context)
                                : () => _go(_page + 1),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _card(KidTheme kt, Widget child) => Center(
    child: SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 640),
        child: Container(decoration: kt.box(), padding: const EdgeInsets.all(22), child: child),
      ),
    ),
  );

  Widget _page0(KidTheme kt, HowTo h) => _card(
    kt,
    Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("You'll need", style: kt.text(28)),
        const SizedBox(height: 10),
        for (final n in h.need)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('•  ', style: kt.text(22)),
                Expanded(child: Text(n, style: kt.text(21, bold: false))),
              ],
            ),
          ),
        const SizedBox(height: 12),
        Text(
          [
            '${h.steps.length} steps',
            if (widget.challenge.minutes > 0) 'about ${widget.challenge.minutes} minutes',
            if (h.age > 0) 'ages ${h.age}+',
          ].join(' · '),
          style: kt.text(16, color: kt.dark.withValues(alpha: 0.7)),
        ),
      ],
    ),
  );

  Widget _step(KidTheme kt, ChallengeCat cat, int n, HowStep s, bool narrow) => _card(
    kt,
    Column(
      children: [
        AspectRatio(
          aspectRatio: 4 / 3,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(kt.radius / 2),
            child: FutureBuilder<Uint8List?>(
              future: Pictures.get(s.image),
              builder: (_, snap) => snap.data != null
                  ? Container(
                      color: Colors.white,
                      child: Image.memory(snap.data!, fit: BoxFit.contain),
                    )
                  : _placeholder(cat, n, loading: snap.connectionState != ConnectionState.done),
            ),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _Number(n),
            const SizedBox(width: 14),
            Expanded(child: Text(s.text, style: kt.text(narrow ? 22 : 26))),
          ],
        ),
      ],
    ),
  );

  Widget _placeholder(ChallengeCat cat, int n, {required bool loading}) => Container(
    color: Color(cat.color).withValues(alpha: 0.15),
    alignment: Alignment.center,
    child: loading
        ? const CircularProgressIndicator()
        : Text(cat.emoji, style: const TextStyle(fontSize: 90)),
  );
}

/// A step number in a black circle, like an instruction sheet.
class _Number extends StatelessWidget {
  final int n;
  const _Number(this.n);

  @override
  Widget build(BuildContext context) => Container(
    width: 44,
    height: 44,
    alignment: Alignment.center,
    decoration: const BoxDecoration(color: Color(0xFF222222), shape: BoxShape.circle),
    child: Text(
      '$n',
      style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800),
    ),
  );
}
