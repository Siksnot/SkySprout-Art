import 'package:flutter/material.dart';

import '../backend.dart';
import '../models.dart';
import '../themes.dart';
import '../widgets/celebrate.dart';
import '../widgets/common.dart';
import 'challenge_screen.dart';
import 'routine_screen.dart';
import 'shop_screen.dart';

/// One child's board ("Sam's Quest Board" and so on, by theme): daily
/// progress, the chore list and bonus jobs, points with the savings goal,
/// a button to the shop, routines, streaks and badges, the family goal and
/// countdowns. Confetti goes off when a chore is approved (or ticked, with
/// approvals off).
class KidScreen extends StatefulWidget {
  final String kid;
  const KidScreen({super.key, required this.kid});

  @override
  State<KidScreen> createState() => _KidScreenState();
}

class _KidScreenState extends State<KidScreen> {
  /// Chores done when the data last loaded, to spot newly approved ones.
  Set<String>? _done;

  void _watch(HubData? d) {
    if (d == null) return;
    final today = d.choresToday(widget.kid);
    final now = {
      for (final c in d.choresFor(widget.kid))
        if (c.done) c.uid,
    };
    final before = _done;
    _done = now;
    if (before == null) return;
    final fresh = now.difference(before);
    if (fresh.isEmpty) return;
    final allDone = today.isNotEmpty && today.every((c) => c.done);
    final wasAllDone = today.isNotEmpty && today.every((c) => before.contains(c.uid));
    final big = allDone && !wasAllDone;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      celebrate(
        context,
        big: big,
        message: big ? 'All done today!\nAmazing, ${nameOf(widget.kid)}! 🎉' : null,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final kid = widget.kid;
    final data = AppScope.of(context).data;
    _watch(data);
    final kt = KidTheme.of(kid);
    final wide = MediaQuery.sizeOf(context).width >= 900;

    Widget content(HubData d) {
      final quests = KBox(
        kt: kt,
        padding: EdgeInsets.zero,
        child: _Quests(kid: kid, data: d, kt: kt),
      );
      final points = Column(
        children: [
          _PointsCard(kid: kid, data: d, kt: kt),
          _SpendButton(kid: kid, kt: kt),
        ],
      );
      final countdowns = _Countdowns(data: d, kt: kt);
      final bonus = d.bonusJobs(kid).isEmpty ? null : _BonusJobs(kid: kid, data: d, kt: kt);
      final routines = d.routinesFor(kid).isEmpty ? null : _Routines(kid: kid, data: d, kt: kt);
      final streak = _StreakCard(kid: kid, data: d, kt: kt);
      final family = d.snap.familyGoal == null ? null : _FamilyGoalCard(kid: kid, data: d, kt: kt);
      final challenge = d.snap.challenge.on ? _ChallengeTile(kid: kid, data: d, kt: kt) : null;
      if (wide) {
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 60),
          children: [
            _DailyBar(kid: kid, data: d, kt: kt),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(flex: 5, child: Column(children: [quests, ?bonus])),
                const SizedBox(width: 16),
                Expanded(flex: 3, child: Column(children: [points, ?challenge, streak])),
                const SizedBox(width: 16),
                Expanded(flex: 3, child: Column(children: [?routines, ?family, countdowns])),
              ],
            ),
          ],
        );
      }
      return ListView(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 60),
        children: [
          _DailyBar(kid: kid, data: d, kt: kt),
          points,
          ?routines,
          quests,
          ?bonus,
          ?challenge,
          streak,
          ?family,
          countdowns,
        ],
      );
    }

    return Theme(
      data: kt.theme,
      child: Scaffold(
        body: KidBackground(
          theme: kt,
          child: SafeArea(
            child: Column(
              children: [
                const StatusBanner(),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 20, 16, 12),
                  child: _Header(kid: kid, data: data, kt: kt),
                ),
                Expanded(
                  child: data == null ? const Center(child: CircularProgressIndicator()) : content(data),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// A themed card.
class KBox extends StatelessWidget {
  final KidTheme kt;
  final Widget child;
  final Color? color;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  const KBox({
    super.key,
    required this.kt,
    required this.child,
    this.color,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
  });

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 14, right: 4),
    child: GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: kt.box(color: color),
        padding: padding,
        child: child,
      ),
    ),
  );
}

/// Small spaced-out caps label like "DAILY QUEST".
Widget _label(KidTheme kt, String text, Color color) => Text(
  text.toUpperCase(),
  style: kt.text(13, color: color).copyWith(letterSpacing: 2.5, fontWeight: FontWeight.w700),
);

/// A row of blocks, [filled] of [count] lit up.
class _Blocks extends StatelessWidget {
  final int count, filled;
  final Color on, off, border;
  final double height;
  const _Blocks({
    required this.count,
    required this.filled,
    required this.on,
    required this.off,
    required this.border,
    this.height = 22,
  });

  @override
  Widget build(BuildContext context) => Row(
    children: [
      for (var i = 0; i < count; i++)
        Expanded(
          child: Container(
            height: height,
            margin: EdgeInsets.only(right: i == count - 1 ? 0 : 6),
            decoration: BoxDecoration(
              color: i < filled ? on : off,
              border: Border.all(color: border, width: 2),
            ),
          ),
        ),
    ],
  );
}

class _Header extends StatelessWidget {
  final String kid;
  final HubData? data;
  final KidTheme kt;
  const _Header({required this.kid, required this.data, required this.kt});

  @override
  Widget build(BuildContext context) {
    final narrow = MediaQuery.sizeOf(context).width < 600;
    return Container(
      decoration: kt.box(),
      padding: const EdgeInsets.fromLTRB(4, 8, 10, 8),
      child: Row(
        children: [
          IconButton(
            iconSize: 30,
            color: kt.dark,
            tooltip: 'Home',
            icon: const Icon(Icons.arrow_back_rounded),
            onPressed: () => Navigator.maybePop(context),
          ),
          Text(kt.boardEmoji, style: TextStyle(fontSize: narrow ? 26 : 34)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              "${nameOf(kid)}'s ${kt.boardName}",
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: kt.text(narrow ? 22 : 30),
            ),
          ),
          if (!narrow) ...[ScreenTimePill(theme: kt, timer: data?.timer(kid)), const SizedBox(width: 12)],
          PointsBadge(theme: kt, points: data?.points(kid) ?? 0, size: narrow ? 20 : 26),
        ],
      ),
    );
  }
}

class _DailyBar extends StatelessWidget {
  final String kid;
  final HubData data;
  final KidTheme kt;
  const _DailyBar({required this.kid, required this.data, required this.kt});

  @override
  Widget build(BuildContext context) {
    final chores = data.choresToday(kid);
    final done = chores.where((c) => c.done).length;
    final narrow = MediaQuery.sizeOf(context).width < 600;
    return KBox(
      kt: kt,
      color: kt.dark,
      padding: const EdgeInsets.fromLTRB(22, 16, 22, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _label(kt, kt.dailyName, kt.labelColor),
          const SizedBox(height: 6),
          Text(
            chores.isEmpty
                ? 'No chores today'
                : done == chores.length
                ? 'All ${chores.length} chores complete! 🎉'
                : '$done of ${chores.length} chores complete',
            style: kt.text(narrow ? 20 : 26, color: Colors.white),
          ),
          const SizedBox(height: 14),
          if (chores.isNotEmpty)
            chores.length <= 16
                ? _Blocks(
                    count: chores.length,
                    filled: done,
                    on: kt.accent,
                    off: Color.lerp(kt.dark, Colors.white, 0.18)!,
                    border: Color.lerp(kt.dark, Colors.black, 0.4)!,
                  )
                : _Blocks(
                    count: 10,
                    filled: (done * 10 / chores.length).floor(),
                    on: kt.accent,
                    off: Color.lerp(kt.dark, Colors.white, 0.18)!,
                    border: Color.lerp(kt.dark, Colors.black, 0.4)!,
                  ),
        ],
      ),
    );
  }
}

class _Quests extends StatelessWidget {
  final String kid;
  final HubData data;
  final KidTheme kt;
  const _Quests({required this.kid, required this.data, required this.kt});

  @override
  Widget build(BuildContext context) {
    final chores = data.choresToday(kid);
    final todo = chores.where((c) => !c.done).toList();
    final done = chores.where((c) => c.done).toList();
    final def = data.snap.defaultPoints(kid);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          color: kt.accent,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          child: Row(
            children: [
              const Text('📜', style: TextStyle(fontSize: 28)),
              const SizedBox(width: 12),
              Expanded(
                child: Text(kt.listName, style: kt.text(24, color: kt.onAccent)),
              ),
            ],
          ),
        ),
        if (chores.isEmpty)
          Padding(
            padding: const EdgeInsets.all(20),
            child: Text('Nothing on the list. Ask a grown-up what\'s next!', style: kt.text(18, bold: false)),
          ),
        for (final c in todo) _QuestRow(kid: kid, item: c, kt: kt, defaultPoints: def),
        if (todo.isNotEmpty && done.isNotEmpty)
          Container(height: 3, color: kt.border.withValues(alpha: 0.25)),
        for (final c in done) _QuestRow(kid: kid, item: c, kt: kt, defaultPoints: def),
        const SizedBox(height: 6),
      ],
    );
  }
}

class _QuestRow extends StatelessWidget {
  final String kid;
  final TodoItem item;
  final KidTheme kt;
  final int defaultPoints;
  const _QuestRow({required this.kid, required this.item, required this.kt, required this.defaultPoints});

  @override
  Widget build(BuildContext context) {
    final pts = item.points ?? defaultPoints;
    return InkWell(
      onTap: () async {
        final state = AppScope.read(context);
        final approve = state.data?.snap.approveChores ?? true;
        final err = await state.kidTick(kid, item);
        if (context.mounted) {
          showResult(
            context,
            err,
            ok: item.done || item.waiting
                ? null
                : approve
                ? 'Great job, ${nameOf(kid)}! A grown-up will check it ⏳'
                : 'Great job, ${nameOf(kid)}! +$pts ⭐',
          );
        }
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: kt.border.withValues(alpha: 0.15), width: 2)),
        ),
        child: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: item.done ? kt.accent : Colors.white,
                borderRadius: BorderRadius.circular(kt.radius / 2),
                border: Border.all(color: kt.border, width: 3),
              ),
              child: item.done
                  ? Icon(Icons.check_rounded, color: kt.onAccent, size: 26)
                  : item.waiting
                  ? Icon(Icons.hourglass_top_rounded, color: kt.dark, size: 22)
                  : null,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    style: kt
                        .text(21, color: item.done ? kt.dark.withValues(alpha: 0.6) : kt.dark)
                        .copyWith(
                          decoration: item.done ? TextDecoration.lineThrough : null,
                          decorationThickness: 2,
                        ),
                  ),
                  if (item.waiting) Text('Waiting for a grown-up to check', style: kt.text(15, bold: false)),
                  if (item.days.isNotEmpty && !item.bonus)
                    Text(
                      item.daysLabel,
                      style: kt.text(13, color: kt.dark.withValues(alpha: 0.6), bold: false),
                    ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Text(
              '+$pts ⭐',
              style: kt.text(18, color: kt.dark.withValues(alpha: item.done ? 0.5 : 1)),
            ),
          ],
        ),
      ),
    );
  }
}

class _PointsCard extends StatelessWidget {
  final String kid;
  final HubData data;
  final KidTheme kt;
  const _PointsCard({required this.kid, required this.data, required this.kt});

  @override
  Widget build(BuildContext context) {
    final points = data.points(kid);
    final saving = data.snap.savingFor(kid);
    final goal = saving?.cost[kid] ?? data.snap.goal(kid);
    final filled = goal <= 0 ? 10 : (points * 10 / goal).floor().clamp(0, 10);
    final money = data.snap.money;
    return KBox(
      kt: kt,
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
      child: Column(
        children: [
          _label(kt, 'Total points', kt.dark.withValues(alpha: 0.75)),
          const SizedBox(height: 6),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('⭐', style: TextStyle(fontSize: 64)),
                const SizedBox(width: 18),
                Text('$points', style: kt.text(64)),
              ],
            ),
          ),
          if (money.on)
            Text(
              '= ${money.of(points)} pocket money',
              style: kt.text(16, color: kt.dark.withValues(alpha: 0.8)),
            ),
          const SizedBox(height: 10),
          if (saving != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                children: [
                  Text(saving.emoji.isEmpty ? '🎁' : saving.emoji, style: const TextStyle(fontSize: 26)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Saving for ${saving.name}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: kt.text(17),
                    ),
                  ),
                ],
              ),
            ),
          _Blocks(
            count: 10,
            filled: filled,
            on: kt.accent,
            off: kt.dark.withValues(alpha: 0.35),
            border: kt.border,
            height: 20,
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              saving != null
                  ? (points >= goal ? 'You can buy it now! 🎉' : '$points of $goal · ${goal - points} to go')
                  : points >= goal
                  ? 'Goal reached! 🏆'
                  : 'Goal: $goal',
              style: kt.text(15, color: kt.dark.withValues(alpha: 0.8)),
            ),
          ),
          if (saving == null)
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Pick something to save for in the shop',
                style: kt.text(13, color: kt.dark.withValues(alpha: 0.6), bold: false),
              ),
            ),
          // The header shows screen time on wider screens.
          if (MediaQuery.sizeOf(context).width < 600)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: ScreenTimePill(theme: kt, timer: data.timer(kid), size: 16),
            ),
        ],
      ),
    );
  }
}

class _SpendButton extends StatelessWidget {
  final String kid;
  final KidTheme kt;
  const _SpendButton({required this.kid, required this.kt});

  @override
  Widget build(BuildContext context) => KBox(
    kt: kt,
    color: kt.accent,
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ShopScreen(kid: kid))),
    child: Row(
      children: [
        const Text('🛍️', style: TextStyle(fontSize: 48)),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Spend points', style: kt.text(28, color: kt.onAccent)),
              Text('Visit the shop', style: kt.text(17, color: kt.onAccent.withValues(alpha: 0.9))),
            ],
          ),
        ),
      ],
    ),
  );
}

/// Opens the challenge spinner, and shows today's challenge.
class _ChallengeTile extends StatelessWidget {
  final String kid;
  final HubData data;
  final KidTheme kt;
  const _ChallengeTile({required this.kid, required this.data, required this.kt});

  @override
  Widget build(BuildContext context) {
    final day = data.challengeFor(kid);
    final left = day.left(data.snap.challenge);
    final c = day.current;
    return KBox(
      kt: kt,
      color: const Color(0xFF7E57C2),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChallengeScreen(kid: kid))),
      child: Row(
        children: [
          const Text('🎡', style: TextStyle(fontSize: 46)),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Challenge spinner', style: kt.text(24, color: Colors.white)),
                Text(
                  c == null
                      ? 'Spin for something fun to make or do!'
                      : day.waiting
                      ? '${c.text} · a grown-up is checking ⏳'
                      : day.done
                      ? 'Done today! 🏆${left > 0 ? ' $left spin${left == 1 ? '' : 's'} left' : ''}'
                      : '${catOf(c.cat).emoji} ${c.text}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: kt.text(16, color: Colors.white.withValues(alpha: 0.92), bold: false),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Countdowns extends StatelessWidget {
  final HubData data;
  final KidTheme kt;
  const _Countdowns({required this.data, required this.kt});

  @override
  Widget build(BuildContext context) {
    final all = activeCountdowns(data.snap.countdowns);
    return KBox(
      kt: kt,
      color: kt.dark,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _label(kt, 'Days to go', kt.labelColor),
          const SizedBox(height: 4),
          Row(
            children: [
              const Text('⏳', style: TextStyle(fontSize: 26)),
              const SizedBox(width: 8),
              Flexible(
                child: Text(
                  'Countdowns',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: kt.text(24, color: Colors.white),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (all.isEmpty) Text('Nothing coming up', style: kt.text(16, color: Colors.white70, bold: false)),
          for (final (i, c) in all.indexed)
            Builder(
              builder: (context) {
                final (emoji, name) = (c.emoji, c.name);
                final first = i == 0;
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: first ? kt.highlight : kt.card,
                    borderRadius: kt.br,
                    border: Border.all(color: first ? const Color(0xFFFFB300) : kt.border, width: 3),
                  ),
                  child: Row(
                    children: [
                      Text(emoji, style: const TextStyle(fontSize: 24)),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(name, maxLines: 2, overflow: TextOverflow.ellipsis, style: kt.text(18)),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: first ? const Color(0xFFFFB300) : kt.accent,
                          border: Border.all(color: kt.border, width: 2),
                          borderRadius: BorderRadius.circular(kt.radius / 2),
                        ),
                        child: Text(
                          c.days == 0 ? 'Today!' : '${c.days} day${c.days == 1 ? '' : 's'}',
                          style: kt.text(16, color: first ? kt.dark : kt.onAccent),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
        ],
      ),
    );
  }
}

class _BonusJobs extends StatelessWidget {
  final String kid;
  final HubData data;
  final KidTheme kt;
  const _BonusJobs({required this.kid, required this.data, required this.kt});

  @override
  Widget build(BuildContext context) {
    final def = data.snap.defaultPoints(kid);
    return KBox(
      kt: kt,
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            color: const Color(0xFFFFB300),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
            child: Row(
              children: [
                const Text('💰', style: TextStyle(fontSize: 26)),
                const SizedBox(width: 12),
                Expanded(
                  child: Text('Bonus jobs', style: kt.text(22, color: const Color(0xFF2F2F2F))),
                ),
                Text('Extra points!', style: kt.text(14, color: const Color(0xFF2F2F2F), bold: false)),
              ],
            ),
          ),
          for (final c in data.bonusJobs(kid)) _QuestRow(kid: kid, item: c, kt: kt, defaultPoints: def),
          const SizedBox(height: 6),
        ],
      ),
    );
  }
}

class _Routines extends StatelessWidget {
  final String kid;
  final HubData data;
  final KidTheme kt;
  const _Routines({required this.kid, required this.data, required this.kt});

  @override
  Widget build(BuildContext context) {
    return KBox(
      kt: kt,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _label(kt, 'Routines', kt.dark.withValues(alpha: 0.75)),
          const SizedBox(height: 8),
          for (final r in data.routinesFor(kid))
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Material(
                color: r.done ? kt.accent.withValues(alpha: 0.25) : kt.card,
                shape: RoundedRectangleBorder(
                  borderRadius: kt.br,
                  side: BorderSide(color: kt.border, width: 2),
                ),
                child: InkWell(
                  borderRadius: kt.br,
                  onTap: r.done || r.waiting || r.steps.isEmpty
                      ? null
                      : () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => RoutineScreen(kid: kid, routineId: r.id),
                          ),
                        ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    child: Row(
                      children: [
                        Text(r.emoji, style: const TextStyle(fontSize: 30)),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(r.name, style: kt.text(20)),
                              Text(
                                r.done
                                    ? 'All done! ✓'
                                    : r.waiting
                                    ? 'Waiting for a grown-up ⏳'
                                    : '${r.steps.length} steps${r.points > 0 ? ' · +${r.points} ⭐' : ''}',
                                style: kt.text(14, bold: false),
                              ),
                            ],
                          ),
                        ),
                        if (!r.done && !r.waiting)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: kt.accent,
                              borderRadius: BorderRadius.circular(kt.radius / 2),
                              border: Border.all(color: kt.border, width: 2),
                            ),
                            child: Text('Start', style: kt.text(16, color: kt.onAccent)),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _StreakCard extends StatelessWidget {
  final String kid;
  final HubData data;
  final KidTheme kt;
  const _StreakCard({required this.kid, required this.data, required this.kt});

  @override
  Widget build(BuildContext context) {
    final st = data.statsFor(kid);
    final n = st.current;
    final got = badges.where((b) => b.earned(st)).length;
    return KBox(
      kt: kt,
      padding: const EdgeInsets.all(16),
      onTap: () => _showBadges(context, st),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _label(kt, 'Streak', kt.dark.withValues(alpha: 0.75)),
          const SizedBox(height: 4),
          Row(
            children: [
              Text(n > 0 ? '🔥' : '💤', style: const TextStyle(fontSize: 36)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  n == 0
                      ? 'Finish every chore today to start a streak!'
                      : '$n day${n == 1 ? '' : 's'} in a row!',
                  style: kt.text(n == 0 ? 17 : 24),
                ),
              ),
            ],
          ),
          if (st.bestNow > n) Text('Best: ${st.bestNow} days', style: kt.text(14, bold: false)),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: Wrap(
                  spacing: 4,
                  runSpacing: 4,
                  children: [
                    for (final b in badges)
                      Opacity(
                        opacity: b.earned(st) ? 1 : 0.22,
                        child: Text(b.emoji, style: const TextStyle(fontSize: 26)),
                      ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text('$got of ${badges.length} badges · tap to see them', style: kt.text(13, bold: false)),
        ],
      ),
    );
  }

  void _showBadges(BuildContext context, KidStats st) => showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text("${nameOf(kid)}'s badges"),
      content: SizedBox(
        width: 420,
        child: ListView(
          shrinkWrap: true,
          children: [
            for (final b in badges)
              ListTile(
                leading: Opacity(
                  opacity: b.earned(st) ? 1 : 0.3,
                  child: Text(b.emoji, style: const TextStyle(fontSize: 32)),
                ),
                title: Text(
                  b.name,
                  style: TextStyle(fontWeight: b.earned(st) ? FontWeight.w800 : FontWeight.w400),
                ),
                subtitle: Text(b.how),
                trailing: b.earned(st) ? const Icon(Icons.check_circle, color: Color(0xFF5DAA3C)) : null,
              ),
          ],
        ),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))],
    ),
  );
}

class _FamilyGoalCard extends StatelessWidget {
  final String kid;
  final HubData data;
  final KidTheme kt;
  const _FamilyGoalCard({required this.kid, required this.data, required this.kt});

  @override
  Widget build(BuildContext context) {
    final g = data.snap.familyGoal!;
    final filled = g.target <= 0 ? 10 : (g.saved * 10 / g.target).floor().clamp(0, 10);
    return KBox(
      kt: kt,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _label(kt, 'Family goal', kt.dark.withValues(alpha: 0.75)),
          const SizedBox(height: 4),
          Row(
            children: [
              Text(g.emoji, style: const TextStyle(fontSize: 34)),
              const SizedBox(width: 10),
              Expanded(child: Text(g.name, style: kt.text(22))),
            ],
          ),
          const SizedBox(height: 10),
          _Blocks(
            count: 10,
            filled: filled,
            on: const Color(0xFFFFB300),
            off: kt.dark.withValues(alpha: 0.2),
            border: kt.border,
            height: 18,
          ),
          const SizedBox(height: 6),
          Text(
            g.reached ? 'We did it! 🎉 Ask a grown-up' : '${g.saved} of ${g.target} ⭐ · ${g.left} to go',
            style: kt.text(15),
          ),
          if ((g.given[kid] ?? 0) > 0) Text('You put in ${g.given[kid]} ⭐', style: kt.text(13, bold: false)),
          if (!g.reached) ...[
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: kt.accent,
                  foregroundColor: kt.onAccent,
                  side: BorderSide(color: kt.border, width: 2),
                ),
                onPressed: data.points(kid) > 0 ? () => _give(context, g) : null,
                child: Text('Add my points', style: kt.text(17, color: kt.onAccent)),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _give(BuildContext context, FamilyGoal g) async {
    final max = [data.points(kid), g.left].reduce((a, b) => a < b ? a : b);
    var n = max < 5 ? max : 5;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: Text('Add points to ${g.name}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton.filledTonal(
                    iconSize: 32,
                    onPressed: n > 1 ? () => set(() => n--) : null,
                    icon: const Icon(Icons.remove),
                  ),
                  SizedBox(
                    width: 100,
                    child: Text(
                      '$n ⭐',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w800),
                    ),
                  ),
                  IconButton.filledTonal(
                    iconSize: 32,
                    onPressed: n < max ? () => set(() => n++) : null,
                    icon: const Icon(Icons.add),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text('You have ${data.points(kid)} ⭐'),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Add them!')),
          ],
        ),
      ),
    );
    if (ok != true || !context.mounted) return;
    final err = await AppScope.read(context).giveToFamily(kid, n);
    if (!context.mounted) return;
    showResult(context, err, ok: 'Thanks for helping the family! +$n to ${g.name}');
    if (err == null && n >= g.left) {
      celebrate(context, big: true, message: '${g.emoji} ${g.name}\nGoal reached!');
    }
  }
}
