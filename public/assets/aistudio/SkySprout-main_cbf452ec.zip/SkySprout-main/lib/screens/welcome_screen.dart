import 'package:flutter/material.dart';

import '../backend.dart';
import '../config.dart';
import '../models.dart';
import '../sync.dart';
import '../themes.dart';
import '../widgets/common.dart';
import 'reset_password_screen.dart';
import 'setup_screen.dart';

/// Called once this device has a family to show.
typedef ReadyCallback = Future<void> Function(Backend backend, AppConfig config, SupabaseAuth? auth);

/// First screen on a new device. With accounts: sign in or create one, then
/// set up a new family or join one. Without: set up a family on this device.
class WelcomeScreen extends StatefulWidget {
  /// Null when this build has no online accounts.
  final SupabaseAuth? auth;
  final ReadyCallback onReady;

  /// Makes the online store for a login (tests swap in a fake).
  final SupabaseStore Function(SupabaseAuth auth)? storeFor;

  /// Set when signing in from the parent menu: the family kept on this
  /// device, which can be moved online if the account has none yet.
  final Map<String, dynamic>? deviceFamily;

  const WelcomeScreen({
    super.key,
    required this.auth,
    required this.onReady,
    this.storeFor,
    this.deviceFamily,
  });

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _newAccount = false;
  bool _busy = false;
  String? _note;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  SupabaseStore _store() => (widget.storeFor ?? SupabaseStore.new)(widget.auth!);

  Future<void> _go(Future<void> Function() f) async {
    setState(() {
      _busy = true;
      _note = null;
    });
    try {
      await f();
    } catch (e) {
      if (mounted) showResult(context, e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _submit() => _go(() async {
    final email = _email.text.trim();
    final password = _password.text;
    if (!email.contains('@')) throw AppError('Enter your email address.');
    if (_newAccount && password.length < 8) throw AppError('Choose a password of at least 8 characters.');
    if (password.isEmpty) throw AppError('Enter your password.');
    if (_newAccount) {
      if (!await widget.auth!.signUp(email, password)) {
        setState(() {
          _newAccount = false;
          _note = 'Nearly there: open the link we emailed to $email, then sign in here.';
        });
        return;
      }
    } else {
      await widget.auth!.signIn(email, password);
    }
    await _signedIn();
  });

  /// After signing in: open the family, or offer to set one up or join one.
  Future<void> _signedIn() async {
    final store = _store();
    final r = await store.fetch();
    if (!mounted) return;
    if (r.data != null) {
      await widget.onReady(HubBackend(store), const AppConfig(mode: DataMode.cloud), widget.auth);
    } else {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => _FamilyChoice(
            store: store,
            auth: widget.auth!,
            onReady: widget.onReady,
            deviceFamily: widget.deviceFamily,
          ),
        ),
      );
    }
  }

  Future<void> _forgot() async {
    final done = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => ResetPasswordScreen(auth: widget.auth!, email: _email.text.trim()),
      ),
    );
    if (done == true) await _go(_signedIn);
  }

  void _deviceOnly() => Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => SetupScreen(
        onCreate: (kids, pin) async {
          final b = HubBackend(PrefsStore());
          await b.create(kids, hashPin(pin));
          await widget.onReady(b, const AppConfig(), null);
        },
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final online = widget.auth != null;
    final t = Theme.of(context);
    return Theme(
      data: parentTheme(MediaQuery.platformBrightnessOf(context)),
      child: Builder(
        builder: (context) {
          return Scaffold(
            appBar: widget.deviceFamily == null ? null : AppBar(title: const Text('Sign in')),
            body: SafeArea(
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 440),
                  child: ListView(
                    shrinkWrap: true,
                    padding: const EdgeInsets.all(24),
                    children: [
                      Text(
                        [for (final k in KidTheme.all) k.mascot].join('  '),
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 40),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Kids Hub',
                        textAlign: TextAlign.center,
                        style: t.textTheme.headlineLarge?.copyWith(fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Chores, points and rewards for the whole family',
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 28),
                      if (online) ...[
                        SegmentedButton<bool>(
                          segments: const [
                            ButtonSegment(value: false, label: Text('Sign in')),
                            ButtonSegment(value: true, label: Text('Create account')),
                          ],
                          selected: {_newAccount},
                          onSelectionChanged: (s) => setState(() => _newAccount = s.first),
                        ),
                        const SizedBox(height: 16),
                        TextField(
                          controller: _email,
                          keyboardType: TextInputType.emailAddress,
                          autofillHints: const [AutofillHints.email],
                          decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder()),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: _password,
                          obscureText: true,
                          autofillHints: const [AutofillHints.password],
                          onSubmitted: (_) => _submit(),
                          decoration: InputDecoration(
                            labelText: 'Password',
                            helperText: _newAccount ? 'At least 8 characters' : null,
                            border: const OutlineInputBorder(),
                          ),
                        ),
                        if (_note != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 12),
                            child: Text(_note!, style: TextStyle(color: t.colorScheme.primary)),
                          ),
                        const SizedBox(height: 16),
                        FilledButton(
                          onPressed: _busy ? null : _submit,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            child: Text(_newAccount ? 'Create account' : 'Sign in'),
                          ),
                        ),
                        if (!_newAccount)
                          TextButton(
                            onPressed: _busy ? null : _forgot,
                            child: const Text('Forgot password?'),
                          ),
                        const SizedBox(height: 12),
                        const Text(
                          'One login per family. Grown-ups sign in once on each phone or tablet; '
                          'the kids never need it.',
                          textAlign: TextAlign.center,
                        ),
                        if (widget.deviceFamily == null) ...[
                          const Divider(height: 40),
                          TextButton(
                            onPressed: _busy ? null : _deviceOnly,
                            child: const Text('Use on this device only, without an account'),
                          ),
                        ],
                      ] else
                        FilledButton(
                          onPressed: _deviceOnly,
                          child: const Padding(
                            padding: EdgeInsets.symmetric(vertical: 12),
                            child: Text('Set up your family'),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// After signing in to an account with no family yet.
class _FamilyChoice extends StatefulWidget {
  final SupabaseStore store;
  final SupabaseAuth auth;
  final ReadyCallback onReady;
  final Map<String, dynamic>? deviceFamily;
  const _FamilyChoice({required this.store, required this.auth, required this.onReady, this.deviceFamily});

  @override
  State<_FamilyChoice> createState() => _FamilyChoiceState();
}

class _FamilyChoiceState extends State<_FamilyChoice> {
  final _code = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  Future<void> _ready() =>
      widget.onReady(HubBackend(widget.store), const AppConfig(mode: DataMode.cloud), widget.auth);

  Future<void> _moveOnline() async {
    setState(() => _busy = true);
    try {
      await widget.store.create(widget.deviceFamily!);
      await _ready();
    } catch (e) {
      if (mounted) showResult(context, e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _join() async {
    if (!validCode(_code.text)) {
      showResult(context, 'A family code is 10 letters and numbers, like ABCDE-23456.');
      return;
    }
    setState(() => _busy = true);
    try {
      await widget.store.join(_code.text);
      await _ready();
    } catch (e) {
      if (mounted) showResult(context, e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: parentTheme(MediaQuery.platformBrightnessOf(context)),
      child: Builder(
        builder: (context) {
          return Scaffold(
            appBar: AppBar(title: const Text('Your family')),
            body: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 520),
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    if (widget.deviceFamily != null) ...[
                      Card(
                        child: ListTile(
                          contentPadding: const EdgeInsets.all(16),
                          leading: const Icon(Icons.cloud_upload_outlined, size: 36),
                          title: const Text('Move this device\'s family online'),
                          subtitle: const Text(
                            'Keeps your children, points, chores and rewards, '
                            'and lets other phones and tablets sign in to them.',
                          ),
                          trailing: const Icon(Icons.chevron_right),
                          enabled: !_busy,
                          onTap: _moveOnline,
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],
                    Card(
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(16),
                        leading: const Icon(Icons.family_restroom, size: 36),
                        title: const Text('Set up a new family'),
                        subtitle: const Text('Add your children, pick their themes and choose a parent PIN.'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => SetupScreen(
                              onCreate: (kids, pin) async {
                                await HubBackend(widget.store).create(kids, hashPin(pin));
                                await _ready();
                              },
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Join a family',
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                            ),
                            const SizedBox(height: 4),
                            const Text(
                              'For a second grown-up. Find the code in Settings on a device '
                              'that already has the family.',
                            ),
                            const SizedBox(height: 12),
                            TextField(
                              controller: _code,
                              textCapitalization: TextCapitalization.characters,
                              decoration: const InputDecoration(
                                labelText: 'Family code',
                                hintText: 'ABCDE-23456',
                              ),
                              onSubmitted: (_) => _join(),
                            ),
                            const SizedBox(height: 12),
                            FilledButton(onPressed: _busy ? null : _join, child: const Text('Join')),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
