import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../backend.dart';
import '../catalog.dart';
import '../models.dart';
import '../photos.dart';
import '../themes.dart';
import '../widgets/celebrate.dart';
import '../widgets/common.dart';
import 'how_to_screen.dart';
import 'routine_screen.dart';

/// The challenge spinner: a child picks a kind of challenge (or lets the
/// wheel choose), spins, and gets something to make or do, with a timer
/// and points. "I did it!" sends it to a grown-up to check, like a chore,
/// and a photo of it goes in the child's gallery on this device.
class ChallengeScreen extends StatefulWidget {
  final String kid;
  const ChallengeScreen({super.key, required this.kid});

  @override
  State<ChallengeScreen> createState() => _ChallengeScreenState();
}

class _ChallengeScreenState extends State<ChallengeScreen> with SingleTickerProviderStateMixin {
  late final _spin = AnimationController(vsync: this, duration: const Duration(milliseconds: 3200));

  /// Wheel turn, in radians, before and after the spin.
  double _from = 0, _to = 0;
  bool _spinning = false;

  /// The category picked to spin in; null lets the wheel choose.
  String? _cat;

  /// Timer for the challenge, in seconds left.
  int _left = 0;
  bool _running = false;
  Timer? _tick;

  /// The challenge the timer was set for.
  String? _timerFor;

  double get _angle => _from + (_to - _from) * Curves.easeOutCubic.transform(_spin.value);

  @override
  void initState() {
    super.initState();
    _spin.addListener(() => setState(() {}));
    Catalog.load().then((_) {
      if (mounted) setState(() {});
    }, onError: (_) {});
  }

  @override
  void dispose() {
    _spin.dispose();
    _tick?.cancel();
    super.dispose();
  }

  Future<void> _go(List<ChallengeCat> cats) async {
    final state = AppScope.read(context);
    setState(() => _spinning = true);
    final err = await state.spinChallenge(widget.kid, cat: _cat);
    if (!mounted) return;
    if (err != null) {
      setState(() => _spinning = false);
      return showResult(context, err);
    }
    final got = state.data?.challengeFor(widget.kid).current;
    final i = math.max(0, cats.indexWhere((c) => c.id == got?.cat));
    // Turn so the slice lands under the pointer at the top, a little off
    // centre so it doesn't look planned.
    final seg = 2 * math.pi / cats.length;
    final land = -(i + 0.5) * seg + (math.Random().nextDouble() - 0.5) * seg * 0.6;
    final now = _angle % (2 * math.pi);
    var delta = (land - now) % (2 * math.pi);
    if (delta < 0) delta += 2 * math.pi;
    _from = now;
    _to = now + 5 * 2 * math.pi + delta;
    _tick?.cancel();
    _running = false;
    await _spin.forward(from: 0);
    if (!mounted) return;
    setState(() => _spinning = false);
    celebrate(context);
  }

  void _toggleTimer() {
    if (_running) {
      _tick?.cancel();
      setState(() => _running = false);
      return;
    }
    if (_left <= 0) return;
    setState(() => _running = true);
    _tick = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return t.cancel();
      setState(() => _left--);
      if (_left <= 0) {
        t.cancel();
        setState(() => _running = false);
      }
    });
  }

  Future<void> _done(Challenge c) async {
    final state = AppScope.read(context);
    final approve = state.data?.snap.approveChores ?? true;
    final err = await state.finishChallenge(widget.kid);
    if (!mounted) return;
    if (err != null) return showResult(context, err);
    _tick?.cancel();
    setState(() => _running = false);
    celebrate(
      context,
      big: true,
      message: approve
          ? 'Challenge done!\nA grown-up will check it ⏳'
          : 'Challenge done!${c.points > 0 ? '\n+${c.points} ⭐' : ''}',
    );
  }

  Future<void> _photo(Challenge c, {bool camera = true}) async {
    try {
      final p = await Photos.take(widget.kid, c, camera: camera);
      if (!mounted || p == null) return;
      showResult(context, null, ok: 'Saved to My makes 📸');
    } catch (e) {
      if (!mounted) return;
      // No camera: offer the photo library instead.
      if (camera) return _photo(c, camera: false);
      showResult(context, 'Couldn\'t get a photo: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final kid = widget.kid;
    final kt = KidTheme.of(kid);
    final data = AppScope.of(context).data;
    final narrow = MediaQuery.sizeOf(context).width < 600;
    return Theme(
      data: kt.theme,
      child: Scaffold(
        body: KidBackground(
          theme: kt,
          child: SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Container(
                    decoration: kt.box(),
                    padding: const EdgeInsets.fromLTRB(4, 8, 12, 8),
                    child: Row(
                      children: [
                        IconButton(
                          iconSize: 30,
                          color: kt.dark,
                          tooltip: 'Back',
                          icon: const Icon(Icons.arrow_back_rounded),
                          onPressed: () => Navigator.maybePop(context),
                        ),
                        Text('🎡', style: TextStyle(fontSize: narrow ? 26 : 34)),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Challenge spinner',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: kt.text(narrow ? 22 : 30),
                          ),
                        ),
                        if (Photos.supported && (data?.snap.challenge.photos ?? false))
                          IconButton(
                            iconSize: 28,
                            color: kt.dark,
                            tooltip: 'My makes',
                            icon: const Icon(Icons.photo_library_rounded),
                            onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => MakesScreen(kid: kid)),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: data == null
                      ? const Center(child: CircularProgressIndicator())
                      : _body(context, kt, data, narrow),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _body(BuildContext context, KidTheme kt, HubData d, bool narrow) {
    final snap = d.snap;
    final cats = snap.spinCats;
    final day = d.challengeFor(widget.kid);
    final left = day.left(snap.challenge);
    if (_cat != null && !cats.any((c) => c.id == _cat)) _cat = null;
    final c = day.current;
    // A new challenge gets its own timer.
    if (c != null && c.id != _timerFor && !_spinning) {
      _timerFor = c.id;
      _left = c.minutes * 60;
    }
    final size = math.min(narrow ? 300.0 : 360.0, MediaQuery.sizeOf(context).width - 64);
    final canSpin = !_spinning && left > 0 && !day.waiting && cats.isNotEmpty;
    // Tablets in landscape show the challenge beside the wheel.
    final wide = MediaQuery.sizeOf(context).width >= 1000;
    final spinner = ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 600),
      child: Column(
        children: [
          if (cats.isEmpty)
            Container(
              decoration: kt.box(),
              padding: const EdgeInsets.all(24),
              child: Text(
                'No challenges yet. Ask a grown-up to add some!',
                textAlign: TextAlign.center,
                style: kt.text(22),
              ),
            )
          else ...[
            SizedBox(
              width: size,
              height: size + 24,
              child: Stack(
                alignment: Alignment.topCenter,
                children: [
                  Positioned(
                    top: 24,
                    child: GestureDetector(
                      onTap: canSpin ? () => _go(cats) : null,
                      child: SizedBox(
                        width: size,
                        height: size,
                        child: CustomPaint(
                          painter: _Wheel(cats, _angle, kt.border),
                          child: Center(
                            child: Container(
                              width: size * 0.26,
                              height: size * 0.26,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                                border: Border.all(color: kt.border, width: 4),
                              ),
                              alignment: Alignment.center,
                              child: Text('SPIN', style: kt.text(size * 0.07)),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  // The pointer.
                  CustomPaint(size: const Size(40, 44), painter: _Pointer(kt.border)),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 8,
              runSpacing: 8,
              children: [
                _chip(kt, null, '🎲', 'Surprise me'),
                for (final cat in cats) _chip(kt, cat.id, cat.emoji, cat.name),
              ],
            ),
            const SizedBox(height: 14),
            BigButton(
              kt: kt,
              label: _spinning
                  ? 'Spinning…'
                  : day.waiting
                  ? 'A grown-up is checking ⏳'
                  : left <= 0
                  ? 'No spins left today'
                  : c == null || day.done
                  ? 'Spin! ($left left)'
                  : 'Spin again ($left left)',
              onTap: canSpin ? () => _go(cats) : null,
            ),
          ],
        ],
      ),
    );
    final card = c != null && !_spinning
        ? _card(kt, c, day, narrow, Photos.supported && snap.challenge.photos)
        : null;
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
      child: Center(
        child: wide
            ? ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1200),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(child: spinner),
                    const SizedBox(width: 24),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 24),
                        child:
                            card ??
                            Container(
                              decoration: kt.box(),
                              padding: const EdgeInsets.all(28),
                              child: Text(
                                _spinning
                                    ? 'Round and round it goes… 🎡'
                                    : 'Pick a kind, then spin the wheel!',
                                textAlign: TextAlign.center,
                                style: kt.text(26),
                              ),
                            ),
                      ),
                    ),
                  ],
                ),
              )
            : ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 600),
                child: Column(children: [spinner, const SizedBox(height: 16), ?card]),
              ),
      ),
    );
  }

  Widget _chip(KidTheme kt, String? id, String emoji, String name) {
    final on = _cat == id;
    return Material(
      color: on ? kt.accent : kt.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(kt.radius / 2 + 8),
        side: BorderSide(color: kt.border, width: 2),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(kt.radius / 2 + 8),
        onTap: _spinning ? null : () => setState(() => _cat = id),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Text('$emoji $name', style: kt.text(17, color: on ? kt.onAccent : kt.dark)),
        ),
      ),
    );
  }

  Widget _card(KidTheme kt, Challenge c, ChallengeDay day, bool narrow, bool photos) {
    final cat = catOf(c.cat);
    final total = c.minutes * 60;
    return Container(
      width: double.infinity,
      decoration: kt.box(),
      padding: const EdgeInsets.all(22),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: Color(cat.color),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: kt.border, width: 2),
            ),
            child: Text(
              '${cat.emoji} ${cat.name.toUpperCase()} CHALLENGE',
              style: kt.text(14, color: Colors.white).copyWith(letterSpacing: 1.5),
            ),
          ),
          const SizedBox(height: 12),
          Text(c.text, textAlign: TextAlign.center, style: kt.text(narrow ? 28 : 34)),
          const SizedBox(height: 6),
          Text(
            [if (c.points > 0) '+${c.points} ⭐', if (c.minutes > 0) '${c.minutes} minutes'].join(' · '),
            style: kt.text(18, color: kt.dark.withValues(alpha: 0.75)),
          ),
          if (day.doing && c.minutes > 0) ...[
            const SizedBox(height: 16),
            GestureDetector(
              onTap: _toggleTimer,
              child: SizedBox(
                width: 150,
                height: 150,
                child: CustomPaint(
                  painter: TimerRing(
                    total <= 0 ? 0 : _left / total,
                    kt.accent,
                    kt.dark.withValues(alpha: 0.12),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          _left <= 0
                              ? "Time's up!"
                              : '${_left ~/ 60}:${(_left % 60).toString().padLeft(2, '0')}',
                          style: kt.text(_left <= 0 ? 22 : 34),
                        ),
                        if (_left > 0)
                          Text(_running ? 'Tap to pause' : 'Tap to start', style: kt.text(13, bold: false)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
          const SizedBox(height: 18),
          if (Catalog.forChallenge(c) case final how? when !day.done) ...[
            BigButton(
              kt: kt,
              label: 'Show me how 📖',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => HowToScreen(kid: widget.kid, challenge: c, howTo: how),
                ),
              ),
            ),
            const SizedBox(height: 12),
          ],
          if (day.doing) BigButton(kt: kt, label: 'I did it! ✓', onTap: () => _done(c)),
          if (day.waiting) Text('Waiting for a grown-up to check ⏳', style: kt.text(20)),
          if (day.done) Text('Challenge complete! 🏆', style: kt.text(22)),
          if (photos) ...[
            const SizedBox(height: 12),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                foregroundColor: kt.dark,
                side: BorderSide(color: kt.border, width: 2),
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
              ),
              icon: const Icon(Icons.photo_camera_rounded),
              label: Text('Take a photo of it', style: kt.text(17)),
              onPressed: () => _photo(c),
            ),
          ],
        ],
      ),
    );
  }
}

/// The wheel: a coloured slice per category with its emoji, turned by [angle].
class _Wheel extends CustomPainter {
  final List<ChallengeCat> cats;
  final double angle;
  final Color border;
  _Wheel(this.cats, this.angle, this.border);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.shortestSide / 2 - 4;
    final seg = 2 * math.pi / cats.length;
    final rect = Rect.fromCircle(center: c, radius: r);
    for (var i = 0; i < cats.length; i++) {
      final start = -math.pi / 2 + angle + i * seg;
      canvas.drawArc(rect, start, seg, true, Paint()..color = Color(cats[i].color));
      canvas.drawArc(
        rect,
        start,
        seg,
        true,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3
          ..color = Colors.white,
      );
      final mid = start + seg / 2;
      final tp = TextPainter(
        text: TextSpan(
          text: cats[i].emoji,
          style: TextStyle(fontSize: r * 0.22),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      final at = c + Offset(math.cos(mid), math.sin(mid)) * r * 0.66;
      tp.paint(canvas, at - Offset(tp.width / 2, tp.height / 2));
    }
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 6
        ..color = border,
    );
  }

  @override
  bool shouldRepaint(_Wheel old) => old.angle != angle || old.cats != cats;
}

/// The arrow at the top of the wheel.
class _Pointer extends CustomPainter {
  final Color border;
  _Pointer(this.border);

  @override
  void paint(Canvas canvas, Size size) {
    final p = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width / 2, size.height)
      ..close();
    canvas.drawPath(p, Paint()..color = const Color(0xFFFFB300));
    canvas.drawPath(
      p,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..strokeJoin = StrokeJoin.round
        ..color = border,
    );
  }

  @override
  bool shouldRepaint(_Pointer old) => old.border != border;
}

/// A child's challenge photos on this device.
class MakesScreen extends StatefulWidget {
  final String kid;
  const MakesScreen({super.key, required this.kid});

  @override
  State<MakesScreen> createState() => _MakesScreenState();
}

class _MakesScreenState extends State<MakesScreen> {
  List<ChallengePhoto>? _photos;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await Photos.of(widget.kid);
    if (mounted) setState(() => _photos = p);
  }

  Future<void> _delete(ChallengePhoto p) async {
    if (!await confirm(context, 'Delete this photo?', p.text, yes: 'Delete', no: 'Keep it')) return;
    if (!mounted) return;
    await Photos.delete(p);
    await _load();
  }

  void _open(ChallengePhoto p) => showDialog<void>(
    context: context,
    builder: (ctx) => Dialog(
      clipBehavior: Clip.antiAlias,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Flexible(child: Image.file(File(p.path), fit: BoxFit.contain)),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Text(
              '${catOf(p.cat).emoji} ${p.text}\n${p.when.day}/${p.when.month}/${p.when.year}',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final kt = KidTheme.of(widget.kid);
    final photos = _photos;
    return Theme(
      data: kt.theme,
      child: Scaffold(
        appBar: AppBar(title: Text("${nameOf(widget.kid)}'s makes")),
        body: photos == null
            ? const Center(child: CircularProgressIndicator())
            : photos.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(
                    'No photos yet. Take one when you finish a challenge! 📸',
                    textAlign: TextAlign.center,
                    style: kt.text(20),
                  ),
                ),
              )
            : GridView.builder(
                padding: const EdgeInsets.all(12),
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: 240,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                ),
                itemCount: photos.length,
                itemBuilder: (_, i) => GestureDetector(
                  onTap: () => _open(photos[i]),
                  onLongPress: () => _delete(photos[i]),
                  child: Container(
                    decoration: kt.box(),
                    clipBehavior: Clip.antiAlias,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.file(File(photos[i].path), fit: BoxFit.cover, cacheWidth: 480),
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            width: double.infinity,
                            color: Colors.black54,
                            padding: const EdgeInsets.all(6),
                            child: Text(
                              photos[i].text,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
      ),
    );
  }
}
