import 'package:flutter/material.dart';

import '../backend.dart';
import '../catalog.dart';
import '../challenge_ai.dart';
import '../models.dart';
import '../themes.dart';
import '../widgets/common.dart';
import '../widgets/hub_menu.dart';
import 'kid_screen.dart';

/// The parent screens, behind the PIN: a tab
/// per child (points, screen time, points log, chores, rewards owned),
/// rewards and their prices,
/// orders to deliver, countdowns and the challenge spinner.
class ParentHome extends StatelessWidget {
  const ParentHome({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final owed = state.data?.owed.where((o) => !o.done).length ?? 0;
    return Theme(
      data: parentTheme(MediaQuery.platformBrightnessOf(context)),
      child: DefaultTabController(
        key: ValueKey(kids.join(',')),
        length: kids.length + 5,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Parent portal'),
            automaticallyImplyLeading: false,
            actions: const [
              HubMenu(place: HubPlace.parents),
              SizedBox(width: 4),
            ],
            bottom: TabBar(
              isScrollable: true,
              tabAlignment: TabAlignment.start,
              tabs: [
                for (final k in kids)
                  Tab(
                    text: switch ((state.data?.chores[k]?.where((c) => c.waiting).length ?? 0) +
                        (state.data?.routinesFor(k).where((r) => r.waiting).length ?? 0) +
                        ((state.data?.challengeFor(k).waiting ?? false) ? 1 : 0)) {
                      0 => '${KidTheme.of(k).mascot} ${nameOf(k)}',
                      final n => '${KidTheme.of(k).mascot} ${nameOf(k)} ⏳$n',
                    },
                  ),
                const Tab(text: '📊 This week'),
                const Tab(text: '🎁 Rewards'),
                Tab(text: owed > 0 ? '📦 Orders ($owed)' : '📦 Orders'),
                const Tab(text: '📅 Countdowns'),
                const Tab(text: '🎡 Challenges'),
              ],
            ),
          ),
          body: Column(
            children: [
              const StatusBanner(),
              Expanded(
                child: TabBarView(
                  children: [
                    for (final k in kids) _KidPanel(kid: k),
                    const _WeekPanel(),
                    const _RewardsPanel(),
                    const _OrdersPanel(),
                    const _CountdownPanel(),
                    const _ChallengesPanel(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget _loadingOr(BuildContext context, Widget Function(HubData) build) {
  final s = AppScope.of(context);
  if (s.data != null) return build(s.data!);
  return Center(child: s.loading ? const CircularProgressIndicator() : const Text('No data yet'));
}

Future<void> _act(BuildContext context, Future<String?> Function() f, {String? ok}) async {
  final err = await f();
  if (context.mounted) showResult(context, err, ok: ok);
}

class _KidPanel extends StatelessWidget {
  final String kid;
  const _KidPanel({required this.kid});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return _loadingOr(context, (data) {
      final scheme = Theme.of(context).colorScheme;
      final chores = data.choresFor(kid);
      final today = data.choresToday(kid);
      final def = data.snap.defaultPoints(kid);
      final money = data.snap.money;
      final st = data.statsFor(kid);
      return RefreshIndicator(
        onRefresh: state.refresh,
        child: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            // Points and quick adjust.
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${nameOf(kid).toUpperCase()} · POINTS',
                      style: TextStyle(
                        letterSpacing: 1.5,
                        fontWeight: FontWeight.w700,
                        color: scheme.primary,
                      ),
                    ),
                    Row(
                      children: [
                        Text(
                          '${data.points(kid)}',
                          style: TextStyle(fontSize: 52, fontWeight: FontWeight.w800, color: scheme.primary),
                        ),
                        const Text(' ⭐', style: TextStyle(fontSize: 32)),
                        const Spacer(),
                        TextButton.icon(
                          icon: const Icon(Icons.open_in_new),
                          label: const Text('Kid view'),
                          onPressed: () =>
                              Navigator.push(context, MaterialPageRoute(builder: (_) => KidScreen(kid: kid))),
                        ),
                      ],
                    ),
                    InkWell(
                      onTap: () => _editGoal(context, data.snap.goal(kid)),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'Goal: ${data.snap.goal(kid)}',
                              style: TextStyle(color: scheme.onSurfaceVariant),
                            ),
                            const SizedBox(width: 6),
                            Icon(Icons.edit, size: 16, color: scheme.onSurfaceVariant),
                          ],
                        ),
                      ),
                    ),
                    Text(
                      [
                        st.current > 0 ? '🔥 ${st.current}-day streak' : 'No streak yet',
                        '🏅 ${badges.where((b) => b.earned(st)).length} of ${badges.length} badges',
                        if (data.snap.savingFor(kid) != null)
                          '🐷 Saving for ${data.snap.savingFor(kid)!.name}',
                      ].join(' · '),
                      style: TextStyle(color: scheme.onSurfaceVariant),
                    ),
                    if (money.on)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                'Worth ${money.of(data.points(kid))} (${money.rate})',
                                style: const TextStyle(fontWeight: FontWeight.w600),
                              ),
                            ),
                            OutlinedButton.icon(
                              icon: const Icon(Icons.payments_outlined),
                              label: const Text('Pay out'),
                              onPressed: data.points(kid) > 0 ? () => _payOut(context, data) : null,
                            ),
                          ],
                        ),
                      ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        for (final d in const [-5, -1, 1, 5])
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 3),
                              child: FilledButton.tonal(
                                style: FilledButton.styleFrom(padding: EdgeInsets.zero),
                                onPressed: () => _act(
                                  context,
                                  () => state.adjustPoints(kid, d),
                                  ok: '${nameOf(kid)}: ${d > 0 ? '+' : ''}$d points',
                                ),
                                child: Text(
                                  d > 0 ? '+$d' : '$d',
                                  maxLines: 1,
                                  softWrap: false,
                                  style: const TextStyle(fontSize: 18),
                                ),
                              ),
                            ),
                          ),
                        IconButton(
                          tooltip: 'Other amount',
                          icon: const Icon(Icons.edit),
                          onPressed: () => _customPoints(context),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            _TimerCard(kid: kid, timer: data.timer(kid)),
            if (data.snap.challenge.on && data.challengeFor(kid).current != null)
              _ChallengeToday(kid: kid, day: data.challengeFor(kid)),
            const _Section('Points log'),
            _PointsLog(entries: (data.log[kid] ?? const []).take(20).toList()),
            _Section(
              'Chores · ${today.where((c) => c.done).length}/${today.length} done today',
              action: TextButton.icon(
                icon: const Icon(Icons.add),
                label: const Text('Add'),
                onPressed: () => _ChoreEditor.show(context, kid, null, def),
              ),
            ),
            Card(
              child: Column(
                children: [
                  if (chores.isEmpty) const ListTile(title: Text('No chores on the list')),
                  for (final c in chores)
                    if (c.waiting)
                      ListTile(
                        tileColor: Theme.of(context).colorScheme.tertiaryContainer,
                        leading: const Icon(Icons.hourglass_top_rounded),
                        title: Text(c.title),
                        subtitle: Text(
                          '${nameOf(kid)} says it\'s done · ${c.points ?? def} pts${c.bonus ? ' · bonus job' : ''}',
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            TextButton(
                              onPressed: () => _act(context, () => state.approveChore(kid, c, false)),
                              child: const Text('Not yet'),
                            ),
                            FilledButton(
                              onPressed: () => _act(
                                context,
                                () => state.approveChore(kid, c, true),
                                ok: 'Approved: +${c.points ?? def} for ${nameOf(kid)}',
                              ),
                              child: const Text('Approve'),
                            ),
                          ],
                        ),
                      )
                    else
                      CheckboxListTile(
                        controlAffinity: ListTileControlAffinity.leading,
                        value: c.done,
                        title: Text(
                          c.title,
                          style: TextStyle(decoration: c.done ? TextDecoration.lineThrough : null),
                        ),
                        subtitle: Text(
                          [
                            if (c.bonus) '💰 Bonus job' else c.daysLabel,
                            c.points != null ? '${c.points} pts' : '$def pts (default)',
                            if (!c.bonus && !c.dueOn(data.weekday)) 'not today',
                          ].join(' · '),
                        ),
                        secondary: IconButton(
                          tooltip: 'Edit chore',
                          icon: const Icon(Icons.edit_outlined),
                          onPressed: () => _ChoreEditor.show(context, kid, c, def),
                        ),
                        onChanged: (v) => _act(context, () => state.setChore(kid, c, v ?? false)),
                      ),
                  const Divider(height: 1),
                  _DefaultPoints(kid: kid, value: def),
                ],
              ),
            ),
            _Section(
              'Routines',
              action: TextButton.icon(
                icon: const Icon(Icons.add),
                label: const Text('Add'),
                onPressed: () => _RoutineEditor.show(context, kid, null),
              ),
            ),
            Card(
              child: Column(
                children: [
                  if (data.routinesFor(kid).isEmpty) const ListTile(title: Text('No routines')),
                  for (final r in data.routinesFor(kid))
                    if (r.waiting)
                      ListTile(
                        tileColor: Theme.of(context).colorScheme.tertiaryContainer,
                        leading: Text(r.emoji, style: const TextStyle(fontSize: 26)),
                        title: Text('${r.name} routine'),
                        subtitle: Text('${nameOf(kid)} says it\'s done · ${r.points} pts'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            TextButton(
                              onPressed: () => _act(context, () => state.approveRoutine(kid, r.id, false)),
                              child: const Text('Not yet'),
                            ),
                            FilledButton(
                              onPressed: () => _act(
                                context,
                                () => state.approveRoutine(kid, r.id, true),
                                ok: 'Approved: +${r.points} for ${nameOf(kid)}',
                              ),
                              child: const Text('Approve'),
                            ),
                          ],
                        ),
                      )
                    else
                      ListTile(
                        leading: Text(r.emoji, style: const TextStyle(fontSize: 26)),
                        title: Text(r.name),
                        subtitle: Text(
                          '${r.steps.length} steps · ${r.points} pts${r.done ? ' · done today ✓' : ''}',
                        ),
                        trailing: const Icon(Icons.edit_outlined),
                        onTap: () => _RoutineEditor.show(context, kid, r),
                      ),
                ],
              ),
            ),
            _Section('Rewards ${nameOf(kid)} owns'),
            Card(
              child: Column(
                children: [
                  for (final r in data.slots)
                    ListTile(
                      leading: Text(r.emoji.isEmpty ? '🎁' : r.emoji, style: const TextStyle(fontSize: 26)),
                      title: Text(r.name),
                      subtitle: r.minutes > 0 ? Text('${r.minutes} min') : null,
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '${r.own[kid] ?? 0}',
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          if ((r.own[kid] ?? 0) > 0)
                            TextButton(
                              onPressed: () =>
                                  _act(context, () => state.useReward(kid, r), ok: 'Used ${r.name}'),
                              child: const Text('Use one'),
                            ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      );
    });
  }

  Future<void> _editGoal(BuildContext context, int current) async {
    final v = await _ask(
      context,
      '${nameOf(kid)}\'s points goal',
      '$current',
      hint: 'Fills the 10-block goal bar on their board',
      number: true,
    );
    final n = int.tryParse(v ?? '');
    if (n == null || n <= 0 || !context.mounted) return;
    await _act(context, () => AppScope.read(context).setGoal(kid, n), ok: 'Goal set to $n');
  }

  Future<void> _payOut(BuildContext context, HubData data) async {
    final money = data.snap.money;
    final have = data.points(kid);
    final v = await _ask(
      context,
      'Pay ${nameOf(kid)} pocket money',
      '$have',
      hint: 'Points to turn into money (${money.rate}). They have $have.',
      number: true,
    );
    final n = int.tryParse(v ?? '');
    if (n == null || n <= 0 || !context.mounted) return;
    await _act(
      context,
      () => AppScope.read(context).payOut(kid, n),
      ok: 'Paid ${nameOf(kid)} ${money.of(n)} (−$n points)',
    );
  }

  Future<void> _customPoints(BuildContext context) async {
    final v = await _ask(
      context,
      'Change ${nameOf(kid)}\'s points',
      '',
      hint: 'Use a minus sign to take points away, e.g. -15',
      number: true,
    );
    final n = int.tryParse(v ?? '');
    if (n == null || n == 0 || !context.mounted) return;
    await _act(
      context,
      () => AppScope.read(context).adjustPoints(kid, n),
      ok: '${nameOf(kid)}: ${n > 0 ? '+' : ''}$n points',
    );
  }
}

Future<String?> _ask(
  BuildContext context,
  String title,
  String initial, {
  String? hint,
  bool number = false,
}) {
  final ctl = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: ctl,
        autofocus: true,
        keyboardType: number ? const TextInputType.numberWithOptions(signed: true) : TextInputType.text,
        decoration: InputDecoration(helperText: hint, helperMaxLines: 2),
        onSubmitted: (v) => Navigator.pop(ctx, v),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, ctl.text), child: const Text('Save')),
      ],
    ),
  );
}

/// − value + control used for prices and chore points.
class _Stepper extends StatelessWidget {
  final int value;
  final int min;
  final ValueChanged<int> onChanged;
  const _Stepper({required this.value, required this.onChanged, this.min = 0});

  @override
  Widget build(BuildContext context) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      IconButton(
        visualDensity: VisualDensity.compact,
        icon: const Icon(Icons.remove),
        onPressed: value > min ? () => onChanged(value - 1) : null,
      ),
      SizedBox(
        width: 36,
        child: Text(
          '$value',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
        ),
      ),
      IconButton(
        visualDensity: VisualDensity.compact,
        icon: const Icon(Icons.add),
        onPressed: () => onChanged(value + 1),
      ),
    ],
  );
}

class _DefaultPoints extends StatefulWidget {
  final String kid;
  final int value;
  const _DefaultPoints({required this.kid, required this.value});

  @override
  State<_DefaultPoints> createState() => _DefaultPointsState();
}

class _DefaultPointsState extends State<_DefaultPoints> {
  double? _dragging;

  @override
  Widget build(BuildContext context) {
    final v = _dragging ?? widget.value.toDouble().clamp(0, 10);
    return ListTile(
      leading: const Icon(Icons.stars_outlined),
      title: const Text('Points for chores without their own'),
      subtitle: Slider(
        value: v.toDouble(),
        min: 0,
        max: 10,
        divisions: 10,
        label: '${v.round()}',
        onChanged: (x) => setState(() => _dragging = x),
        onChangeEnd: (x) async {
          await _act(context, () => AppScope.read(context).setDefaultPoints(widget.kid, x.round()));
          if (mounted) setState(() => _dragging = null);
        },
      ),
      trailing: Text('${v.round()}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    );
  }
}

/// Add or edit a chore: its name and points.
class _ChoreEditor extends StatefulWidget {
  final String kid;
  final TodoItem? item;
  final int defaultPoints;
  const _ChoreEditor({required this.kid, required this.item, required this.defaultPoints});

  static Future<void> show(BuildContext context, String kid, TodoItem? item, int def) => showDialog(
    context: context,
    builder: (_) => Theme(
      data: Theme.of(context),
      child: AppScope(
        state: AppScope.read(context),
        child: _ChoreEditor(kid: kid, item: item, defaultPoints: def),
      ),
    ),
  );

  @override
  State<_ChoreEditor> createState() => _ChoreEditorState();
}

class _ChoreEditorState extends State<_ChoreEditor> {
  late final _name = TextEditingController(text: widget.item?.title ?? '');
  late int _points = widget.item?.points ?? widget.defaultPoints;
  late bool _useDefault = widget.item != null && widget.item!.points == null;
  late final Set<int> _days = {...?widget.item?.days};
  late bool _bonus = widget.item?.bonus ?? false;
  bool _busy = false;

  Future<void> _save() async {
    final name = _name.text.trim();
    if (name.isEmpty) return;
    setState(() => _busy = true);
    final s = AppScope.read(context);
    final summary = choreSummary(name, _useDefault ? null : _points);
    final days = _bonus || _days.length == 7 ? <int>[] : (_days.toList()..sort());
    final err = widget.item == null
        ? await s.addChore(widget.kid, summary, days: days, bonus: _bonus)
        : await s.renameChore(widget.kid, widget.item!, summary, days: days, bonus: _bonus);
    if (!mounted) return;
    Navigator.pop(context);
    showResult(context, err);
  }

  Future<void> _delete() async {
    final item = widget.item!;
    if (!await confirm(
      context,
      'Delete "${item.title}"?',
      'It comes off ${nameOf(widget.kid)}\'s list.',
      yes: 'Delete',
      no: 'Cancel',
    )) {
      return;
    }
    if (!mounted) return;
    final err = await AppScope.read(context).removeChore(widget.kid, item);
    if (!mounted) return;
    Navigator.pop(context);
    showResult(context, err);
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.item == null ? 'New chore for ${nameOf(widget.kid)}' : 'Edit chore'),
    scrollable: true,
    content: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TextField(
          controller: _name,
          autofocus: widget.item == null,
          textCapitalization: TextCapitalization.sentences,
          decoration: const InputDecoration(labelText: 'Chore name'),
        ),
        const SizedBox(height: 12),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: Text('Use default points (${widget.defaultPoints})'),
          value: _useDefault,
          onChanged: (v) => setState(() => _useDefault = v),
        ),
        if (!_useDefault)
          Row(
            children: [
              const Expanded(child: Text('Points')),
              _Stepper(value: _points, min: 0, onChanged: (v) => setState(() => _points = v)),
            ],
          ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('One-off bonus job'),
          subtitle: const Text('Extra points; gone the day after it\'s done'),
          value: _bonus,
          onChanged: (v) => setState(() => _bonus = v),
        ),
        if (!_bonus) ...[
          const SizedBox(height: 4),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              _days.isEmpty || _days.length == 7 ? 'Days: every day' : 'Days: only on these',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
          const SizedBox(height: 4),
          Wrap(
            spacing: 4,
            runSpacing: 4,
            children: [
              for (var d = 1; d <= 7; d++)
                FilterChip(
                  label: Text(weekdayShort[d - 1].substring(0, 2)),
                  showCheckmark: false,
                  visualDensity: VisualDensity.compact,
                  selected: _days.contains(d),
                  onSelected: (on) => setState(() => on ? _days.add(d) : _days.remove(d)),
                ),
            ],
          ),
        ],
      ],
    ),
    actions: [
      if (widget.item != null)
        TextButton(
          onPressed: _busy ? null : _delete,
          style: TextButton.styleFrom(foregroundColor: Colors.red.shade700),
          child: const Text('Delete'),
        ),
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
      FilledButton(onPressed: _busy ? null : _save, child: Text(widget.item == null ? 'Add' : 'Save')),
    ],
  );
}

class _PointsLog extends StatelessWidget {
  final List<LogEntry> entries;
  const _PointsLog({required this.entries});

  @override
  Widget build(BuildContext context) {
    if (entries.isEmpty) {
      return const Card(child: ListTile(title: Text('No points yet')));
    }
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    String dayLabel(DateTime d) {
      final day = DateTime(d.year, d.month, d.day);
      final diff = today.difference(day).inDays;
      final date = '${d.day}/${d.month}/${d.year}';
      return diff == 0
          ? 'Today · $date'
          : diff == 1
          ? 'Yesterday · $date'
          : date;
    }

    String time(DateTime d) => '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

    final children = <Widget>[];
    String? last;
    for (final e in entries.take(20)) {
      final label = dayLabel(e.when);
      if (label != last) {
        children.add(
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
        );
        last = label;
      }
      children.add(
        ListTile(
          dense: true,
          leading: Icon(Icons.circle, size: 10, color: Theme.of(context).colorScheme.primary),
          title: Text(e.text),
          trailing: Text(time(e.when)),
        ),
      );
    }
    return Card(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
    );
  }
}

class _TimerCard extends StatelessWidget {
  final String kid;
  final TimerInfo? timer;
  const _TimerCard({required this.kid, required this.timer});

  @override
  Widget build(BuildContext context) {
    final t = timer;
    final running = t?.running ?? false;
    final paused = t?.paused ?? false;
    Future<void> act(String action, {Duration? by}) =>
        _act(context, () => AppScope.read(context).timer(kid, action, by: by));

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 8, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.hourglass_empty),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text('Screen time', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                ),
                Ticker(
                  builder: (_) => Text(
                    running || paused
                        ? '${formatLeft(t!.left() ?? Duration.zero)}${paused ? ' paused' : ' left'}'
                        : 'Idle',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(width: 8),
              ],
            ),
            Wrap(
              spacing: 4,
              children: [
                if (running)
                  TextButton.icon(
                    onPressed: () => act('pause'),
                    icon: const Icon(Icons.pause),
                    label: const Text('Pause'),
                  ),
                if (paused)
                  TextButton.icon(
                    onPressed: () => act('start'),
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('Resume'),
                  ),
                if (running || paused) ...[
                  TextButton(
                    onPressed: () => act('change', by: const Duration(minutes: 5)),
                    child: const Text('+5 min'),
                  ),
                  TextButton(
                    onPressed: () => act('change', by: const Duration(minutes: -5)),
                    child: const Text('−5 min'),
                  ),
                  TextButton.icon(
                    onPressed: () => act('cancel'),
                    icon: const Icon(Icons.stop),
                    label: const Text('Stop'),
                  ),
                ],
                if (!running && !paused)
                  TextButton.icon(
                    onPressed: () => act('start'),
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('Start'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Every reward: what it is and whether it's in the shop.
class _RewardsPanel extends StatelessWidget {
  const _RewardsPanel();

  @override
  Widget build(BuildContext context) {
    return _loadingOr(context, (data) {
      final goal = data.snap.familyGoal;
      final money = data.snap.money;
      return ListView(
        padding: const EdgeInsets.all(12),
        children: [
          _Section(
            'Family goal',
            action: TextButton.icon(
              icon: Icon(goal == null ? Icons.add : Icons.refresh),
              label: Text(goal == null ? 'Set one' : 'New goal'),
              onPressed: () => _editFamilyGoal(context),
            ),
          ),
          Card(
            child: goal == null
                ? const ListTile(
                    title: Text('No family goal'),
                    subtitle: Text('Everyone puts points towards one shared treat, like pizza night.'),
                  )
                : ListTile(
                    leading: Text(goal.emoji, style: const TextStyle(fontSize: 30)),
                    title: Text(goal.name),
                    subtitle: Text(
                      [
                        goal.reached
                            ? 'Reached! 🎉 Time to treat them'
                            : '${goal.saved} of ${goal.target} points',
                        for (final k in kids)
                          if ((goal.given[k] ?? 0) > 0) '${nameOf(k)} ${goal.given[k]}',
                      ].join(' · '),
                    ),
                    trailing: IconButton(
                      tooltip: 'Remove the goal',
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        if (!await confirm(
                          context,
                          'Remove ${goal.name}?',
                          'Points already put in are not given back.',
                          yes: 'Remove',
                          no: 'Cancel',
                        )) {
                          return;
                        }
                        if (context.mounted) {
                          await _act(context, () => AppScope.read(context).setFamilyGoal(null));
                        }
                      },
                    ),
                  ),
          ),
          const _Section('Pocket money'),
          Card(
            child: Column(
              children: [
                SwitchListTile(
                  title: const Text('Turn points into pocket money'),
                  subtitle: Text(money.on ? money.rate : 'Show what points are worth, and pay them out'),
                  value: money.on,
                  onChanged: (v) => _act(
                    context,
                    () => AppScope.read(
                      context,
                    ).setMoney(Money(on: v, points: money.points, cents: money.cents, symbol: money.symbol)),
                  ),
                ),
                if (money.on)
                  ListTile(
                    leading: const Icon(Icons.currency_exchange),
                    title: Text(money.rate),
                    subtitle: const Text('Tap to change the rate'),
                    trailing: const Icon(Icons.edit_outlined),
                    onTap: () => _editRate(context, money),
                  ),
              ],
            ),
          ),
          _Section(
            'Manage rewards',
            action: TextButton.icon(
              icon: const Icon(Icons.add),
              label: const Text('Add'),
              onPressed: () => _RewardEditor.show(context, null),
            ),
          ),
          Card(
            child: Column(
              children: [
                if (data.snap.rewards.isEmpty) const ListTile(title: Text('No rewards yet. Add one!')),
                for (final (i, r) in data.snap.rewards.indexed)
                  ListTile(
                    leading: CircleAvatar(
                      child: Text(
                        r.emoji.isEmpty ? '${i + 1}' : r.emoji,
                        style: const TextStyle(fontSize: 20),
                      ),
                    ),
                    title: Text(r.name.isEmpty ? 'Unnamed reward' : r.name),
                    subtitle: Text(
                      [
                        r.category,
                        if (r.minutes > 0) '${r.minutes} min',
                        r.on ? 'in shops' : 'hidden',
                      ].join(' · '),
                    ),
                    trailing: const Icon(Icons.edit_outlined),
                    onTap: () => _RewardEditor.show(context, r),
                  ),
              ],
            ),
          ),
          const _Section('Prices (points to claim)'),
          if (data.snap.rewards.isNotEmpty)
            const Padding(
              padding: EdgeInsets.fromLTRB(8, 0, 8, 4),
              child: Text('Each child can have their own price.'),
            ),
          for (final r in data.snap.rewards)
            Card(
              child: Column(
                children: [
                  ListTile(
                    dense: true,
                    leading: Text(r.emoji.isEmpty ? '⭐' : r.emoji, style: const TextStyle(fontSize: 22)),
                    title: Text(
                      r.name.isEmpty ? 'Unnamed reward' : r.name,
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                    ),
                  ),
                  for (final kid in kids)
                    ListTile(
                      dense: true,
                      contentPadding: const EdgeInsets.only(left: 56, right: 8),
                      title: Text('${KidTheme.of(kid).mascot} ${nameOf(kid)}'),
                      trailing: _Stepper(
                        value: r.cost[kid] ?? 0,
                        onChanged: (v) => _act(context, () => AppScope.read(context).setPrice(kid, r.key, v)),
                      ),
                    ),
                ],
              ),
            ),
          const SizedBox(height: 24),
        ],
      );
    });
  }
}

Future<void> _editFamilyGoal(BuildContext context) async {
  final name = TextEditingController(text: 'Pizza night');
  final emoji = TextEditingController(text: '🍕');
  final target = TextEditingController(text: '100');
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('New family goal'),
      scrollable: true,
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('The kids put their points in together. Starting a new goal clears the old one.'),
          const SizedBox(height: 12),
          Row(
            children: [
              SizedBox(
                width: 64,
                child: TextField(
                  controller: emoji,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 24),
                  decoration: const InputDecoration(labelText: 'Emoji'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: name,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: const InputDecoration(labelText: 'What for'),
                ),
              ),
            ],
          ),
          TextField(
            controller: target,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Points needed'),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 6,
            children: [
              for (final (e, n) in const [
                ('🍕', 'Pizza night'),
                ('🎬', 'Cinema trip'),
                ('🏊', 'Swimming'),
                ('🎳', 'Bowling'),
              ])
                ActionChip(
                  label: Text('$e $n'),
                  onPressed: () {
                    emoji.text = e;
                    name.text = n;
                  },
                ),
            ],
          ),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Start')),
      ],
    ),
  );
  final n = int.tryParse(target.text.trim()) ?? 0;
  if (ok != true || name.text.trim().isEmpty || n <= 0 || !context.mounted) return;
  await _act(
    context,
    () => AppScope.read(context).setFamilyGoal(
      FamilyGoal(
        name: name.text.trim(),
        emoji: emoji.text.trim().isEmpty ? '🎉' : emoji.text.trim(),
        target: n,
      ),
    ),
    ok: 'Family goal set: ${name.text.trim()}',
  );
}

Future<void> _editRate(BuildContext context, Money money) async {
  final pts = TextEditingController(text: '${money.points}');
  final dollars = TextEditingController(text: (money.cents / 100).toStringAsFixed(2));
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Pocket money rate'),
      content: Row(
        children: [
          Expanded(
            child: TextField(
              controller: pts,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Points'),
            ),
          ),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Text('=')),
          Expanded(
            child: TextField(
              controller: dollars,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: 'Money', prefixText: money.symbol),
            ),
          ),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
      ],
    ),
  );
  final p = int.tryParse(pts.text.trim());
  final d = double.tryParse(dollars.text.trim());
  if (ok != true || p == null || p <= 0 || d == null || d < 0 || !context.mounted) return;
  await _act(
    context,
    () =>
        AppScope.read(context)
            .setMoney(Money(on: true, points: p, cents: (d * 100).round(), symbol: money.symbol)),
  );
}

class _RewardEditor extends StatefulWidget {
  /// Null for a new reward.
  final Reward? reward;
  const _RewardEditor({required this.reward});

  static Future<void> show(BuildContext context, Reward? r) => showDialog(
    context: context,
    builder: (_) => Theme(
      data: Theme.of(context),
      child: AppScope(
        state: AppScope.read(context),
        child: _RewardEditor(reward: r),
      ),
    ),
  );

  @override
  State<_RewardEditor> createState() => _RewardEditorState();
}

class _RewardEditorState extends State<_RewardEditor> {
  late final Reward r =
      widget.reward ??
      Reward(key: '', emoji: '', name: '', desc: '', minutes: 0, on: true, cost: const {}, own: const {});
  late bool _on = r.on;
  late String _category = rewardCategories.contains(r.category) ? r.category : 'Reward';
  late final _emoji = TextEditingController(text: r.emoji);
  late final _name = TextEditingController(text: r.name);
  late final _desc = TextEditingController(text: r.desc);
  late int _minutes = r.minutes;
  bool _busy = false;

  Future<void> _save() async {
    setState(() => _busy = true);
    final updated = Reward(
      key: r.key,
      emoji: _emoji.text.trim(),
      name: _name.text.trim(),
      desc: _desc.text.trim(),
      category: _category,
      minutes: _minutes,
      on: _on,
      cost: r.cost,
      own: r.own,
    );
    if (updated.name.isEmpty) {
      setState(() => _busy = false);
      showResult(context, 'Give the reward a name.');
      return;
    }
    final err = await AppScope.read(context).saveReward(updated, on: _on);
    if (!mounted) return;
    Navigator.pop(context);
    showResult(
      context,
      err,
      ok: err == null ? 'Saved ${updated.name.isEmpty ? 'reward' : updated.name}' : null,
    );
  }

  Future<void> _delete() async {
    if (!await confirm(
      context,
      'Delete ${r.name}?',
      'It comes out of the shop, and anyone who owns one loses it.',
      yes: 'Delete',
      no: 'Cancel',
    )) {
      return;
    }
    if (!mounted) return;
    final err = await AppScope.read(context).deleteReward(r.key);
    if (!mounted) return;
    Navigator.pop(context);
    showResult(context, err, ok: err == null ? 'Deleted ${r.name}' : null);
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.reward == null ? 'New reward' : 'Edit reward'),
    content: SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Show in shops'),
            value: _on,
            onChanged: (v) => setState(() => _on = v),
          ),
          TextField(
            controller: _emoji,
            decoration: const InputDecoration(labelText: 'Emoji'),
          ),
          TextField(
            controller: _name,
            textCapitalization: TextCapitalization.sentences,
            decoration: const InputDecoration(labelText: 'Name'),
          ),
          TextField(
            controller: _desc,
            textCapitalization: TextCapitalization.sentences,
            decoration: const InputDecoration(labelText: 'Description'),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            initialValue: _category,
            decoration: const InputDecoration(labelText: 'Shop label'),
            items: [for (final c in rewardCategories) DropdownMenuItem(value: c, child: Text(c))],
            onChanged: (v) => setState(() => _category = v ?? _category),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              const Expanded(child: Text('Screen time minutes (0 = a parent hands it over)')),
              _Stepper(value: _minutes, onChanged: (v) => setState(() => _minutes = v)),
            ],
          ),
        ],
      ),
    ),
    actions: [
      if (widget.reward != null) TextButton(onPressed: _busy ? null : _delete, child: const Text('Delete')),
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
      FilledButton(onPressed: _busy ? null : _save, child: const Text('Save reward')),
    ],
  );
}

class _OrdersPanel extends StatefulWidget {
  const _OrdersPanel();

  @override
  State<_OrdersPanel> createState() => _OrdersPanelState();
}

class _OrdersPanelState extends State<_OrdersPanel> {
  final _add = TextEditingController();

  Future<void> _submit() async {
    final text = _add.text.trim();
    if (text.isEmpty) return;
    _add.clear();
    await _act(context, () => AppScope.read(context).addOrder(text));
  }

  @override
  Widget build(BuildContext context) {
    return _loadingOr(context, (data) {
      final waiting = data.owed.where((o) => !o.done).toList();
      final given = data.owed.where((o) => o.done).toList();
      Widget tile(TodoItem o) => CheckboxListTile(
        value: o.done,
        title: Text(o.summary, style: TextStyle(decoration: o.done ? TextDecoration.lineThrough : null)),
        onChanged: (v) => _act(context, () => AppScope.read(context).setOwedDone(o, v ?? false)),
      );
      return ListView(
        padding: const EdgeInsets.all(12),
        children: [
          const _Section('Orders to deliver'),
          Card(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 4, 4),
                  child: TextField(
                    controller: _add,
                    onSubmitted: (_) => _submit(),
                    decoration: InputDecoration(
                      hintText: 'Add item',
                      border: InputBorder.none,
                      suffixIcon: IconButton(icon: const Icon(Icons.add), onPressed: _submit),
                    ),
                  ),
                ),
                const Divider(height: 1),
                if (waiting.isEmpty) const ListTile(title: Text('Nothing to hand over 🎉')),
                for (final o in waiting) tile(o),
              ],
            ),
          ),
          if (given.isNotEmpty) ...[
            const _Section('Handed over'),
            Card(child: Column(children: [for (final o in given) tile(o)])),
          ],
        ],
      );
    });
  }
}

class _CountdownPanel extends StatelessWidget {
  const _CountdownPanel();

  @override
  Widget build(BuildContext context) {
    return _loadingOr(context, (data) {
      final all = [...data.snap.countdowns]..sort((a, b) => a.days.compareTo(b.days));
      return ListView(
        padding: const EdgeInsets.all(12),
        children: [
          _Section(
            'Countdowns',
            action: TextButton.icon(
              icon: const Icon(Icons.add),
              label: const Text('Add'),
              onPressed: () => _CountdownEditor.show(context, null),
            ),
          ),
          if (all.isEmpty) const ListTile(title: Text('No countdowns yet. Add a birthday or holiday!')),
          if (!all.any((c) => c.easter))
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                icon: const Text('🐣', style: TextStyle(fontSize: 20)),
                label: const Text('Add Easter'),
                onPressed: () async {
                  final state = AppScope.read(context);
                  final err = await state.saveCountdown(easterCountdown(''));
                  if (context.mounted) showResult(context, err, ok: err == null ? 'Added Easter' : null);
                },
              ),
            ),
          for (final c in all)
            Card(
              color: c.days >= 0 && c.days < 7 ? Theme.of(context).colorScheme.tertiaryContainer : null,
              child: ListTile(
                leading: Text(c.emoji, style: const TextStyle(fontSize: 28)),
                title: Text(c.name),
                subtitle: Text(
                  c.easter
                      ? 'Easter Sunday, ${_date(c.date, false)} · moves every year'
                      : '${_date(c.date, c.yearly)}${c.yearly ? ' · every year' : ''}',
                ),
                trailing: Text(
                  c.days < 0 ? 'Past' : daysText(c.days),
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                onTap: () => c.id.startsWith(birthdayPrefix)
                    ? showResult(context, null, ok: 'Change birthdays in Settings, under each child.')
                    : _CountdownEditor.show(context, c),
              ),
            ),
        ],
      );
    });
  }
}

const _months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

String _date(DateTime d, bool yearly) => '${d.day} ${_months[d.month - 1]}${yearly ? '' : ' ${d.year}'}';

class _CountdownEditor extends StatefulWidget {
  /// Null for a new countdown.
  final Countdown? countdown;
  const _CountdownEditor({required this.countdown});

  static Future<void> show(BuildContext context, Countdown? c) => showDialog(
    context: context,
    builder: (_) => Theme(
      data: Theme.of(context),
      child: AppScope(
        state: AppScope.read(context),
        child: _CountdownEditor(countdown: c),
      ),
    ),
  );

  @override
  State<_CountdownEditor> createState() => _CountdownEditorState();
}

class _CountdownEditorState extends State<_CountdownEditor> {
  late final _emoji = TextEditingController(text: widget.countdown?.emoji ?? '🎉');
  late final _name = TextEditingController(text: widget.countdown?.name ?? '');
  late DateTime _when = widget.countdown?.date ?? DateTime.now().add(const Duration(days: 7));
  late bool _yearly = widget.countdown?.yearly ?? true;
  late final bool _easter = widget.countdown?.easter ?? false;

  Future<void> _pick() async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: _when.isBefore(DateTime(now.year - 1)) ? now : _when,
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 5),
    );
    if (d != null) setState(() => _when = d);
  }

  Future<void> _save() async {
    final name = _name.text.trim();
    if (name.isEmpty) {
      showResult(context, 'Give the countdown a name.');
      return;
    }
    final c = Countdown(
      id: widget.countdown?.id ?? '',
      emoji: _emoji.text.trim().isEmpty ? '📅' : _emoji.text.trim(),
      name: name,
      date: _when,
      yearly: _yearly,
      easter: _easter,
    );
    final err = await AppScope.read(context).saveCountdown(c);
    if (!mounted) return;
    Navigator.pop(context);
    showResult(context, err, ok: err == null ? 'Saved $name' : null);
  }

  Future<void> _delete() async {
    final err = await AppScope.read(context).deleteCountdown(widget.countdown!.id);
    if (!mounted) return;
    Navigator.pop(context);
    showResult(context, err, ok: err == null ? 'Deleted ${widget.countdown!.name}' : null);
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.countdown == null ? 'New countdown' : 'Edit countdown'),
    content: SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              SizedBox(
                width: 64,
                child: TextField(
                  controller: _emoji,
                  decoration: const InputDecoration(labelText: 'Emoji'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _name,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: const InputDecoration(labelText: 'Name', hintText: 'e.g. Sam\'s birthday'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_easter)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.event),
              title: Text('Easter Sunday, ${_date(_when, false)}'),
              subtitle: const Text('The date moves every year and is worked out for you.'),
            )
          else ...[
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.event),
              title: Text(_date(_when, false)),
              trailing: const Text('Change'),
              onTap: _pick,
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Every year'),
              subtitle: const Text('For birthdays and holidays'),
              value: _yearly,
              onChanged: (v) => setState(() => _yearly = v),
            ),
          ],
        ],
      ),
    ),
    actions: [
      if (widget.countdown != null) TextButton(onPressed: _delete, child: const Text('Delete')),
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
      FilledButton(onPressed: _save, child: const Text('Save')),
    ],
  );
}

class _Section extends StatelessWidget {
  final String text;
  final Widget? action;
  const _Section(this.text, {this.action});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(8, 14, 0, 4),
    child: Row(
      children: [
        Expanded(child: Text(text, style: Theme.of(context).textTheme.titleMedium)),
        ?action,
      ],
    ),
  );
}

/// Add or edit a routine: name, emoji, points and its steps with minutes.
class _RoutineEditor extends StatefulWidget {
  final String kid;
  final Routine? routine;
  const _RoutineEditor({required this.kid, required this.routine});

  static Future<void> show(BuildContext context, String kid, Routine? r) => Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => Theme(
        data: Theme.of(context),
        child: AppScope(
          state: AppScope.read(context),
          child: _RoutineEditor(kid: kid, routine: r),
        ),
      ),
    ),
  );

  @override
  State<_RoutineEditor> createState() => _RoutineEditorState();
}

class _RoutineEditorState extends State<_RoutineEditor> {
  late final _name = TextEditingController(text: widget.routine?.name ?? '');
  late final _emoji = TextEditingController(text: widget.routine?.emoji ?? '⭐');
  late int _points = widget.routine?.points ?? 2;
  late final List<(TextEditingController, int)> _steps = [
    for (final s in widget.routine?.steps ?? const [RoutineStep('', 2)])
      (TextEditingController(text: s.text), s.minutes),
  ];
  bool _busy = false;

  @override
  void dispose() {
    _name.dispose();
    _emoji.dispose();
    for (final (c, _) in _steps) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    final steps = [
      for (final (c, m) in _steps)
        if (c.text.trim().isNotEmpty) RoutineStep(c.text.trim(), m),
    ];
    if (_name.text.trim().isEmpty || steps.isEmpty) {
      showResult(context, 'Give it a name and at least one step.');
      return;
    }
    setState(() => _busy = true);
    final err = await AppScope.read(context).saveRoutine(
      widget.kid,
      Routine(
        id: widget.routine?.id ?? '',
        name: _name.text.trim(),
        emoji: _emoji.text.trim().isEmpty ? '⭐' : _emoji.text.trim(),
        points: _points,
        steps: steps,
      ),
    );
    if (!mounted) return;
    setState(() => _busy = false);
    if (err != null) return showResult(context, err);
    Navigator.pop(context);
  }

  Future<void> _delete() async {
    final r = widget.routine!;
    if (!await confirm(context, 'Delete the ${r.name} routine?', '', yes: 'Delete', no: 'Cancel')) return;
    if (!mounted) return;
    final err = await AppScope.read(context).deleteRoutine(widget.kid, r.id);
    if (!mounted) return;
    if (err != null) return showResult(context, err);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(
        widget.routine == null ? 'New routine for ${nameOf(widget.kid)}' : 'Edit ${widget.routine!.name}',
      ),
      actions: [
        if (widget.routine != null)
          IconButton(
            tooltip: 'Delete routine',
            icon: const Icon(Icons.delete_outline),
            onPressed: _busy ? null : _delete,
          ),
        TextButton(onPressed: _busy ? null : _save, child: const Text('Save')),
      ],
    ),
    body: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 640),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Row(
              children: [
                SizedBox(
                  width: 64,
                  child: TextField(
                    controller: _emoji,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 24),
                    decoration: const InputDecoration(labelText: 'Emoji'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _name,
                    textCapitalization: TextCapitalization.words,
                    decoration: const InputDecoration(labelText: 'Name, e.g. Morning'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Expanded(child: Text('Points for finishing it')),
                _Stepper(value: _points, onChanged: (v) => setState(() => _points = v)),
              ],
            ),
            const _Section('Steps'),
            for (final (i, (c, m)) in _steps.indexed)
              Card(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 4, 4, 4),
                  child: Row(
                    children: [
                      Text('${i + 1}.', style: const TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(width: 8),
                      Expanded(
                        child: TextField(
                          controller: c,
                          textCapitalization: TextCapitalization.sentences,
                          decoration: const InputDecoration(hintText: 'Step', border: InputBorder.none),
                        ),
                      ),
                      _Stepper(value: m, onChanged: (v) => setState(() => _steps[i] = (c, v))),
                      const Text('min'),
                      IconButton(
                        tooltip: 'Remove step',
                        icon: const Icon(Icons.close),
                        onPressed: _steps.length == 1 ? null : () => setState(() => _steps.removeAt(i)),
                      ),
                    ],
                  ),
                ),
              ),
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                icon: const Icon(Icons.add),
                label: const Text('Add a step'),
                onPressed: () => setState(() => _steps.add((TextEditingController(), 2))),
              ),
            ),
            const Text('Minutes give the step a timer; 0 means no timer.'),
          ],
        ),
      ),
    ),
  );
}

/// Each child's week: points earned, chores and routines done, what they
/// bought, and their streak.
class _WeekPanel extends StatefulWidget {
  const _WeekPanel();

  @override
  State<_WeekPanel> createState() => _WeekPanelState();
}

class _WeekPanelState extends State<_WeekPanel> {
  bool _last = false;

  @override
  Widget build(BuildContext context) {
    return _loadingOr(context, (data) {
      final now = DateTime.now();
      final thisMonday = mondayOf(now);
      final from = _last ? DateTime(thisMonday.year, thisMonday.month, thisMonday.day - 7) : thisMonday;
      final to = _last ? thisMonday : DateTime(now.year, now.month, now.day + 1);
      String d(DateTime t) =>
          '${t.day} ${const ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][t.month - 1]}';
      final money = data.snap.money;
      return ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Center(
            child: SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('This week')),
                ButtonSegment(value: true, label: Text('Last week')),
              ],
              selected: {_last},
              onSelectionChanged: (v) => setState(() => _last = v.first),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Text(
              '${d(from)} to ${d(to.subtract(const Duration(days: 1)))}',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
          for (final kid in kids) _weekCard(context, data, kid, from, to, money),
          if (data.snap.familyGoal case final g?)
            Card(
              child: ListTile(
                leading: Text(g.emoji, style: const TextStyle(fontSize: 28)),
                title: Text('Family goal: ${g.name}'),
                subtitle: Text(g.reached ? 'Reached! 🎉' : '${g.saved} of ${g.target} points'),
              ),
            ),
        ],
      );
    });
  }

  Widget _weekCard(BuildContext context, HubData data, String kid, DateTime from, DateTime to, Money money) {
    final entries = [
      for (final e in data.log[kid] ?? const <LogEntry>[])
        if (!e.when.isBefore(from) && e.when.isBefore(to)) e,
    ];
    var earned = 0, chores = 0, routines = 0, challenges = 0, gave = 0, paid = 0;
    final bought = <String, int>{};
    for (final e in entries) {
      final delta = e.delta ?? 0;
      switch (e.kind) {
        case 'chore':
          chores++;
        case 'unchore':
          chores--;
        case 'routine':
          routines++;
        case 'challenge':
          challenges++;
        case 'buy':
          bought[e.what ?? '?'] = (bought[e.what ?? '?'] ?? 0) + 1;
        case 'family':
          gave -= delta;
        case 'payout':
          paid -= delta;
      }
      if (delta > 0 && e.kind != 'unchore') earned += delta;
      if (e.kind == 'unchore') earned += delta;
    }
    final st = data.statsFor(kid);
    final scheme = Theme.of(context).colorScheme;
    Widget stat(String value, String label) => Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: scheme.primary),
          ),
          Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
        ],
      ),
    );
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${KidTheme.of(kid).mascot} ${nameOf(kid)}', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            Row(
              children: [
                stat('$earned', 'points earned'),
                stat('$chores', 'chores done'),
                stat('$routines', 'routines'),
                stat('${st.current}', 'day streak'),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              bought.isEmpty
                  ? 'Bought: nothing'
                  : 'Bought: ${bought.entries.map((e) => e.value > 1 ? '${e.key} ×${e.value}' : e.key).join(', ')}',
            ),
            if (challenges > 0) Text('Challenges done: $challenges'),
            if (gave > 0) Text('Put $gave points into the family goal'),
            if (paid > 0) Text('Paid out: ${money.of(paid)} ($paid points)'),
            Text(
              'Badges: ${badges.any((b) => b.earned(st)) ? badges.where((b) => b.earned(st)).map((b) => b.emoji).join(' ') : 'none yet'}',
            ),
          ],
        ),
      ),
    );
  }
}

/// Today's challenge on a child's tab, with Approve when it is waiting.
class _ChallengeToday extends StatelessWidget {
  final String kid;
  final ChallengeDay day;
  const _ChallengeToday({required this.kid, required this.day});

  @override
  Widget build(BuildContext context) {
    final c = day.current!;
    final state = AppScope.of(context);
    return Column(
      children: [
        const _Section('Challenge today'),
        Card(
          child: ListTile(
            tileColor: day.waiting ? Theme.of(context).colorScheme.tertiaryContainer : null,
            leading: Text(catOf(c.cat).emoji, style: const TextStyle(fontSize: 26)),
            title: Text(c.text),
            subtitle: Text(
              [
                day.waiting
                    ? '${nameOf(kid)} says it\'s done'
                    : day.done
                    ? 'Done ✓'
                    : 'Doing it now',
                '${c.points} pts',
                '${day.spins} spin${day.spins == 1 ? '' : 's'} used',
              ].join(' · '),
            ),
            trailing: day.waiting
                ? Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextButton(
                        onPressed: () => _act(context, () => state.approveChallenge(kid, false)),
                        child: const Text('Not yet'),
                      ),
                      FilledButton(
                        onPressed: () => _act(
                          context,
                          () => state.approveChallenge(kid, true),
                          ok: 'Approved: +${c.points} for ${nameOf(kid)}',
                        ),
                        child: const Text('Approve'),
                      ),
                    ],
                  )
                : null,
          ),
        ),
      ],
    );
  }
}

/// The challenge spinner: on or off, spins a day, which kinds are on, and
/// the list of challenges in each kind.
class _ChallengesPanel extends StatelessWidget {
  const _ChallengesPanel();

  @override
  Widget build(BuildContext context) {
    return _loadingOr(context, (data) {
      final state = AppScope.of(context);
      final s = data.snap.challenge;
      Future<void> set(ChallengeSettings n) => _act(context, () => state.setChallengeSettings(n));
      return ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            child: Column(
              children: [
                SwitchListTile(
                  title: const Text('Challenge spinner'),
                  subtitle: const Text('Kids spin for something to make or do, and earn points for it.'),
                  value: s.on,
                  onChanged: (v) => set(s.copyWith(on: v)),
                ),
                SwitchListTile(
                  title: const Text('Photos of what they make'),
                  subtitle: const Text(
                    'Kids can take a photo when they finish. Photos stay on that tablet and are never uploaded.',
                  ),
                  value: s.photos,
                  onChanged: (v) => set(s.copyWith(photos: v)),
                ),
                ListTile(
                  title: const Text('Spins a day'),
                  subtitle: const Text('Each child. Spinning again uses one up.'),
                  trailing: _Stepper(
                    value: s.spins,
                    min: 1,
                    onChanged: (v) => set(s.copyWith(spins: v)),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 14),
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 6,
                    children: [
                      for (final cat in challengeCats)
                        FilterChip(
                          label: Text('${cat.emoji} ${cat.name}'),
                          selected: s.catOn(cat.id),
                          onSelected: (on) => set(
                            s.copyWith(
                              offCats: on
                                  ? [
                                      for (final o in s.offCats)
                                        if (o != cat.id) o,
                                    ]
                                  : [...s.offCats, cat.id],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          _Section(
            'Challenges',
            action: TextButton.icon(
              icon: const Icon(Icons.add),
              label: const Text('Add'),
              onPressed: () => _ChallengeEditor.show(context, null),
            ),
          ),
          for (final cat in challengeCats)
            Card(
              child: ExpansionTile(
                leading: Text(cat.emoji, style: const TextStyle(fontSize: 26)),
                title: Text(cat.name),
                subtitle: Text(
                  '${data.snap.challenges.where((c) => c.cat == cat.id && c.on).length} on'
                  '${s.catOn(cat.id) ? '' : ' · kind switched off'}',
                ),
                children: [
                  for (final c in data.snap.challenges)
                    if (c.cat == cat.id)
                      ListTile(
                        title: Text(
                          c.text,
                          style: TextStyle(color: c.on ? null : Theme.of(context).disabledColor),
                        ),
                        subtitle: Text(
                          [
                            '${c.points} pts',
                            if (c.minutes > 0) '${c.minutes} min',
                            if (!c.on) 'off',
                          ].join(' · '),
                        ),
                        trailing: const Icon(Icons.edit_outlined),
                        onTap: () => _ChallengeEditor.show(context, c),
                      ),
                  ListTile(
                    leading: const Icon(Icons.add),
                    title: Text('Add a ${cat.name.toLowerCase()} challenge'),
                    onTap: () => _ChallengeEditor.show(context, null, cat: cat.id),
                  ),
                ],
              ),
            ),
        ],
      );
    });
  }
}

class _ChallengeEditor extends StatefulWidget {
  /// Null for a new challenge.
  final Challenge? challenge;
  final String cat;
  const _ChallengeEditor({required this.challenge, required this.cat});

  static Future<void> show(BuildContext context, Challenge? c, {String? cat}) => Navigator.push(
    context,
    MaterialPageRoute<void>(
      builder: (_) => AppScope(
        state: AppScope.read(context),
        child: _ChallengeEditor(challenge: c, cat: c?.cat ?? cat ?? challengeCats.first.id),
      ),
    ),
  );

  @override
  State<_ChallengeEditor> createState() => _ChallengeEditorState();
}

class _ChallengeEditorState extends State<_ChallengeEditor> {
  static const _maxSteps = 6;
  static const _quick = {
    'Easier': 'Make it easier for a 4 year old.',
    'Harder': 'Make it a bit harder for an 8 year old.',
    'More fun': 'Make it more fun and exciting, same length.',
    'Simpler words': 'Make the steps shorter and simpler to read.',
    'Safety check': 'Check it is safe for kids and add grown-up help where needed.',
  };

  final _text = TextEditingController();
  final _need = TextEditingController();
  final _ask = TextEditingController();
  final _steps = <TextEditingController>[];
  late String _cat = widget.cat;
  int _points = 3, _minutes = 20, _age = 5;
  bool _on = true, _asking = false, _touched = false;
  ChallengeDraft? _beforeAi;

  @override
  void initState() {
    super.initState();
    final c = widget.challenge;
    if (c != null) {
      _points = c.points;
      _minutes = c.minutes;
      _on = c.on;
    }
    _fill(_draftOf(c));
    // The catalog's steps, once loaded, for a starter challenge with none of its own.
    if (c != null && c.how == null) {
      Catalog.load().then((_) {
        if (mounted && !_touched) setState(() => _fill(_draftOf(c)));
      });
    }
  }

  ChallengeDraft _draftOf(Challenge? c) {
    final how = c == null ? null : Catalog.forChallenge(c);
    return ChallengeDraft(
      text: c?.text ?? '',
      cat: _cat,
      points: _points,
      minutes: _minutes,
      age: how?.age ?? 5,
      need: how?.need ?? const [],
      steps: how == null ? const ['', '', ''] : [for (final s in how.steps) s.text],
    );
  }

  ChallengeDraft get _draft => ChallengeDraft(
    text: _text.text.trim(),
    cat: _cat,
    points: _points,
    minutes: _minutes,
    age: _age,
    need: [
      for (final n in _need.text.split(','))
        if (n.trim().isNotEmpty) n.trim(),
    ],
    steps: [
      for (final s in _steps)
        if (s.text.trim().isNotEmpty) s.text.trim(),
    ],
  );

  void _fill(ChallengeDraft d) {
    _text.text = d.text;
    _cat = d.cat;
    _points = d.points;
    _minutes = d.minutes;
    _age = d.age;
    _need.text = d.need.join(', ');
    for (final s in _steps) {
      s.dispose();
    }
    _steps
      ..clear()
      ..addAll([for (final s in d.steps) TextEditingController(text: s)]);
  }

  @override
  void dispose() {
    for (final c in [_text, _need, _ask, ..._steps]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _askClaude(String request) async {
    final state = AppScope.read(context);
    if (request.trim().isEmpty || _asking) return;
    final before = _draft;
    setState(() => _asking = true);
    try {
      final got = await ChallengeAi(state.auth!).ask(before, request.trim());
      if (!mounted) return;
      setState(() {
        _beforeAi = before;
        _touched = true;
        _fill(got);
      });
      showResult(context, null, ok: 'Claude changed it. Save to keep it.');
    } on AppError catch (e) {
      if (mounted) showResult(context, e.message);
    } finally {
      if (mounted) setState(() => _asking = false);
    }
  }

  Future<void> _save() async {
    final d = _draft;
    if (d.text.isEmpty) return showResult(context, 'Give the challenge a name.');
    // Steps that match the catalog's are left to the catalog, so they get its pictures.
    final starter = Catalog.entry(src: widget.challenge?.src, text: d.text);
    final same =
        starter != null &&
        starter.age == d.age &&
        starter.need.join('\n') == d.need.join('\n') &&
        starter.steps.map((s) => s.text).join('\n') == d.steps.join('\n');
    final err = await AppScope.read(context).saveChallenge(
      Challenge(
        id: widget.challenge?.id ?? '',
        cat: d.cat,
        text: d.text,
        points: d.points,
        minutes: d.minutes,
        on: _on,
        how: same || d.steps.isEmpty ? null : ChallengeHow(age: d.age, need: d.need, steps: d.steps),
      ),
    );
    if (!mounted) return;
    if (err != null) return showResult(context, err);
    Navigator.pop(context);
  }

  Future<void> _delete() async {
    final state = AppScope.read(context);
    final err = await state.deleteChallenge(widget.challenge!.id);
    if (!mounted) return;
    if (err != null) return showResult(context, err);
    Navigator.pop(context);
  }

  Widget _askCard(BuildContext context) {
    final purple = const Color(0xFF7E57C2);
    final isNew = _text.text.trim().isEmpty;
    return Card(
      color: purple.withValues(alpha: 0.08),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '✨ Ask Claude',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: purple),
            ),
            const SizedBox(height: 8),
            if (!isNew)
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final e in _quick.entries)
                    ActionChip(label: Text(e.key), onPressed: _asking ? null : () => _askClaude(e.value)),
                ],
              ),
            TextField(
              controller: _ask,
              minLines: 1,
              maxLines: 3,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                hintText: isNew
                    ? 'e.g. a marble run from toilet rolls'
                    : 'e.g. use things everyone has at home',
              ),
              onSubmitted: _askClaude,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: purple),
                  icon: _asking
                      ? const SizedBox.square(
                          dimension: 16,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Icon(Icons.auto_awesome),
                  label: Text(_asking ? 'Thinking…' : (isNew ? 'Write it' : 'Change it')),
                  onPressed: _asking ? null : () => _askClaude(_ask.text),
                ),
                const SizedBox(width: 8),
                if (_beforeAi != null && !_asking)
                  TextButton(
                    onPressed: () => setState(() {
                      _fill(_beforeAi!);
                      _beforeAi = null;
                    }),
                    child: const Text('Undo'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.challenge == null ? 'New challenge' : 'Edit challenge'),
        actions: [TextButton(onPressed: _save, child: const Text('Save'))],
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 640),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
              children: [
                if (ChallengeAi.canUse(state.auth)) _askCard(context),
                const SizedBox(height: 8),
                TextField(
                  controller: _text,
                  autofocus: widget.challenge == null && !ChallengeAi.canUse(state.auth),
                  maxLines: 2,
                  minLines: 1,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: const InputDecoration(labelText: 'Challenge, e.g. Build a bridge'),
                  onChanged: (_) => setState(() => _touched = true),
                ),
                DropdownButtonFormField<String>(
                  key: ValueKey(_cat),
                  initialValue: _cat,
                  decoration: const InputDecoration(labelText: 'Kind'),
                  items: [
                    for (final c in challengeCats)
                      DropdownMenuItem(value: c.id, child: Text('${c.emoji} ${c.name}')),
                  ],
                  onChanged: (v) => setState(() => _cat = v ?? _cat),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Expanded(child: Text('Points')),
                    _Stepper(value: _points, min: 1, onChanged: (v) => setState(() => _points = v)),
                  ],
                ),
                Row(
                  children: [
                    const Expanded(child: Text('Timer minutes (0 for none)')),
                    _Stepper(value: _minutes, onChanged: (v) => setState(() => _minutes = v)),
                  ],
                ),
                Row(
                  children: [
                    const Expanded(child: Text('From age')),
                    _Stepper(value: _age, min: 2, onChanged: (v) => setState(() => _age = v)),
                  ],
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('In the spinner'),
                  value: _on,
                  onChanged: (v) => setState(() => _on = v),
                ),
                TextField(
                  controller: _need,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: const InputDecoration(labelText: 'You\'ll need (commas between)'),
                  onChanged: (_) => _touched = true,
                ),
                const SizedBox(height: 18),
                Text('Show me how', style: Theme.of(context).textTheme.titleMedium),
                for (final (i, c) in _steps.indexed)
                  Row(
                    key: ObjectKey(c),
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 14, right: 10),
                        child: CircleAvatar(
                          radius: 14,
                          backgroundColor: Colors.black,
                          child: Text('${i + 1}', style: const TextStyle(color: Colors.white)),
                        ),
                      ),
                      Expanded(
                        child: TextField(
                          controller: c,
                          minLines: 1,
                          maxLines: 3,
                          textCapitalization: TextCapitalization.sentences,
                          decoration: InputDecoration(hintText: 'Step ${i + 1}'),
                          onChanged: (_) => _touched = true,
                        ),
                      ),
                      PopupMenuButton<String>(
                        onSelected: (a) => setState(() {
                          _touched = true;
                          final j = a == 'up' ? i - 1 : i + 1;
                          if (a == 'remove') {
                            _steps.removeAt(i).dispose();
                          } else {
                            _steps[i] = _steps[j];
                            _steps[j] = c;
                          }
                        }),
                        itemBuilder: (_) => [
                          if (i > 0) const PopupMenuItem(value: 'up', child: Text('Move up')),
                          if (i < _steps.length - 1)
                            const PopupMenuItem(value: 'down', child: Text('Move down')),
                          const PopupMenuItem(value: 'remove', child: Text('Remove')),
                        ],
                      ),
                    ],
                  ),
                if (_steps.length < _maxSteps)
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton.icon(
                      icon: const Icon(Icons.add),
                      label: const Text('Add a step'),
                      onPressed: () => setState(() => _steps.add(TextEditingController())),
                    ),
                  ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    if (widget.challenge != null) TextButton(onPressed: _delete, child: const Text('Delete')),
                    const Spacer(),
                    FilledButton(onPressed: _save, child: const Text('Save')),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
