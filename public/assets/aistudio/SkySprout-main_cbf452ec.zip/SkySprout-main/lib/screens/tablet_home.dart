import 'dart:async';

import 'package:flutter/material.dart';

import '../models.dart';
import '../themes.dart';
import '../widgets/common.dart';
import '../widgets/hub_menu.dart';
import '../widgets/kids_hub_sign.dart';
import 'kid_screen.dart';

/// The home page every device opens on: a header with the time and a
/// gallery of big buttons, one per kid's dashboard plus
/// one for the parent portal.
class TabletHome extends StatelessWidget {
  const TabletHome({super.key});

  @override
  Widget build(BuildContext context) {
    // Rebuild when the family changes, so added children show.
    AppScope.of(context);
    final landscape = MediaQuery.sizeOf(context).aspectRatio > 1;

    return Scaffold(
      backgroundColor: const Color(0xFFF4EFE6),
      body: SafeArea(
        child: Column(
          children: [
            const StatusBanner(),
            const _Header(),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Builder(
                  builder: (context) {
                    // On a phone with more than one kid, a scrolling list of cards,
                    // with the parent portal kept in view below it.
                    if (MediaQuery.sizeOf(context).shortestSide < 600 && kids.length > 1) {
                      return Column(
                        children: [
                          Expanded(
                            child: ListView(
                              children: [
                                for (final k in kids)
                                  Padding(
                                    padding: const EdgeInsets.all(10),
                                    child: _KidCard(kid: k, compact: true),
                                  ),
                              ],
                            ),
                          ),
                          const Padding(padding: EdgeInsets.all(10), child: _ParentCard()),
                        ],
                      );
                    }
                    // One row in landscape (up to 4 a row); in portrait one card a
                    // row for two kids, two a row for more.
                    final perRow = landscape ? kids.length.clamp(1, 4) : (kids.length <= 2 ? 1 : 2);
                    final rows = [
                      for (var i = 0; i < kids.length; i += perRow)
                        kids.sublist(i, (i + perRow).clamp(0, kids.length)),
                    ];
                    return Column(
                      children: [
                        for (final row in rows)
                          Expanded(
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                for (final k in row)
                                  Expanded(
                                    child: Padding(
                                      padding: const EdgeInsets.all(10),
                                      child: _KidCard(kid: k),
                                    ),
                                  ),
                                // Keep a short last row's cards the same width.
                                for (var i = row.length; i < perRow; i++) const Expanded(child: SizedBox()),
                              ],
                            ),
                          ),
                        const Padding(padding: EdgeInsets.all(10), child: _ParentCard()),
                      ],
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header();

  @override
  Widget build(BuildContext context) {
    final phone = MediaQuery.sizeOf(context).shortestSide < 600;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // The ☰ menu sits in its own row above the header.
        const Padding(
          padding: EdgeInsets.fromLTRB(6, 2, 6, 0),
          child: HubMenu(place: HubPlace.kids, iconSize: 32, color: Color(0xFF2F2F2F)),
        ),
        Padding(
          padding: EdgeInsets.fromLTRB(phone ? 10 : 18, 0, phone ? 16 : 24, 4),
          child: Row(
            children: [
              Flexible(
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: KidsHubSign(height: phone ? 76 : 120),
                ),
              ),
              const SizedBox(width: 12),
              _Clock(big: !phone),
            ],
          ),
        ),
      ],
    );
  }
}

/// The parent portal's button in the gallery. Asks for the PIN. Shows how
/// many things are waiting for a grown-up.
class _ParentCard extends StatelessWidget {
  const _ParentCard();

  @override
  Widget build(BuildContext context) {
    final phone = MediaQuery.sizeOf(context).shortestSide < 600;
    // Chores to approve and rewards to hand over.
    final waiting = AppScope.of(context).waitingCount;
    return SizedBox(
      height: MediaQuery.sizeOf(context).shortestSide < 600 ? 92 : 112,
      child: Material(
        color: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: Color(0xFF2F2F2F), width: 3),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => openParentPortal(context),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Icon(Icons.lock_rounded, size: phone ? 32 : 40, color: const Color(0xFF2F2F2F)),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Parent portal',
                        style: TextStyle(
                          fontSize: phone ? 22 : 28,
                          fontWeight: FontWeight.w800,
                          color: const Color(0xFF2F2F2F),
                        ),
                      ),
                      const Text(
                        'Grown-ups only · PIN needed',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 15, color: Color(0xFF555555)),
                      ),
                    ],
                  ),
                ),
                if (waiting > 0)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE8590C),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      phone ? '$waiting' : '$waiting waiting',
                      style: TextStyle(
                        fontSize: phone ? 18 : 20,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),
                  ),
                const Icon(Icons.chevron_right, size: 32, color: Color(0xFF2F2F2F)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _KidCard extends StatelessWidget {
  final String kid;

  /// Sized to its content, for the scrolling list on phones.
  final bool compact;
  const _KidCard({required this.kid, this.compact = false});

  @override
  Widget build(BuildContext context) {
    final data = AppScope.of(context).data;
    final kt = KidTheme.of(kid);
    final chores = data?.choresFor(kid) ?? const <TodoItem>[];
    final done = chores.where((c) => c.done).length;
    final toDo = chores.where((c) => !c.done).take(3).toList();

    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => KidScreen(kid: kid))),
      child: Container(
        decoration: kt
            .box(color: kt.bg)
            .copyWith(
              boxShadow: [BoxShadow(color: kt.border, offset: const Offset(6, 6))],
            ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(kt.radius > 0 ? kt.radius - 2 : 0),
          child: KidBackground(
            theme: kt,
            child: Padding(
              padding: MediaQuery.sizeOf(context).shortestSide < 600
                  ? const EdgeInsets.fromLTRB(16, 14, 16, 44)
                  : const EdgeInsets.fromLTRB(24, 30, 24, 56),
              child: LayoutBuilder(
                builder: (context, c) {
                  final roomy = !compact && c.maxHeight > 420;
                  // Short cards (lots of kids on a small screen) leave the chores out.
                  final showChores = compact || c.maxHeight > 190;
                  return Column(
                    mainAxisSize: compact ? MainAxisSize.min : MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(kt.mascot, style: TextStyle(fontSize: roomy ? 56 : 40)),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  nameOf(kid),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: kt.text(roomy ? 46 : 32),
                                ),
                                if (childOf(kid)?.ageNow case final age?)
                                  Text('Age $age', style: kt.text(roomy ? 20 : 16, bold: false)),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Wrap(
                        spacing: 12,
                        runSpacing: 10,
                        children: [
                          PointsBadge(theme: kt, points: data?.points(kid) ?? 0, size: roomy ? 32 : 22),
                          ScreenTimePill(theme: kt, timer: data?.timer(kid), size: roomy ? 18 : 14),
                        ],
                      ),
                      compact ? const SizedBox(height: 14) : const Spacer(),
                      if (chores.isNotEmpty && showChores)
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(14),
                          decoration: kt.box(shadow: false),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                done == chores.length
                                    ? 'All chores done! 🎉'
                                    : '$done of ${chores.length} chores done',
                                style: kt.text(20),
                              ),
                              if (roomy)
                                for (final ch in toDo)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 6),
                                    child: Text(
                                      '□  ${ch.title}',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: kt.text(18, bold: false),
                                    ),
                                  ),
                            ],
                          ),
                        ),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Clock extends StatefulWidget {
  final bool big;
  const _Clock({this.big = true});

  @override
  State<_Clock> createState() => _ClockState();
}

class _ClockState extends State<_Clock> {
  late final Timer _t = Timer.periodic(
    const Duration(seconds: 15),
    (_) => setState(() => _now = DateTime.now()),
  );
  DateTime _now = DateTime.now();

  @override
  void dispose() {
    _t.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    // 12-hour clock: 6:05 PM.
    final h = _now.hour % 12 == 0 ? 12 : _now.hour % 12;
    final mm = _now.minute.toString().padLeft(2, '0');
    final ampm = _now.hour < 12 ? 'AM' : 'PM';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          '$h:$mm $ampm',
          style: TextStyle(
            fontSize: widget.big ? 40 : 28,
            fontWeight: FontWeight.w900,
            color: const Color(0xFF2F2F2F),
            height: 1.1,
          ),
        ),
        Text(
          '${days[_now.weekday - 1]} ${_now.day} ${months[_now.month - 1]}',
          style: TextStyle(fontSize: widget.big ? 18 : 13, color: const Color(0xFF5A5A5A)),
        ),
      ],
    );
  }
}
