import 'package:flutter/material.dart';

import '../config.dart';
import '../themes.dart';
import '../widgets/common.dart';

/// Asked once after signing in on a device: is it a parent's phone, which
/// gets notifications, or a kids' tablet, which doesn't? Changed later in
/// Settings.
class DeviceRoleScreen extends StatelessWidget {
  const DeviceRoleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return Theme(
      data: parentTheme(MediaQuery.platformBrightnessOf(context)),
      child: Builder(
        builder: (context) => Scaffold(
          appBar: AppBar(title: const Text('Who uses this device?')),
          body: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 560),
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  const Text('You can change this later in Settings.'),
                  const SizedBox(height: 16),
                  _Choice(
                    icon: Icons.phone_android_rounded,
                    title: 'A parent\'s phone',
                    text:
                        'Get a notification when a chore needs approving or something is bought in the shop.',
                    onTap: () => state.setRole(DeviceRole.parent),
                  ),
                  const SizedBox(height: 12),
                  _Choice(
                    icon: Icons.tablet_android_rounded,
                    title: 'The kids\' tablet',
                    text: 'No notifications. The kids tick their chores and use the shop here.',
                    onTap: () => state.setRole(DeviceRole.kids),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Choice extends StatelessWidget {
  final IconData icon;
  final String title, text;
  final VoidCallback onTap;
  const _Choice({required this.icon, required this.title, required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      leading: Icon(icon, size: 40),
      title: Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
      subtitle: Text(text),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    ),
  );
}
