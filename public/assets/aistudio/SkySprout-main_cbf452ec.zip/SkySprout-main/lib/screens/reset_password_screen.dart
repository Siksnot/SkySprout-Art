import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models.dart';
import '../sync.dart';
import '../themes.dart';

/// Forgot password, in three steps: the email address, the passcode that
/// Supabase emails, then a new password. Pops true once signed in.
class ResetPasswordScreen extends StatefulWidget {
  final SupabaseAuth auth;
  final String email;
  const ResetPasswordScreen({super.key, required this.auth, this.email = ''});

  @override
  State<ResetPasswordScreen> createState() => _ResetPasswordScreenState();
}

enum _Step { email, code, password }

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  late final _email = TextEditingController(text: widget.email);
  final _code = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  _Step _step = _Step.email;
  bool _busy = false;
  bool _show = false;
  String? _error;

  /// Seconds until another passcode can be sent.
  int _wait = 0;
  Timer? _timer;

  @override
  void dispose() {
    _timer?.cancel();
    for (final c in [_email, _code, _password, _confirm]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _run(Future<void> Function() f) async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await f();
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _send() => _run(() async {
    final email = _email.text.trim();
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email)) {
      throw AppError('Enter the email address you signed up with.');
    }
    await widget.auth.resetPassword(email);
    _code.clear();
    setState(() => _step = _Step.code);
    _startWait();
  });

  void _startWait() {
    _timer?.cancel();
    setState(() => _wait = 60);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return t.cancel();
      setState(() => _wait--);
      if (_wait <= 0) t.cancel();
    });
  }

  Future<void> _check() => _run(() async {
    final code = _code.text.replaceAll(RegExp(r'\s'), '');
    if (code.length < 6) throw AppError('Enter the passcode from the email.');
    await widget.auth.verifyResetCode(_email.text, code);
    setState(() => _step = _Step.password);
  });

  Future<void> _save() => _run(() async {
    if (_password.text.length < 8) throw AppError('Use at least 8 characters.');
    if (_password.text != _confirm.text) throw AppError('The two passwords don\'t match.');
    await widget.auth.setPassword(_password.text);
    if (mounted) Navigator.pop(context, true);
  });

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    final (icon, title, body, fields, button, action) = switch (_step) {
      _Step.email => (
        Icons.lock_reset_rounded,
        'Reset your password',
        'Enter the email address for your Kids Hub account and we\'ll send you a passcode.',
        [
          TextField(
            controller: _email,
            keyboardType: TextInputType.emailAddress,
            autofillHints: const [AutofillHints.email],
            autofocus: _email.text.isEmpty,
            onSubmitted: (_) => _send(),
            decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder()),
          ),
        ],
        'Send passcode',
        _send,
      ),
      _Step.code => (
        Icons.mark_email_read_outlined,
        'Check your email',
        'We sent a passcode to ${_email.text.trim()}. It can take a minute to arrive; '
            'check your spam folder if you can\'t see it.',
        [
          TextField(
            controller: _code,
            autofocus: true,
            keyboardType: TextInputType.number,
            autofillHints: const [AutofillHints.oneTimeCode],
            inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(10)],
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 30, letterSpacing: 10, fontWeight: FontWeight.w700),
            onSubmitted: (_) => _check(),
            decoration: const InputDecoration(hintText: '••••••', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 8),
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            children: [
              TextButton(
                onPressed: _busy ? null : () => setState(() => _step = _Step.email),
                child: const Text('Use a different email'),
              ),
              TextButton(
                onPressed: _busy || _wait > 0 ? null : _send,
                child: Text(_wait > 0 ? 'Resend in ${_wait}s' : 'Resend passcode'),
              ),
            ],
          ),
        ],
        'Continue',
        _check,
      ),
      _Step.password => (
        Icons.password_rounded,
        'Choose a new password',
        'You\'re signed in. Pick a new password for ${_email.text.trim()}.',
        [
          TextField(
            controller: _password,
            autofocus: true,
            obscureText: !_show,
            autofillHints: const [AutofillHints.newPassword],
            decoration: InputDecoration(
              labelText: 'New password',
              helperText: 'At least 8 characters',
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(
                tooltip: _show ? 'Hide password' : 'Show password',
                icon: Icon(_show ? Icons.visibility_off : Icons.visibility),
                onPressed: () => setState(() => _show = !_show),
              ),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _confirm,
            obscureText: !_show,
            autofillHints: const [AutofillHints.newPassword],
            onSubmitted: (_) => _save(),
            decoration: const InputDecoration(labelText: 'Type it again', border: OutlineInputBorder()),
          ),
        ],
        'Save and sign in',
        _save,
      ),
    };
    final step = _Step.values.indexOf(_step);

    return Theme(
      data: parentTheme(MediaQuery.platformBrightnessOf(context)),
      child: Scaffold(
        appBar: AppBar(title: Text('Step ${step + 1} of 3')),
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: ListView(
                padding: const EdgeInsets.all(24),
                children: [
                  LinearProgressIndicator(value: (step + 1) / 3, borderRadius: BorderRadius.circular(4)),
                  const SizedBox(height: 28),
                  Icon(icon, size: 56, color: t.colorScheme.primary),
                  const SizedBox(height: 16),
                  Text(
                    title,
                    textAlign: TextAlign.center,
                    style: t.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  Text(body, textAlign: TextAlign.center, style: t.textTheme.bodyLarge),
                  const SizedBox(height: 24),
                  ...fields,
                  if (_error != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Text(_error!, style: TextStyle(color: t.colorScheme.error)),
                    ),
                  const SizedBox(height: 20),
                  FilledButton(
                    onPressed: _busy ? null : action,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: _busy
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : Text(button),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
