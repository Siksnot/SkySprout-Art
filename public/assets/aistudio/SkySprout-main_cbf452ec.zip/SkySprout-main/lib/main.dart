import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app_state.dart';
import 'config.dart';
import 'backend.dart';
import 'screens/device_role_screen.dart';
import 'screens/welcome_screen.dart';
import 'sync.dart';
import 'screens/tablet_home.dart';
import 'themes.dart';
import 'widgets/common.dart';
import 'widgets/hub_menu.dart';
import 'widgets/kids_hub_sign.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // The loading page shows straight away, and for at least a moment.
  runApp(const Directionality(textDirection: TextDirection.ltr, child: SplashScreen()));
  final shown = Future<void>.delayed(const Duration(milliseconds: 1500));
  final config = await AppConfig.load();
  final auth = syncAvailable ? SupabaseAuth() : null;
  await auth?.restore();
  await shown;
  runApp(KidsHubApp(initial: config, auth: auth));
}

/// How long the app waits untouched before going back to the kid picker,
/// which also locks the parent screens again.
const idleTimeout = Duration(minutes: 3);

class KidsHubApp extends StatefulWidget {
  /// This device's settings; null until a family is set up or joined here.
  final AppConfig? initial;

  /// The grown-up's login, when this build has online accounts.
  final SupabaseAuth? auth;
  const KidsHubApp({super.key, this.initial, this.auth});

  @override
  State<KidsHubApp> createState() => _KidsHubAppState();
}

class _KidsHubAppState extends State<KidsHubApp> {
  /// A new navigator each time the family changes, so the welcome screens
  /// don't stay underneath the kid picker (and the other way round).
  var _nav = GlobalKey<NavigatorState>();
  AppState? _state;

  @override
  void initState() {
    super.initState();
    final c = widget.initial;
    final auth = widget.auth;
    if (c?.mode == DataMode.device) {
      _state = _stateFor(HubBackend(PrefsStore()), c!, null);
    } else if (c?.mode == DataMode.cloud && auth != null && auth.signedIn) {
      _state = _stateFor(HubBackend(SupabaseStore(auth)), c!, auth);
    }
  }

  AppState _stateFor(Backend b, AppConfig c, SupabaseAuth? auth) =>
      AppState(c, b, auth: auth, onSignedOut: _signedOut, onSignedIn: _ready);

  @override
  void dispose() {
    _state?.dispose();
    super.dispose();
  }

  Future<void> _ready(Backend backend, AppConfig c, SupabaseAuth? auth) async {
    await c.save();
    final old = _state;
    setState(() {
      _state = _stateFor(backend, c, auth);
      _nav = GlobalKey<NavigatorState>();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => old?.dispose());
  }

  void _signedOut() {
    final old = _state;
    setState(() {
      _state = null;
      _nav = GlobalKey<NavigatorState>();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => old?.dispose());
  }

  @override
  Widget build(BuildContext context) {
    final state = _state;
    final app = MaterialApp(
      title: 'Kids Hub',
      navigatorKey: _nav,
      debugShowCheckedModeBanner: false,
      theme: parentTheme(Brightness.light),
      darkTheme: parentTheme(Brightness.dark),
      builder: state == null ? null : (context, child) => _IdleReturn(navigator: _nav, child: child!),
      home: state == null ? WelcomeScreen(auth: widget.auth, onReady: _ready) : const _Home(),
    );
    return state == null ? app : AppScope(state: state, child: app);
  }
}

/// Tablets run full screen like a kiosk.
bool isTablet(BuildContext context) => MediaQuery.sizeOf(context).shortestSide >= 600;

/// Every device opens on the kid picker. The parent screens are behind the
/// menu button and the parent PIN. A parent's phone asks for the PIN straight
/// away, and again when a notification is tapped.
class _Home extends StatefulWidget {
  const _Home();

  @override
  State<_Home> createState() => _HomeState();
}

class _HomeState extends State<_Home> {
  /// Open the parent portal once the family has loaded.
  bool _wantPortal = false;
  bool _init = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_init) return;
    _init = true;
    final s = AppScope.read(context);
    _wantPortal = s.config.role == DeviceRole.parent;
    s.push?.onOpen = () {
      if (!mounted) return;
      setState(() => _wantPortal = true);
    };
  }

  void _openPortal() {
    _wantPortal = false;
    // Only from the home page: if a parent is already in the portal (or a
    // child is on their dashboard) this would close it or interrupt them.
    if (ModalRoute.of(context)?.isCurrent ?? false) openParentPortal(context);
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIMode(
      isTablet(context) ? SystemUiMode.immersiveSticky : SystemUiMode.edgeToEdge,
    );
    // Keep the loading page up until the family has loaded.
    final s = AppScope.of(context);
    final loaded = s.data != null || s.error != null;
    // Online, ask once whether this is a parent's phone or a kids' tablet.
    final askRole = loaded && s.data != null && s.config.mode == DataMode.cloud && s.config.role == null;
    if (_wantPortal && s.data != null && !askRole) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && _wantPortal) _openPortal();
      });
    }
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 400),
      child: !loaded
          ? const SplashScreen()
          : askRole
          ? const DeviceRoleScreen()
          : const TabletHome(),
    );
  }
}

/// Goes back to the kid picker after [idleTimeout] without a touch, or when
/// the app is sent to the background. Either way the parent screens close,
/// so the PIN is needed again.
class _IdleReturn extends StatefulWidget {
  final GlobalKey<NavigatorState> navigator;
  final Widget child;
  const _IdleReturn({required this.navigator, required this.child});

  @override
  State<_IdleReturn> createState() => _IdleReturnState();
}

class _IdleReturnState extends State<_IdleReturn> {
  Timer? _t;
  late final AppLifecycleListener _life;

  void _home() => widget.navigator.currentState?.popUntil((r) => r.isFirst);

  void _reset() {
    _t?.cancel();
    _t = Timer(idleTimeout, _home);
  }

  @override
  void initState() {
    super.initState();
    _reset();
    _life = AppLifecycleListener(onHide: _home);
  }

  @override
  void dispose() {
    _t?.cancel();
    _life.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) =>
      Listener(behavior: HitTestBehavior.translucent, onPointerDown: (_) => _reset(), child: widget.child);
}
