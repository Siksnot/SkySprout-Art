import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

/// Where this device keeps the family's data.
enum DataMode { device, cloud }

/// Who uses this device. A parent's phone gets notifications; a kids'
/// tablet never asks for them.
enum DeviceRole { parent, kids }

/// What a parent's phone is told about.
enum Alert {
  /// A child ticked a chore or finished a routine that needs approving.
  approve,

  /// A child bought something from the shop, or wants a reward handed over.
  shop,
}

/// This device's own settings. The children and PIN live in the family's
/// data (see `Family`), so every device shares them.
class AppConfig {
  final DataMode mode;

  /// Null until asked, after signing in on this device.
  final DeviceRole? role;

  /// The notifications this phone wants, when it is a parent's phone.
  final Set<Alert> alerts;
  const AppConfig({this.mode = DataMode.device, this.role, this.alerts = const {Alert.approve, Alert.shop}});

  AppConfig copyWith({DeviceRole? role, Set<Alert>? alerts}) =>
      AppConfig(mode: mode, role: role ?? this.role, alerts: alerts ?? this.alerts);

  /// A parent PIN is 4 to 8 digits.
  static bool validPin(String pin) => RegExp(r'^\d{4,8}$').hasMatch(pin);

  Map<String, dynamic> toJson() => {
    'mode': mode.name,
    if (role != null) 'role': role!.name,
    'alerts': [for (final a in alerts) a.name],
  };

  factory AppConfig.fromJson(Map<String, dynamic> j) => AppConfig(
    mode: DataMode.values.firstWhere((m) => m.name == j['mode'], orElse: () => DataMode.device),
    role: DeviceRole.values.where((r) => r.name == j['role']).firstOrNull,
    alerts: j['alerts'] is List
        ? {
            for (final a in Alert.values)
              if ((j['alerts'] as List).contains(a.name)) a,
          }
        : const {Alert.approve, Alert.shop},
  );

  static const _key = 'kids_hub_device_v1';

  /// Null until a family has been set up or joined on this device.
  static Future<AppConfig?> load() async {
    final raw = (await SharedPreferences.getInstance()).getString(_key);
    if (raw == null) return null;
    try {
      return AppConfig.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  Future<void> save() async => (await SharedPreferences.getInstance()).setString(_key, jsonEncode(toJson()));

  static Future<void> clear() async => (await SharedPreferences.getInstance()).remove(_key);
}
