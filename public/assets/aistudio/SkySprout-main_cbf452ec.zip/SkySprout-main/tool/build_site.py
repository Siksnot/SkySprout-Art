"""Builds site/index.html, a browsable page of every starter challenge.

Reads every challenge (kind, points, minutes and steps) from
assets/catalog/challenges.txt and writes site/index.html plus its step
pictures in site/img/. Upload the site folder anywhere (e.g.
magnolia213.xyz/kidshub/challenges/). A step without a picture shows a
placeholder.

It also writes build/catalog.txt, a copy of challenges.txt to upload to the
"challenges" bucket in Supabase Storage, so the app picks up changes without
a new release (see docs/challenge_pictures.md).

    python3 tool/build_site.py
"""
import json
import shutil
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
# Step pictures sit next to the page in img/ (copied from the app's assets).
PICTURES = 'img/'
KINDS = {
    'lego': ('Bricks', '🧱'),
    'craft': ('Craft', '✂️'),
    'draw': ('Drawing', '🎨'),
    'outdoor': ('Outdoors', '🌳'),
    'kind': ('Kindness', '💛'),
    'cook': ('Kitchen', '🍳'),
}


def key(text):
    s = re.sub('[^a-z0-9]+', '_', text.lower()).strip('_')
    return s[:48]


def starters():
    """{key: (kind, points, minutes)} for every challenge in the catalog."""
    return {c['key']: (c['cat'], c['pts'], c['min']) for c in catalog()}


def catalog(removed=False):
    """The challenges in challenges.txt, in order. Ones marked "removed: yes"
    are left out unless [removed]."""
    items, cur = [], None
    for raw in (ROOT / 'assets/catalog/challenges.txt').read_text().splitlines():
        line = raw.strip()
        if line.startswith('## '):
            title = line[3:].strip()
            cur = {'title': title, 'key': key(title), 'cat': 'craft', 'pts': 3, 'min': 0, 'removed': False,
                   'age': 0, 'need': [], 'steps': [], 'prompts': []}
            items.append(cur)
        elif cur is None or not line or line.startswith('#'):
            continue
        elif m := re.match(r'^(id|kind|points|minutes|removed|age):\s*(.*)$', line):
            name, value = m.group(1), m.group(2).strip()
            if name == 'id':
                cur['key'] = key(value) or cur['key']
            elif name == 'kind':
                cur['cat'] = value
            elif name == 'removed':
                cur['removed'] = value.lower() in ('yes', 'true')
            else:
                cur[{'points': 'pts', 'minutes': 'min', 'age': 'age'}[name]] = int(value or 0)
        elif line.startswith('need:'):
            cur['need'] = [n.strip() for n in line[5:].split(',') if n.strip()]
        elif m := re.match(r'^(\d+)\.\s*(.*)$', line):
            text, _, prompt = m.group(2).partition('||')
            cur['steps'].append(text.strip())
            cur['prompts'].append(prompt.strip())
    return [c for c in items if removed or not c['removed']]


def main():
    data = []
    for c in catalog():
        c.pop('removed')
        data.append(c)
    full = [{**c, 'steps': [{'text': t, 'prompt': p} for t, p in zip(c['steps'], c['prompts'])]} for c in data]
    for c in data + full:
        c.pop('prompts')
    page = (ROOT / 'tool/site_template.html').read_text()
    page = page.replace('/*DATA*/[]', json.dumps(data, ensure_ascii=False))
    page = page.replace('/*KINDS*/{}', json.dumps(KINDS, ensure_ascii=False))
    page = page.replace('/*PICTURES*/""', json.dumps(PICTURES))
    out = ROOT / 'site/index.html'
    out.parent.mkdir(exist_ok=True)
    out.write_text(
        '<!doctype html>\n<html lang="en-GB">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
        + page.replace('<div class="wrap">', '</head>\n<body>\n<div class="wrap">', 1)
        + '\n</body>\n</html>\n'
    )
    img = ROOT / 'site/img'
    img.mkdir(exist_ok=True)
    for f in (ROOT / 'assets/catalog/img').glob('*.webp'):
        shutil.copy(f, img / f.name)
    # The same page without its own <html>, for previewing as a Claude artifact.
    (ROOT / 'site/preview.html').write_text(page)
    # The private editor, published as a Claude artifact (see docs/challenge_pictures.md).
    editor = (ROOT / 'tool/editor_template.html').read_text()
    editor = editor.replace('/*DATA*/[]', json.dumps(full, ensure_ascii=False))
    editor = editor.replace('/*KINDS*/{}', json.dumps(KINDS, ensure_ascii=False))
    (ROOT / 'site/editor.html').write_text(editor)
    # The catalog the app downloads, to upload to the "challenges" bucket.
    build = ROOT / 'build'
    build.mkdir(exist_ok=True)
    shutil.copy(ROOT / 'assets/catalog/challenges.txt', build / 'catalog.txt')
    print(f'Wrote {out} with {len(data)} challenges, and build/catalog.txt')


if __name__ == '__main__':
    main()
