"""Diagrams for more Crafts challenges (pencil pot, paper chain, pasta necklace,
snail house, rainbow without paint, pirate hat, bird feeder)."""
import math
import random

from style import INK, arrow, dot, ghost, ground, hand, motion, thin

D = {}


# ── Shared bits ──────────────────────────────────────────────────────────
def g(body, x=0, y=0, r=0, s=1):
    return f'<g transform="translate({x} {y}) rotate({r}) scale({s})">{body}</g>'


def face(x, y, r=30, mouth='smile'):
    """A round child's head with a simple face and a tuft of hair."""
    e = r * 0.36
    s = (f'<circle cx="{x}" cy="{y}" r="{r}"/>' + dot(x - e, y - r * 0.12, r * 0.08 + 1)
         + dot(x + e, y - r * 0.12, r * 0.08 + 1)
         + thin(f'M{x - r * 0.8} {y - r * 0.55} q{r * 0.4} {-r * 0.7} {r * 1.1} {-r * 0.4} q{r * 0.4} {-r * 0.3} {r * 0.5} {r * 0.3}'))
    if mouth == 'smile':
        s += f'<path d="M{x - r * 0.3} {y + r * 0.35} q{r * 0.3} {r * 0.25} {r * 0.6} 0" fill="none"/>'
    elif mouth == 'open':
        s += f'<ellipse cx="{x}" cy="{y + r * 0.42}" rx="{r * 0.2}" ry="{r * 0.16}"/>'
    return s


def scissors(x, y, r=0, s=1, halo=False):
    b = ('<path d="M0 0 L46 -9 Q50 -7 46 -4 Z"/><path d="M0 0 L46 9 Q50 7 46 4 Z"/>'
         '<path d="M0 0 L-14 -8 M0 0 L-14 8" fill="none"/>'
         '<circle cx="-22" cy="-11" r="9"/><circle cx="-22" cy="11" r="9"/>' + dot(0, 0, 2))
    if halo:  # a white edge so they show up on black paper
        b = f'<g stroke="#fff" stroke-width="7">{b}</g>' + b
    return g(b, x, y, r, s)


def pencil(x, y, r=0, n=90, s=1, felt=False):
    """A pencil (or felt pen) lying along +x from its back end at (x, y), point at the far end."""
    if felt:
        b = (f'<rect x="0" y="-6" width="{n - 16}" height="12" rx="3"/>'
             f'<path d="M{n - 16} -4 L{n - 4} -3 Q{n} 0 {n - 4} 3 L{n - 16} 4 Z"/>' + thin('M18 -6 V6'))
    else:
        b = (f'<path d="M0 -5 H{n - 18} L{n} 0 L{n - 18} 5 H0 Z"/>' + thin(f'M10 -5 V5 M{n - 18} -5 V5')
             + f'<path d="M{n - 6} -1.7 L{n} 0 L{n - 6} 1.7 Z" fill="{INK}"/>')
    return g(b, x, y, r, s)


def tape(x, y, r=0, w=16, h=24):
    return g(f'<rect x="{-w / 2}" y="{-h / 2}" width="{w}" height="{h}" rx="1" stroke-width="1.8"/>'
             + thin(f'M{-w / 2 + 3} {-h / 2 + 6} l{w - 6} -4 M{-w / 2 + 3} {h / 2 - 3} l{w - 6} -4'), x, y, r)


def adult_hand(x, y, s=1.5, flip=False):
    """A grown-up's bigger hand with a shirt cuff."""
    k = -1 if flip else 1
    return hand(x, y, s, flip) + f'<rect x="{x - (10 * s if k > 0 else 18 * s)}" y="{y + 12 * s}" width="{28 * s}" height="{16 * s}" rx="3"/>'


# ── Make a pencil pot from a toilet roll ─────────────────────────────────
_tx, _tb, _TR, _TH = 210, 222, 34, 104


def _tube(cx=_tx, yb=_tb, deco=False, base=False):
    r, ry, yt = _TR, 10, yb - _TH
    s = ''
    if base:  # the card circle under the tube, a little wider
        s += f'<ellipse cx="{cx}" cy="{yb + 2}" rx="{r + 7}" ry="{ry + 4}"/>'
    s += f'<path d="M{cx - r} {yt} V{yb} A{r} {ry} 0 0 0 {cx + r} {yb} V{yt} Z"/>'
    s += f'<ellipse cx="{cx}" cy="{yt}" rx="{r}" ry="{ry}"/>' + thin(f'M{cx - r + 5} {yt + 2} Q{cx} {yt - 8} {cx + r - 5} {yt + 2}')
    if deco:
        s += _tube_deco(cx, yb)
    return s


def _tube_deco(cx=_tx, yb=_tb):
    r, ry, yt = _TR, 10, yb - _TH
    s = ''
    for y0 in (yt + 22, yt + 66):  # two bold bands
        s += f'<path d="M{cx - r} {y0} A{r} {ry} 0 0 0 {cx + r} {y0} V{y0 + 10} A{r} {ry} 0 0 1 {cx - r} {y0 + 10} Z" fill="{INK}"/>'
    zz = f'M{cx - r} {yt + 52} ' + ''.join(f'l{6} {(-1) ** i * 7} ' for i in range(11))
    s += thin(zz)
    for sx in (cx - 18, cx + 2, cx + 22):
        s += _star(sx, yt + 92 + (4 if sx == cx + 2 else 0), 5)
    return s


def _star(x, y, r, fill=INK, stroke=None):
    pts = ' '.join(f'{x + (r if i % 2 == 0 else r * 0.45) * math.sin(i * math.pi / 5):.1f},'
                   f'{y - (r if i % 2 == 0 else r * 0.45) * math.cos(i * math.pi / 5):.1f}' for i in range(10))
    st = f' stroke="{stroke}"' if stroke else ' stroke="none"'
    return f'<polygon points="{pts}" fill="{fill}"{st}/>'


def _card(x0, y0, x1, y1, skew=30):
    return f'<polygon points="{x0},{y1} {x1},{y1} {x1 + skew},{y0} {x0 + skew},{y0}"/>'


_pp1 = (_card(70, 186, 300, 262, 40)
        + ghost(f'M{_tx + _TR + 7} {_tb + 4} A{_TR + 7} 14 0 0 1 {_tx - _TR - 7} {_tb + 4}')
        + f'<path d="M{_tx - _TR - 7} {_tb + 4} A{_TR + 7} 14 0 0 1 {_tx + _TR + 7} {_tb + 4}" fill="none" stroke-width="1.8"/>'
        + _tube()
        + pencil(_tx + _TR + 39, _tb - 74, 112, 84)
        + hand(_tx + _TR + 45, _tb - 24, 0.9, flip=True)
        + arrow(f'M{_tx + 56} {_tb + 30} Q{_tx} {_tb + 48} {_tx - 54} {_tb + 28}'))

# the card with a round hole cut out, and the circle taped under the tube
_scrap = (_card(28, 200, 122, 262, 26)
          + f'<ellipse cx="{88}" cy="{231}" rx="30" ry="13"/>' + thin('M62 233 Q88 222 114 233'))
_pp2 = (_scrap + scissors(56, 160, 30, 0.8)
        + _tube(base=True) + tape(_tx - 22, _tb - 2, -8) + tape(_tx + 22, _tb - 2, 8)
        + arrow(f'M100 196 C110 130 {_tx - 70} 150 {_tx - 46} {_tb - 6}'))

_pp3 = (_tube(base=True, deco=True)
        + pencil(_tx + 104, _tb - 116, 150, 84, felt=True)
        + hand(_tx + 92, _tb - 64, 0.9, flip=True)
        + motion(f'M{_tx - 60} {_tb - 110} l-12 -12', f'M{_tx - 66} {_tb - 70} h-18', f'M{_tx - 60} {_tb - 30} l-12 10'))


def _pot_full():
    r, ry, yt = _TR, 10, _tb - _TH
    back = f'<ellipse cx="{_tx}" cy="{yt}" rx="{r}" ry="{ry}"/>'
    pens = (pencil(_tx - 14, yt + 30, -112, 130) + pencil(_tx + 4, yt + 30, -84, 128, felt=True)
            + pencil(_tx + 16, yt + 30, -62, 120) + pencil(_tx - 4, yt + 30, -98, 112)
            + pencil(_tx + 10, yt + 30, -74, 104, felt=True))
    body = (f'<ellipse cx="{_tx}" cy="{_tb + 2}" rx="{r + 7}" ry="{ry + 4}"/>'
            f'<path d="M{_tx - r} {yt} A{r} {ry} 0 0 0 {_tx + r} {yt} V{_tb} A{r} {ry} 0 0 1 {_tx - r} {_tb} Z"/>')
    return back + pens + body + _tube_deco()


_pp4 = (ground(_tb + 16, 70, 330) + _pot_full()
        + motion(f'M{_tx - 70} 60 l-12 -12', f'M{_tx - 80} 100 h-18', f'M{_tx + 70} 60 l12 -12', f'M{_tx + 80} 100 h18'))

D['make_a_pencil_pot_from_a_toilet_roll'] = [_pp1, _pp2, _pp3, _pp4]


# ── Make a paper chain as long as you are tall ───────────────────────────
def _ring(cx, cy, rx, ry, w=13, part=None):
    """A paper ring: an ink band with a white middle. part=(start, length) in % draws only a piece."""
    if part:
        a, n = part
        di = f' pathLength="100" stroke-dasharray="0 {a} {n} 100" stroke-linecap="butt"'
        dw = f' pathLength="100" stroke-dasharray="0 {a - 1.5} {n + 3} 100" stroke-linecap="butt"'
    else:
        di = dw = ''
    return (f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="none" stroke-width="{w}"{di}/>'
            f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="none" stroke="#fff" stroke-width="{w - 5}"{dw}/>')


def _strip(x, y, r=0, n=110, h=14):
    return g(f'<rect x="0" y="{-h / 2}" width="{n}" height="{h}" rx="1"/>', x, y, r)


_ra = (170, 160, 62, 30)  # first ring
_rb = (226, 160, 24, 56)  # second ring, standing up through the first


def _ringA():
    cx, cy, rx, ry = _ra
    return _ring(*_ra) + tape(cx, cy - ry, 0, 14, 20)


def _ringB():
    cx, cy, rx, ry = _rb
    # B goes behind the front of A: redraw A's front edge over it
    return _ring(*_rb) + tape(cx + rx, cy, 90, 14, 20) + _ring(*_ra, part=(10, 12))


_pc1 = (f'<rect x="40" y="70" width="150" height="190" rx="2"/>'
        + ''.join(ghost(f'M{40 + i * 25} 70 V260') for i in (1, 2, 3, 4, 5))
        + scissors(165, 52, 90, 0.8)
        + ''.join(_strip(226 + (i % 2) * 8, 248 - i * 19, -3 + (i % 3) * 3, 130) for i in range(6))
        + arrow('M196 96 Q250 60 300 120'))

_pc2 = (_strip(40, 66, 6, 140) + _ringA()
        + arrow('M190 84 C250 86 262 140 238 166'))

_pc3 = (_ringA() + _ringB()
        + arrow(f'M{_rb[0] + 40} {_rb[1] - 70} C{_rb[0] + 70} {_rb[1] - 30} {_rb[0] + 64} {_rb[1] + 30} {_rb[0] + 34} {_rb[1] + 50}'))


def _chain(x0, x1, y):
    s, x, i = '', x0 + 14, 0
    xs = []
    while x + 14 <= x1:
        xs.append(x)
        x += 22
    for x in xs[::2]:
        s += _ring(x, y, 14, 8, 8)
    for x in xs[1::2]:
        s += _ring(x, y, 5, 13, 8)
        s += _ring(x - 22, y, 14, 8, 8, part=(8, 10)) if x - 22 >= xs[0] else ''
    return s


def _lying(x, y):
    """A child lying on their back, head on the left at x, back along y."""
    s = (f'<rect x="{x + 34}" y="{y - 34}" width="120" height="34" rx="14"/>'  # body
         f'<rect x="{x + 146}" y="{y - 26}" width="118" height="13" rx="6"/>'
         f'<rect x="{x + 146}" y="{y - 14}" width="118" height="13" rx="6"/>'
         f'<path d="M{x + 262} {y - 28} q12 -14 14 6 V{y} H{x + 260} Z"/>'
         + thin(f'M{x + 50} {y - 20} H{x + 136}')
         + f'<circle cx="{x + 18}" cy="{y - 20}" r="20"/>'
         + dot(x + 12, y - 30, 2.2) + dot(x + 24, y - 30, 2.2)
         + f'<path d="M{x + 10} {y - 16} q8 6 16 0" fill="none"/>'
         + thin(f'M{x - 2} {y - 14} q-6 -12 2 -24'))
    return s


_lx, _ly = 30, 130
_pc4 = (_lying(_lx, _ly) + ground(_ly + 2, 24, 376) + _chain(_lx - 2, _lx + 280, 196)
        + ghost(f'M{_lx - 2} 96 V214') + ghost(f'M{_lx + 280} 96 V214')
        + motion('M326 182 l12 -10', 'M330 196 h16', 'M326 210 l12 10'))

D['make_a_paper_chain_as_long_as_you_are_tall'] = [_pc1, _pc2, _pc3, _pc4]


# ── Make a necklace from pasta or beads ──────────────────────────────────
def pasta(x, y, r=0, pat='plain', s=1):
    b = '<path d="M-16 -8 H16 V8 H-16 Z"/><ellipse cx="16" cy="0" rx="4" ry="8"/><ellipse cx="16" cy="0" rx="1.6" ry="4" fill="#1d1d1f" stroke="none"/>'
    if pat == 'stripe':
        b += thin('M-10 -8 V8 M-3 -8 V8 M4 -8 V8')
    elif pat == 'dots':
        b += dot(-9, -3, 1.8) + dot(-1, 3, 1.8) + dot(7, -3, 1.8) + dot(-9, 4, 1.8) + dot(7, 4, 1.8)
    elif pat == 'solid':
        b = f'<path d="M-16 -8 H16 V8 H-16 Z" fill="{INK}"/><ellipse cx="16" cy="0" rx="4" ry="8"/><ellipse cx="16" cy="0" rx="1.6" ry="4" fill="#1d1d1f" stroke="none"/>'
    elif pat == 'zig':
        b += thin('M-14 4 l5 -8 l5 8 l5 -8 l5 8 l5 -8')
    return g(b, x, y, r, s)


_nk1 = ('<rect x="30" y="150" width="340" height="110" rx="2"/>'
        + pasta(240, 186, -10, 'stripe') + pasta(300, 200, 14, 'dots') + pasta(340, 176, -4, 'solid')
        + pasta(250, 234, 8, 'zig') + pasta(320, 236, -12, 'stripe')
        + pasta(96, 214, 0, 'dots')
        + pencil(176, 136, 128, 80, felt=True) + hand(166, 172, 0.9)
        + motion('M240 150 q-6 -10 0 -20 q6 -10 0 -20', 'M296 160 q-6 -10 0 -20 q6 -10 0 -20',
                 'M346 146 q-6 -10 0 -20 q6 -10 0 -20'))


def _knot(x, y, s=1):
    return g('<path d="M-12 -2 C-16 -18 8 -20 10 -4 C12 12 -10 14 -12 -2 Z"/>'
             + thin('M-8 -10 q8 10 14 -2 M-9 4 q10 -4 16 6'), x, y, 0, s)


_nk2 = (f'<path d="M120 150 C190 128 260 170 350 146" fill="none" stroke-width="3.2"/>'
        + f'<path d="M84 196 q6 -16 18 -24" fill="none" stroke-width="3.2"/>' + _knot(118, 152, 1.9)
        + arrow('M92 112 C64 140 80 196 118 190 C150 184 154 150 144 132'))

_sx0, _sy0, _sx1, _sy1 = 90, 236, 250, 100  # string from knot to tip
_ang = math.degrees(math.atan2(_sy1 - _sy0, _sx1 - _sx0))


def _on_string(t):
    return _sx0 + (_sx1 - _sx0) * t, _sy0 + (_sy1 - _sy0) * t


_pats = ['stripe', 'solid', 'stripe', 'solid', 'stripe']
_nk3 = (f'<path d="M{_sx0} {_sy0} L{_sx1} {_sy1}" fill="none"/>' + _knot(_sx0, _sy0, 1.4)
        + ''.join(pasta(*_on_string(0.14 + i * 0.17), _ang + 180, p) for i, p in enumerate(_pats[:4]))
        + ghost(f'M{_sx1 + 6} {_sy1 - 5} L{_sx1 + 26} {_sy1 - 22}')
        + pasta(*_on_string(1.3), _ang + 180, 'solid') + hand(340, 98, 0.9, flip=True)
        + arrow(f'M{_sx1 + 4} {_sy1 - 64} C{_sx1 - 26} {_sy1 - 50} {_sx1 - 24} {_sy1 - 20} {_sx1 - 8} {_sy1 - 6}'))


def _necklace(cx, top, w, depth, n=11):
    s = f'<path d="M{cx - w} {top} C{cx - w} {top + depth * 1.3} {cx + w} {top + depth * 1.3} {cx + w} {top}" fill="none"/>'
    pats = ['stripe', 'solid'] * 8
    for i in range(n):
        t = 0.1 + 0.8 * i / (n - 1)
        # point and tangent on the cubic
        p0, p1, p2, p3 = (cx - w, top), (cx - w, top + depth * 1.3), (cx + w, top + depth * 1.3), (cx + w, top)
        b = [(1 - t) ** 3, 3 * t * (1 - t) ** 2, 3 * t * t * (1 - t), t ** 3]
        x = sum(bi * p[0] for bi, p in zip(b, (p0, p1, p2, p3)))
        y = sum(bi * p[1] for bi, p in zip(b, (p0, p1, p2, p3)))
        dx = 3 * ((1 - t) ** 2 * (p1[0] - p0[0]) + 2 * t * (1 - t) * (p2[0] - p1[0]) + t * t * (p3[0] - p2[0]))
        dy = 3 * ((1 - t) ** 2 * (p1[1] - p0[1]) + 2 * t * (1 - t) * (p2[1] - p1[1]) + t * t * (p3[1] - p2[1]))
        s += pasta(x, y, math.degrees(math.atan2(dy, dx)), pats[i], 0.85)
    return s


def _bust(cx, hy, r=46):
    sh = hy + r + 26
    return (f'<path d="M{cx - 120} 282 C{cx - 120} {sh + 10} {cx - 90} {sh} {cx - 30} {sh - 4} '
            f'H{cx + 30} C{cx + 90} {sh} {cx + 120} {sh + 10} {cx + 120} 282 Z"/>'
            + f'<rect x="{cx - 14}" y="{hy + r - 8}" width="28" height="{sh - hy - r + 6}"/>'
            + face(cx, hy, r))


_nk4 = (_bust(200, 84) + _necklace(200, 150, 46, 84, 12)
        + motion('M112 140 l-12 -12', 'M100 178 h-18', 'M288 140 l12 -12', 'M300 178 h18'))

D['make_a_necklace_from_pasta_or_beads'] = [_nk1, _nk2, _nk3, _nk4]


# ── Build a house for a snail from things in the garden ──────────────────
_gy = 236  # ground


def _leaf(x, y, r=0, s=1, veins=True):
    b = '<path d="M-30 0 Q0 -16 30 0 Q0 16 -30 0 Z"/>'
    if veins:
        b += thin('M-26 0 H24')
    return g(b, x, y, r, s)


def _plant():
    s = '<circle cx="360" cy="40" r="15"/>' + ''.join(
        thin(f'M{360 + 21 * math.cos(a):.1f} {40 + 21 * math.sin(a):.1f} l{7 * math.cos(a):.1f} {7 * math.sin(a):.1f}')
        for a in [i * math.pi / 4 for i in range(8)])
    s += ('<path d="M350 236 C342 150 300 96 214 82" fill="none"/>'
          '<path d="M356 236 C358 176 344 140 312 122" fill="none"/>'
          '<path d="M346 236 C320 176 250 140 146 124" fill="none"/>')
    s += (_leaf(176, 82, -6, 1.5) + _leaf(112, 126, 14, 1.4) + _leaf(278, 112, -30, 1.3)
          + _leaf(258, 74, 8, 1.1))
    return s + ground(_gy)


_hx = 186  # house middle


def _stones(x0, x1, y, n):
    s = ''
    step = (x1 - x0) / n
    for i in range(n):
        s += f'<ellipse cx="{x0 + step * (i + .5)}" cy="{y}" rx="{step / 2 + 2}" ry="9"/>'
    return s


def _twig(x, y0, y1, k=0):
    return (f'<path d="M{x} {y0} L{x + k} {y1}" stroke-width="5"/><path d="M{x} {y0} L{x + k} {y1}" stroke="#fff" stroke-width="1.2"/>'
            + thin(f'M{x + k * .5} {(y0 + y1) / 2} l6 -8'))


def _walls(done=True):
    s = ''.join(_twig(_hx - 44 + i * 11, _gy - 4, _gy - 52, (i % 2) * 2 - 1) for i in range(9))
    s += _stones(_hx - 66, _hx - 18, _gy - 8, 3) + _stones(_hx - 64, _hx - 22, _gy - 24, 2)
    if done:
        s += _stones(_hx + 18, _hx + 66, _gy - 8, 3) + _stones(_hx + 22, _hx + 64, _gy - 24, 2)
    else:
        s += _stones(_hx + 18, _hx + 50, _gy - 8, 2) + ghost(f'M{_hx + 50} {_gy - 8} a8 8 0 1 0 16 0 a8 8 0 1 0 -16 0')
    return s


def _moss():
    return ''.join(thin(f'M{x} {_gy - 2} q3 -8 6 0 q3 -8 6 0') for x in range(_hx - 14, _hx + 14, 12))


def _roof():
    return (f'<path d="M{_hx - 86} {_gy - 44} Q{_hx} {_gy - 92} {_hx + 86} {_gy - 44} Q{_hx} {_gy - 60} {_hx - 86} {_gy - 44} Z"/>'
            + thin(f'M{_hx - 80} {_gy - 46} Q{_hx} {_gy - 76} {_hx + 80} {_gy - 46}'
                   f'M{_hx - 40} {_gy - 58} l-10 -8 M{_hx} {_gy - 62} l-10 -8 M{_hx + 40} {_gy - 58} l-10 -8'))


def _snail(x, y, s=1, flip=False):
    b = ('<path d="M-30 0 H18 Q28 0 28 -10 L30 -18 Q26 -26 22 -18 L20 -8 Q14 -4 -30 0 Z"/>'
         '<path d="M26 -20 L30 -32 M22 -18 L22 -30" fill="none" stroke-width="1.8"/>'
         + dot(30, -33, 2.2) + dot(22, -31, 2.2)
         + '<circle cx="-6" cy="-16" r="16"/>'
         + thin('M-6 -16 m0 0 a3 3 0 1 1 4 3 a7 7 0 1 1 -10 -8 a11 11 0 1 1 16 -2'))
    return f'<g transform="translate({x} {y}) scale({-s if flip else s} {s})">{b}</g>'


_sn1 = (_plant()
        + ghost(f'M{_hx - 50} {_gy - 2} a50 10 0 1 0 100 0 a50 10 0 1 0 -100 0')
        + arrow(f'M{_hx - 10} {_gy - 110} Q{_hx + 30} {_gy - 70} {_hx + 4} {_gy - 18}'))
_sn2 = (_plant() + _walls(done=False)
        + f'<ellipse cx="{_hx + 104}" cy="{_gy - 66}" rx="10" ry="8"/>'
        + arrow(f'M{_hx + 100} {_gy - 52} Q{_hx + 94} {_gy - 18} {_hx + 70} {_gy - 10}'))
_sn3 = (_plant() + _walls() + _moss() + _roof()
        + arrow(f'M{_hx - 130} {_gy - 110} Q{_hx - 120} {_gy - 64} {_hx - 92} {_gy - 52}'))
_sn4 = (_plant() + _walls() + _moss() + _roof()
        + _snail(_hx + 118, _gy, 1.0) + face(46, 180, 28)
        + motion(f'M{_hx + 82} {_gy - 24} h-14', f'M{_hx + 80} {_gy - 10} h-12'))

D['build_a_house_for_a_snail_from_things_in_the_gar'] = [_sn1, _sn2, _sn3, _sn4]


# ── Make a rainbow with anything but paint ───────────────────────────────
def _button(r=0):
    return '<circle r="8"/>' + dot(-2.6, -2.6, 1.3) + dot(2.6, -2.6, 1.3) + dot(-2.6, 2.6, 1.3) + dot(2.6, 2.6, 1.3)


def _sock(r=0):
    return ('<path d="M-5 -10 V2 Q-5 9 2 9 H8 Q11 9 11 5 Q11 1 6 0 H4 V-10 Z"/>' + thin('M-5 -6 H4'))


def _block(r=0):
    return '<rect x="-7" y="-7" width="14" height="14" rx="1.5"/>' + thin('M-3 -3 h6 v6 h-6 Z')


def _rleaf(r=0):
    return '<path d="M-10 0 Q0 -8 10 0 Q0 8 -10 0 Z"/>' + thin('M-9 0 H8')


def _crayon(r=0):
    return '<path d="M-9 -4 H5 L10 0 L5 4 H-9 Z"/>' + thin('M-5 -4 V4')


def _bead(r=0):
    return '<circle r="7"/><circle r="2.4" fill="#1d1d1f" stroke="none"/>'


# (item, spacing along the arc, turn: 'tan' follows the curve, 'rad' points out)
_BANDS = [(_button, 19, 'tan'), (_sock, 18, 'rad'), (_block, 17, 'tan'),
          (_rleaf, 20, 'tan'), (_crayon, 13, 'rad'), (_bead, 15, 'tan')]
_rcx, _rcy, _R0, _DR = 200, 246, 156, 23


def _band(k, upto=1.0, cx=_rcx, cy=_rcy):
    item, sp, turn = _BANDS[k]
    r = _R0 - k * _DR
    n = int(math.pi * r / sp)
    s = ''
    for i in range(n + 1):
        if i > n * upto:
            break
        a = math.pi * (1 - i / n)
        x, y = cx + r * math.cos(a), cy - r * math.sin(a)
        rot = 90 - math.degrees(a) if turn == 'tan' else -math.degrees(a)
        s += g(item(), round(x, 1), round(y, 1), round(rot, 1))
    return s


def _rest_ghost(k, frm):
    r = _R0 - k * _DR
    a = math.pi * (1 - frm)
    x, y = _rcx + r * math.cos(a), _rcy - r * math.sin(a)
    return ghost(f'M{x:.1f} {y:.1f} A{r} {r} 0 0 1 {_rcx + r} {_rcy}')


def _group(cx, cy, item, rots=(0, 30, -20, 60, 10)):
    pts = [(-14, -10), (12, -12), (0, 6), (-16, 14), (16, 12)]
    return (ghost(f'M{cx - 42} {cy} a42 34 0 1 0 84 0 a42 34 0 1 0 -84 0')
            + ''.join(g(item(), cx + px, cy + py, r, 1.3) for (px, py), r in zip(pts, rots)))


_rb1 = (''.join(_group(80 + (i % 3) * 120, 96 + (i // 3) * 110, _BANDS[i][0]) for i in range(6))
        + g(_bead(), 352, 156, 0, 1.3)
        + arrow('M352 172 Q356 206 330 212'))
_rb2 = (_band(0, 0.72) + _rest_ghost(0, 0.75)
        + g(_button(), 364, 60, 0, 1.2)
        + arrow('M364 76 Q364 100 330 112'))
_rb3 = (''.join(_band(k) for k in range(5)) + _band(5, 0.5) + _rest_ghost(5, 0.55)
        + g(_bead(), 200, 274, 0, 1.2)
        + arrow('M214 270 Q250 262 240 222'))
# step 4: the rainbow, and two hands holding up a phone to take its picture
_rb4 = (g(''.join(_band(k) for k in range(6)), -6, 66, 0, 0.7)
        + '<rect x="270" y="104" width="84" height="134" rx="10"/>'
        + '<rect x="278" y="118" width="68" height="102" rx="3"/>'
        + ''.join(f'<path d="M{312 - r} 190 A{r} {r} 0 0 1 {312 + r} 190" fill="none" stroke-width="{1.6 if i % 2 else 3}"/>'
                  for i, r in enumerate((26, 21, 16, 11, 6)))
        + hand(246, 256, 0.9) + hand(376, 256, 0.9, flip=True)
        + motion('M312 88 v-16', 'M282 92 l-10 -12', 'M342 92 l10 -12'))

D['make_a_rainbow_with_anything_but_paint'] = [_rb1, _rb2, _rb3, _rb4]


# ── Make a pirate hat and eye patch ──────────────────────────────────────
_HAT = ('M-130 -20 C-100 10 -50 30 0 30 C50 30 100 10 130 -20 C100 -10 78 -20 62 -36 '
        'C50 -70 20 -82 0 -82 C-20 -82 -50 -70 -62 -36 C-78 -20 -100 -10 -130 -20 Z')


def _hat(x, y, s=1, cut=None):
    return g(f'<path d="{_HAT}" fill="{INK}"/>', x, y, 0, s)


def _skull(x, y, s=1):
    w = '#fff'
    b = (f'<path d="M-14 6 C-20 -4 -16 -18 0 -18 C16 -18 20 -4 14 6 V12 H-14 Z" fill="{w}" stroke="{w}"/>'
         f'<circle cx="-6" cy="-4" r="4" fill="{INK}" stroke="none"/><circle cx="6" cy="-4" r="4" fill="{INK}" stroke="none"/>'
         f'<path d="M-22 16 L22 32 M22 16 L-22 32" stroke="{w}" stroke-width="4"/>'
         f'<circle cx="-23" cy="15" r="3" fill="{w}" stroke="none"/><circle cx="23" cy="15" r="3" fill="{w}" stroke="none"/>'
         f'<circle cx="-23" cy="33" r="3" fill="{w}" stroke="none"/><circle cx="23" cy="33" r="3" fill="{w}" stroke="none"/>')
    return g(b, x, y, 0, s)


# step 1: a black sheet; the hat is half cut out along its outline
_ph1 = (f'<rect x="30" y="56" width="340" height="206" rx="2" fill="{INK}"/>'
        + g(f'<path d="{_HAT}" fill="none" stroke="#fff" stroke-width="2.4" stroke-dasharray="7 6"/>'
            f'<path d="{_HAT}" fill="none" stroke="#fff" stroke-width="3" pathLength="100" stroke-dasharray="48 100"/>', 200, 180)
        + scissors(338, 150, 196, 0.9, halo=True)
        + arrow('M330 210 Q350 180 340 166'))
_ph2 = (_hat(186, 190, 1.2) + _skull(186, 144, 1.1)
        + '<path d="M232 168 L292 112 L302 122 L242 178 Z"/><path d="M232 168 L224 184 L242 178 Z"/>'
        + hand(310, 168, 0.9, flip=True)
        + arrow('M236 200 Q260 214 282 196'))


def _patch(x, y, s=1):
    return g(f'<ellipse cx="0" cy="0" rx="34" ry="26" fill="{INK}"/>', x, y, 0, s)


_ph3 = (_patch(200, 150)
        + '<path d="M172 140 C120 110 80 132 30 112" fill="none"/>'
        + '<path d="M228 140 C280 110 320 132 370 112" fill="none"/>'
        + tape(178, 136, 64, 14, 22)
        + tape(270, 64, -20, 14, 22)
        + arrow('M284 72 Q272 116 238 134')
        + f'<path d="M110 222 h96 l-6 46 h-96 Z" fill="{INK}"/>'
        + '<ellipse cx="152" cy="244" rx="20" ry="15" fill="#fff"/>'
        + scissors(244, 230, 200, 0.8))


def _pirate(cx, cy, r=60):
    s = face(cx, cy, r, mouth='open')
    s += f'<path d="M{cx - r + 4} {cy - 26} L{cx + r - 6} {cy - 4}" fill="none" stroke-width="2"/>'
    s += f'<ellipse cx="{cx - r * 0.36}" cy="{cy - r * 0.12}" rx="15" ry="12" fill="{INK}"/>'
    s += _hat(cx, cy - r - 2, 0.72) + _skull(cx, cy - r - 26, 0.6)
    return s


_ph4 = (_pirate(180, 180, 66)
        + motion('M260 200 q12 12 0 24', 'M274 188 q22 24 0 48', 'M288 176 q32 36 0 72'))

D['make_a_pirate_hat_and_eye_patch'] = [_ph1, _ph2, _ph3, _ph4]


# ── Make a bird feeder with a grown-up ───────────────────────────────────
_CONE = 'M0 -40 C30 -40 30 12 0 40 C-30 12 -30 -40 0 -40 Z'
_rng = random.Random(7)
_SEEDS = [(_rng.uniform(-20, 20), _rng.uniform(-34, 30), _rng.uniform(0, 180)) for _ in range(60)]
_SEEDS = [(x, y, a) for x, y, a in _SEEDS if abs(x) < 22 * (1 - max(0, y) / 44) and abs(x) < 20][:26]


def _seed(x, y, a, s=1):
    return f'<ellipse cx="0" cy="0" rx="{3 * s}" ry="{1.8 * s}" transform="translate({x:.1f} {y:.1f}) rotate({a:.0f})" fill="{INK}" stroke="none"/>'


_cid = [0]


def cone(x, y, r=0, s=1, spread=False, seeds=False):
    _cid[0] += 1
    cid = f'cone{_cid[0]}'
    b = f'<clipPath id="{cid}"><path d="{_CONE}"/></clipPath><path d="{_CONE}"/><g clip-path="url(#{cid})">'
    for j, yy in enumerate(range(-30, 34, 9)):
        hw = 22 if yy < 0 else 22 * (1 - yy / 46)
        xs = [x0 for x0 in range(-24 + (j % 2) * 5, 24, 10) if abs(x0 + 5) < hw]
        b += ''.join(thin(f'M{x0} {yy} q5 7 10 0') for x0 in range(-30 + (j % 2) * 5, 30, 10))
    if spread:
        b += thin('M-14 -20 q6 -4 12 0 q6 4 12 0 M-16 0 q6 -4 12 0 q6 4 12 0 M-10 18 q5 -4 10 0 q5 4 10 0')
    if seeds:
        b += ''.join(_seed(px, py, a) for px, py, a in _SEEDS)
    b += f'</g><path d="{_CONE}" fill="none"/><path d="M0 -40 V-48" fill="none" stroke-width="4"/>'
    return g(b, x, y, r, s)


_bf1 = (cone(200, 176, 0, 1.4)
        + f'<ellipse cx="200" cy="112" rx="10" ry="4" fill="none" stroke-width="2"/>'
        + '<path d="M194 113 C170 100 150 90 130 86 M206 113 C230 100 250 90 270 86" fill="none" stroke-width="2"/>'
        + hand(92, 120, 0.9) + hand(308, 120, 0.9, flip=True)
        + arrow('M170 128 Q200 150 232 126'))


def _plate(cx, cy, rx=130, ry=28):
    return (f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}"/>'
            + thin(f'M{cx - rx + 22} {cy} A{rx - 22} {ry - 8} 0 0 0 {cx + rx - 22} {cy}'))


def _jar(x, y):
    return (f'<path d="M{x - 24} {y - 46} V{y} A24 7 0 0 0 {x + 24} {y} V{y - 46} Z"/>'
            f'<rect x="{x - 27}" y="{y - 60}" width="54" height="16" rx="3"/>' + thin(f'M{x - 24} {y - 30} H{x + 24}'))


def _knife(x, y, r=0):
    return g('<rect x="0" y="-5" width="44" height="10" rx="4"/><path d="M44 -4 H86 Q96 0 86 6 H44 Z"/>', x, y, r)


_bf2 = (_plate(224, 232, 120) + cone(226, 214, 90, 1.2, spread=True)
        + '<path d="M170 214 q-14 -2 -24 -14" fill="none" stroke-width="2"/>'
        + _jar(50, 250)
        + _knife(286, 116, 128) + adult_hand(308, 132, 1.5, flip=True)
        + arrow('M180 172 Q220 158 260 172'))

_plate_seeds = ''.join(_seed(224 + _rng.uniform(-90, 90), 232 + _rng.uniform(-14, 14), _rng.uniform(0, 180), 1.2)
                       for _ in range(70))
_bf3 = (_plate(224, 232, 120) + _plate_seeds + cone(226, 210, 90, 1.2, spread=True, seeds=True)
        + '<path d="M170 210 q-14 -2 -24 -14" fill="none" stroke-width="2"/>'
        + arrow('M194 160 C216 140 254 144 266 170') + arrow('M266 256 C246 272 206 270 192 254'))


def _bird(x, y, s=1, left=False):
    b = ('<path d="M-22 4 L-38 -6 L-36 8 Z"/>'
         '<ellipse cx="0" cy="0" rx="24" ry="17"/>'
         '<circle cx="18" cy="-14" r="11"/><path d="M28 -16 L38 -12 L28 -10 Z"/>'
         + dot(20, -16, 2) + thin('M-10 -4 q10 10 22 2')
         + '<path d="M-4 16 V26 M6 16 V26" fill="none" stroke-width="2"/>')
    return f'<g transform="translate({x} {y}) scale({-s if left else s} {s})">{b}</g>'


_bf4 = ('<path d="M16 64 C100 56 220 74 384 60" fill="none" stroke-width="8"/>'
        + thin('M90 60 l-14 -20 M290 66 l16 -18')
        + _leaf(66, 38, -30, 0.6, False) + _leaf(318, 44, -40, 0.6, False)
        + '<path d="M180 66 V136" fill="none" stroke-width="2"/>'
        + cone(180, 194, 0, 1.2, spread=True, seeds=True)
        + _bird(312, 40, 0.8, left=True) + face(70, 236, 32)
        + motion('M282 34 C250 30 230 110 214 150'))

D['make_a_bird_feeder_with_a_grown_up'] = [_bf1, _bf2, _bf3, _bf4]
