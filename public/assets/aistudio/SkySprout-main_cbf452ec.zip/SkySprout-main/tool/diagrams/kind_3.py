"""Diagrams for the last Kindness challenges (a "you are great" sign, feeding
a pet, picking up five things, saying what you love, playing someone else's
game, a secret good deed). Simple round-headed people; the accent is only for
arrows and dashed motion lines."""
import math
import re

from style import INK, arrow, dot, ghost, ground, motion, thin

D = {}


# ── Shared bits ──────────────────────────────────────────────────────────
def key(title):
    return re.sub(r'[^a-z0-9]+', '_', title.lower()).strip('_')[:48]


def g(body, x=0, y=0, s=1, rot=0):
    t = f'translate({x} {y})'
    if rot:
        t += f' rotate({rot})'
    if s != 1:
        t += f' scale({s})'
    return f'<g transform="{t}">{body}</g>'


def face(cx, cy, r=24, mouth='smile', hair=True, look=0):
    """A round head. mouth: smile, grin, open (talking), shh (pressed shut), o.
    look moves the eyes sideways (-1 left, 1 right)."""
    ex = r * .12 * look
    s = (f'<circle cx="{cx}" cy="{cy}" r="{r}"/>'
         + dot(cx - r * .35 + ex, cy - r * .08) + dot(cx + r * .35 + ex, cy - r * .08))
    m = {
        'smile': f'M{cx - r * .3} {cy + r * .35} q{r * .3} {r * .25} {r * .6} 0',
        'shh': f'M{cx - r * .22} {cy + r * .42} q{r * .22} {r * .12} {r * .44} -{r * .06}',
    }
    if mouth in m:
        s += thin(m[mouth])
    elif mouth == 'grin':
        s += (f'<path d="M{cx - r * .4} {cy + r * .26} q{r * .4} {r * .5} {r * .8} 0 Z" stroke-width="1.8"/>')
    elif mouth in ('open', 'o'):
        s += f'<ellipse cx="{cx + ex}" cy="{cy + r * .42}" rx="{r * .16}" ry="{r * .12}" stroke-width="1.8"/>'
    if hair:
        s += (f'<path d="M{cx - r * .92} {cy - r * .4} q{r * .3} {-r * .85} {r * 1.1} {-r * .7} '
              f'q{r * .6} {r * .02} {r * .8} {r * .5}" fill="none"/>')
    return s


def grown_head(cx, cy, r=24, mouth='smile', look=0):
    """A grown-up's head: a bun on top and round glasses."""
    return (f'<circle cx="{cx}" cy="{cy - r - 4}" r="{r * .38:.1f}"/>' + face(cx, cy, r, mouth, False, look)
            + f'<path d="M{cx - r * .92} {cy - r * .25} q{r * .17} {-r * .83} {r * .92} {-r * .83} '
              f'q{r * .75} 0 {r * .92} {r * .83}" fill="none"/>'
            + f'<circle cx="{cx - r * .35 + r * .12 * look}" cy="{cy - r * .08}" r="{r * .27:.1f}" fill="none" stroke-width="1.6"/>'
            + f'<circle cx="{cx + r * .35 + r * .12 * look}" cy="{cy - r * .08}" r="{r * .27:.1f}" fill="none" stroke-width="1.6"/>')


def _arm(sx, sy, ex, ey, cx=None, cy=None, hand=True):
    if cx is None:
        cx, cy = (sx + ex) / 2 + (ex - sx) * .1, (sy + ey) / 2 + 8
    d = f'M{sx} {sy} Q{cx} {cy} {ex} {ey}'
    s = (f'<path d="{d}" fill="none" stroke-width="7"/>'
         f'<path d="{d}" fill="none" stroke="#fff" stroke-width="2.2"/>')
    if hand:
        s += f'<circle cx="{ex}" cy="{ey}" r="6"/>'
    return s


def person(cx, by, s=1.0, arms=None, adult=False, mouth='smile', look=0, walk=False, behind='', front=''):
    """A child (or grown-up) standing, feet at by. arms: list of (side, end x, end y[, ctrl x, ctrl y])
    in local units, from the shoulder at (18 * side, -top + 8). `behind` is drawn behind the arms
    but in front of the body (something held against the chest)."""
    leg = 60 if adult else 40
    top = leg + (66 if adult else 56)
    if walk:
        legs = (f'<path d="M-9 {-leg} L-22 -2" fill="none" stroke-width="10"/><path d="M-9 {-leg} L-22 -2" fill="none" stroke="#fff" stroke-width="5.2"/>'
                f'<path d="M9 {-leg} L20 -2" fill="none" stroke-width="10"/><path d="M9 {-leg} L20 -2" fill="none" stroke="#fff" stroke-width="5.2"/>')
    else:
        legs = (f'<rect x="-14" y="{-leg}" width="10" height="{leg}" rx="3"/>'
                f'<rect x="4" y="{-leg}" width="10" height="{leg}" rx="3"/>')
    arms = arms if arms is not None else [(-1, -30, -44), (1, 30, -44)]
    a = ''
    for arm in arms:
        side, ex, ey = arm[:3]
        ctrl = arm[3:] if len(arm) > 3 else (ex * .8, (ey - top + 8) / 2 - 6)
        a += _arm(18 * side, -top + 8, ex, ey, *ctrl)
    body = f'<path d="M-22 {-leg} L-18 {-top + 4} Q0 {-top - 4} 18 {-top + 4} L22 {-leg} Z"/>'
    hy = -top - 26
    neck = f'<rect x="-5" y="{-top - 6}" width="10" height="8"/>'
    head = grown_head(0, hy, 24, mouth, look) if adult else face(0, hy, 24, mouth, True, look)
    return g(legs + body + behind + neck + head + a + front, cx, by, s)


def head_y(by, s=1.0, adult=False):
    """Where person()'s head centre lands."""
    return by - s * ((126 if adult else 96) + 26)


def sitter(cx, by, s=1.0, arms=None, mouth='smile', look=0):
    """A child sitting cross-legged on the floor, seen from the front; bottom at by."""
    top = 70
    legs = ('<path d="M-40 -2 Q-40 -20 -18 -20 H18 Q40 -20 40 -2 Q40 6 30 6 H-30 Q-40 6 -40 -2 Z"/>'
            + thin('M0 -18 V4') + '<ellipse cx="-30" cy="0" rx="8" ry="5"/><ellipse cx="30" cy="0" rx="8" ry="5"/>')
    arms = arms if arms is not None else [(-1, -30, -20), (1, 30, -20)]
    a = ''
    for arm in arms:
        side, ex, ey = arm[:3]
        ctrl = arm[3:] if len(arm) > 3 else (ex * .9, (ey - top + 8) / 2)
        a += _arm(18 * side, -top + 8, ex, ey, *ctrl)
    body = f'<path d="M-22 -14 L-18 {-top + 4} Q0 {-top - 4} 18 {-top + 4} L22 -14 Z"/>'
    neck = f'<rect x="-5" y="{-top - 6}" width="10" height="8"/>'
    return g(body + legs + neck + face(0, -top - 26, 24, mouth, True, look) + a, cx, by, s)


def heart(cx, cy, s, sw=1.8, fill='#fff'):
    return (f'<path d="{heart_d(cx, cy, s)} Z" stroke-width="{sw}" fill="{fill}"/>')


def heart_d(cx, cy, s):
    return (f'M{cx} {cy + s * .8} C{cx - s * 1.4} {cy - s * .1} {cx - s * .6} {cy - s * 1.1} {cx} {cy - s * .4} '
            f'C{cx + s * .6} {cy - s * 1.1} {cx + s * 1.4} {cy - s * .1} {cx} {cy + s * .8}')


def star_pts(cx, cy, r):
    pts = []
    for i in range(10):
        a = -math.pi / 2 + i * math.pi / 5
        rr = r if i % 2 == 0 else r * .45
        pts.append(f'{cx + rr * math.cos(a):.1f},{cy + rr * math.sin(a):.1f}')
    return ' '.join(pts)


def star(cx, cy, r):
    return f'<polygon points="{star_pts(cx, cy, r)}" stroke-width="1.8"/>'


def scribble(x, y, n, w=22, sw=1.6):
    """Joined-up 'handwriting' loops (no real letters)."""
    d = f'M{x} {y}'
    for i in range(n):
        h = (14, 20, 10, 18, 12)[i % 5]
        d += (f' c{w * .2} -{h * .2} {w * .55} -{h} {w * .35} -{h} c-{w * .25} 0 -{w * .2} {h * .7} {w * .15} {h} '
              f'c{w * .15} {h * .1} {w * .3} -{h * .05} {w * .45} -{h * .15}')
    return f'<path d="{d}" fill="none" stroke-width="{sw}"/>'


def speech(x0, y0, x1, y1, tx, ty, bx=None, inside=''):
    """A rounded speech bubble with its tail pointing to (tx, ty) from the bottom edge at bx."""
    r = 14
    bx = (x0 + x1) / 2 - 7 if bx is None else bx
    return (f'<path d="M{x0 + r} {y0} H{x1 - r} Q{x1} {y0} {x1} {y0 + r} V{y1 - r} Q{x1} {y1} {x1 - r} {y1} '
            f'H{bx + 16} L{tx} {ty} L{bx} {y1} H{x0 + r} Q{x0} {y1} {x0} {y1 - r} V{y0 + r} Q{x0} {y0} {x0 + r} {y0} Z"/>'
            + inside)


def cloud(cx, cy, rx, ry, n=9, tail=None, inside=''):
    """A thought bubble round (cx, cy); tail = the little (x, y, r) circles leading to the thinker."""
    pts = [(cx + rx * math.cos(2 * math.pi * i / n + .3), cy + ry * math.sin(2 * math.pi * i / n + .3)) for i in range(n)]
    d = f'M{pts[0][0]:.1f} {pts[0][1]:.1f}'
    for i in range(n):
        p, q = pts[i], pts[(i + 1) % n]
        rr = math.dist(p, q) * .56
        d += f' A{rr:.1f} {rr:.1f} 0 0 1 {q[0]:.1f} {q[1]:.1f}'
    s = ''.join(f'<circle cx="{x}" cy="{y}" r="{r}"/>' for x, y, r in (tail or ()))
    return s + f'<path d="{d} Z"/>' + inside


def pen(x, y, rot=-50, s=1.0):
    """A felt pen, tip at (x, y), body running off at angle rot."""
    b = ('<path d="M0 0 L12 -4 V4 Z"/>'
         '<rect x="12" y="-7" width="64" height="14" rx="3"/>'
         '<rect x="76" y="-8" width="14" height="16" rx="3"/>'
         + thin('M24 -7 V7'))
    return g(b, x, y, s, rot)


def fist(x=0, y=0, rot=0, s=1.0):
    """A mitten fist closed round something at (x, y); the forearm runs off along +x."""
    b = ('<path d="M14 -11 L66 -11 M14 11 L66 11" fill="none"/>'
         '<rect x="14" y="-11" width="52" height="22" stroke="none"/>'
         '<rect x="64" y="-15" width="20" height="30" rx="3"/>'
         '<path d="M-18 -6 Q-18 -19 -6 -19 H6 Q18 -19 18 -6 V6 Q18 19 6 19 H-6 Q-18 19 -18 6 Z"/>'
         + thin('M-18 -4 h9 M-18 6 h9') + '<path d="M-10 -19 Q0 -30 12 -18" fill="none"/>')
    return g(b, x, y, s, rot)


def pen_held(x, y, rot=-50, s=1.0, arm=70):
    return g(pen(0, 0, 0) + fist(40, 0, arm), x, y, s, rot)


def tape(x, y, w=30, h=12, rot=0):
    z = 3
    pts = [(0, 0), (w, 0), (w - z, h / 4), (w, h / 2), (w - z, 3 * h / 4), (w, h), (0, h),
           (z, 3 * h / 4), (0, h / 2), (z, h / 4)]
    p = ' '.join(f'{a - w / 2},{b - h / 2}' for a, b in pts)
    return g(f'<polygon points="{p}" stroke-width="1.8"/>', x, y, 1, rot)


# A child's arm with one finger up to the lips (person() local units) and the finger itself.
SHH_ARM = (1, 2, -94, 40, -84)
SHH = '<rect x="-3" y="-116" width="8" height="20" rx="4"/><circle cx="2" cy="-94" r="7"/>'



# ── Make a "you are great" sign for someone ──────────────────────────────
def _sign(x, y, w=200, h=130, deco=True, words=True):
    s = f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="3"/>'
    if words:  # big bubbly 'letters' as fat loops
        s += scribble(x + 30, y + 54, 5, 28, 4) + scribble(x + 46, y + 96, 4, 28, 4)
    if deco:
        s += (star(x + 22, y + 22, 11) + heart(x + w - 22, y + 24, 10) + heart(x + 20, y + h - 18, 9)
              + star(x + w - 22, y + h - 20, 11))
    return s


SX, SY = 100, 70
D[key('Make a "you are great" sign for someone')] = [
    # someone special in a thought bubble, cheered with little sparkles
    ground(276) + person(90, 276, 1, mouth='smile', arms=[(-1, -30, -44), (1, 28, -112, 40, -120)])
    + cloud(250, 104, 100, 66, 10, tail=((124, 122, 5), (140, 104, 8)),
            inside=grown_head(250, 112, 30, 'grin') + star(194, 86, 9) + star(306, 86, 9) + heart(306, 140, 9))
    + motion('M220 84 l-16 -14', 'M280 84 l16 -14'),
    # big bubbly writing on the paper, felt pen still going
    _sign(SX, SY, deco=False, words=False)
    + scribble(SX + 30, SY + 54, 5, 28, 4) + scribble(SX + 46, SY + 96, 3, 28, 4)
    + pen_held(SX + 128, SY + 92, -50, 1, 90)
    + arrow(f'M{SX + 46} {SY + 150} H{SX + 130}'),
    # stars and hearts round the edge, one being drawn
    _sign(SX, SY, deco=False)
    + star(SX + 22, SY + 22, 11) + heart(SX + 178, SY + 24, 10) + heart(SX + 20, SY + 112, 9)
    + f'<polygon points="{star_pts(SX + 178, SY + 110, 11)}" fill="none" stroke-width="1.6" stroke-dasharray="3 4"/>'
    + pen_held(SX + 186, SY + 120, -45, 1, 90)
    + motion(f'M{SX + 160} {SY + 92} l-8 -8', f'M{SX + 156} {SY + 112} h-12', f'M{SX + 166} {SY + 130} l-6 8'),
    # taped to a bedroom door, the child tiptoes away
    ground(280, 24, 376)
    + '<rect x="40" y="20" width="150" height="260"/><rect x="52" y="30" width="126" height="250"/>'
    + '<circle cx="166" cy="160" r="7"/>'
    + g(_sign(0, 0, 200, 130), 70, 72, .52)
    + tape(80, 74, 22, 9, -30) + tape(166, 74, 22, 9, 30)
    + person(296, 280, .95, mouth='grin', walk=True, look=-1,
             arms=[(-1, -36, -50), (1, 34, -50)])
    + motion('M350 210 h18', 'M346 230 h22')
    + arrow('M240 120 C214 112 196 110 182 112', dashed=True),
]


# ── Help feed a pet ──────────────────────────────────────────────────────
def kibble(x0, x1, y0, y1, n, seed=2):
    import random
    rnd = random.Random(seed)
    return ''.join(f'<circle cx="{rnd.uniform(x0, x1):.1f}" cy="{rnd.uniform(y0, y1):.1f}" r="3.2" stroke-width="1.6"/>'
                   for _ in range(n))


def bowl(cx, y, w=44, food=False, water=False):
    """A pet bowl seen from slightly above; y is the rim."""
    s = (f'<path d="M{cx - w} {y} L{cx - w + 8} {y + 22} H{cx + w - 8} L{cx + w} {y} Z"/>'
         f'<ellipse cx="{cx}" cy="{y}" rx="{w}" ry="9"/>')
    if food:
        s += (f'<ellipse cx="{cx}" cy="{y}" rx="{w - 6}" ry="6" stroke-width="1.6"/>'
              + kibble(cx - w + 14, cx + w - 14, y - 6, y + 2, 9, seed=int(cx)))
    if water:
        s += f'<ellipse cx="{cx}" cy="{y + 1}" rx="{w - 7}" ry="5.5" stroke-width="1.6"/>' + thin(f'M{cx - 14} {y + 1} q7 -3 14 0 q7 3 14 0')
    return s


def scoop(x, y, rot=0, full=True, flip=False):
    """A pet food scoop: cup at (x, y), handle running off along +x. flip turns the cup's mouth down."""
    b = ('<rect x="20" y="-5" width="46" height="10" rx="5"/>'
         '<path d="M-22 -16 L22 -16 L18 12 Q0 22 -18 12 Z"/>'
         '<ellipse cx="0" cy="-16" rx="22" ry="6"/>')
    if full:
        b += kibble(-16, 16, -22, -15, 7, seed=5)
    if flip:
        b = f'<g transform="scale(1 -1)">{b}</g>'
    return g(b, x, y, 1, rot)


def food_bag(x, by):
    return (f'<path d="M{x} {by} L{x + 4} {by - 76} L{x + 12} {by - 86} H{x + 52} L{x + 60} {by - 76} L{x + 64} {by} Z"/>'
            + thin(f'M{x + 4} {by - 76} H{x + 60}') + paw_icon(x + 32, by - 36))


def paw_icon(cx, cy):
    return (f'<ellipse cx="{cx}" cy="{cy + 4}" rx="9" ry="7" stroke-width="1.8"/>'
            + ''.join(f'<circle cx="{cx + dx}" cy="{cy + dy}" r="3.6" stroke-width="1.8"/>'
                      for dx, dy in ((-11, -6), (-4, -12), (4, -12), (11, -6))))


def cat(x, y, s=1.0, eating=False):
    """A cat standing, facing left; feet at (x, y). eating: head down to a bowl."""
    hx, hy = (-44, -28) if eating else (-36, -52)
    b = ('<path d="M26 -30 C52 -36 56 -70 44 -82" fill="none" stroke-width="7"/>'
         '<path d="M26 -30 C52 -36 56 -70 44 -82" fill="none" stroke="#fff" stroke-width="2.2"/>'
         '<path d="M-22 -18 V0 M-12 -18 V0 M14 -18 V0 M24 -18 V0" fill="none" stroke-width="2.4"/>'
         '<ellipse cx="0" cy="-30" rx="34" ry="17"/>'
         f'<path d="M{hx - 13} {hy - 4} L{hx - 12} {hy - 24} L{hx - 2} {hy - 12} Z"/>'
         f'<path d="M{hx + 2} {hy - 13} L{hx + 12} {hy - 24} L{hx + 13} {hy - 4} Z"/>'
         f'<circle cx="{hx}" cy="{hy}" r="15"/>'
         + (thin(f'M{hx - 9} {hy - 1} q3 3 6 0 M{hx + 2} {hy - 1} q3 3 6 0') if eating
            else dot(hx - 6, hy - 2, 2) + dot(hx + 4, hy - 2, 2))
         + thin(f'M{hx - 3} {hy + 7} q2 2 4 0'))
    return g(b, x, y, s)


def jug(cx, cy, rot=-40):
    """A water jug: spout top left, handle on the right, tipped by rot."""
    b = ('<path d="M-28 -40 L28 -40 L34 40 H-34 Z"/><path d="M-28 -40 L-44 -50 L-31 -26" />'
         '<path d="M30 -26 Q56 -24 52 6 Q48 22 34 20" fill="none" stroke-width="6"/>'
         '<path d="M30 -26 Q56 -24 52 6 Q48 22 34 20" fill="none" stroke="#fff" stroke-width="1.4"/>'
         + thin('M-31 -4 H31'))
    return g(b, cx, cy, 1, rot)


BY_ = 250
D[key('Help feed a pet')] = [
    # a grown-up holds out the scoop: this much
    ground(276) + food_bag(196, 276)
    + scoop(150, 150, 0)
    + person(300, 276, 1.05, adult=True, look=-1, mouth='open',
             arms=[(-1, -80, -120, -50, -150), (1, 30, -50)])
    + person(80, 276, 1, mouth='o', look=1, arms=[(-1, -30, -44), (1, 30, -44)])
    + motion('M132 112 l-6 -10', 'M152 106 v-12', 'M172 112 l6 -10'),
    # tip the scoop slowly over the bowl
    ground(BY_ + 24) + bowl(190, BY_, 72)
    + kibble(150, 226, BY_ - 4, BY_ + 2, 9, seed=4)
    + scoop(170, 140, -15, full=False, flip=True)
    + fist(228, 124, -15)
    + kibble(156, 186, 170, 226, 6, seed=11)
    + motion('M140 172 v44', 'M200 172 v44')
    + arrow('M128 104 C108 118 108 140 128 150'),
    # fresh water from a jug into the second bowl
    ground(BY_ + 24) + bowl(96, BY_, 54, food=True) + bowl(244, BY_, 54, water=True)
    + jug(304, 128) + fist(341, 94, -60, .9)
    + motion('M240 118 C232 160 236 210 240 240', 'M250 120 C246 162 250 210 254 240'),
    # the cat eats; the child watches, happy
    ground(276) + bowl(118, 252, 40, food=True)
    + cat(206, 276, 1.15, eating=True)
    + person(326, 276, 1, mouth='grin', look=-1, arms=[(-1, -36, -52), (1, 30, -44)])
    + motion('M66 226 l-12 -6', 'M64 248 h-14', 'M140 210 l4 -12'),
]


# ── Pick up 5 things off the floor ───────────────────────────────────────
def ball(cx, cy, r=13):
    return (f'<circle cx="{cx}" cy="{cy}" r="{r}"/>'
            + thin(f'M{cx - r} {cy} Q{cx} {cy + r * .7} {cx + r} {cy} M{cx} {cy - r} Q{cx - r * .6} {cy} {cx} {cy + r}'))


def block(x, y, a=22):
    """A toy block: front square at (x, y) with a top and side."""
    d = a * .35
    return (f'<rect x="{x}" y="{y}" width="{a}" height="{a}"/>'
            f'<path d="M{x} {y} L{x + d} {y - d} H{x + a + d} L{x + a} {y} Z"/>'
            f'<path d="M{x + a} {y} L{x + a + d} {y - d} V{y + a - d} L{x + a} {y + a} Z"/>'
            + star(x + a / 2, y + a / 2 + 1, a * .3).replace('stroke-width="1.8"', 'stroke-width="1.4"'))


def teddy(cx, by, s=1.0):
    b = ('<circle cx="-11" cy="-44" r="6"/><circle cx="11" cy="-44" r="6"/>'
         '<ellipse cx="-12" cy="-4" rx="8" ry="6"/><ellipse cx="12" cy="-4" rx="8" ry="6"/>'
         '<ellipse cx="0" cy="-14" rx="14" ry="14"/>'
         '<circle cx="0" cy="-36" r="12"/><ellipse cx="0" cy="-32" rx="5" ry="4"/>'
         + dot(-4, -39, 1.8) + dot(4, -39, 1.8) + dot(0, -33, 1.6))
    return g(b, cx, by, s)


def book(x, y, rot=0):
    b = ('<rect x="0" y="0" width="38" height="28" rx="2"/>' + thin('M7 0 V28')
         + '<circle cx="23" cy="13" r="6" stroke-width="1.6"/>')
    return g(b, x, y, 1, rot)


def car(x, by, s=1.0):
    b = ('<path d="M-26 -8 V-18 L-14 -20 L-6 -32 H12 L20 -20 L28 -18 V-8 Z"/>'
         + thin('M-4 -29 V-20 M10 -29 V-20 M-10 -20 H22')
         + '<circle cx="-14" cy="-6" r="6"/><circle cx="16" cy="-6" r="6"/>')
    return g(b, x, by, s)


def toy_box(x, y, w=110, h=64):
    return (f'<path d="M{x} {y} L{x + 18} {y - 16} H{x + w + 18} L{x + w} {y} Z"/>'
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}"/>'
            f'<path d="M{x + w} {y} L{x + w + 18} {y - 16} V{y + h - 16} L{x + w} {y + h} Z"/>'
            + thin(f'M{x} {y + 18} H{x + w}'))


def shelf(x, y, w=130):
    """Two shelves; returns the frame. Top shelf at y + 52, bottom at y + 112."""
    return (f'<rect x="{x}" y="{y}" width="{w}" height="120" fill="none"/>'
            + f'<path d="M{x} {y + 60} H{x + w}" fill="none"/>')


RUG = '<ellipse cx="200" cy="244" rx="176" ry="38" stroke-width="1.8"/>'
D[key('Pick up 5 things off the floor')] = [
    # five things lying about on the rug; the child has a look
    RUG + person(70, 246, .9, look=1, mouth='o', arms=[(-1, -30, -44), (1, 22, -112, 40, -100)])
    + ball(140, 252) + block(186, 222) + car(266, 258) + teddy(320, 254, .8) + book(206, 254, -12)
    + motion('M96 136 C140 150 166 180 180 206'),
    # the first thing goes into the toy box
    ground(270) + toy_box(220, 206)
    + person(140, 270, 1, mouth='smile', look=1, arms=[(-1, -30, -44), (1, 78, -110, 50, -140)])
    + ball(232, 162, 14)
    + arrow('M252 150 C276 140 288 160 284 188'),
    # three more in the child's arms, two already on the shelf: five altogether
    ground(276) + shelf(244, 120)
    + ball(266, 167, 12) + book(286, 152, 0) + block(336, 156, 20)
    + person(130, 276, 1, mouth='grin', look=1,
             behind=teddy(-46, -14, .8) + car(52, -54, .9),
             arms=[(-1, -46, -58, -40, -80), (1, 50, -80, 40, -100)])
    + arrow('M192 188 C222 178 244 192 264 212', dashed=True),
    # all five away on the shelf, floor clear, arms up
    ground(276) + shelf(232, 112, 140)
    + ball(256, 160, 12) + book(280, 146) + block(330, 150, 20)
    + teddy(262, 232, .62) + car(326, 232, .8)
    + person(120, 276, 1, mouth='grin', arms=[(-1, -44, -168), (1, 44, -168)])
    + motion('M58 92 l-10 -6', 'M60 116 h-14', 'M182 92 l10 -6', 'M180 116 h14'),
]


# ── Tell someone what you love about them ────────────────────────────────
def kitchen():
    """A worktop with cupboards and a kettle, at the back on the right."""
    return ('<rect x="236" y="168" width="140" height="108"/><path d="M230 160 H382 V168 H230 Z"/>'
            + thin('M306 176 V268 M296 214 v14 M316 214 v14')
            + '<path d="M334 160 V138 Q334 128 344 128 H360 Q370 128 370 138 V160 Z"/>'
            + '<path d="M334 140 L322 132" fill="none"/><path d="M344 128 Q352 118 360 128" fill="none"/>')


D[key('Tell someone what you love about them')] = [
    # thinking of the grown-up and a heart
    ground(276) + person(90, 276, 1, arms=[(-1, -30, -44), (1, 28, -112, 40, -120)])
    + cloud(250, 104, 100, 66, 10, tail=((124, 122, 5), (140, 104, 8)),
            inside=grown_head(220, 112, 30, 'smile') + heart(296, 108, 26, 2.4)),
    # walk up to them in the kitchen
    ground(276) + kitchen()
    + person(270, 276, 1.05, adult=True, look=-1, arms=[(-1, -40, -60), (1, 30, -60)])
    + person(88, 276, 1, walk=True, look=1, arms=[(-1, -36, -52), (1, 34, -48)])
    + motion('M30 196 h18', 'M24 218 h22')
    + arrow('M128 128 C164 108 196 110 222 126'),
    # say it: a heart in the speech bubble
    ground(276)
    + person(280, 276, 1.05, adult=True, mouth='grin', look=-1, arms=[(-1, -30, -50), (1, 30, -50)])
    + person(110, 276, 1, mouth='open', look=1, arms=[(-1, -30, -44), (1, 30, -44)])
    + speech(40, 22, 200, 104, 120, 124, 96,
             inside=heart(78, 62, 20, 2.4) + scribble(110, 72, 3, 22))
    + motion('M140 144 q8 6 0 14', 'M150 138 q14 12 0 26'),
    # they smile and give a big hug back
    ground(276)
    + person(150, 276, 1, mouth='grin', look=1, arms=[(-1, -30, -44), (1, 46, -50, 40, -70)])
    + person(254, 276, 1.05, adult=True, mouth='grin', look=-1,
             arms=[(-1, -54, -48, -40, -80), (1, 30, -50)])
    + motion(heart_d(200, 72, 24))
    + motion('M162 72 l-10 -8', 'M240 48 l10 -8'),
]


# ── Play a game someone else likes ───────────────────────────────────────
def card(x, y, rot=0, back=False, w=30, h=42):
    b = f'<rect x="{-w / 2}" y="{-h / 2}" width="{w}" height="{h}" rx="3"/>'
    if back:
        b += f'<rect x="{-w / 2 + 5}" y="{-h / 2 + 5}" width="{w - 10}" height="{h - 10}" rx="1" stroke-width="1.4" fill="none"/>' \
             + thin(f'M{-w / 2 + 5} {-h / 2 + 5} L{w / 2 - 5} {h / 2 - 5} M{w / 2 - 5} {-h / 2 + 5} L{-w / 2 + 5} {h / 2 - 5}')
    else:
        b += heart(0, -2, 8)
    return g(b, x, y, 1, rot)


D[key('Play a game someone else likes')] = [
    # what do you like to play? (cards, ball, blocks)
    ground(276)
    + person(96, 276, 1, mouth='open', look=1, arms=[(-1, -30, -44), (1, 34, -60)])
    + person(296, 276, .9, mouth='smile', look=-1, arms=[(-1, -30, -44), (1, 30, -44)])
    + speech(40, 20, 216, 92, 112, 132, 96,
             inside=card(80, 56, -8, back=True) + ball(130, 56, 16) + block(166, 46, 24))
    + motion('M132 140 q8 6 0 14', 'M142 134 q14 12 0 26'),
    # the sibling shows how: this card goes here
    ground(276)
    + sitter(110, 268, 1, mouth='smile', look=1, arms=[(-1, -30, -20), (1, 30, -20)])
    + sitter(290, 268, 1, mouth='open', look=-1, arms=[(1, 30, -20), (-1, -70, -100, -60, -40)])
    + card(220, 146, -10)
    + card(170, 252, -6, back=True) + card(178, 248, 4, back=True)
    + ghost('M218 232 h30 v40 h-30 Z')
    + arrow('M226 176 C230 196 232 210 234 224'),
    # play together on the floor
    ground(276)
    + '<g transform="translate(200 254)">'
    + card(-28, 0, -8, back=True) + card(-22, -2, 4, back=True)
    + card(26, 0, 6) + '</g>'
    + sitter(84, 268, 1, mouth='grin', look=1, arms=[(-1, -30, -20), (1, 76, -30, 50, -40)])
    + sitter(316, 268, 1, mouth='grin', look=-1, arms=[(1, 30, -20), (-1, -60, -66)])
    + card(250, 202, 12)
    + arrow('M262 222 C258 240 246 246 236 250'),
    # laughing together; a heart says what they liked
    ground(276)
    + person(140, 276, 1, mouth='grin', look=1, arms=[(-1, -40, -110, -40, -80), (1, 30, -44)])
    + person(262, 276, .92, mouth='grin', look=-1, arms=[(-1, -30, -44), (1, 40, -110, 40, -80)])
    + card(200, 258, -6, back=True) + card(212, 262, 8)
    + heart(200, 60, 20, 2.4)
    + motion('M100 70 l-10 -8', 'M96 92 h-14', 'M302 70 l10 -8', 'M306 92 h14'),
]


# ── Do a secret good deed and don't tell ─────────────────────────────────
def bed(x, by, w=210, made=True, pull=0):
    """A bed seen from the side, foot on the right. pull = how far the cover is pulled up (0..1)."""
    s = (f'<rect x="{x}" y="{by - 120}" width="14" height="120" rx="3"/>'
         f'<rect x="{x + w - 10}" y="{by - 56}" width="10" height="56" rx="3"/>'
         f'<rect x="{x + 10}" y="{by - 54}" width="{w - 14}" height="22" rx="3"/>'
         f'<path d="M{x + 14} {by - 54} H{x + w - 6}" fill="none"/>'
         f'<rect x="{x + 22}" y="{by - 76}" width="56" height="22" rx="10"/>')
    if made:
        s += (f'<path d="M{x + 70} {by - 62} Q{x + 70} {by - 68} {x + 80} {by - 68} H{x + w - 6} '
              f'V{by - 24} H{x + 76} Q{x + 70} {by - 24} {x + 70} {by - 32} Z"/>'
              + thin(f'M{x + 86} {by - 60} H{x + w - 14}'))
    else:
        f = x + w - 6 - pull * (w - 82)
        s += (f'<path d="M{f} {by - 70} Q{f - 10} {by - 64} {f - 4} {by - 50} Q{f + 6} {by - 36} {f} {by - 24} '
              f'H{x + w - 6} V{by - 58} Q{x + w - 30} {by - 72} {f} {by - 70} Z"/>'
              + thin(f'M{f + 14} {by - 60} q14 -4 30 4'))
    return s


D[key('Do a secret good deed and don\'t tell')] = [
    # shh: a secret plan to make someone's bed
    ground(276) + person(96, 276, 1, mouth='shh', look=1, arms=[(-1, -30, -44), SHH_ARM], front=SHH)
    + cloud(262, 104, 104, 66, 10, tail=((128, 120, 5), (144, 102, 8)),
            inside=g(bed(0, 0, 170), 196, 150, .78) + heart(312, 70, 12, 2.2))
    + motion('M50 136 q-10 10 0 20', 'M40 128 q-18 18 0 36'),
    # nobody's looking: pull the cover up
    ground(276) + bed(20, 276, 240, made=False, pull=.4)
    + person(300, 276, 1, mouth='smile', look=-1, arms=[(-1, -110, -70, -60, -110), (1, 30, -44)])
    + arrow('M180 180 C156 166 126 166 104 178')
    + motion('M352 76 l10 -8', 'M358 98 h14'),
    # don't tell! finger on the lips, bed made behind
    ground(276) + bed(30, 276, 190)
    + person(296, 276, 1.05, mouth='grin', look=-1, arms=[(-1, -30, -44), SHH_ARM], front=SHH)
    + motion('M340 112 q10 10 0 20', 'M350 104 q18 18 0 36'),
    # a warm glow inside
    ground(276)
    + person(200, 276, 1.1, mouth='grin', arms=[(-1, -10, -66, -40, -60), (1, 10, -66, 40, -60)],
             behind=heart(0, -86, 18, 2.4))
    + motion('M200 34 v-16', 'M140 58 l-12 -10', 'M260 58 l12 -10', 'M118 120 h-18', 'M282 120 h18',
             'M132 180 l-14 8', 'M268 180 l14 8'),
]
