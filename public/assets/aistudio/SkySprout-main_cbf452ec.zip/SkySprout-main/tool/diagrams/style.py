"""Shared drawing kit for the challenge step diagrams.

Every diagram is a 400 x 300 SVG drawn like a printed instruction sheet:
black line art on white, no text, and one accent colour per kind used only
for arrows and dashed motion lines. `render.py` turns them into the WebP
pictures the app and website show.
"""

INK = '#1d1d1f'
W, H = 400, 300
ACCENTS = {
    'lego': '#D6372F',
    'craft': '#8A3FB0',
    'draw': '#1F74C9',
    'outdoor': '#2F8A3C',
    'kind': '#C98A00',
    'cook': '#E0661B',
}


def svg(body, cat):
    """A whole diagram: white page, the ink style, and an arrowhead in the kind's colour."""
    acc = ACCENTS[cat]
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="1200" height="900">'
        f'<rect width="{W}" height="{H}" fill="#fff"/>'
        f'<defs><marker id="a" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="5" markerHeight="5" '
        f'orient="auto-start-reverse"><path d="M1 1 L9 5 L1 9" fill="none" stroke="{acc}" stroke-width="2" '
        f'stroke-linecap="round" stroke-linejoin="round"/></marker></defs>'
        f'<g fill="#fff" stroke="{INK}" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round" '
        f'style="--acc:{acc}">{body.replace("ACC", acc)}</g></svg>'
    )


# Accent strokes. Write ACC in a path's stroke and svg() swaps in the kind's colour.
def arrow(d, dashed=False):
    """A curved arrow along path d, in the accent colour."""
    dash = 'stroke-dasharray="6 6" ' if dashed else ''
    return f'<path d="{d}" fill="none" stroke="ACC" stroke-width="2.4" {dash}marker-end="url(#a)"/>'


def motion(*ds):
    """Dashed accent lines: movement, sound, sparkle, wind."""
    return ''.join(f'<path d="{d}" fill="none" stroke="ACC" stroke-width="2.4" stroke-dasharray="5 6"/>' for d in ds)


def ground(y=238, x0=24, x1=376):
    return f'<path d="M{x0} {y} H{x1}" stroke="{INK}" stroke-width="1.6" stroke-dasharray="2 7"/>'


def dot(x, y, r=2.4):
    return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{INK}" stroke="none"/>'


def thin(d):
    """A lighter detail line (texture, folds, stitching)."""
    return f'<path d="{d}" fill="none" stroke-width="1.6"/>'


def ghost(d):
    """A dashed ink outline for 'goes here' or 'fold here'."""
    return f'<path d="{d}" fill="none" stroke-width="1.6" stroke-dasharray="4 5"/>'


def hand(x, y, s=1.0, flip=False):
    """A simple mitten-style hand, wrist at (x, y), fingers pointing up-right."""
    t = f'translate({x} {y}) scale({-s if flip else s} {s})'
    return (f'<g transform="{t}"><path d="M0 0 C-4 -16 -2 -30 8 -38 C14 -44 22 -44 28 -40 L40 -30 '
            f'C46 -26 44 -18 38 -20 L30 -24 C34 -14 30 0 22 6 L18 18 L-6 18 Z"/>'
            f'<path d="M8 -38 C4 -48 14 -52 18 -44" fill="none"/></g>')


# Toy bricks: side view, studs on top.
U, BH = 16, 18  # one stud's width, one brick's height


def brick(x, y, n, studs=True):
    s = f'<rect x="{x}" y="{y}" width="{n * U}" height="{BH}" rx="1.5"/>'
    if studs:
        s += ''.join(f'<rect x="{x + i * U + 4}" y="{y - 4}" width="8" height="4" rx="1"/>' for i in range(n))
    return s


def slope(x, y, n=1):
    """A pointy brick (spike, roof tip)."""
    return f'<polygon points="{x},{y + BH} {x + n * U},{y + BH} {x + n * U / 2},{y}"/>'
