"""Diagrams for more Kitchen challenges (ice lollies, cakes, popcorn, a yogurt
pot, washing the vegetables, a teddy picnic, funny toast). Worktops are seen
slightly from above; wherever there is heat (oven, hob, toaster) a grown-up's
bigger hand with a sleeve is doing it. The orange accent is only for arrows
and dashed motion lines."""
import math
import re

from craft_3 import grip, mitt
from kind_2 import head, limb, person, tap
from style import INK, arrow, dot, ghost, ground, motion, thin

D = {}


def key(title):
    return re.sub(r'[^a-z0-9]+', '_', title.lower()).strip('_')[:48]


# ── Shared bits ──────────────────────────────────────────────────────────
def g(body, x=0, y=0, s=1, rot=0, flip=False):
    t = f'translate({x} {y})'
    if rot:
        t += f' rotate({rot})'
    if s != 1 or flip:
        t += f' scale({-s if flip else s} {s})'
    return f'<g transform="{t}">{body}</g>'


def worktop(y=244, d=58, x0=18, x1=382):
    """A kitchen worktop seen slightly from above: its top surface and front edge at y."""
    return (f'<path d="M{x0 + 26} {y - d} H{x1 - 26} L{x1} {y} H{x0} Z" stroke-width="1.6"/>'
            f'<rect x="{x0}" y="{y}" width="{x1 - x0}" height="12" rx="3"/>')


def sink(x0=22, y0=172, w=200, h=92):
    """A sink basin seen from above and in front."""
    return (f'<rect x="{x0}" y="{y0}" width="{w}" height="{h}" rx="16"/>'
            f'<rect x="{x0 + 14}" y="{y0 + 12}" width="{w - 28}" height="{h - 24}" rx="11"/>')


def tap_r(x, y):
    """kind_2's tap mirrored: spout mouth at (x, y), column on the right."""
    return f'<g transform="translate({x} {y}) scale(-1 1)">{tap(0, 0)}</g>'


def water(x, y0, y1, gap=6):
    return motion(f'M{x - gap} {y0} V{y1}', f'M{x + gap} {y0} V{y1}')


def bubbles(pts):
    return ''.join(f'<circle cx="{x}" cy="{y}" r="{r}" stroke-width="1.6"/>' for x, y, r in pts)


def apron(cx, yt, hip):
    """An apron over person()'s torso (kid sizes)."""
    return (thin(f'M{cx - 12} {yt + 10} L{cx - 8} {yt - 4} M{cx + 12} {yt + 10} L{cx + 8} {yt - 4}')
            + f'<path d="M{cx - 13} {yt + 10} H{cx + 13} V{yt + 30} L{cx + 24} {hip + 22} '
              f'Q{cx} {hip + 28} {cx - 24} {hip + 22} L{cx - 13} {yt + 30} Z"/>'
            + thin(f'M{cx - 13} {yt + 30} H{cx + 13} M{cx + 13} {yt + 30} l12 8 M{cx + 13} {yt + 30} l12 -2')
            + f'<rect x="{cx - 10}" y="{hip - 4}" width="20" height="14" rx="2" fill="none" stroke-width="1.6"/>')


def kid_at_sink(apron_=False, veg=False):
    """A child standing at a sink unit, washing hands under the tap."""
    cx, by = 150, 276
    yt, hip = 164, 226  # kid torso top and hip for by=276
    s = ground(278)
    # the sink unit: cabinet, worktop, basin, tap
    s += ('<rect x="212" y="200" width="160" height="76"/>'
          + thin('M292 208 V268 M282 230 v14 M302 230 v14')
          + '<path d="M204 178 H380 L376 200 H208 Z"/>'
          + '<path d="M232 182 H340 Q344 182 342 186 L338 194 Q337 196 333 196 H238 Q234 196 233 194 L229 186 Q228 182 232 182 Z" stroke-width="1.6"/>'
          + tap_r(256, 112))
    s += person(cx, by, 'kid', arms=(), look=1, mouth='smile')
    if apron_:
        s += apron(cx, yt, hip)
    sx, sy = cx, yt + 11
    s += (limb(f'M{sx - 20} {sy} Q{sx + 30} {sy + 40} {244} {164}', 15) + f'<circle cx="244" cy="164" r="9.3"/>'
          + limb(f'M{sx + 20} {sy} Q{sx + 60} {sy + 26} {262} {158}', 15) + f'<circle cx="262" cy="158" r="9.3"/>')
    s += water(256, 118, 150, 4) + bubbles([(232, 146, 4), (276, 146, 5), (270, 132, 3), (226, 160, 3)])
    return s


# ── Make ice lollies from juice ──────────────────────────────────────────
def mould(cx, by, level=0, stick=False, rot=0):
    """A tapered lolly mould with its rim at by - 72. level: how far below the rim the juice is."""
    rt = by - 72
    s = f'<path d="M{cx - 17} {rt} L{cx - 11} {by - 10} Q{cx} {by + 4} {cx + 11} {by - 10} L{cx + 17} {rt}"/>'
    if level:
        ly = rt + level
        hw = 17 - 6 * level / 62
        s += thin(f'M{cx - hw:.1f} {ly} Q{cx} {ly + 4} {cx + hw:.1f} {ly}')
    s += f'<ellipse cx="{cx}" cy="{rt}" rx="17" ry="4.5"/>'
    if stick:
        s += (f'<path d="M{cx - 4} {rt + 2} V{rt - 46} Q{cx - 4} {rt - 50} {cx} {rt - 50} '
              f'Q{cx + 4} {rt - 50} {cx + 4} {rt - 46} V{rt + 2}"/>'
              f'<path d="M{cx - 17} {rt} A17 4.5 0 0 0 {cx + 17} {rt}" fill="none"/>')
    if rot:
        s = f'<g transform="rotate({rot} {cx} {by - 36})">{s}</g>'
    return s


def rack(x0, x1, by):
    """The stand the moulds sit in (drawn over their bottoms)."""
    return (f'<rect x="{x0}" y="{by - 24}" width="{x1 - x0}" height="26" rx="5"/>'
            + thin(f'M{x0 + 6} {by - 16} H{x1 - 6}'))


def moulds(xs, by, levels, sticks):
    s = ''.join(mould(x, by, lv, st) for x, lv, st in zip(xs, levels, sticks))
    return s + rack(xs[0] - 28, xs[-1] + 28, by)


def jug_r(cx, cy, rot=40):
    """A jug with its spout top right and handle on the left, tipped by rot."""
    b = ('<path d="M28 -40 L-28 -40 L-34 40 H34 Z"/><path d="M28 -40 L44 -50 L31 -26"/>'
         '<path d="M-30 -26 Q-56 -24 -52 6 Q-48 22 -34 20" fill="none" stroke-width="7"/>'
         '<path d="M-30 -26 Q-56 -24 -52 6 Q-48 22 -34 20" fill="none" stroke="#fff" stroke-width="2"/>'
         + thin('M-31 -8 H31'))
    return g(b, cx, cy, 1, rot)


def lolly(cx, y, s=1.0):
    """A juice lolly, stick down, the flat end of the lolly at y."""
    b = ('<path d="M-4 0 V40 Q-4 44 0 44 Q4 44 4 40 V0"/>'
         '<path d="M-16 0 L-11 -52 Q0 -68 11 -52 L16 0 Z"/>'
         + thin('M-6 -44 Q-8 -26 -8 -10'))
    return g(b, cx, y, s)


def moon(x, y, r=16):
    return (f'<path d="M{x + r * .3:.1f} {y - r} A{r} {r} 0 1 0 {x + r * .3:.1f} {y + r} '
            f'A{r * .8:.1f} {r * .8:.1f} 0 1 1 {x + r * .3:.1f} {y - r} Z"/>')


def twinkle(x, y, r=5):
    return thin(f'M{x} {y - r} V{y + r} M{x - r} {y} H{x + r}')


MX = (176, 222, 268, 314)
MB = 240
_stick4 = (f'<path d="M{MX[3] - 4} 170 V104 Q{MX[3] - 4} 100 {MX[3]} 100 Q{MX[3] + 4} 100 {MX[3] + 4} 104 V170 Z"/>')

D[key('Make ice lollies from juice')] = [
    # pour the juice in, not quite to the top
    worktop(256, 52)
    + moulds(MX, MB, (0, 0, 0, 0), (False,) * 4)
    + mould(MX[0], MB, 16) + rack(MX[0] - 28, MX[-1] + 28, MB)
    + jug_r(104, 112, 40) + grip(64, 94, 60)
    + motion(f'M{MX[0] - 6} 104 Q{MX[0] - 3} 140 {MX[0]} 180'),

    # a stick in each one
    worktop(256, 52)
    + moulds(MX, MB, (16,) * 4, (True, True, True, False))
    + _stick4 + mould(MX[3], MB, 16) + rack(MX[0] - 28, MX[-1] + 28, MB)
    + grip(MX[3] + 4, 108, 200)
    + arrow(f'M{MX[3] + 46} 118 V162'),

    # into the freezer overnight
    ground(272)
    + '<rect x="132" y="30" width="146" height="242" rx="6"/>'
    + '<rect x="144" y="42" width="122" height="218" rx="3"/>'
    + '<rect x="144" y="100" width="122" height="6"/><rect x="144" y="182" width="122" height="6"/>'
    + thin('M150 216 H260 M150 240 H260') + '<rect x="186" y="202" width="38" height="7" rx="3" fill="none" stroke-width="1.6"/>'
    + '<path d="M278 34 L338 54 V250 L278 270 Z"/>' + thin('M290 86 H328 M290 150 H328 M290 214 H328')
    + '<rect x="326" y="130" width="6" height="44" rx="3"/>'
    + g(moulds((0, 38, 76), 0, (16,) * 3, (True,) * 3), 182, 182, .6)
    + moon(66, 70, 20) + twinkle(100, 44) + twinkle(40, 118, 4) + twinkle(104, 100, 4)
    + arrow('M70 220 C96 178 124 160 160 156'),

    # warm water, and pop one out
    sink(22, 176, 200, 90) + tap(120, 98)
    + water(118, 104, 152, 5)
    + mould(126, 240, 16, True, -24) + grip(150, 222, 200)
    + lolly(304, 164, 1.1) + grip(304, 200, 250)
    + arrow('M168 150 C200 100 240 86 272 94'),
]


# ── Help a grown-up bake some cakes ──────────────────────────────────────
def big_bowl(cx=214, cy=150, rx=96, ry=24, mix=True):
    s = (f'<path d="M{cx - rx} {cy} Q{cx - rx + 10} {cy + 92} {cx} {cy + 92} Q{cx + rx - 10} {cy + 92} {cx + rx} {cy}"/>'
         f'<ellipse cx="{cx}" cy="{cy + 90}" rx="{rx * .36:.1f}" ry="5"/>'
         f'<path d="M{cx - rx} {cy} Q{cx - rx + 10} {cy + 92} {cx} {cy + 92} Q{cx + rx - 10} {cy + 92} {cx + rx} {cy}"/>'
         f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}"/>')
    if mix:
        s += (f'<ellipse cx="{cx}" cy="{cy + 6}" rx="{rx - 12}" ry="{ry - 7}" stroke-width="1.6"/>'
              + thin(f'M{cx - 40} {cy + 6} q20 -8 40 0 q20 8 40 -2'))
    return s


def wooden_spoon(x0, y0, x1, y1):
    """A wooden spoon handle from (x0, y0) (in the bowl) up to (x1, y1)."""
    return limb(f'M{x0} {y0} L{x1} {y1}', 10)


def case(cx, cy, full=0, rx=24):
    """A paper cake case seen a little from above, rim centre (cx, cy). full: 0 empty, 1 mixture, 2 baked."""
    ry = rx * .36
    b = rx * .72
    s = f'<path d="M{cx - rx} {cy} L{cx - b:.1f} {cy + 22} Q{cx} {cy + 28} {cx + b:.1f} {cy + 22} L{cx + rx} {cy}"/>'
    s += thin(''.join(f'M{cx + k * rx * .9:.1f} {cy + 3} L{cx + k * b * .9:.1f} {cy + 23} ' for k in (-.6, -.2, .2, .6)))
    s += f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry:.1f}"/>'
    if full == 1:
        s += f'<path d="M{cx - rx + 5} {cy} Q{cx - rx + 6} {cy - 9} {cx} {cy - 10} Q{cx + rx - 6} {cy - 9} {cx + rx - 5} {cy} Z" stroke-width="1.6"/>'
    elif full == 2:
        s += f'<path d="M{cx - rx - 1} {cy + 2} Q{cx - rx} {cy - 22} {cx} {cy - 24} Q{cx + rx} {cy - 22} {cx + rx + 1} {cy + 2} Q{cx} {cy + 8} {cx - rx - 1} {cy + 2} Z"/>'
    return s


def cupcake(cx, cy, rx=24):
    """A baked cake in its case with a swirl of icing, sprinkles and a cherry."""
    s = case(cx, cy, 2, rx)
    s += (f'<path d="M{cx - rx + 2} {cy - 10} Q{cx - rx + 4} {cy - 26} {cx} {cy - 28} Q{cx + rx - 4} {cy - 26} {cx + rx - 2} {cy - 10} '
          f'Q{cx} {cy - 2} {cx - rx + 2} {cy - 10} Z"/>'
          + thin(f'M{cx - rx + 8} {cy - 16} Q{cx} {cy - 10} {cx + rx - 8} {cy - 16}')
          + f'<circle cx="{cx}" cy="{cy - 33}" r="6"/>' + thin(f'M{cx} {cy - 39} q2 -8 8 -10'))
    for dx, dy, a in ((-12, -20, 30), (-2, -22, -40), (8, -18, 60), (14, -14, -20), (-16, -13, 80)):
        s += g('<rect x="-3" y="-1" width="6" height="2" rx="1" fill="' + INK + '" stroke="none"/>', cx + dx, cy + dy, 1, a)
    return s


def cooling_rack(x0, x1, y):
    return (f'<path d="M{x0 + 14} {y - 30} H{x1 - 14} L{x1} {y} H{x0} Z" stroke-width="1.6"/>'
            + thin(''.join(f'M{x0 + 14 + i * (x1 - x0 - 28) / 6:.1f} {y - 30} L{x0 + i * (x1 - x0) / 6:.1f} {y} ' for i in range(1, 6))
                   + f'M{x0 + 7} {y - 15} H{x1 - 7}')
            + f'<path d="M{x0 + 4} {y} v8 M{x1 - 4} {y} v8" fill="none"/>')


def tin_case(cx, cy, rx, fill=0, berries=False):
    """A paper case in the muffin tin, seen from above at a slant. fill: 0 empty, 1 mixture."""
    ry = rx * .55
    s = f'<ellipse cx="{cx:.1f}" cy="{cy:.1f}" rx="{rx:.1f}" ry="{ry:.1f}"/>'
    if not fill:
        s += f'<ellipse cx="{cx:.1f}" cy="{cy + ry * .3:.1f}" rx="{rx * .55:.1f}" ry="{ry * .5:.1f}" fill="none" stroke-width="1.4"/>'
    s += thin(f'M{cx - rx * .8:.1f} {cy - ry * .45:.1f} l{rx * .08:.1f} {ry * .2:.1f} M{cx + rx * .8:.1f} {cy - ry * .45:.1f} l{-rx * .08:.1f} {ry * .2:.1f}') if fill else thin(''.join(f'M{cx + rx * .9 * math.cos(math.radians(a)):.1f} {cy + ry * .9 * math.sin(math.radians(a)):.1f} '
                      f'L{cx + rx * .55 * math.cos(math.radians(a)):.1f} {cy + ry * .3 + ry * .5 * math.sin(math.radians(a)):.1f} '
                      for a in range(0, 360, 45)))
    if fill:
        s += (f'<path d="M{cx - rx * .86:.1f} {cy + ry * .1:.1f} Q{cx - rx * .7:.1f} {cy - ry * .9:.1f} {cx:.1f} {cy - ry * .8:.1f} '
              f'Q{cx + rx * .7:.1f} {cy - ry * .9:.1f} {cx + rx * .86:.1f} {cy + ry * .1:.1f} Q{cx:.1f} {cy + ry * .95:.1f} '
              f'{cx - rx * .86:.1f} {cy + ry * .1:.1f} Z"/>'
              + thin(f'M{cx - rx * .4:.1f} {cy - ry * .2:.1f} q{rx * .3:.1f} {-ry * .3:.1f} {rx * .6:.1f} 0'))
        if berries:
            s += ''.join(f'<circle cx="{cx + rx * fx:.1f}" cy="{cy + ry * fy:.1f}" r="{rx * .12:.1f}" fill="{INK}"/>'
                         for fx, fy in ((-.4, .1), (.35, -.2), (.05, .45)))
    return s


def muffin_tin(cx, cy, w=240, d=104, filled=0, berries=False):
    """A 12-hole muffin tin with paper cases, seen from above at a slant; front edge at cy + d / 2.
    filled: how many cases (back row first, left to right) already have mixture in."""
    top, bot = cy - d / 2, cy + d / 2
    bw = w * .84
    s = (f'<path d="M{cx - bw / 2 + 10} {top} H{cx + bw / 2 - 10} Q{cx + bw / 2} {top} {cx + bw / 2 + 2} {top + 10} '
         f'L{cx + w / 2} {bot - 8} Q{cx + w / 2} {bot} {cx + w / 2 - 10} {bot} H{cx - w / 2 + 10} Q{cx - w / 2} {bot} {cx - w / 2} {bot - 8} '
         f'L{cx - bw / 2 - 2} {top + 10} Q{cx - bw / 2} {top} {cx - bw / 2 + 10} {top} Z"/>'
         f'<path d="M{cx - w / 2} {bot - 4} V{bot + 6} Q{cx - w / 2} {bot + 10} {cx - w / 2 + 8} {bot + 10} H{cx + w / 2 - 8} '
         f'Q{cx + w / 2} {bot + 10} {cx + w / 2} {bot + 6} V{bot - 4}" fill="none"/>')
    n = 0
    for r in range(3):
        f = (r + .5) / 3
        y = top + 4 + (d - 8) * (r + .5) / 3
        rw = bw + (w - bw) * f
        rx = (rw / 4) * .4
        for c in range(4):
            x = cx - rw / 2 + rw * (c + .5) / 4
            s += tin_case(x, y - 2, rx, 1 if n < filled else 0, berries)
            n += 1
    return s


def mixture(cx, cy, rx, ry, lumps=()):
    """A soft mixture inside a big bowl, just below its rim."""
    s = (f'<path d="M{cx - rx} {cy} Q{cx - rx * .6:.1f} {cy - ry * 1.1:.1f} {cx} {cy - ry * .9:.1f} '
         f'Q{cx + rx * .6:.1f} {cy - ry * 1.1:.1f} {cx + rx} {cy} Q{cx} {cy + ry * 1.2:.1f} {cx - rx} {cy} Z" stroke-width="1.8"/>')
    return s + ''.join(lumps)


def shell(x, y, rot, s=1.0):
    """Half an eggshell, its broken edge facing along rot degrees."""
    return g('<path d="M3 -16 A13 16 0 0 0 3 16 L-2 10 L3 5 L-2 0 L3 -5 L-2 -10 Z"/>', x, y, s, rot)


BX, BY = 200, 132  # mixing bowl rim


def batter_spoon(tx, ty, a=-50, L=96, berries=False):
    """A spoon with a dollop of mixture, its bowl at (tx, ty), handle going off at a degrees;
    returns the drawing and where a hand holds it."""
    r = math.radians(a)
    ex, ey = tx + L * math.cos(r), ty + L * math.sin(r)
    sx, sy = tx + 14 * math.cos(r), ty + 14 * math.sin(r)
    s = limb(f'M{sx:.1f} {sy:.1f} L{ex:.1f} {ey:.1f}', 7)
    s += f'<ellipse cx="{tx}" cy="{ty}" rx="16" ry="10" transform="rotate({a} {tx} {ty})"/>'
    s += f'<path d="M{tx - 13} {ty + 2} Q{tx - 6} {ty - 14} {tx + 4} {ty - 12} Q{tx + 12} {ty - 6} {tx + 8} {ty + 4} Z" stroke-width="1.6"/>'
    if berries:
        s += f'<circle cx="{tx - 3}" cy="{ty - 4}" r="3.4" fill="{INK}"/>'
    return s, (ex - 22 * math.cos(r), ey - 22 * math.sin(r))


def stir(bx, by, inside):
    """The big bowl on the ground line, a wooden spoon going round in it."""
    return (ground(by + 100) + big_bowl(bx, by, 110, 26, mix=False) + inside
            + wooden_spoon(bx + 22, by + 6, bx + 88, by - 90) + grip(bx + 76, by - 72, 226)
            + arrow(f'M{bx - 70} {by + 30} C{bx - 36} {by + 50} {bx + 40} {by + 50} {bx + 74} {by + 26}'))


def tin_and_spoon(berries=False):
    """A muffin tin, half its cases filled, and a spoon dropping mixture into the next one."""
    sp, h = batter_spoon(236, 132, -50, 96, berries)
    return (ground(276) + muffin_tin(200, 204, 300, 120, filled=6, berries=berries)
            + sp + grip(*h, 150) + motion('M232 150 v34'))


def on_rack(cake, steam=False):
    """Three big cakes on a cooling rack."""
    s = ground(246, 30, 370) + cooling_rack(40, 360, 238)
    s += ''.join(cake(x, 196, 34) for x in (110, 200, 290))
    if steam:
        s += motion('M110 130 q-8 -10 0 -20 q8 -10 0 -20', 'M290 130 q-8 -10 0 -20 q8 -10 0 -20')
    return s


_fluffy = mixture(BX, BY + 10, 92, 14, [thin(f'M{BX - 48} {BY + 8} q16 -8 32 0 q16 -8 32 0 q16 -8 32 0')])
_smooth = mixture(BX, 160, 92, 12, [thin(f'M{BX - 46} 160 q46 10 92 0')])

D[key('Help a grown-up bake some cakes')] = [
    # 1. beat the butter and sugar until fluffy
    stir(BX, BY, _fluffy),

    # 2. an egg drops into the mixture
    ground(252) + big_bowl(BX, 150, 110, 26, mix=False) + _smooth
    + grip(BX - 30, 56, 10) + shell(BX - 6, 62, 100, 1.6)
    + f'<path d="M{BX} 74 Q{BX - 4} 86 {BX - 14} 98 Q{BX - 20} 114 {BX} 116 Q{BX + 20} 114 {BX + 14} 98 Q{BX + 4} 86 {BX} 74 Z"/>'
    + f'<circle cx="{BX}" cy="105" r="8"/>'
    + motion(f'M{BX - 14} 124 V140', f'M{BX + 14} 124 V140'),

    # 3. spoon the mixture into the 12 cases
    tin_and_spoon(),

    # 4. baked by a grown-up, then decorated on the cooling rack
    on_rack(cupcake)
    + motion('M200 106 v-16', 'M174 114 l-12 -12', 'M226 114 l12 -12'),
]


# ── Make popcorn with a grown-up ─────────────────────────────────────────
def hob(y=210):
    """The cooker top: worktop, a burner ring and the front with knobs (no numbers)."""
    return (f'<path d="M40 {y - 70} H360 L382 {y} H18 Z" stroke-width="1.6"/>'
            f'<rect x="18" y="{y}" width="364" height="40" rx="4"/>'
            + ''.join(f'<circle cx="{120 + i * 40}" cy="{y + 20}" r="8"/>' + thin(f'M{120 + i * 40} {y + 13} v6') for i in range(5)))


def pan(cx=180, cy=118, rx=78, ry=20, inside='', handle=True):
    """A saucepan seen slightly from above, rim centre (cx, cy), long handle to the right."""
    s = ''
    if handle:
        s += limb(f'M{cx + rx - 8} {cy + 14} L{cx + rx + 80} {cy + 4}', 14)
    s += (f'<path d="M{cx - rx} {cy} V{cy + 54} Q{cx - rx} {cy + 70} {cx} {cy + 70} Q{cx + rx} {cy + 70} {cx + rx} {cy + 54} V{cy}"/>'
          f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}"/>'
          f'<ellipse cx="{cx}" cy="{cy + 3}" rx="{rx - 8}" ry="{ry - 5}" fill="none" stroke-width="1.4"/>' + inside)
    return s


def lid(cx, cy, rx=80, ry=20):
    return (f'<path d="M{cx - rx} {cy} Q{cx - rx + 8} {cy - 30} {cx} {cy - 32} Q{cx + rx - 8} {cy - 30} {cx + rx} {cy} '
            f'Q{cx} {cy + ry} {cx - rx} {cy} Z"/>'
            f'<rect x="{cx - 12}" y="{cy - 44}" width="24" height="12" rx="5"/>')


def flames(cx, y, w=60):
    return thin(''.join(f'M{cx + dx - 5} {y} q5 -10 5 -14 q3 6 5 14 ' for dx in range(-w // 2, w // 2 + 1, w // 4)))


def kernel(x, y, a=0):
    return g('<ellipse cx="0" cy="0" rx="3.4" ry="2.4"/>', x, y, 1, a)


def puff(x, y, s=1.0):
    """One piece of popcorn."""
    return g('<circle cx="-5" cy="2" r="6"/><circle cx="5" cy="2" r="6"/><circle cx="0" cy="-5" r="6.5"/>'
             + thin('M-2 0 q2 2 4 0'), x, y, s)


def small_cup(cx, by, w=30, h=28):
    t, b = w / 2, w * .36
    return (f'<path d="M{cx - t} {by - h} L{cx - b} {by} Q{cx} {by + 4} {cx + b} {by} L{cx + t} {by - h}"/>'
            f'<ellipse cx="{cx}" cy="{by - h}" rx="{t}" ry="{w * .14:.1f}"/>')


PCX, PCY = 160, 112

D[key('Make popcorn with a grown-up')] = [
    # a grown-up heats a little oil
    hob(222) + flames(PCX, 190, 64)
    + pan(PCX, PCY, inside=f'<ellipse cx="{PCX}" cy="{PCY + 6}" rx="30" ry="6" stroke-width="1.4"/>')
    + grip(PCX + 150, PCY + 6, 160, grown=True)
    + '<path d="M38 120 V80 Q38 70 46 66 V50 H56 V66 Q64 70 64 80 V120 Q64 126 58 126 H44 Q38 126 38 120 Z"/>'
    + thin('M38 92 H64')
    + motion(f'M{PCX - 30} 76 q-8 -10 0 -20 q8 -10 0 -20', f'M{PCX + 10} 76 q-8 -10 0 -20 q8 -10 0 -20'),

    # kernels in, then the lid on
    hob(222) + flames(PCX, 190, 64)
    + pan(PCX, PCY, inside=''.join(kernel(PCX + dx, PCY + dy, a) for dx, dy, a in
                                   ((-24, 6, 20), (-10, 9, -30), (6, 5, 60), (20, 9, 0), (-2, 13, 40), (30, 4, -50))))
    + grip(PCX + 150, PCY + 6, 160, grown=True)
    + g(small_cup(0, 0, 34, 32), 96, 54, 1, 64) + grip(84, 40, 330)
    + ''.join(kernel(x, y, a) for x, y, a in ((122, 64, 0), (128, 80, 40), (136, 94, -20)))
    + lid(250, 46, 56, 14)
    + arrow('M196 40 C176 52 170 70 176 86'),

    # listen from a safe distance
    ground(276)
    + person(76, 276, 'kid', arms=((-1, (44, 132, 22, 182)), (1, (108, 132, 130, 182))), mouth='open', look=1)
    + '<rect x="170" y="190" width="150" height="86"/>' + '<path d="M162 172 H330 L326 190 H166 Z"/>'
    + ''.join(f'<circle cx="{200 + i * 30}" cy="210" r="6"/>' for i in range(4))
    + pan(226, 136, 36, 9, handle=False)
    + limb('M258 152 L296 148', 9)
    + g(lid(0, 0, 38, 9), 226, 124, 1, -8)
    + puff(204, 112, .8) + puff(250, 104, .8)
    + person(340, 276, 'adult', arms=((-1, (296, 148, 312, 186)), (1, None)), look=-1)
    + motion('M196 94 l-10 -12', 'M226 84 v-16', 'M258 92 l10 -12', 'M178 118 l-14 -4'),

    # into a bowl; let it cool, then share
    worktop(258, 60)
    + '<path d="M106 150 Q114 236 200 236 Q286 236 294 150"/>'
    + '<ellipse cx="200" cy="236" rx="40" ry="6"/>'
    + ''.join(puff(x, y) for x, y in ((128, 146), (150, 136), (176, 130), (204, 126), (230, 130), (254, 136),
                                         (274, 146), (164, 116), (192, 108), (220, 112), (244, 122), (204, 92), (140, 150), (262, 150)))
    + '<path d="M106 150 Q200 172 294 150" fill="none"/>'
    + limb('M20 196 Q50 170 92 158', 15) + '<circle cx="96" cy="156" r="9.3"/>'
    + limb('M380 196 Q350 170 308 158', 15) + '<circle cx="304" cy="156" r="9.3"/>'
    + motion('M170 70 q-8 -10 0 -20 q8 -10 0 -20', 'M230 70 q-8 -10 0 -20 q8 -10 0 -20'),
]


# ── Make a yogurt pot with layers ────────────────────────────────────────
def berry(x, y, r=6):
    return f'<circle cx="{x}" cy="{y}" r="{r}"/>' + dot(x + r * .3, y - r * .3, 1.2)


def crumb(x, y, a=0):
    return g('<path d="M-4 -2 L2 -4 L5 1 L0 4 L-5 2 Z" stroke-width="1.6"/>', x, y, 1, a)


def layered(cx, by, layers, w=96, h=128):
    """A clear tumbler, base centre (cx, by), showing its layers from the bottom up.
    layers: list of (kind, height), kind 'yog', 'fruit' or 'crunch'."""
    t, b = w / 2, w * .36

    def half(y):
        return b + (t - b) * (by - y) / h

    s = f'<path d="M{cx - t} {by - h} L{cx - b} {by} Q{cx} {by + 6} {cx + b} {by} L{cx + t} {by - h}"/>'
    y = by
    for i, (kind, hh) in enumerate(layers):
        top = y - hh
        hw = half(top) - 3
        if kind == 'fruit':
            n = max(2, int(2 * hw // 15))
            for j in range(n):
                x = cx - hw + 8 + j * (2 * hw - 16) / max(1, n - 1)
                s += berry(round(x, 1), round(top + hh / 2 + (2 if j % 2 else -2), 1), min(6, hh / 2 - 1))
        elif kind == 'crunch':
            n = int(2 * hw // 10)
            for j in range(n):
                x = cx - hw + 6 + j * (2 * hw - 12) / max(1, n - 1)
                s += crumb(round(x, 1), round(top + hh / 2 + (3 if j % 2 else -2), 1), j * 50)
        if i < len(layers) - 1 or kind == 'yog':
            s += thin(f'M{cx - hw:.1f} {top:.1f} Q{cx} {top + 4:.1f} {cx + hw:.1f} {top:.1f}')
        y = top
    s += f'<ellipse cx="{cx}" cy="{by - h}" rx="{t}" ry="{w * .12:.1f}"/>'
    return s


def spoon(tx, ty, a=-50, L=96, full=''):
    """A teaspoon whose bowl is at (tx, ty), its handle going off at a degrees."""
    r = math.radians(a)
    ex, ey = tx + L * math.cos(r), ty + L * math.sin(r)
    sx, sy = tx + 14 * math.cos(r), ty + 14 * math.sin(r)
    s = limb(f'M{sx:.1f} {sy:.1f} L{ex:.1f} {ey:.1f}', 7)
    s += f'<ellipse cx="{tx}" cy="{ty}" rx="16" ry="10" transform="rotate({a} {tx} {ty})"/>'
    if full == 'yog':
        s += f'<path d="M{tx - 12} {ty + 2} Q{tx - 4} {ty - 12} {tx + 10} {ty - 6} Q{tx + 6} {ty + 6} {tx - 12} {ty + 2} Z" stroke-width="1.6"/>'
    return s, (ex - 22 * math.cos(r), ey - 22 * math.sin(r))


def tub(cx, by, w=60, h=46):
    return (f'<path d="M{cx - w / 2} {by - h} L{cx - w / 2 + 6} {by} H{cx + w / 2 - 6} L{cx + w / 2} {by - h}"/>'
            f'<ellipse cx="{cx}" cy="{by - h}" rx="{w / 2}" ry="7"/>'
            f'<ellipse cx="{cx}" cy="{by - h + 2}" rx="{w / 2 - 6}" ry="4" stroke-width="1.4" fill="none"/>')


def dish(cx, by, w=70, inside=''):
    return (f'<path d="M{cx - w / 2} {by - 18} Q{cx - w / 2 + 4} {by} {cx} {by} Q{cx + w / 2 - 4} {by} {cx + w / 2} {by - 18}"/>'
            + inside + f'<path d="M{cx - w / 2} {by - 18} Q{cx} {by - 8} {cx + w / 2} {by - 18}" fill="none"/>')


YX, YB = 200, 240

_sp1, _h1 = spoon(190, 100, -22, 96, 'yog')
_berries = ''.join(berry(x, y, 6) for x, y in ((302, 196), (318, 192), (334, 197), (310, 184), (326, 182)))
_bits = ''.join(crumb(x, y, i * 40) for i, (x, y) in enumerate(((300, 196), (314, 192), (330, 198), (320, 184), (306, 186), (338, 188))))


def bust(cx, cy, r=34, mouth='grin', look=0):
    """A child's head and shoulders."""
    return (f'<path d="M{cx - r * 1.4:.1f} {cy + r * 2.3:.1f} V{cy + r * 1.5:.1f} Q{cx - r * 1.4:.1f} {cy + r * .95:.1f} {cx - r * .6:.1f} {cy + r * .95:.1f} '
            f'H{cx + r * .6:.1f} Q{cx + r * 1.4:.1f} {cy + r * .95:.1f} {cx + r * 1.4:.1f} {cy + r * 1.5:.1f} V{cy + r * 2.3:.1f}"/>'
            + head(cx, cy, r, mouth, look=look))


D[key('Make a yogurt pot with layers')] = [
    worktop(256, 50)
    + layered(YX, YB, [('yog', 30)]) + thin(f'M{YX - 20} {YB - 14} q6 -5 12 0 M{YX + 6} {YB - 18} q6 -5 12 0')
    + tub(320, 236)
    + _sp1 + grip(*_h1, 150)
    + arrow('M178 116 C174 128 178 140 186 150'),

    worktop(256, 50)
    + layered(YX, YB, [('yog', 34), ('fruit', 14)])
    + dish(320, 216, 74, _berries)
    + berry(204, 90, 6) + berry(198, 120, 6)
    + grip(212, 60, 250)
    + arrow('M244 76 C256 100 252 124 238 144'),

    worktop(256, 50)
    + layered(YX, YB, [('yog', 34), ('fruit', 14), ('crunch', 12)])
    + dish(320, 216, 74, _bits)
    + grip(204, 56, 250)
    + motion('M192 80 v56', 'M210 82 v58')
    + crumb(198, 90, 20) + crumb(204, 112, 70) + crumb(200, 134, 10),

    worktop(256, 50)
    + layered(150, YB, [('yog', 26), ('fruit', 14), ('crunch', 12), ('yog', 24), ('fruit', 14), ('crunch', 12)], 100, 136)
    + spoon(160, 98, -70, 100)[0]
    + bust(300, 126, 34, 'grin', -1)
    + arrow('M214 82 C236 60 254 64 264 80', dashed=True),
]


# ── Wash and dry the vegetables for tea ──────────────────────────────────
def carrot(x, y, a=0, s=1.0):
    """A carrot with its top at (x, y), pointing off at a degrees."""
    b = ('<path d="M0 -9 Q50 -6 74 0 Q50 6 0 9 Q-4 0 0 -9 Z"/>'
         + thin('M16 -6 l3 4 M34 4 l3 -4 M52 -3 l3 3')
         + '<path d="M-2 -4 Q-14 -16 -20 -14 Q-12 -6 -2 -2 M-2 0 Q-18 0 -22 6 Q-10 8 -2 3" stroke-width="1.8"/>')
    return g(b, x, y, s, a)


def potato(x, y, s=1.0, a=0):
    return g('<path d="M-20 -4 Q-18 -16 -2 -15 Q16 -16 20 -4 Q22 10 4 13 Q-16 14 -20 -4 Z"/>'
             + dot(-8, -4, 1.6) + dot(8, 2, 1.6) + dot(2, -8, 1.4), x, y, s, a)


def colander(cx=200, cy=150, rx=96, ry=24, inside=''):
    holes = ''.join(dot(cx + dx, cy + dy, 2) for dx, dy in
                    ((-60, 30), (-36, 40), (-12, 44), (12, 44), (36, 40), (60, 30), (-48, 56), (-20, 62), (8, 63), (36, 58)))
    return (f'<path d="M{cx - rx - 22} {cy + 2} h22 M{cx + rx} {cy + 2} h22" fill="none" stroke-width="7"/>'
            f'<path d="M{cx - rx} {cy} Q{cx - rx + 12} {cy + 84} {cx} {cy + 84} Q{cx + rx - 12} {cy + 84} {cx + rx} {cy}"/>'
            f'<path d="M{cx - 34} {cy + 82} L{cx - 40} {cy + 96} H{cx + 40} L{cx + 34} {cy + 82}"/>'
            + holes + f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}"/>' + inside
            + f'<path d="M{cx - rx} {cy} Q{cx} {cy + ry * 2.1} {cx + rx} {cy}" fill="none"/>')


def towel(x0, y0, x1, y1, d=30):
    """A tea towel lying flat on the worktop, stripes near each end."""
    return (f'<path d="M{x0 + d} {y0} H{x1 - d} L{x1} {y1} H{x0} Z"/>'
            + thin(f'M{x0 + d * .8 + 14} {y0} L{x0 + 14} {y1} M{x0 + d * .8 + 24} {y0} L{x0 + 24} {y1} '
                   f'M{x1 - d * .8 - 14} {y0} L{x1 - 14} {y1} M{x1 - d * .8 - 24} {y0} L{x1 - 24} {y1}'))


D[key('Wash and dry the vegetables for tea')] = [
    kid_at_sink(),

    worktop(264, 60)
    + colander(214, 140, 96, 24,
               potato(176, 140, .9, -10) + potato(244, 142, .9, 15) + carrot(196, 130, 10, .8) + potato(212, 150, .9))
    + potato(50, 232, .9) + potato(86, 240, .9, 20) + carrot(310, 236, -170, .9)
    + carrot(100, 84, 30, .9) + grip(86, 76, 340)
    + arrow('M130 70 C160 58 180 74 186 96'),

    sink(30, 190, 340, 84)
    + tap(184, 60)
    + water(182, 66, 138, 5)
    + carrot(112, 150, 0, 1.5)
    + grip(108, 150, 0)
    + grip(222, 152, 170, flip=True)
    + motion('M214 112 q10 -8 20 0', 'M230 104 q12 -8 24 0')
    + dot(170, 176, 1.8) + dot(186, 184, 1.6) + dot(202, 174, 1.6),

    worktop(262, 66)
    + towel(64, 192, 336, 252)
    + carrot(84, 234, -4, .9) + carrot(152, 220, 0, 1.3) + potato(300, 228)
    + '<path d="M170 200 Q205 194 238 200 L246 236 Q206 244 164 236 Z"/>' + thin('M184 199 L180 238 M195 198 L192 240')
    + mitt(188, 176, 1.1, 80)
    + motion('M160 128 l-10 -8', 'M196 112 v-14', 'M232 126 l10 -8'),
]


# ── Make a picnic for your toys ──────────────────────────────────────────
def picnic_blanket(x0=86, x1=314, y0=150, y1=250, d=40, n=6, m=3):
    s = f'<path d="M{x0} {y0} H{x1} L{x1 + d} {y1} H{x0 - d} Z"/>'
    lines = ''
    for i in range(1, n):
        f = i / n
        lines += f'M{x0 + (x1 - x0) * f:.1f} {y0} L{x0 - d + (x1 - x0 + 2 * d) * f:.1f} {y1} '
    for j in range(1, m):
        f = j / m
        y = y0 + (y1 - y0) * f
        lines += f'M{x0 - d * f:.1f} {y:.1f} H{x1 + d * f:.1f} '
    return s + thin(lines)


def bear(cx, by, s=1.0, wave=False):
    """A sitting teddy with its legs out in front, seen from the front; bottom at by."""
    arm_r = ('<path d="M12 -34 Q26 -46 28 -58" fill="none" stroke-width="9"/><path d="M12 -34 Q26 -46 28 -58" fill="none" '
             'stroke="#fff" stroke-width="4.2"/><circle cx="28" cy="-60" r="5"/>') if wave else \
        '<ellipse cx="17" cy="-22" rx="6" ry="11" transform="rotate(-18 17 -22)"/>'
    b = ('<circle cx="-12" cy="-64" r="6"/><circle cx="12" cy="-64" r="6"/>'
         '<ellipse cx="-17" cy="-22" rx="6" ry="11" transform="rotate(18 -17 -22)"/>'
         + ('' if wave else '') +
         '<ellipse cx="0" cy="-22" rx="16" ry="18"/>' + arm_r
         + '<ellipse cx="-10" cy="-4" rx="8" ry="6"/><ellipse cx="10" cy="-4" rx="8" ry="6"/>'
         '<circle cx="0" cy="-54" r="14"/><ellipse cx="0" cy="-50" rx="6" ry="4.5"/>'
         + dot(-5, -58, 1.8) + dot(5, -58, 1.8) + dot(0, -51, 1.6))
    return g(b, cx, by, s)


def toy_plate(x, y, rx=16, ry=6):
    return f'<ellipse cx="{x}" cy="{y}" rx="{rx}" ry="{ry}"/><ellipse cx="{x}" cy="{y}" rx="{rx * .6:.1f}" ry="{ry * .55:.1f}" fill="none" stroke-width="1.4"/>'


def toy_cup(x, by, s=1.0):
    return g('<path d="M6 -10 q7 0 7 5 q0 5 -7 5" fill="none" stroke-width="1.8"/>'
             '<path d="M-7 -14 H7 L6 0 H-6 Z"/><ellipse cx="0" cy="-14" rx="7" ry="2"/>', x, by, s)


def cracker(x, y, s=1.0, a=0):
    return g('<rect x="-9" y="-9" width="18" height="18" rx="2"/>'
             + dot(-4, -4, 1.3) + dot(4, -4, 1.3) + dot(-4, 4, 1.3) + dot(4, 4, 1.3), x, y, s, a)


def room():
    """Bedroom floor meeting the wall, with a skirting board."""
    return thin('M18 104 H382') + thin('M18 96 H382')


SEATS = [(130, 160, .9), (270, 160, .9), (58, 248, 1.0), (342, 248, 1.0)]
PLATES = [(130, 172), (270, 172), (88, 240), (312, 240)]

D[key('Make a picnic for your toys')] = [
    room()
    + picnic_blanket(110, 290, 150, 236, 40)
    + ghost('M110 150 Q160 120 200 126 Q250 120 290 150')
    + ghost('M70 236 Q120 196 200 200 Q280 196 330 236')
    + arrow('M200 92 C200 112 200 124 200 140'),

    room()
    + picnic_blanket()
    + bear(130, 160, .9) + bear(270, 160, .9) + bear(58, 248)
    + bear(318, 186, .9) + grip(329, 126, 90)
    + arrow('M286 150 C286 186 306 214 324 226'),

    room()
    + picnic_blanket()
    + bear(130, 160, .9) + bear(270, 160, .9) + bear(58, 248) + bear(342, 248)
    + toy_plate(152, 176) + toy_cup(110, 182)
    + toy_plate(250, 176) + toy_cup(292, 182)
    + toy_plate(98, 230) + toy_cup(118, 222)
    + toy_plate(302, 230) + toy_cup(200, 120, 1.2)
    + grip(206, 112, 250)
    + arrow('M230 128 C262 150 278 186 282 210'),

    room()
    + picnic_blanket(150, 330, 150, 236, 40)
    + bear(196, 160, .9) + bear(290, 160, .9) + bear(352, 236)
    + toy_plate(216, 176) + toy_plate(270, 176) + toy_plate(318, 222)
    + '<ellipse cx="244" cy="210" rx="34" ry="12"/>'
    + cracker(232, 204, .8, 10) + cracker(252, 206, .8, -12) + cracker(242, 196, .8, 30)
    + person(70, 280, 'small', legs='sit_r', arms=((-1, None), (1, (150, 200, 120, 222))), mouth='grin', look=1)
    + cracker(156, 192, .9, 10)
    + arrow('M150 170 C162 148 180 146 190 152', dashed=True),
]


# ── Make toast with a grown-up, with a funny topping ────────────────────
def toaster(cx=200, by=244, w=176, h=100, up=0):
    """A toaster seen from the front and a little above; up = how far the toast pops out."""
    x0, x1, top = cx - w / 2, cx + w / 2, by - h
    s = ''
    for sx in (cx - 34, cx + 34):
        if up:
            s += bread(sx, top + 26 - up, 60, 64)
    s += (f'<path d="M{x0} {by} V{top + 26} Q{x0} {top} {x0 + 26} {top} H{x1 - 26} Q{x1} {top} {x1} {top + 26} V{by} Z"/>'
          + f'<path d="M{x0 + 6} {by} v8 M{x1 - 6} {by} v8" fill="none" stroke-width="5"/>')
    for sx in (cx - 34, cx + 34):
        s += f'<rect x="{sx - 34}" y="{top + 6}" width="68" height="9" rx="4.5" fill="{INK}"/>'
        if up:
            s += bread(sx, top + 26 - up, 60, 64, clip=top + 10)
    s += (f'<rect x="{x1}" y="{top + 30}" width="16" height="12" rx="3"/>'
          + thin(f'M{x1 - 6} {top + 28} V{by - 10}')
          + f'<circle cx="{x0 + 30}" cy="{by - 30}" r="9"/>' + thin(f'M{x0 + 30} {by - 38} v6'))
    return s


def bread(cx, by, w=64, h=68, clip=None, toasted=False):
    """A slice of bread, face on: square bottom at by, rounded double top."""
    hw = w / 2
    d = (f'M{cx - hw + 4} {by} V{by - h + 22} Q{cx - hw - 6} {by - h + 4} {cx - hw + 8} {by - h} '
         f'Q{cx} {by - h - 6} {cx + hw - 8} {by - h} Q{cx + hw + 6} {by - h + 4} {cx + hw - 4} {by - h + 22} V{by}')
    if clip is not None:  # only the part sticking out above the slot
        return ''
    s = f'<path d="{d} Z"/>'
    s += f'<path d="{d}" fill="none" stroke-width="1.4" transform="translate({cx} {by - h / 2}) scale(.84) translate({-cx} {-by + h / 2})"/>'
    return s


def blunt_knife(tx, ty, a=-20, L=110):
    """A round-ended table knife, blade end at (tx, ty), handle at a degrees."""
    r = math.radians(a)
    b = ('<path d="M0 -6 Q-8 -6 -8 0 Q-8 6 0 6 H44 V-6 Z"/>'
         '<rect x="44" y="-5" width="60" height="10" rx="5"/>')
    return g(b, tx, ty, 1, a), (tx + 82 * math.cos(r), ty + 82 * math.sin(r))


def jar(cx, by, w=46, h=52):
    return (f'<rect x="{cx - w / 2}" y="{by - h}" width="{w}" height="{h}" rx="8"/>'
            f'<rect x="{cx - w / 2 - 2}" y="{by - h - 12}" width="{w + 4}" height="14" rx="3"/>'
            + thin(f'M{cx - w / 2 + 8} {by - h + 14} V{by - 10}'))


def plate(cx, cy, rx=110, ry=30):
    return (f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}"/>'
            f'<ellipse cx="{cx}" cy="{cy}" rx="{rx * .78:.1f}" ry="{ry * .72:.1f}" fill="none" stroke-width="1.4"/>')


def toast_flat(cx, cy, w=150, h=96):
    """A slice of toast lying on a plate, seen from above at a slant."""
    hw = w / 2
    return (f'<path d="M{cx - hw + 10} {cy + h / 2} L{cx - hw + 18} {cy - h / 2 + 22} Q{cx - hw + 4} {cy - h / 2 + 2} {cx - hw + 30} {cy - h / 2} '
            f'Q{cx} {cy - h / 2 - 6} {cx + hw - 30} {cy - h / 2} Q{cx + hw - 4} {cy - h / 2 + 2} {cx + hw - 18} {cy - h / 2 + 22} '
            f'L{cx + hw - 10} {cy + h / 2} Z"/>')


TX, TB = 196, 250
_knife, _knife_at = blunt_knife(196, 196, -34)

D[key('Make toast with a grown-up, with a funny topping')] = [
    # bread in, with a grown-up
    worktop(262, 50) + toaster(TX - 10, TB)
    + bread(TX - 44, 112, 60, 64) + grip(TX - 74, 70, 330)
    + grip(TX + 92, TB - 66, 200, grown=True)
    + arrow(f'M{TX - 4} 70 V128'),

    # pop! then let it cool a little
    worktop(262, 50)
    + bread(116, 176, 56, 62) + bread(184, 170, 56, 62) + toaster(150, TB, 160, 96)
    + grip(112, 222, 0, grown=True, flip=True)
    + motion('M94 102 l-10 -10', 'M150 86 v-16', 'M206 96 l10 -10')
    + plate(320, 232, 56, 14) + toast_flat(320, 222, 92, 34)
    + motion('M306 192 q-6 -8 0 -16 q6 -8 0 -16', 'M334 192 q-6 -8 0 -16 q6 -8 0 -16'),

    # spread it
    worktop(262, 60) + plate(184, 214, 120, 32)
    + toast_flat(184, 206, 156, 70)
    + '<path d="M126 220 Q120 196 140 184 Q190 176 230 186 Q252 200 240 222 Q184 230 126 220 Z" stroke-width="1.6"/>'
    + thin('M146 206 q20 -10 40 0 t40 -4')
    + jar(344, 206)
    + _knife + grip(*_knife_at, 160)
    + arrow('M110 160 C130 148 170 148 190 158')
    + arrow('M190 166 C170 176 130 176 112 168'),

    # a funny face
    worktop(266, 60) + plate(200, 210, 150, 46)
    + toast_flat(200, 196, 210, 116)
    + '<circle cx="168" cy="178" r="9" fill="' + INK + '"/><circle cx="232" cy="178" r="9" fill="' + INK + '"/>'
    + '<path d="M146 204 Q200 250 254 204 Q258 214 252 220 Q200 260 148 220 Q142 214 146 204 Z"/>'
    + thin('M160 216 l4 -4 M200 234 v-6 M240 216 l-4 -4')
    + '<ellipse cx="200" cy="198" rx="8" ry="6"/>' + dot(200, 198, 2)
    + motion('M92 124 l-12 -10', 'M84 160 h-16', 'M308 124 l12 -10', 'M316 160 h16'),
]
