"""Diagrams for the last Outdoors challenges (fairy garden, shape walk, water the
plants, animal tracks, race a grown-up, smooth and rough). People are the simple
round-headed figures from kind_2; the green accent is only for arrows and dashed
motion lines showing what moves, where to look, or a sound."""
import math
import re

from style import INK, arrow, dot, ghost, ground, motion, thin
from craft_3 import dog, grip
from kind import crayon_held, flower, g, sparkle
from kind_2 import SIZES, fist, hands, head, limb, person, qmark, think, top_of

D = {}


def key(title):
    return re.sub(r'[^a-z0-9]+', '_', title.lower()).strip('_')[:48]


def rot_pt(x, y, lx, ly, s=1.0, rot=0):
    """Where local point (lx, ly) of a g(body, x, y, s, rot) group lands."""
    r = math.radians(rot)
    return (round(x + s * (lx * math.cos(r) - ly * math.sin(r)), 1),
            round(y + s * (lx * math.sin(r) + ly * math.cos(r)), 1))


def ink_hand(x, y, kind='kid'):
    return hands((x, y), kind=kind)


# ── Garden things ────────────────────────────────────────────────────────
def pot(cx, ty, rx, ry, h, soil=True, rim=14):
    """A flower pot seen slightly from above; rim top centred at (cx, ty). Returns (svg, floor y)."""
    bx = rx * .74
    by = ty + h
    s = (f'<path d="M{cx - rx * .96:.1f} {ty + rim} L{cx - bx:.1f} {by} Q{cx} {by + ry * .55:.1f} {cx + bx:.1f} {by} '
         f'L{cx + rx * .96:.1f} {ty + rim} Z"/>'
         f'<path d="M{cx - rx} {ty} V{ty + rim} A{rx} {ry} 0 0 0 {cx + rx} {ty + rim} V{ty} Z"/>'
         f'<ellipse cx="{cx}" cy="{ty}" rx="{rx}" ry="{ry}"/>')
    if soil:
        sr, sy = rx - 9, ry - 6
        s += f'<ellipse cx="{cx}" cy="{ty + 2}" rx="{sr}" ry="{sy}" stroke-width="1.8"/>'
        for i in range(int(rx / 9)):
            a = i * 2.39996
            f = math.sqrt((i + .5) / (rx / 9))
            s += dot(cx + sr * .86 * f * math.cos(a), ty + 2 + sy * .8 * f * math.sin(a), 1.5)
    return s, round(by + ry * .27, 1)


def pebble(x, y, rx=8, ry=5, rot=0, shine=False):
    s = f'<ellipse cx="{x}" cy="{y}" rx="{rx}" ry="{ry}" transform="rotate({rot} {x} {y})"/>'
    if shine:
        s += thin(f'M{x - rx * .5:.1f} {y - ry * .35:.1f} q{rx * .3:.1f} {-ry * .4:.1f} {rx * .65:.1f} {-ry * .35:.1f}')
    return s


def pebble_path(n, p0, p1, p2, k=1.0):
    """n pebbles along a curve from p0 (front) through p1 to p2 (back), getting smaller."""
    s = ''
    for i in range(n):
        t = i / 9
        x = (1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0]
        y = (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]
        sc = (1 - t * .45) * k
        s += pebble(round(x + (4 if i % 2 else -4), 1), round(y, 1), round(9 * sc, 1), round(5.5 * sc, 1), (i * 23) % 40 - 20)
    return s


def twig_door(x, by, w=40, h=66, rot=0):
    """A little arched door made of upright twigs, standing on (x, by)."""
    r = w / 2
    b = (f'<path d="M{-r} 0 V{-h + r} A{r} {r} 0 0 1 {r} {-h + r} V0 Z"/>'
         + thin(f'M{-r / 2} -2 V{-h + r * .36:.1f} M0 -2 V{-h + 2} M{r / 2} -2 V{-h + r * .36:.1f}')
         + thin(f'M{-r - 4} {-h * .3:.1f} H{r + 4}')
         + thin(f'M{-r * .75:.1f} {-h * .66:.1f} l-8 -6 M{r * .75:.1f} {-h * .5:.1f} l8 -7')
         + dot(r * .7, -h * .45, 2.6))
    return g(b, x, by, 1, rot)


def moss(x, y, w=40, h=14):
    n = 5
    d = f'M{x - w / 2} {y}'
    for i in range(n):
        d += f' a{w / n / 2:.1f} {h * (.8 + .2 * (i % 2)):.1f} 0 0 1 {w / n:.1f} 0'
    return f'<path d="{d} Z"/>' + dot(x - w * .2, y - h * .4, 1.4) + dot(x + w * .15, y - h * .5, 1.4) + dot(x, y - h * .2, 1.4)


def petal_flower(x, y, r=7):
    return flower(x, y, r, 0, 1.6)


def tree(x, by, s=1.0):
    return g('<path d="M-9 0 V-70 M9 0 V-70" fill="none"/><rect x="-9" y="-74" width="18" height="74" rx="3"/>'
             + thin('M-2 -14 q3 -8 0 -16 M3 -40 q-3 -8 0 -16')
             + '<path d="M0 -150 C30 -150 44 -128 38 -112 C52 -100 40 -72 16 -78 C2 -66 -30 -70 -34 -88 '
               'C-52 -96 -46 -128 -26 -128 C-22 -142 -12 -150 0 -150 Z"/>', x, by, s)


def bush(x, by, w=60, h=34):
    return (f'<path d="M{x - w / 2} {by} C{x - w / 2 - 6} {by - h * .7} {x - w * .2} {by - h * 1.1} {x} {by - h * .8} '
            f'C{x + w * .2} {by - h * 1.2} {x + w / 2 + 6} {by - h * .7} {x + w / 2} {by} Z"/>')


def fence(x0, x1, by, h=60):
    s = ''
    x = x0
    while x <= x1 - 18:
        s += f'<path d="M{x} {by} V{by - h + 8} L{x + 9} {by - h} L{x + 18} {by - h + 8} V{by} Z" stroke-width="2"/>'
        x += 24
    return (f'<rect x="{x0 - 6}" y="{by - h * .75:.1f}" width="{x - x0 + 6}" height="8" rx="2" stroke-width="2"/>'
            f'<rect x="{x0 - 6}" y="{by - h * .32:.1f}" width="{x - x0 + 6}" height="8" rx="2" stroke-width="2"/>' + s)


def grass(x, y):
    return thin(f'M{x - 6} {y} l2 -9 M{x} {y} v-12 M{x + 6} {y} l-2 -9')


# ── Make a fairy garden ──────────────────────────────────────────────────
FP = dict(cx=200, ty=152, rx=150, ry=50, h=94)
PATH = [(118, 186, 13), (150, 182, 12.5), (180, 176, 12), (204, 166, 11), (214, 154, 10.5),
        (228, 144, 10), (246, 136, 9)]


def _fairy_pot():
    return pot(**FP)[0]


def _path(n=len(PATH)):
    return ''.join(pebble(x, y, r, r * .62, (i * 29) % 40 - 20) for i, (x, y, r) in enumerate(PATH[:n]))


_door = twig_door(270, 132, 44, 74, 4)

D[key('Make a fairy garden')] = [
    # find a corner or a pot
    ground(262)
    + person(96, 262, 'kid', arms=((-1, None), (1, (156, 168, 150, 196))), look=1, mouth='grin')
    + pot(280, 180, 76, 24, 76)[0]
    + grass(206, 262) + grass(366, 262) + grass(338, 262)
    + arrow('M172 160 C196 130 230 128 254 146', dashed=True),

    # a pebble path across the soil
    _fairy_pot() + _path(5)
    + ghost('M228 144 m-10 0 a10 6.2 0 1 0 20 0 a10 6.2 0 1 0 -20 0')
    + fist(300, 70, 1, (80, -80)) + pebble(300, 90, 12, 7.5)
    + arrow('M282 104 C262 112 250 124 242 134'),

    # a little twig door
    _fairy_pot() + _path()
    + ghost('M248 132 V80 A22 22 0 0 1 292 80 V132')
    + twig_door(326, 116, 40, 66, 10)
    + fist(358, 92, 1, (36, -100))
    + arrow('M318 46 C306 30 286 34 276 52'),

    # moss, petals and something sparkly
    _fairy_pot() + _path() + _door
    + moss(96, 158, 50, 15) + moss(320, 164, 44, 13) + moss(250, 186, 34, 11)
    + petal_flower(110, 132) + petal_flower(200, 126, 6) + petal_flower(162, 154, 6) + petal_flower(318, 136, 6)
    + '<polygon points="290,178 298,170 306,178 298,186"/>'
    + sparkle(304, 78, 11) + sparkle(298, 178, 14),
]


# ── Go on a shape walk ───────────────────────────────────────────────────
def pavement():
    s = '<path d="M20 200 H380" fill="none" stroke-width="1.6"/>'
    s += thin('M20 230 H380 M20 270 H380')
    for x in (80, 160, 240, 320):
        s += thin(f'M{x} 200 L{200 + (x - 200) * 1.3:.1f} 292')
    return s


def drain(cx, cy, rx=60, ry=26):
    s = f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}"/>'
    s += f'<ellipse cx="{cx}" cy="{cy}" rx="{rx - 8}" ry="{ry - 4}" fill="none" stroke-width="1.6"/>'
    for i in range(-3, 4):
        x = cx + i * rx * .2
        half = (ry - 6) * math.sqrt(max(0, 1 - (i * rx * .2 / (rx - 10)) ** 2))
        s += thin(f'M{x:.1f} {cy - half:.1f} V{cy + half:.1f}')
    return s


def window(x, y, w):
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{w}"/>'
            + thin(f'M{x + w / 2} {y} V{y + w} M{x} {y + w / 2} H{x + w}')
            + f'<rect x="{x - 6}" y="{y + w}" width="{w + 12}" height="7" rx="2"/>')


def house_front(x, by, w, h, roof=0, win=50, door=True):
    """A house front, ground at by. roof = roof height (0 for a flat top)."""
    s = ''
    if roof:
        s += f'<path d="M{x - 14} {by - h} L{x + w / 2} {by - h - roof} L{x + w + 14} {by - h} Z"/>'
    s += f'<rect x="{x}" y="{by - h}" width="{w}" height="{h}"/>'
    if door:
        s += (f'<rect x="{x + w * .6:.1f}" y="{by - h * .52:.1f}" width="{w * .26:.1f}" height="{h * .52:.1f}" rx="2"/>'
              + dot(x + w * .81, by - h * .27, 2.6))
    if win:
        s += window(x + w * .12, by - h * .8, win)
    return s


_pointer = dict(arms=((-1, None), (1, (164, 128, 142, 166))), look=1, mouth='open')

D[key('Go on a shape walk: find a circle, square and triangle')] = [
    pavement()
    + drain(262, 246, 66, 24)
    + person(92, 262, 'kid', arms=((-1, None), (1, (150, 188, 140, 196))), look=1, mouth='open')
    + bush(330, 200, 70, 40) + bush(250, 200, 50, 28)
    + motion('M262 212 C316 212 340 228 340 246 C340 266 300 280 262 280 C222 280 184 266 184 246 C184 228 214 212 262 212')
    + arrow('M164 186 C186 176 204 194 206 218', dashed=True),

    ground(262)
    + house_front(196, 262, 168, 200, 0, 66)
    + person(92, 262, 'kid', **_pointer)
    + motion('M204 90 H294 V182 H204 Z')
    + arrow('M168 118 C178 104 188 102 198 104', dashed=True),

    ground(262)
    + house_front(206, 262, 150, 120, 104, 0)
    + window(224, 168, 30)
    + person(92, 262, 'kid', arms=((-1, None), (1, (160, 116, 140, 160))), look=1, mouth='open')
    + motion('M180 136 L281 30 L382 136 Z')
    + arrow('M172 104 C186 84 200 78 214 80', dashed=True),

    ground(270)
    + '<path d="M20 196 H380" fill="none" stroke-width="1.6"/>'
    + house_front(250, 196, 54, 58, 38, 22, False) + house_front(326, 196, 54, 58, 38, 22, False)
    + '<path d="M222 270 V176" fill="none" stroke-width="4"/>'
    + '<circle cx="222" cy="162" r="16"/><circle cx="222" cy="162" r="11" fill="none" stroke-width="1.6"/>'
    + person(66, 270, 'adult', look=1, legs='walk', arms=((-1, None), (1, (118, 214, 110, 204))))
    + person(158, 270, 'kid', look=1, legs='walk', arms=((-1, (118, 214, 126, 210)), (1, (196, 140, 196, 180))), mouth='grin')
    + ink_hand(118, 214)
    + arrow('M200 126 C236 90 280 84 310 110', dashed=True),
]


# ── Water the plants ─────────────────────────────────────────────────────
def can(x, by, s=1.0, rot=0):
    """A watering can, base centre at (x, by), spout to the right."""
    b = ('<path d="M26 -20 L80 -70 L88 -62 L32 -8 Z"/>'
         '<ellipse cx="86" cy="-68" rx="7" ry="12" transform="rotate(-45 86 -68)"/>'
         '<path d="M-30 -58 Q-24 -96 4 -96 Q28 -96 30 -60" fill="none" stroke-width="12"/>'
         '<path d="M-30 -58 Q-24 -96 4 -96 Q28 -96 30 -60" fill="none" stroke="#fff" stroke-width="7.2"/>'
         '<path d="M-36 -60 H36 L32 0 H-32 Z"/>'
         '<ellipse cx="-14" cy="-60" rx="14" ry="4" stroke-width="1.8"/>'
         + thin('M-34 -46 H35'))
    return g(b, x, by, s, rot)


HANDLE = (0, -96)
SPOUT = (92, -72)


def garden_tap(x, y):
    """A garden tap on a brick wall; the spout mouth at (x, y)."""
    wall = '<rect x="20" y="20" width="96" height="240"/>'
    for i, yy in enumerate(range(44, 260, 24)):
        wall += thin(f'M20 {yy} H116')
        off = 0 if i % 2 else 24
        wall += ''.join(thin(f'M{xx} {yy - 24} V{yy}') for xx in range(44 + off, 116, 48))
    return (wall
            + f'<path d="M116 {y - 30} H{x - 6} Q{x + 8} {y - 30} {x + 8} {y - 16} V{y} H{x - 8} V{y - 12} '
              f'Q{x - 8} {y - 16} {x - 12} {y - 16} H116 Z"/>'
            + f'<rect x="{x - 30}" y="{y - 40}" width="8" height="10"/>'
            + f'<rect x="{x - 46}" y="{y - 46}" width="40" height="8" rx="4"/>')


def plant(x, by, s=1.0):
    return g('<path d="M0 0 V-56" fill="none"/>'
             '<path d="M0 -20 C-10 -30 -30 -30 -36 -22 C-28 -12 -10 -12 0 -20 Z"/>'
             '<path d="M0 -36 C10 -46 30 -46 36 -38 C28 -28 10 -28 0 -36 Z"/>'
             '<path d="M0 -54 C-6 -66 -20 -70 -26 -64 C-20 -54 -8 -52 0 -54 Z"/>' + flower(4, -66, 7, 0, 1.6), x, by, s)


def shelf():
    return ('<rect x="40" y="168" width="250" height="14" rx="3"/>'
            '<path d="M56 182 V272 M274 182 V272" fill="none" stroke-width="7"/>'
            '<path d="M56 182 V272 M274 182 V272" fill="none" stroke="#fff" stroke-width="2.6"/>'
            '<rect x="40" y="222" width="250" height="10" rx="3"/>'
            + ground(274))


_cx2, _cb2, _cs2, _cr2 = 186, 214, .78, 28
_hx2, _hy2 = rot_pt(_cx2, _cb2, *HANDLE, _cs2, _cr2)
_sx2, _sy2 = rot_pt(_cx2, _cb2, *SPOUT, _cs2, _cr2)
_pot2, _floor2 = pot(300, 236, 40, 12, 36)

def finger(tx, ty, sx, sy, cx, cy, kind='kid'):
    """An arm from (sx, sy) bending through (cx, cy) to a hand whose pointing finger touches (tx, ty)."""
    lw = SIZES[kind][4]
    ang = math.atan2(ty - cy, tx - cx)
    hx, hy = tx - 34 * math.cos(ang), ty - 34 * math.sin(ang)
    return (limb(f'M{sx} {sy} Q{cx} {cy} {hx:.1f} {hy:.1f}', lw)
            + f'<circle cx="{hx:.1f}" cy="{hy:.1f}" r="{lw * .9:.1f}"/>'
            + limb(f'M{hx + 10 * math.cos(ang):.1f} {hy + 10 * math.sin(ang):.1f} '
                   f'L{tx - 4 * math.cos(ang):.1f} {ty - 4 * math.sin(ang):.1f}', 10))


def drop(x, y, s=1.0):
    return g('<path d="M0 -8 Q-6 0 -5 3 Q-4 8 0 8 Q4 8 5 3 Q6 0 0 -8 Z" stroke-width="1.8"/>', x, y, s)


D[key('Water the plants')] = [
    # fill the can at the tap, not too full
    ground(262, 120, 376) + garden_tap(182, 104)
    + can(196, 262, 1.0)
    + ghost('M164 224 H228')
    + motion('M178 110 V196', 'M186 110 V196')
    + fist(160, 54, 1, (120, -60))
    + arrow('M146 254 V230'),

    # water the soil at the bottom of the plant
    ground(_floor2)
    + person(96, _floor2, 'kid', arms=((-1, None), (1, (_hx2, _hy2, 140, 200))), look=1)
    + can(_cx2, _cb2, _cs2, _cr2) + ink_hand(_hx2, _hy2)
    + plant(306, 238, 1.0) + _pot2
    + motion(f'M{_sx2 + 4} {_sy2 + 6} q2 14 4 26', f'M{_sx2 + 12} {_sy2 + 2} q4 14 8 28',
             f'M{_sx2 - 4} {_sy2 + 8} q0 12 0 22'),

    # is the soil wet now?
    pot(200, 160, 136, 42, 100)[0]
    + plant(150, 160, 1.4)
    + drop(110, 166) + drop(196, 180) + drop(300, 168) + drop(226, 146)
    + finger(262, 162, 400, 60, 300, 120)
    + motion('M244 160 l-10 -2', 'M280 166 l10 2', 'M250 176 l-6 6', 'M274 178 l6 6'),

    # back where it lives
    shelf()
    + pot(80, 146, 20, 6, 22, False)[0] + plant(80, 146, .5)
    + pot(120, 146, 20, 6, 22, False)[0] + plant(120, 146, .5)
    + '<g stroke-dasharray="4 5" stroke-width="1.6">' + can(190, 168, .72) + '</g>'
    + can(306, 128, .72)
    + fist(306, 56, 1, (70, -60))
    + arrow('M296 140 C270 160 252 156 240 148'),
]


# ── Look for animal tracks ───────────────────────────────────────────────
def paw(x, y, s=1.0, rot=0, fill=INK):
    toes = ((-12.5, -12, -22), (-4.8, -19.5, -7), (4.8, -19.5, 7), (12.5, -12, 22))
    return g(f'<path d="M-9 4 Q-12 -6 0 -6 Q12 -6 9 4 Q6 12 0 10 Q-6 12 -9 4 Z" fill="{fill}"/>'
             + ''.join(f'<ellipse cx="{tx}" cy="{ty}" rx="3.3" ry="4.5" transform="rotate({a} {tx} {ty})" fill="{fill}"/>'
                       for tx, ty, a in toes), x, y, s, rot)


def bird_print(x, y, s=1.0, rot=0):
    return g(f'<path d="M0 0 V12 M0 0 L-10 -14 M0 0 V-18 M0 0 L10 -14" fill="none" stroke-width="4"/>', x, y, s, rot)


def mud(x, y, rx, ry):
    d = ''
    n = 12
    for i in range(n + 1):
        a = 2 * math.pi * i / n
        k = 1 + .07 * math.sin(i * 2.3)
        px, py = x + rx * k * math.cos(a), y + ry * k * math.sin(a)
        d += (f'M{px:.1f} {py:.1f}' if i == 0 else f' Q{x + rx * 1.12 * math.cos(a - math.pi / n):.1f} '
              f'{y + ry * 1.12 * math.sin(a - math.pi / n):.1f} {px:.1f} {py:.1f}')
    return f'<path d="{d} Z"/>'


def mud_dots(x0, x1, y0, y1, n=14, seed=5):
    s = ''
    for i in range(n):
        u = (i * 0.618 + seed * .13) % 1
        v = (i * 0.382 + seed * .29) % 1
        s += thin(f'M{x0 + (x1 - x0) * u:.1f} {y0 + (y1 - y0) * v:.1f} h6')
    return s


def bird(x, by, s=1.0):
    """A small bird standing, facing left."""
    return g('<path d="M-4 0 V-12 M6 0 V-12 M-8 0 H0 M2 0 H10" fill="none" stroke-width="2"/>'
             '<path d="M22 -30 L40 -22 L26 -18 Z"/>'
             '<ellipse cx="4" cy="-26" rx="22" ry="15"/>'
             '<circle cx="-16" cy="-40" r="11"/><path d="M-26 -42 L-36 -38 L-26 -36 Z"/>'
             + dot(-18, -42, 2) + thin('M2 -30 q10 4 16 -2'), x, by, s)


D[key('Look for animal tracks')] = [
    # soft ground: a muddy path in the park
    '<path d="M20 170 H380" fill="none" stroke-width="1.6"/>'
    + '<path d="M118 292 C150 240 196 210 190 170 H214 C224 210 264 240 312 292" fill="none"/>'
    + mud(200, 252, 46, 14) + mud(214, 196, 18, 6)
    + mud_dots(150, 270, 208, 286, 12)
    + tree(330, 176, .9) + tree(62, 176, .7) + bush(120, 170, 50, 26) + bush(290, 170, 36, 22)
    + grass(60, 250) + grass(350, 262) + grass(96, 210) + grass(306, 220)
    + arrow('M200 282 C204 250 196 222 202 192', dashed=True),

    # tracks in the mud
    mud(200, 170, 172, 104)
    + mud_dots(60, 330, 90, 250, 10, 2)
    + paw(110, 228, 1.4, 60) + paw(150, 186, 1.4, 60) + paw(196, 192, 1.4, 60)
    + paw(236, 150, 1.4, 60) + paw(282, 156, 1.4, 60) + paw(318, 116, 1.4, 60)
    + arrow('M96 266 C150 250 250 186 330 160', dashed=True),

    # count the toes: who made them?
    mud(200, 236, 176, 50)
    + bird_print(108, 238, 1.6) + paw(286, 240, 1.7)
    + bird(108, 120, 1.25) + dog(268, 128, 1.6)
    + arrow('M108 196 C96 176 96 160 104 136', dashed=True)
    + arrow('M286 196 C300 176 300 158 290 136', dashed=True),

    # draw them at home
    '<rect x="70" y="40" width="250" height="200" rx="3"/>'
    + '<g stroke-width="1.8">' + paw(116, 104, 1.4, 0, '#fff') + paw(166, 140, 1.4, 0, '#fff') + '</g>'
    + bird_print(130, 196, 1.3).replace('stroke-width="4"', 'stroke-width="3"')
    + bird_print(180, 210, 1.3).replace('stroke-width="4"', 'stroke-width="3"')
    + thin('M206 112 Q203 98 216 98 Q229 98 226 112') + thin('M201 88 q0 -6 3 -8')
    + crayon_held(226, 112, -40)
    + arrow('M200 120 Q212 132 226 124', dashed=True),
]


# ── Race a grown-up to the end of the garden ─────────────────────────────
D[key('Race a grown-up to the end of the garden')] = [
    ground(272)
    + '<path d="M40 280 H240" fill="none" stroke-width="5"/>'
    + person(80, 272, 'kid', look=1, mouth='grin', arms=((-1, (52, 190, 40, 214)), (1, (120, 194, 136, 204))))
    + person(180, 272, 'adult', look=1, mouth='smile', arms=((-1, (150, 176, 136, 190)), (1, (214, 162, 226, 196))))
    + tree(340, 272, .9)
    + arrow('M248 236 H300', dashed=True),

    ground(272)
    + person(200, 272, 'kid', look=0, mouth='big', brows='up',
             arms=((-1, (174, 156, 128, 196)), (1, (226, 156, 272, 196))))
    + motion('M262 128 q12 14 0 28', 'M282 116 q20 26 0 52', 'M302 104 q28 38 0 76',
             'M138 128 q-12 14 0 28', 'M118 116 q-20 26 0 52', 'M98 104 q-28 38 0 76'),

    ground(272)
    + tree(352, 272, .9)
    + person(218, 272, 'kid', look=1, mouth='grin', legs='walk',
             arms=((-1, (184, 190, 186, 160)), (1, (256, 172, 250, 200))))
    + person(100, 272, 'adult', look=1, mouth='open', legs='walk',
             arms=((-1, (64, 168, 66, 130)), (1, (146, 152, 136, 186))))
    + motion('M24 140 H48', 'M18 170 H44', 'M160 180 H178', 'M152 206 H174')
    + arrow('M180 44 Q240 28 300 44', dashed=True),

    ground(272)
    + tree(352, 272, .9)
    + person(270, 272, 'kid', look=-1, mouth='grin', brows='up',
             arms=((-1, (226, 112, 226, 150)), (1, (314, 112, 314, 150))))
    + person(110, 272, 'adult', look=1, mouth='open', legs='walk')
    + motion('M232 92 l-10 -10', 'M270 74 V60', 'M308 92 l10 -10', 'M214 120 h-14', 'M326 120 h14'),
]


# ── Smooth and rough ─────────────────────────────────────────────────────
def leaf(x, y, s=1.0, rot=0, shiny=True):
    b = ('<path d="M-18 0 C-10 -12 10 -12 18 0 C10 12 -10 12 -18 0 Z"/>' + thin('M-16 0 H14'))
    if shiny:
        b += thin('M-6 -6 q4 -2 8 -2')
    return g(b, x, y, s, rot)


def pine_cone(x, y, s=1.0, rot=0):
    b = '<path d="M0 -26 C16 -24 18 0 12 14 Q0 26 -12 14 C-18 0 -16 -24 0 -26 Z"/>'
    for yy in (-14, -4, 6):
        b += thin(f'M-12 {yy} l6 6 l6 -6 l6 6 l6 -6')
    b += thin('M-8 16 l4 4 l4 -4 l4 4')
    b += '<path d="M0 -26 V-34" fill="none"/>'
    return g(b, x, y, s, rot)


def bark(x, y, s=1.0, rot=0):
    b = ('<path d="M-24 -10 L-14 -14 L0 -11 L12 -15 L24 -10 L22 12 L8 14 L-6 11 L-22 13 Z"/>'
         + thin('M-14 -10 q2 10 -2 20 M-2 -9 q-2 10 2 18 M10 -12 q3 12 -1 24'))
    return g(b, x, y, s, rot)


def rough_stone(x, y, s=1.0):
    b = ('<path d="M-16 6 L-14 -6 L-6 -12 L4 -10 L14 -12 L18 0 L14 10 L0 12 L-10 12 Z"/>'
         + dot(-6, -2, 1.5) + dot(4, 4, 1.5) + dot(8, -4, 1.5) + dot(-10, 6, 1.5) + dot(0, -6, 1.5))
    return g(b, x, y, s)


def bowl(cx, y, w=64, items=''):
    """A bowl seen slightly from above, rim centred at (cx, y); items are drawn inside it."""
    ry = w * .22
    return (f'<ellipse cx="{cx}" cy="{y}" rx="{w}" ry="{ry:.1f}"/>'
            + items
            + f'<path d="M{cx - w} {y} A{w} {ry:.1f} 0 0 0 {cx + w} {y} Q{cx + w * .9:.1f} {y + w * .9:.1f} {cx} {y + w * .9:.1f} '
              f'Q{cx - w * .9:.1f} {y + w * .9:.1f} {cx - w} {y} Z"/>'
            + f'<path d="M{cx - w * .3:.1f} {y + w * .9:.1f} h{w * .6:.1f}" fill="none"/>')


def _smooth(n):
    things = [leaf(-16, -6, 1.0, -20), pebble(-40, 2, 14, 9, -10, True), pebble(40, 2, 13, 8, 14, True),
              pebble(10, 6, 12, 8, 0, True), leaf(12, -16, .9, 30)]
    order = [4, 0, 1, 2, 3] if n == 5 else [0, 1, 2, 3]
    return ''.join(things[i] for i in order[:n])


def _rough(n):
    things = [bark(-26, 0, 1.0, -10), pine_cone(4, -12, .9, 14), rough_stone(30, 2), rough_stone(-6, 6, .8),
              pine_cone(-30, -10, .8, -20)]
    order = [0, 1, 2, 3, 4]
    return ''.join(things[i] for i in order[:n])


BY = 168
B1, B2, BW = 108, 292, 82


def _bowls(left=0, right=0):
    return ('<path d="M20 248 H380" fill="none" stroke-width="1.6"/>'
            + bowl(B1, BY, BW, g(_smooth(left), B1, BY - 10, 1.35))
            + bowl(B2, BY, BW, g(_rough(right), B2, BY - 10, 1.35)))


_hd = top_of(0)[1]
_feel = g(person(0, 0, 'kid', look=0, mouth='smile', arms=((-1, (-22, -66, -44, -76)), (1, (22, -66, 44, -76))))
          + f'<circle cx="-10.8" cy="{_hd:.1f}" r="3.8" stroke="none"/><circle cx="10.8" cy="{_hd:.1f}" r="3.8" stroke="none"/>'
          + thin(f'M-17 {_hd - 1:.1f} q6 5 12 0 M5 {_hd - 1:.1f} q6 5 12 0')
          + pine_cone(0, -62, .95) + ink_hand(-22, -66) + ink_hand(22, -66), 110, 278, 1.25)

D[key('Collect 5 things that are smooth and 5 that are rough')] = [
    # feel the bark with your fingers
    ground(272)
    + '<path d="M258 272 V110 M322 272 V110" fill="none"/>'
    + '<path d="M258 272 Q250 272 246 278 M322 272 Q332 272 336 278" fill="none"/>'
    + thin('M272 130 q6 30 0 60 q-6 30 0 60 M292 120 q-6 40 0 80 q6 40 0 80 M310 140 q6 30 0 60 q-6 30 0 60')
    + '<path d="M290 22 C326 18 352 38 350 60 C376 66 378 104 352 112 C344 130 310 130 300 118 '
      'C286 132 246 130 240 112 C214 108 210 74 232 66 C230 40 258 22 290 22 Z"/>'
    + person(130, 272, 'kid', look=1, mouth='smile', arms=((-1, None), (1, (252, 170, 204, 204))))
    + motion('M240 150 l-10 -8', 'M236 168 h-14', 'M240 186 l-10 8'),

    # smooth things in one bowl
    _bowls(4)
    + fist(176, 44, 1, (90, -60)) + pebble(176, 66, 16, 10, 10, True)
    + arrow('M162 84 C150 100 140 112 132 122'),

    # rough things in the other bowl
    _bowls(5, 4)
    + fist(330, 40, 1, (60, -60)) + pine_cone(330, 84, .9)
    + arrow('M306 72 C292 86 286 100 286 114'),

    # eyes shut: which is it?
    ground(278) + _feel
    + think(202, 22, 176, 104, 150, 112,
            pebble(246, 76, 20, 12, -8, True) + qmark(290, 74, 1.3) + pine_cone(334, 78, .85, 10))
    + motion('M70 186 l-10 -6', 'M68 206 h-12', 'M150 186 l10 -6', 'M152 206 h12'),
]
