"""Diagrams for the first Outdoors challenges (ten leaves, a den, a bug hunt,
rainbow colours, a stick and stone picture, jumping jacks and hops, the biggest
stick). Simple round-headed people from kind_2 and plain garden things in ink;
the green accent is only for arrows and dashed motion lines."""
import math
import re

from draw_3 import hold_pencil
from kind import flower
from kind_2 import book_open, fist, hands, head, limb, person, SIZES
from style import INK, arrow, dot, ghost, ground, motion, thin

D = {}


def key(title):
    return re.sub(r'[^a-z0-9]+', '_', title.lower()).strip('_')[:48]


def g(body, x=0, y=0, s=1, rot=0):
    t = f'translate({x} {y})'
    if rot:
        t += f' rotate({rot})'
    if s != 1:
        t += f' scale({s})'
    return f'<g transform="{t}">{body}</g>'


# ── Garden things ────────────────────────────────────────────────────────
def scallop(cx, cy, rx, ry, n=9, k=.3, start=0):
    """A bumpy closed outline (tree tops, bushes, clouds)."""
    pts = [(cx + rx * math.cos(start + 2 * math.pi * i / n), cy + ry * math.sin(start + 2 * math.pi * i / n))
           for i in range(n)]
    d = f'M{pts[0][0]:.1f} {pts[0][1]:.1f}'
    for i in range(n):
        p, q = pts[i], pts[(i + 1) % n]
        mx, my = (p[0] + q[0]) / 2, (p[1] + q[1]) / 2
        d += f' Q{mx + (mx - cx) * k:.1f} {my + (my - cy) * k:.1f} {q[0]:.1f} {q[1]:.1f}'
    return d + ' Z'


def tree(x, by, s=1.0):
    """A friendly tree: trunk standing on by, round bumpy top."""
    t = (f'<path d="M{x - 14 * s:.1f} {by} Q{x - 8 * s:.1f} {by - 50 * s:.1f} {x - 10 * s:.1f} {by - 100 * s:.1f} '
         f'H{x + 10 * s:.1f} Q{x + 8 * s:.1f} {by - 50 * s:.1f} {x + 14 * s:.1f} {by} Z"/>'
         + f'<path d="{scallop(x, by - 140 * s, 70 * s, 52 * s, 10, .32, .3)}"/>'
         + thin(f'M{x - 30 * s:.1f} {by - 150 * s:.1f} q8 -8 18 -4 M{x + 18 * s:.1f} {by - 128 * s:.1f} q8 -8 18 -2'))
    return t


def bush(x, by, w=70, h=40):
    return (f'<path d="M{x - w / 2} {by} Q{x - w / 2 - 10} {by - h * .6} {x - w * .25} {by - h * .75} '
            f'Q{x - w * .2} {by - h * 1.1} {x} {by - h} Q{x + w * .2} {by - h * 1.1} {x + w * .25} {by - h * .75} '
            f'Q{x + w / 2 + 10} {by - h * .6} {x + w / 2} {by} Z"/>')


def grass(x, y):
    return thin(f'M{x - 6} {y} l2 -9 M{x} {y} v-12 M{x + 6} {y} l-2 -9')


def stone(x, y, rx=22, ry=12, rot=0):
    return (f'<g transform="translate({x} {y}) rotate({rot})"><path d="M{-rx} 0 Q{-rx} {-ry} {-rx * .2:.1f} {-ry} '
            f'Q{rx * .9:.1f} {-ry * 1.05:.1f} {rx} {-ry * .1:.1f} Q{rx * .9:.1f} {ry * .8:.1f} 0 {ry * .8:.1f} '
            f'Q{-rx} {ry * .8:.1f} {-rx} 0 Z"/>'
            + thin(f'M{-rx * .5:.1f} {-ry * .45:.1f} q{rx * .3:.1f} {-ry * .25:.1f} {rx * .6:.1f} {-ry * .1:.1f}') + '</g>')


def pebble(x, y, r=7):
    return f'<ellipse cx="{x}" cy="{y}" rx="{r}" ry="{r * .72:.1f}"/>'


def stick(x0, y0, x1, y1, w=10, twig=.55, side=1):
    """A stick with a small twig and a knot; twig at fraction `twig` along it."""
    dx, dy = x1 - x0, y1 - y0
    L = math.hypot(dx, dy)
    nx, ny = -dy / L, dx / L
    mx, my = x0 + dx * .5 + nx * L * .03, y0 + dy * .5 + ny * L * .03
    s = limb(f'M{x0:.1f} {y0:.1f} Q{mx:.1f} {my:.1f} {x1:.1f} {y1:.1f}', w)
    if twig:
        tx, ty = x0 + dx * twig, y0 + dy * twig
        ex, ey = tx + (dx / L * .5 + nx * side) * L * .22, ty + (dy / L * .5 + ny * side) * L * .22
        s += limb(f'M{tx:.1f} {ty:.1f} L{ex:.1f} {ey:.1f}', max(w * .55, 6))
    kx, ky = x0 + dx * .3, y0 + dy * .3
    s += f'<ellipse cx="{kx:.1f}" cy="{ky:.1f}" rx="{w * .22:.1f}" ry="{w * .14:.1f}" stroke-width="1.4"/>'
    return s


# ── Leaves: ten different shapes, drawn about 100 tall, stem pointing down ──
LEAF = {
    'oval': 'M0 40 C-34 20 -30 -30 0 -50 C30 -30 34 20 0 40 Z',
    'maple': ('M0 30 L-10 30 L-40 22 L-32 8 L-50 -12 L-30 -14 L-34 -38 L-14 -24 L0 -52 L14 -24 '
              'L34 -38 L30 -14 L50 -12 L32 8 L40 22 L10 30 Z'),
    'oak': ('M0 40 Q-14 42 -12 30 Q-30 30 -22 16 Q-38 10 -24 0 Q-38 -12 -20 -18 Q-30 -36 -12 -34 '
            'Q-12 -54 0 -50 Q12 -54 12 -34 Q30 -36 20 -18 Q38 -12 24 0 Q38 10 22 16 Q30 30 12 30 Q14 42 0 40 Z'),
    'heart': 'M0 -50 C-10 -30 -44 -12 -40 14 C-36 36 -10 38 0 28 C10 38 36 36 40 14 C44 -12 10 -30 0 -50 Z',
    'long': 'M0 44 C-13 20 -13 -20 0 -54 C13 -20 13 20 0 44 Z',
    'holly': ('M0 40 L-14 30 L-28 34 L-22 20 L-34 10 L-22 4 L-30 -10 L-16 -12 L-20 -28 L-6 -26 L0 -50 '
              'L6 -26 L20 -28 L16 -12 L30 -10 L22 4 L34 10 L22 20 L28 34 L14 30 Z'),
    'ivy': 'M0 38 Q-22 42 -44 26 Q-36 10 -22 6 Q-30 -22 0 -50 Q30 -22 22 6 Q36 10 44 26 Q22 42 0 38 Z',
    'fan': 'M0 40 L-40 -14 Q-22 -42 -4 -32 L0 -22 L4 -32 Q22 -42 40 -14 Z',
}


def _zig_round():
    pts = []
    for i in range(28):
        a = -math.pi / 2 + 2 * math.pi * i / 28
        r = 36 if i % 2 == 0 else 31
        pts.append(f'{r * math.cos(a) * .9:.1f} {r * math.sin(a) * 1.15 - 8:.1f}')
    return 'M' + ' L'.join(pts) + ' Z'


LEAF['round'] = _zig_round()


def leaf(x, y, kind='oval', s=.5, rot=0, veins=True, stem=62):
    """One leaf centred about (x, y), s=1 is about 100 tall."""
    sw, tw = 2.4 / s, 1.5 / s
    if kind == 'conker':  # five long fingers from one point
        b = ''
        for a, L in ((-72, 34), (-36, 44), (0, 52), (36, 44), (72, 34)):
            b += (f'<g transform="translate(0 22) rotate({a})"><path d="M0 0 C-11 -{L * .4:.0f} -9 -{L * .85:.0f} 0 -{L} '
                  f'C9 -{L * .85:.0f} 11 -{L * .4:.0f} 0 0 Z" stroke-width="{sw:.2f}"/>'
                  f'<path d="M0 -2 V-{L - 6}" fill="none" stroke-width="{tw:.2f}"/></g>')
        body = f'<path d="M0 22 V{stem}" fill="none" stroke-width="{sw:.2f}"/>' + b
    else:
        base = {'maple': 30, 'heart': 28, 'ivy': 38, 'fan': 40, 'round': 30}.get(kind, 40)
        tip = {'maple': -46, 'fan': -24, 'round': -44}.get(kind, -46)
        body = (f'<path d="M0 {base} V{stem}" fill="none" stroke-width="{sw:.2f}"/>'
                f'<path d="{LEAF[kind]}" stroke-width="{sw:.2f}"/>')
        if veins:
            v = f'M0 {base} V{tip}'
            if kind == 'maple':
                v += ' M0 26 L-42 -10 M0 26 L42 -10 M0 26 L-32 16 M0 26 L32 16'
            elif kind == 'fan':
                v = 'M0 38 L-24 -26 M0 38 L-10 -30 M0 38 L10 -30 M0 38 L24 -26'
            elif kind == 'ivy':
                v += ' M0 30 L-34 22 M0 30 L34 22'
            elif kind in ('oval', 'oak', 'heart', 'round'):
                v += ' M0 14 L-14 2 M0 14 L14 2 M0 -6 L-12 -18 M0 -6 L12 -18'
            body += f'<path d="{v}" fill="none" stroke-width="{tw:.2f}"/>'
    return f'<g transform="translate({x} {y}) rotate({rot}) scale({s})">{body}</g>'


KINDS10 = ['round', 'long', 'heart', 'oval', 'holly', 'ivy', 'fan', 'oak', 'conker', 'maple']


# ── Small creatures ──────────────────────────────────────────────────────
def beetle(x, y, s=1.0, rot=0):
    b = ('<path d="M-12 -6 l-8 -6 M-12 2 l-10 0 M-12 8 l-8 6 M12 -6 l8 -6 M12 2 l10 0 M12 8 l8 6" fill="none" stroke-width="1.8"/>'
         '<ellipse cx="0" cy="3" rx="13" ry="15"/>'
         '<path d="M0 -10 V18" fill="none" stroke-width="1.6"/>'
         f'<ellipse cx="0" cy="-14" rx="8" ry="6" fill="{INK}"/>'
         '<path d="M-3 -19 q-4 -6 -9 -6 M3 -19 q4 -6 9 -6" fill="none" stroke-width="1.6"/>')
    return f'<g transform="translate({x} {y}) rotate({rot}) scale({s})">{b}</g>'


def ladybird(x, y, s=1.0, rot=0):
    b = ('<path d="M-11 -2 l-7 -4 M-12 5 l-8 1 M11 -2 l7 -4 M12 5 l8 1" fill="none" stroke-width="1.8"/>'
         '<path d="M-14 0 A14 14 0 0 1 14 0 Q14 16 0 16 Q-14 16 -14 0 Z"/>'
         f'<path d="M-8 -8 A9 8 0 0 1 8 -8 Q4 -12 0 -12 Q-4 -12 -8 -8 Z" fill="{INK}"/>'
         '<path d="M0 -10 V16" fill="none" stroke-width="1.6"/>'
         + dot(-7, 1, 2.6) + dot(7, 1, 2.6) + dot(-5, 9, 2.2) + dot(5, 9, 2.2))
    return f'<g transform="translate({x} {y}) rotate({rot}) scale({s})">{b}</g>'


def worm(x, y, s=1.0, flip=False):
    b = ('<path d="M-26 0 q6 -12 13 0 q6 12 13 0 q6 -12 13 0" fill="none" stroke-width="7"/>'
         '<path d="M-26 0 q6 -12 13 0 q6 12 13 0 q6 -12 13 0" fill="none" stroke="#fff" stroke-width="2.6"/>'
         + dot(10, -3, 1.4))
    return f'<g transform="translate({x} {y}) scale({-s if flip else s} {s})">{b}</g>'


def ant(x, y, s=1.0):
    b = ('<path d="M-6 0 l-4 6 M0 0 l0 7 M6 0 l4 6 M-6 0 l-4 -6 M6 0 l4 -6" fill="none" stroke-width="1.5"/>'
         f'<circle cx="-9" cy="0" r="4" fill="{INK}"/><circle cx="0" cy="0" r="3" fill="{INK}"/>'
         f'<ellipse cx="10" cy="0" rx="6" ry="4.5" fill="{INK}"/>'
         '<path d="M-12 -2 q-4 -6 -8 -5" fill="none" stroke-width="1.4"/>')
    return f'<g transform="translate({x} {y}) scale({s})">{b}</g>'


def tally(x, y, n, h=22, gap=8):
    """n tally marks; every fifth crosses the four before it."""
    s, cx = '', x
    for i in range(n):
        if i % 5 == 4:
            s += f'<path d="M{cx - 5 * gap - 3} {y + h * .75:.1f} L{cx - gap + 4} {y + h * .2:.1f}" fill="none" stroke-width="2.2"/>'
            cx += gap
        else:
            s += f'<path d="M{cx} {y} V{y + h}" fill="none" stroke-width="2.2"/>'
            cx += gap
    return s


def magnifier(cx, cy, r=34, ang=-140, inside=''):
    """A magnifying glass: lens centre (cx, cy), handle going off at ang degrees. Returns (svg, grip point)."""
    a = math.radians(ang)
    hx0, hy0 = cx + (r + 3) * math.cos(a), cy + (r + 3) * math.sin(a)
    hx1, hy1 = cx + (r + 50) * math.cos(a), cy + (r + 50) * math.sin(a)
    s = (limb(f'M{hx0:.1f} {hy0:.1f} L{hx1:.1f} {hy1:.1f}', 13)
         + f'<circle cx="{cx}" cy="{cy}" r="{r + 5}"/><circle cx="{cx}" cy="{cy}" r="{r}"/>'
         + inside
         + thin(f'M{cx - r * .6:.1f} {cy - r * .3:.1f} q{r * .15:.1f} {-r * .35:.1f} {r * .45:.1f} {-r * .45:.1f}'))
    gx, gy = cx + (r + 34) * math.cos(a), cy + (r + 34) * math.sin(a)
    return s, (round(gx, 1), round(gy, 1))


# ── Den things ───────────────────────────────────────────────────────────
GY = 262  # garden floor for the den


def chair(cx, face=-1, gy=GY):
    """A garden chair seen from the side; face=-1 faces left (back on the right)."""
    bx = cx - face * 34  # back post x
    s = (f'<rect x="{cx - 38}" y="{gy - 74}" width="76" height="10" rx="3"/>'
         f'<rect x="{cx - 36}" y="{gy - 64}" width="8" height="64" rx="2"/>'
         f'<rect x="{cx + 28}" y="{gy - 64}" width="8" height="64" rx="2"/>'
         f'<rect x="{bx - 4}" y="{gy - 170}" width="9" height="98" rx="3"/>'
         f'<path d="M{bx} {gy - 160} V{gy - 84}" fill="none" stroke-width="1.4"/>')
    return s


BL, BR, BT = 130, 270, GY - 170  # inner back posts and their top


def blanket():
    """The blanket over the two chair backs; the near side is left open to see in."""
    back = (f'<path d="M{BL} {BT} Q200 {BT + 18} {BR} {BT} L{BR + 2} {GY - 2} Q235 {GY + 2} 200 {GY - 2} '
            f'Q165 {GY + 2} {BL - 2} {GY - 2} Z"/>'
            + thin(f'M170 {BT + 14} q-4 50 2 {GY - BT - 18} M232 {BT + 14} q4 50 -2 {GY - BT - 18}'))
    front = (f'<path d="M{BL - 6} {BT - 4} Q200 {BT + 14} {BR + 6} {BT - 4} L{BR + 4} {BT + 16} '
             f'Q{BR - 16} {BT + 28} {BR - 34} {BT + 24} Q{BR - 52} {BT + 32} 200 {BT + 28} '
             f'Q{BL + 52} {BT + 32} {BL + 34} {BT + 24} Q{BL + 16} {BT + 28} {BL - 4} {BT + 16} Z"/>')
    ends = (f'<path d="M{BL - 4} {BT - 4} C{BL - 24} {BT - 6} {BL - 30} {BT + 20} {BL - 30} {BT + 56} '
            f'L{BL - 12} {BT + 62} Q{BL - 10} {BT + 30} {BL + 2} {BT + 6} Z"/>'
            f'<path d="M{BR + 4} {BT - 4} C{BR + 24} {BT - 6} {BR + 30} {BT + 20} {BR + 30} {BT + 56} '
            f'L{BR + 12} {BT + 62} Q{BR + 10} {BT + 30} {BR - 2} {BT + 6} Z"/>')
    return back, front + ends


def peg(x, y, rot=0):
    """A clothes peg clipping the blanket to a chair, its jaw at (x, y)."""
    return (f'<g transform="translate({x} {y}) rotate({rot})">'
            '<rect x="-5" y="-30" width="10" height="34" rx="3"/>'
            '<path d="M0 -30 V4" fill="none" stroke-width="1.4"/>'
            '<circle cx="0" cy="-12" r="3.5" stroke-width="1.6"/></g>')


def cushion(cx, by, w=58, h=20, rot=0):
    return (f'<g transform="rotate({rot} {cx} {by})"><path d="M{cx - w / 2} {by} Q{cx - w / 2 - 6} {by - h / 2} {cx - w / 2} {by - h} '
            f'Q{cx} {by - h - 6} {cx + w / 2} {by - h} Q{cx + w / 2 + 6} {by - h / 2} {cx + w / 2} {by} Q{cx} {by + 5} {cx - w / 2} {by} Z"/>'
            + dot(cx, by - h / 2, 2) + '</g>')


def den(inside=''):
    back, front = blanket()
    return (ground(GY + 2) + chair(BL - 34, -1) + chair(BR + 34, 1) + back + inside + front
            + peg(BL - 2, BT + 22, -10) + peg(BR + 2, BT + 22, 10))


# ── Rainbow things ───────────────────────────────────────────────────────
def bottle_top(x, y, s=1.0):
    ridges = ''.join(f'M{-14 + i * 4} 0 v10 ' for i in range(8))
    return g('<path d="M-15 0 V10 Q0 15 15 10 V0"/><ellipse cx="0" cy="0" rx="15" ry="5"/>'
             + thin(ridges), x, y, s)


def bell_flower(x, y, s=1.0):
    """A sprig of little bell flowers (the purple one)."""
    b = '<path d="M0 30 Q-2 0 6 -30" fill="none"/>'
    for (bx, by_, r) in ((6, -30, 0), (-8, -14, -30), (12, -6, 30), (-6, 6, -30)):
        b += (f'<g transform="translate({bx} {by_}) rotate({r})"><path d="M-6 0 Q-6 -10 0 -10 Q6 -10 6 0 L8 4 '
              f'Q4 2 3 5 Q0 2 -3 5 Q-4 2 -8 4 Z"/></g>')
    return g(b, x, y, s)


def tray(cx, cy, w=320, h=110):
    """A tray seen from slightly above."""
    return (f'<rect x="{cx - w / 2}" y="{cy - h / 2}" width="{w}" height="{h}" rx="14"/>'
            f'<rect x="{cx - w / 2 + 10}" y="{cy - h / 2 + 9}" width="{w - 20}" height="{h - 18}" rx="9" fill="none" stroke-width="1.6"/>')


# items in rainbow order: red tulip, orange (oak) leaf, yellow flower, green leaf, blue bottle top, purple bells
def rb_item(i, x, y, s=1.0):
    if i == 0:
        return tulip(x, y, s * 1.1)
    if i == 1:
        return leaf(x, y - 4, 'oak', .44 * s, 15)
    if i == 2:
        return g(flower(0, 0, 9, 0), x, y, s * 1.3)
    if i == 3:
        return leaf(x, y - 4, 'oval', .44 * s, -15)
    if i == 4:
        return bottle_top(x, y - 4, s * 1.1)
    return bell_flower(x, y, s * .85)


def rainbow(cx, by, r0=34, n=6, gap=7):
    return ''.join(f'<path d="M{cx - r0 - i * gap} {by} A{r0 + i * gap} {r0 + i * gap} 0 0 1 {cx + r0 + i * gap} {by}" '
                   f'fill="none" stroke-width="2"/>' for i in range(n))


# ── People helpers ───────────────────────────────────────────────────────
def jumper(cx, by, pose='star', mouth='big', flip=False):
    """A child mid-jump. pose: star (arms and legs out wide) or hop (one foot tucked up)."""
    r, w, th, ll, lw = SIZES['kid']
    hip = by - ll
    yt = hip - th
    hy = yt - r + 2
    s = ''
    if pose == 'star':
        for d in (-1, 1):
            fx = cx + d * 50
            s += limb(f'M{cx + d * w * .45:.1f} {hip} L{fx} {by - 6}', lw)
            s += f'<ellipse cx="{fx + d * 5}" cy="{by - 3}" rx="{lw * .7:.1f}" ry="{lw * .38:.1f}"/>'
        arms = ((-1, (cx - 74, yt - 44, cx - 50, yt - 6)), (1, (cx + 74, yt - 44, cx + 50, yt - 6)))
    else:
        d = -1 if flip else 1  # which leg stays down
        s += limb(f'M{cx + d * w * .45:.1f} {hip} V{by - 3}', lw)
        s += f'<ellipse cx="{cx + d * w * .45 + d * 4:.1f}" cy="{by - 1}" rx="{lw * .7:.1f}" ry="{lw * .38:.1f}"/>'
        kx, ky = cx - d * (w * .45 + 22), hip + 26
        fx, fy = cx - d * 6, hip + 32
        s += limb(f'M{cx - d * w * .45:.1f} {hip} L{kx:.1f} {ky:.1f} L{fx:.1f} {fy:.1f}', lw)
        s += f'<ellipse cx="{fx - d * 2:.1f}" cy="{fy + 2:.1f}" rx="{lw * .62:.1f}" ry="{lw * .45:.1f}"/>'
        arms = ((-1, (cx - 58, yt + 8, cx - 46, yt + 22)), (1, (cx + 58, yt + 8, cx + 46, yt + 22)))
    body = (f'<path d="M{cx - w} {hip + 4} V{yt + 12} Q{cx - w} {yt} {cx - w + 12} {yt} H{cx + w - 12} '
            f'Q{cx + w} {yt} {cx + w} {yt + 12} V{hip + 4} Z"/>')
    a = ''
    for side, (ex, ey, mx, my) in arms:
        sx, sy = cx + side * (w - 7), yt + 11
        a += limb(f'M{sx:.1f} {sy:.1f} Q{mx:.1f} {my:.1f} {ex:.1f} {ey:.1f}', lw)
        a += f'<circle cx="{ex:.1f}" cy="{ey:.1f}" r="{lw * .62:.1f}"/>'
    return s + body + head(cx, hy, r, mouth) + a


def camera(cx, cy):
    return (f'<rect x="{cx - 22}" y="{cy - 14}" width="44" height="30" rx="5"/>'
            f'<rect x="{cx - 12}" y="{cy - 20}" width="14" height="7" rx="2"/>'
            f'<circle cx="{cx + 4}" cy="{cy + 1}" r="9"/><circle cx="{cx + 4}" cy="{cy + 1}" r="4" stroke-width="1.6"/>')


def paving(x0=150, x1=372, y0=196, y1=266, k=30, rows=2, cols=4):
    """A patch of paving slabs seen slightly from above."""
    pts = f'{x0 + k},{y0} {x1 - k},{y0} {x1},{y1} {x0},{y1}'
    s = f'<polygon points="{pts}"/>'
    for i in range(1, cols):
        t = i / cols
        s += thin(f'M{x0 + k + (x1 - x0 - 2 * k) * t:.1f} {y0} L{x0 + (x1 - x0) * t:.1f} {y1}')
    for j in range(1, rows):
        t = j / rows
        y = y0 + (y1 - y0) * t
        s += thin(f'M{x0 + k * (1 - t):.1f} {y:.1f} H{x1 - k * (1 - t):.1f}')
    return s


def stone_face(cx, cy, r=1.0, eye=True):
    """A smiling face made of pebbles, sticks and leaves, lying on the paving."""
    s = ''
    n = 14
    for i in range(n):
        a = 2 * math.pi * i / n
        s += pebble(cx + 62 * r * math.cos(a), cy + 30 * r * math.sin(a), 7 * r)
    s += pebble(cx - 22 * r, cy - 10 * r, 8 * r)
    s += pebble(cx + 22 * r, cy - 10 * r, 8 * r) if eye else \
        f'<ellipse cx="{cx + 22 * r}" cy="{cy - 10 * r}" rx="{8 * r}" ry="{5.8 * r:.1f}" fill="none" stroke-width="1.6" stroke-dasharray="4 4"/>'
    s += pebble(cx, cy + 2 * r, 5 * r)
    s += limb(f'M{cx - 30 * r:.1f} {cy + 8 * r:.1f} Q{cx} {cy + 30 * r:.1f} {cx + 30 * r:.1f} {cy + 8 * r:.1f}', 8 * r)
    s += leaf(cx - 26 * r, cy - 40 * r, 'long', .3 * r, -60) + leaf(cx, cy - 46 * r, 'long', .3 * r, 0) \
        + leaf(cx + 26 * r, cy - 40 * r, 'long', .3 * r, 60)
    return s


def reach(hx, hy, fx, fy, cx=None, cy=None):
    """A child's arm coming in from (fx, fy) with its hand at (hx, hy), drawn over what it holds."""
    if cx is None:
        cx, cy = (hx + fx) / 2, (hy + fy) / 2 - 10
    return limb(f'M{fx} {fy} Q{cx} {cy} {hx} {hy}', 15) + f'<circle cx="{hx}" cy="{hy}" r="9.3"/>'


def tulip(x, y, s=1.0, stem=0):
    """A tulip head at (x, y) (the red one), with an optional stem going down."""
    b = (f'<path d="M0 10 V{10 + stem}" fill="none"/>' if stem else '') + \
        ('<path d="M-12 -10 L-12 4 Q0 16 12 4 L12 -10 L6 -3 L0 -13 L-6 -3 Z"/>' + thin('M-6 -3 L-4 8 M6 -3 L4 8'))
    return g(b, x, y, s)


def bunch(px, py, leaves):
    """Leaves whose stems all meet at (px, py): (kind, scale, angle, distance)."""
    out = ''
    for k, sc, a, dist in leaves:
        r = math.radians(a)
        Ls = dist / sc
        cx, cy = px + dist * math.sin(r), py - dist * math.cos(r)
        out += leaf(round(cx, 1), round(cy, 1), k, sc, a, stem=round(Ls + 24 / sc, 1))
    return out


# ═════════════════════════════════════════════════════════════════════════
# Find 10 different leaves
_ground_leaves = (leaf(84, 256, 'oval', .34, 70) + leaf(208, 254, 'maple', .34, -20)
                  + leaf(172, 256, 'heart', .32, 100) + leaf(244, 258, 'oak', .32, 30)
                  + leaf(44, 262, 'long', .3, -80))
D[key('Find 10 different leaves')] = [
    ground(278) + tree(130, 276, 1.15)
    + _ground_leaves
    + person(296, 276, 'kid', arms=((-1, (250, 240, 252, 214)), (1, None)), legs='kneel', look=-1, mouth='open')
    + arrow('M260 154 Q214 170 206 226', dashed=True),
    # a hand holding a bunch of different leaves by their stems
    bunch(196, 222, (('oval', .6, -56, 110), ('oak', .6, -26, 124), ('maple', .62, 4, 128),
                     ('heart', .58, 32, 118), ('holly', .54, 60, 104)))
    + fist(196, 222, 1, (40, 44), 19)
    + motion('M70 70 l-12 -8', 'M64 100 h-16', 'M330 70 l12 -8'),
    ground(214)
    + ''.join(leaf(x, 206 - 52 * s, k, s) for x, k, s in zip(
        (30, 58, 88, 120, 156, 194, 234, 276, 320, 364), KINDS10,
        (.18, .22, .26, .3, .34, .38, .42, .46, .5, .54)))
    + arrow('M40 240 Q200 256 362 236'),
    ground(278)
    + person(200, 276, 'kid', arms=((-1, None), (1, (256, 92, 252, 150))), mouth='grin', look=1)
    + leaf(270, 58, 'maple', .88, 12) + hands((256, 92))
    + motion('M318 30 l12 -8', 'M330 62 h16', 'M218 30 l-12 -10'),
]

# Build a den
D[key('Build a den')] = [
    ground(GY + 2) + chair(BL - 34, -1) + chair(BR + 34, 1) + grass(200, GY) + grass(30, GY) + grass(372, GY)
    + arrow(f'M180 {GY - 30} Q150 {GY - 40} 112 {GY - 30}', dashed=True)
    + arrow(f'M220 {GY - 30} Q250 {GY - 40} 288 {GY - 30}', dashed=True),
    den() + arrow('M200 20 Q200 44 200 80'),
    den(cushion(170, GY - 2, 60, 22, -4) + cushion(228, GY - 2, 58, 20, 5))
    + arrow(f'M40 {GY - 34} Q90 {GY - 60} 150 {GY - 30}', dashed=True)
    + cushion(36, GY - 2, 46, 18),
    den(cushion(170, GY - 2, 76, 20, -2) + cushion(248, GY - 2, 44, 16, 6)
        + person(162, GY - 20, 'small', arms=((-1, (152, GY - 54, 142, GY - 60)), (1, (196, GY - 54, 188, GY - 50))),
                 legs='sit_r', look=1)
        + book_open(174, GY - 58, 50, 32, 'star', -4) + hands((152, GY - 54), (196, GY - 54))
        + f'<ellipse cx="248" cy="{GY - 22}" rx="13" ry="5"/>'
        + f'<circle cx="243" cy="{GY - 28}" r="5"/><circle cx="253" cy="{GY - 29}" r="5"/>')
    + motion(f'M120 {BT - 16} l-8 -10', f'M200 {BT - 10} v-14', f'M280 {BT - 16} l8 -10'),
]

# Go on a bug hunt and count what you find
_lifted = g(stone(-50, 0, 50, 22), 334, 262, rot=28)
_mg, _mgp = magnifier(278, 214, 40, -150, beetle(278, 220, 1.5, 0) + thin('M244 244 H312'))
D[key('Go on a bug hunt and count what you find')] = [
    ground(272) + beetle(262, 262, .65, 20) + worm(306, 268, .55) + ant(226, 266, .8)
    + _lifted
    + person(176, 272, 'kid', arms=((-1, (250, 228, 214, 252)), (1, (244, 212, 222, 196))), legs='kneel', look=1, mouth='open')
    + hands((250, 228), (244, 212))
    + arrow('M236 186 Q244 160 270 156', dashed=True) + grass(40, 272) + grass(370, 272),
    ground(272) + person(110, 272, 'kid', arms=((-1, None), (1, _mgp)), legs='kneel', look=1)
    + _mg + hands(_mgp) + beetle(278, 262, .5, 0)
    + arrow('M150 118 Q210 110 236 166', dashed=True),
    # paper with tally marks next to bug drawings
    '<rect x="70" y="30" width="230" height="240" rx="4"/>'
    + beetle(110, 74, .9) + tally(150, 63, 3)
    + ladybird(110, 132, .9) + tally(150, 121, 5)
    + worm(110, 188, .85) + tally(150, 177, 2)
    + ant(110, 240, 1.1) + tally(150, 229, 1)
    + hold_pencil(166, 252, -40, 60)
    + arrow('M232 282 Q186 290 170 262'),
    ground(272) + beetle(262, 258, .7, 80) + worm(300, 264, .6) + ant(332, 264, .8)
    + stone(282, 230, 52, 22, 4)
    + person(164, 272, 'kid', arms=((-1, (230, 238, 204, 256)), (1, (232, 224, 210, 204))), legs='kneel', look=1, mouth='smile')
    + hands((230, 238), (232, 224))
    + arrow('M350 178 Q362 206 346 232') + grass(40, 272) + grass(370, 272),
]

# Find something for every colour of the rainbow
D[key('Find something for every colour of the rainbow')] = [
    ground(278) + f'<path d="{scallop(326, 246, 52, 32, 8, .3)}"/>'
    + tulip(300, 200, 1.1, 40) + tulip(330, 188, 1.1, 46) + tulip(356, 202, 1.1, 36)
    + person(140, 276, 'kid', arms=((-1, None), (1, (206, 126, 206, 166))), look=1, mouth='grin')
    + tulip(206, 98, 1.3, 22) + hands((206, 126))
    + arrow('M300 168 Q268 104 234 96', dashed=True),
    tray(200, 210, 330, 110)
    + rb_item(0, 70, 212) + rb_item(1, 140, 212) + rb_item(2, 210, 212)
    + rb_item(3, 290, 108) + reach(290, 136, 360, 40, 330, 120)
    + arrow('M290 160 Q296 182 290 202', dashed=True),
    tray(200, 210, 330, 110)
    + ''.join(rb_item(i, x, 212) for i, x in zip(range(4), (64, 116, 168, 218)))
    + rb_item(5, 276, 208)
    + rb_item(4, 334, 112) + reach(334, 106, 390, 20, 370, 90)
    + arrow('M334 138 Q340 162 334 194', dashed=True),
    rainbow(200, 128, 30, 6, 9)
    + tray(200, 214, 340, 100)
    + ''.join(rb_item(i, 60 + i * 56, 216) for i in range(6))
    + arrow('M60 278 Q200 292 340 278'),
]

# Make a picture with sticks and stones
_face_eye = ghost('M216 182 a10 7 0 1 0 0.1 0')
D[key('Make a picture with sticks and stones')] = [
    ground(272, 24, 150) + grass(60, 272) + grass(124, 272) + grass(380, 272)
    + paving(150, 372, 196, 266)
    + person(80, 270, 'kid', arms=((-1, None), (1, (156, 176, 140, 196))), look=1)
    + arrow('M180 150 Q240 140 260 186', dashed=True),
    ground(272)
    + stick(100, 254, 230, 230, 10, .5) + stick(140, 266, 290, 256, 10, .6, -1) + stick(120, 236, 250, 254, 8, 0)
    + pebble(162, 268, 11) + pebble(196, 266, 10) + pebble(236, 270, 12) + pebble(268, 264, 9) + pebble(186, 246, 9)
    + pebble(214, 252, 8)
    + leaf(304, 238, 'oval', .4, 60) + leaf(84, 244, 'oak', .4, -50) + leaf(260, 222, 'heart', .36, 20)
    + pebble(306, 128, 12) + reach(306, 118, 392, 30, 370, 110)
    + arrow('M300 150 Q290 186 266 208', dashed=True),
    paving(30, 370, 120, 280, 40)
    + stone_face(200, 204, 1.25, eye=False)
    + pebble(296, 70, 9) + reach(296, 62, 390, 10, 360, 70)
    + arrow('M290 92 Q290 150 236 186', dashed=True),
    ground(278) + paving(150, 386, 214, 276, 30)
    + stone_face(270, 246, .72)
    + person(84, 276, 'kid', arms=((-1, (138, 146, 96, 186)), (1, (166, 146, 140, 182))), look=1, mouth='grin')
    + camera(152, 140) + hands((138, 146), (166, 146))
    + motion('M182 150 l20 12', 'M178 164 l14 18', 'M184 134 l22 2'),
]

# Do 20 jumping jacks and 10 hops on each foot
D[key('Do 20 jumping jacks and 10 hops on each foot')] = [
    ground(278) + tree(72, 276, .7) + bush(340, 276, 60, 34)
    + person(200, 276, 'kid', mouth='smile')
    + ghost('M110 270 Q200 250 290 270 Q200 292 110 270 Z')
    + arrow('M160 236 Q120 240 104 260') + arrow('M240 236 Q280 240 296 260'),
    ground(278)
    + jumper(200, 262, 'star', 'big')
    + arrow('M110 140 Q100 100 124 72') + arrow('M290 140 Q300 100 276 72')
    + motion('M246 82 l14 -4', 'M248 96 h16'),
    ground(278) + '<ellipse cx="210" cy="276" rx="22" ry="4" stroke-width="1.6"/>'
    + jumper(200, 250, 'hop', 'smile')
    + motion('M188 266 l-10 6', 'M232 266 l10 6')
    + arrow('M286 268 Q306 196 326 268', dashed=True),
    ground(278) + '<ellipse cx="190" cy="276" rx="22" ry="4" stroke-width="1.6"/>'
    + jumper(200, 250, 'hop', 'grin', flip=True)
    + motion('M168 266 l-10 6', 'M212 266 l10 6')
    + arrow('M114 268 Q94 196 74 268', dashed=True),
]

# Find the biggest stick you can carry
D[key('Find the biggest stick you can carry')] = [
    ground(278) + tree(150, 276, 1.15)
    + stick(50, 268, 140, 262, 8, .5) + stick(150, 270, 270, 260, 10, .6, -1) + stick(96, 254, 156, 258, 6, 0)
    + person(330, 276, 'kid', look=-1, mouth='open')
    + arrow('M296 150 Q246 170 232 232', dashed=True),
    ground(278) + stick(30, 270, 100, 266, 6, 0) + stick(270, 272, 384, 262, 12, .6, -1)
    + person(150, 276, 'kid', arms=((-1, None), (1, (228, 196, 214, 214))), look=1, mouth='flat')
    + stick(176, 214, 286, 176, 9, 0) + hands((228, 196))
    + arrow('M246 160 V120', dashed=True),
    ground(278)
    + person(170, 276, 'kid', arms=((-1, (130, 214, 134, 236)), (1, (210, 214, 206, 236))), look=-1, legs='walk', mouth='smile')
    + stick(40, 210, 276, 216, 12, .82, -1) + hands((130, 214), (210, 214))
    + person(338, 276, 'adult', look=-1)
    + arrow('M110 262 H40', dashed=True),
    ground(278)
    + person(150, 276, 'kid', arms=((-1, None), (1, (224, 180, 212, 214))), look=1, mouth='grin')
    + stick(226, 272, 234, 38, 12, .86) + hands((224, 180))
    + ghost('M110 106 H250')
    + arrow('M270 104 Q284 70 252 40'),
]
