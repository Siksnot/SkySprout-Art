"""More diagrams for the Bricks challenges. Bricks overlap by at least one
stud wherever they connect; top-down views sit on a base plate."""
import math
import re
from collections import deque

from style import BH, INK, U, arrow, brick, dot, ghost, ground, hand, motion, slope, thin

D = {}


def _key(title):
    return re.sub(r'[^a-z0-9]+', '_', title.lower()).strip('_')[:48]


# ── Shared bits ──────────────────────────────────────────────────────────
def _wheel(cx, cy, r=16, tread=False):
    s = f'<circle cx="{cx}" cy="{cy}" r="{r}"/><circle cx="{cx}" cy="{cy}" r="{r * 0.42:.1f}"/>'
    if tread:
        s += thin(' '.join(f'M{cx + (r - 5) * math.cos(a):.1f} {cy + (r - 5) * math.sin(a):.1f} '
                           f'L{cx + r * math.cos(a):.1f} {cy + r * math.sin(a):.1f}'
                           for a in (i * math.pi / 7 for i in range(14))))
    return s + dot(cx, cy)


def _plate(x, y, n, h=8):
    """A thin base plate, side view."""
    return (f'<rect x="{x}" y="{y}" width="{n * U}" height="{h}" rx="1.5"/>'
            + ''.join(f'<rect x="{x + i * U + 4}" y="{y - 4}" width="8" height="4" rx="1"/>' for i in range(n)))


def _tplate(x, y, cols, rows):
    """A base plate seen from above: a grid of little studs."""
    s = f'<rect x="{x - 4}" y="{y - 4}" width="{cols * U + 8}" height="{rows * U + 8}" rx="4"/>'
    return s + ''.join(f'<circle cx="{x + c * U + 8}" cy="{y + r * U + 8}" r="2.6" stroke-width="1.2"/>'
                       for r in range(rows) for c in range(cols))


def _tbrick(x, y, w, h):
    """A brick seen from above, w x h studs."""
    s = f'<rect x="{x + 1}" y="{y + 1}" width="{w * U - 2}" height="{h * U - 2}" rx="2"/>'
    return s + ''.join(f'<circle cx="{x + c * U + 8}" cy="{y + r * U + 8}" r="4.2" stroke-width="1.6"/>'
                       for r in range(h) for c in range(w))


def _hops(pts, h=26):
    """Dashed counting hops from point to point."""
    return motion(*(f'M{a[0]} {a[1]} Q{(a[0] + b[0]) / 2} {min(a[1], b[1]) - h} {b[0]} {b[1]}'
                    for a, b in zip(pts, pts[1:])))


def _rot(body, deg, cx, cy):
    return f'<g transform="rotate({deg} {cx} {cy})">{body}</g>'


# ── Make a car with as few bricks as you can ─────────────────────────────
def _car_base(x, y, missing=False):
    s = _wheel(x + 28, y + BH - 5, 15) + _wheel(x + 84, y + BH - 5, 15)  # far-side wheels peep out
    s += brick(x, y, 6) + _wheel(x + 20, y + BH, 16)
    if missing:
        return s + f'<circle cx="{x + 76}" cy="{y + BH}" r="16" fill="none" stroke-width="1.6" stroke-dasharray="4 5"/>'
    return s + _wheel(x + 76, y + BH, 16)


def _car_top(x, y):
    # A seat with a back, and a bonnet brick holding the steering wheel.
    sx, sy = x + 3 * U + 12, y - BH - 20
    return (brick(x + U, y - BH, 2) + brick(x + U, y - 2 * BH, 1)
            + f'<path d="M{x + 4 * U + 6} {y - BH - 3} L{sx + 2} {sy + 4}" fill="none"/>'
            + f'<rect x="{sx - 3}" y="{sy - 9}" width="6" height="18" rx="3" transform="rotate(-25 {sx} {sy})"/>'
            + brick(x + 4 * U, y - BH, 2))


_cx, _cy = 152, 204
D[_key('Make a car with as few bricks as you can')] = [
    ground() + _wheel(110, 222) + _wheel(158, 222) + _wheel(206, 222)
    + f'<circle cx="254" cy="222" r="16" fill="none" stroke-width="1.6" stroke-dasharray="4 5"/>'
    + _wheel(318, 110) + arrow('M318 140 q4 50 -42 70'),
    ground() + _car_base(_cx, _cy, missing=True) + _wheel(320, 160)
    + arrow('M316 186 q-10 40 -72 38'),
    ground() + _car_base(_cx, _cy) + _car_top(_cx, _cy)
    + arrow(f'M{_cx - 40} {_cy - 80} q30 -20 52 22'),
    ground() + _car_base(40, _cy) + _car_top(40, _cy)
    + brick(170, 220, 6) + brick(276, 220, 2) + brick(318, 220, 2) + brick(360, 220, 1)
    + _hops([(218, 206), (292, 206), (334, 206), (368, 206)], 26),
]


# ── Build a maze for a marble ────────────────────────────────────────────
_MAZE = '''###############
#.....#.......#
#.###.#.#####.#
#.#...#.....#.#
#.#.#######.#.#
#...#.....#...#
###.#.###.###.#
#...#.#.....#.#
#.###.#.###.#.#
#.....#...#...#
#.#######.###.#
#.........#...#
###############'''.split()
_MX, _MY = 80, 46


def _runs(cells):
    """Split wall cells into bricks: rows first, then columns, 2 to 4 studs long."""
    cells, out = set(cells), []

    def chunks(n):
        while n > 4:
            k = 4 if n - 4 != 1 else 3
            yield k
            n -= k
        yield n

    for r in range(len(_MAZE)):
        c = 0
        while c < 15:
            n = 0
            while (r, c + n) in cells:
                n += 1
            if n >= 2:
                k = c
                for m in chunks(n):
                    out.append((r, k, m, 1))
                    k += m
                for j in range(n):
                    cells.discard((r, c + j))
            c += max(n, 1)
    for c in range(15):
        r = 0
        while r < len(_MAZE):
            n = 0
            while (r + n, c) in cells:
                n += 1
            k = r
            for m in (chunks(n) if n else ()):
                out.append((k, c, 1, m))
                k += m
            r += max(n, 1)
    return out


def _is_outer(r, c):
    return r in (0, 12) or c in (0, 14)


_OUTER = _runs([(r, c) for r, row in enumerate(_MAZE) for c, ch in enumerate(row) if ch == '#' and _is_outer(r, c)])
_INNER = _runs([(r, c) for r, row in enumerate(_MAZE) for c, ch in enumerate(row) if ch == '#' and not _is_outer(r, c)])


def _bricks(lst, skip=()):
    return ''.join(_tbrick(_MX + c * U, _MY + r * U, w, h) for r, c, w, h in lst if (r, c) not in skip)


def _maze_path():
    start, end = (1, 1), (11, 13)
    prev, q = {start: None}, deque([start])
    while q:
        p = q.popleft()
        for d in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (p[0] + d[0], p[1] + d[1])
            if _MAZE[n[0]][n[1]] == '.' and n not in prev:
                prev[n] = p
                q.append(n)
    path, p = [], end
    while p:
        path.append(p)
        p = prev[p]
    path.reverse()
    return [path[0]] + [b for a, b, c in zip(path, path[1:], path[2:])
                        if (b[0] - a[0], b[1] - a[1]) != (c[0] - b[0], c[1] - b[1])] + [path[-1]]


def _xy(rc):
    return _MX + rc[1] * U + 8, _MY + rc[0] * U + 8


def _marble(x, y, r=6):
    return f'<circle cx="{x}" cy="{y}" r="{r}"/>' + thin(f'M{x - 3} {y - 1} q1 -3 4 -3')


def _flag(x, y):
    return (f'<path d="M{x - 4} {y + 6} V{y - 14}" fill="none" stroke-width="2"/>'
            f'<path d="M{x - 4} {y - 14} l12 4 l-12 4 Z" fill="{INK}" stroke-width="1.6"/>')


_mpts = [_xy(p) for p in _maze_path()]
_maze2 = _tplate(_MX, _MY, 15, 13) + _bricks(_OUTER) + _bricks(_INNER)
_route = 'M' + ' L'.join(f'{x} {y}' for x, y in [(_mpts[0][0] + 9, _mpts[0][1])] + _mpts[1:-1] + [(_mpts[-1][0], _mpts[-1][1] - 10)])
# Step 4: the marble halfway along, with a trail behind it.
_mi = 7
_mx0, _my0 = _mpts[_mi - 1]
_mx1, _my1 = _mpts[_mi]
_mm = ((_mx0 + _mx1) / 2, (_my0 + _my1) / 2)
D[_key('Build a maze for a marble')] = [
    _tplate(_MX, _MY, 15, 13) + _bricks(_OUTER, skip={(9, 14)})
    + ghost(f'M{_MX + 14 * U + 1} {_MY + 9 * U + 1} h14 v46 h-14 Z')
    + _tbrick(352, 70, 1, 3) + arrow('M368 124 q6 40 -38 70'),
    _tplate(_MX, _MY, 15, 13) + _bricks(_OUTER) + _bricks(_INNER, skip={(4, 4)})
    + ghost(f'M{_MX + 4 * U + 1} {_MY + 4 * U + 1} h62 v14 h-62 Z')
    + _tbrick(290, 10, 4, 1) + arrow('M284 18 q-70 -4 -92 84'),
    _maze2 + _marble(*_mpts[0]) + _flag(*_mpts[-1]) + arrow(_route, dashed=True),
    _rot(_maze2 + _flag(*_mpts[-1]) + _marble(*_mm)
         + motion(f'M{_mx0} {_my0} L{_mm[0] + (_mx0 - _mm[0]) * 0.25:.1f} {_mm[1] + (_my0 - _mm[1]) * 0.25:.1f}'),
         -7, 200, 150)
    + hand(48, 214, 0.8) + hand(352, 186, 0.8, flip=True)
    + arrow('M120 26 q80 -24 160 0'),
]


# ── Make a monster with three eyes ───────────────────────────────────────
_MO = 200  # centre of the middle stud column
_MB = 232  # bottom of the body
_MROWS = [[(-2, 3), (1, 2)], [(-3, 2), (-1, 4)], [(-4, 4), (0, 5)],
          [(-4, 2), (-2, 4), (2, 3)], [(-3, 3), (0, 4)], [(-2, 3), (1, 2)]]


def _mc(c):
    return _MO - 8 + c * U


def _my(i):
    return _MB - (i + 1) * BH


def _monster_body(missing_top=False):
    s = brick(_mc(-2), _MB, 2, studs=False) + brick(_mc(1), _MB, 2, studs=False)
    for i, row in enumerate(_MROWS):
        for c, n in row:
            if missing_top and i == 5 and c == 1:
                continue
            s += brick(_mc(c), _my(i), n)
    return s


def _eye(c, look=(0, 0)):
    x, y = _mc(c) + 8, _my(5)
    return (f'<rect x="{x - 7}" y="{y - 8}" width="14" height="8" rx="1"/>'
            f'<circle cx="{x}" cy="{y - 19}" r="11"/>' + dot(x + look[0], y - 19 + look[1], 3.6))


def _monster_eyes(skip=None):
    looks = {-2: (-4, 2), 0: (0, -4), 2: (4, 2)}
    return ''.join(_eye(c, looks[c]) for c in (-2, 0, 2) if c != skip)


def _monster_face():
    y = _my(2) - 6
    s = (slope(_mc(-3), _my(5)) + slope(_mc(3), _my(5))
         + f'<rect x="{_MO - 38}" y="{y}" width="76" height="26" rx="10"/>')
    for i in range(4):
        tx = _MO - 30 + i * 16
        s += f'<path d="M{tx} {y} v9 h12 v-9" fill="none" stroke-width="2"/>'
    return s


D[_key('Make a monster with three eyes')] = [
    ground(250) + _monster_body(missing_top=True)
    + brick(_mc(1) + 70, _my(5) - 50, 2) + arrow(f'M{_mc(1) + 112} {_my(5) - 30} q8 30 -54 34'),
    ground(250) + _monster_body() + _monster_eyes(skip=2)
    + f'<g transform="translate(60 -50)">{_eye(2, (4, 2))}</g>'
    + arrow(f'M{_mc(2) + 84} {_my(5) - 52} q14 40 -40 44'),
    ground(250) + _monster_body() + _monster_eyes() + _monster_face()
    + arrow(f'M{_MO + 120} {_my(1)} q-6 -30 -54 -18'),
    ground(250) + _rot(_monster_body() + _monster_eyes() + _monster_face(), -6, _mc(2) + 8, 250)
    + motion('M286 170 q12 14 0 28', 'M300 160 q20 24 0 48', 'M314 150 q28 34 0 68',
             'M114 170 q-12 14 0 28', 'M100 160 q-20 24 0 48', 'M86 150 q-28 34 0 68'),
]


# ── Build your bedroom out of bricks ─────────────────────────────────────
_RX, _RY = 80, 58  # 15 x 12 base plate, seen from above
_RWALLS = [(0, 0, 3, 1), (0, 3, 2, 1), (0, 9, 3, 1), (0, 12, 3, 1),
           (1, 0, 1, 4), (5, 0, 1, 4), (8, 0, 1, 3), (1, 14, 1, 4), (5, 14, 1, 4), (8, 14, 1, 3),
           (11, 0, 4, 1), (11, 4, 5, 1), (11, 12, 3, 1)]


def _room(skip=()):
    s = _tplate(_RX, _RY, 15, 12)
    for r, c, w, h in _RWALLS:
        if (r, c) not in skip:
            s += _tbrick(_RX + c * U, _RY + r * U, w, h)
    wx, wy = _RX + 5 * U, _RY
    # a window piece in the back wall, and the door gap with its swing
    s += f'<rect x="{wx + 1}" y="{wy + 3}" width="{4 * U - 2}" height="10" rx="2"/>' + thin(f'M{wx + 4} {wy + 8} h{4 * U - 8}')
    hx, hy = _RX + 9 * U, _RY + 11 * U + 8
    s += ghost(f'M{hx} {hy} L{hx} {hy - 46} A46 46 0 0 1 {hx + 46} {hy}')
    return s


def _furniture():
    bx, by = _RX + U + 4, _RY + U + 4
    bed = (f'<rect x="{bx}" y="{by}" width="60" height="92" rx="4"/>'
           f'<rect x="{bx + 8}" y="{by + 6}" width="44" height="18" rx="7"/>'
           + thin(f'M{bx} {by + 34} H{bx + 60} M{bx + 40} {by + 34} l20 20'))
    wx, wy = _RX + 10 * U + 4, _RY + U + 4
    ward = (f'<rect x="{wx}" y="{wy}" width="56" height="26" rx="2"/>'
            + thin(f'M{wx + 28} {wy} V{wy + 26}') + dot(wx + 23, wy + 18, 2) + dot(wx + 33, wy + 18, 2))
    tx, ty = _RX + 11 * U, _RY + 5 * U
    desk = (f'<rect x="{tx}" y="{ty}" width="40" height="28" rx="2"/>'
            f'<rect x="{tx + 8}" y="{ty + 34}" width="24" height="14" rx="4"/>')
    return bed + ward + desk


def _details():
    rx, ry = _RX + 7 * U - 8, _RY + 8 * U + 6
    rug = (f'<ellipse cx="{rx}" cy="{ry}" rx="40" ry="24"/><ellipse cx="{rx}" cy="{ry}" rx="28" ry="14" fill="none" stroke-width="1.6"/>')
    lx, ly = _RX + 6 * U, _RY + U + 12
    lamp = f'<circle cx="{lx}" cy="{ly}" r="10"/><circle cx="{lx}" cy="{ly}" r="4"/>'
    return rug + lamp


def _bedroom_scene():
    floor = 222
    bed = (f'<path d="M50 {floor} V136 h12 V{floor}" fill="none"/>'
           f'<rect x="50" y="170" width="140" height="30" rx="4"/>'
           f'<rect x="64" y="154" width="40" height="16" rx="7"/>'
           f'<path d="M184 200 V{floor} M62 200 V{floor}" fill="none"/>')
    win = (f'<rect x="210" y="60" width="72" height="62" rx="2"/>'
           + thin('M246 60 V122 M210 91 H282'))
    door = f'<rect x="306" y="96" width="58" height="{floor - 96}" rx="2"/>' + dot(352, 162, 3)
    kid = ('<circle cx="150" cy="262" r="24"/>' + dot(156, 256, 2.6) + dot(170, 254, 2.6)
           + '<path d="M156 272 q8 5 15 -2" fill="none"/>'
           + '<path d="M128 254 q4 -26 30 -24 q16 0 20 12" fill="none"/>')
    return f'<path d="M24 {floor} H376" fill="none"/>' + bed + win + door + kid


D[_key('Build your bedroom out of bricks')] = [
    _bedroom_scene() + arrow('M120 106 q90 -90 230 -18', dashed=True),
    _room(skip={(8, 0)}) + _tbrick(28, 168, 1, 3) + arrow('M36 222 q4 22 40 10'),
    _room() + _furniture() + arrow('M372 50 q6 30 -36 40'),
    _room() + _furniture() + _details()
    + motion(f'M{_RX + 6 * U - 16} {_RY + U - 4} l-6 -6', f'M{_RX + 6 * U + 16} {_RY + U - 4} l6 -6',
             f'M{_RX + 6 * U - 18} {_RY + U + 18} l-6 4', f'M{_RX + 6 * U + 18} {_RY + U + 18} l6 4'),
]


# ── Make a vehicle for driving on the Moon ───────────────────────────────
_BX, _BY = 120, 186  # bottom layer of the chassis


def _buggy_base(missing=False):
    s = '' if missing else _wheel(_BX + 26, _BY + 26, 26, tread=True)
    if missing:
        s += f'<circle cx="{_BX + 26}" cy="{_BY + 26}" r="26" fill="none" stroke-width="1.6" stroke-dasharray="4 5"/>'
    s += _wheel(_BX + 134, _BY + 26, 26, tread=True)
    return (s + brick(_BX, _BY, 6, studs=False) + brick(_BX + 6 * U, _BY, 4, studs=False)
            + brick(_BX, _BY - BH, 4) + brick(_BX + 4 * U, _BY - BH, 6))


def _buggy_seat():
    return brick(_BX + U, _BY - 2 * BH, 2) + brick(_BX + U, _BY - 3 * BH, 1) + brick(_BX + U, _BY - 4 * BH, 1)


def _buggy_tools():
    ax, top = _BX + 8, _BY - 2 * BH
    ant = (brick(_BX, top, 1) + f'<path d="M{ax} {top - 4} V{top - 64}" fill="none"/>'
           f'<path d="M{ax - 14} {top - 70} q14 14 28 0" fill="none"/>' + dot(ax, top - 66, 3))
    fx = _BX + 10 * U
    scoop = (brick(_BX + 8 * U, top, 2)
             + f'<path d="M{fx} {top + 8} L{fx + 22} {top + 26}" fill="none"/>'
             f'<path d="M{fx + 14} {top + 22} h34 l-6 24 h-22 Z"/>')
    return ant + scoop


def _star(x, y, r=7):
    return thin(f'M{x} {y - r} q2 {r - 2} {r} {r} q{-r + 2} 2 {-r} {r} q-2 {-r + 2} {-r} {-r} q{r - 2} -2 {r} {-r} Z')


D[_key('Make a vehicle for driving on the Moon')] = [
    ground() + _buggy_base(missing=True) + _wheel(60, 120, 26, tread=True)
    + arrow('M70 154 q20 50 64 52'),
    ground() + _buggy_base() + _buggy_seat()
    + arrow(f'M{_BX - 30} {_BY - 120} q30 -20 50 30'),
    ground() + _buggy_base() + _buggy_seat() + _buggy_tools()
    + arrow(f'M{_BX - 40} {_BY - 110} q10 -40 36 -30') + arrow(f'M{_BX + 230} {_BY - 100} q12 30 -16 56'),
    '<path d="M16 250 Q80 236 146 244 Q200 252 254 232 Q300 216 350 236 L384 242" fill="none"/>'
    + thin('M60 268 q20 -6 40 0 M210 270 q30 -8 56 0 M310 264 q20 -6 40 0')
    + _star(56, 56) + _star(118, 30, 5) + _star(340, 48) + _star(372, 120, 5) + _star(30, 140, 5)
    + _rot(_buggy_base() + _buggy_seat() + _buggy_tools() + '<circle cx="292" cy="198" r="6"/>', -6, 200, 212)
    + motion('M36 200 h40', 'M46 216 h30', 'M28 184 h30'),
]


# ── Build a castle with a door that opens ────────────────────────────────
_KX, _KY = 96, 62  # 13 x 11 base plate, seen from above
_TOWERS = [(0, 0), (0, 10), (8, 0), (8, 10)]
_KWALLS = [(1, 3, 4, 1), (1, 7, 3, 1), (9, 3, 2, 1), (9, 8, 2, 1),
           (3, 1, 1, 2), (5, 1, 1, 3), (3, 11, 1, 2), (5, 11, 1, 3)]


def _kt(r, c, w, h):
    return _tbrick(_KX + c * U, _KY + r * U, w, h)


def _castle_top(towers=4, walls=True, skip_wall=None):
    s = _tplate(_KX, _KY, 13, 11)
    s += ''.join(_kt(r, c, 3, 3) + f'<rect x="{_KX + c * U + 5}" y="{_KY + r * U + 5}" width="38" height="38" rx="2" fill="none" stroke-width="1.4"/>'
                 for r, c in _TOWERS[:towers])
    if walls:
        s += ''.join(_kt(*w) for w in _KWALLS if w != skip_wall)
    return s


def _castle_front(top=True, flag=False, swing=False):
    py = 236
    rows = [[(0, 3), (3, 2), (8, 2), (10, 3)], [(0, 5), (8, 5)], [(0, 3), (3, 2), (8, 2), (10, 3)],
            [(0, 4), (4, 5), (9, 4)], [(0, 3), (10, 3)], [(0, 3), (10, 3)], [(0, 3), (10, 3)]]
    x0 = 96
    s = _plate(x0 - 16, py, 15)
    for i, row in enumerate(rows):
        s += ''.join(brick(x0 + c * U, py - (i + 1) * BH, n) for c, n in row)
    if top:
        for c in (3, 5, 7, 9):
            s += brick(x0 + c * U, py - 5 * BH, 1)
        for c in (0, 2, 10, 12):
            s += brick(x0 + c * U, py - 8 * BH, 1)
    gx, gt = x0 + 5 * U, py - 3 * BH
    if swing:
        s += (ghost(f'M{gx + 2} {gt + 2} H{gx + 46} V{py - 1} H{gx + 2} Z')
              + arrow(f'M{gx + 40} {py + 16} Q{gx + 10} {py + 36} {gx - 26} {py + 20}', dashed=True))
    s += (f'<polygon points="{gx},{gt + 1} {gx},{py} {gx - 22},{py + 10} {gx - 22},{gt + 6}"/>'
          + thin(f'M{gx - 7} {gt + 3} V{py + 3} M{gx - 15} {gt + 4} V{py + 7}'))
    if flag:
        fx, ft = x0 + 12 * U + 8, py - 8 * BH - 4
        s += f'<path d="M{fx} {ft} V{ft - 50}" fill="none"/><path d="M{fx} {ft - 50} q14 -6 28 2 v18 q-14 -8 -28 -2 Z"/>'
    return s


D[_key('Build a castle with a door that opens')] = [
    _castle_top(towers=3, walls=False)
    + ghost(f'M{_KX + 10 * U + 2} {_KY + 8 * U + 2} h44 v44 h-44 Z')
    + _tbrick(326, 120, 3, 3)
    + arrow('M350 172 q4 40 -46 54'),
    _castle_top(skip_wall=(5, 11, 1, 3)) + _tbrick(340, 130, 1, 3)
    + ghost(f'M{_KX + 11 * U + 2} {_KY + 5 * U + 2} h12 v44 h-12 Z')
    + arrow('M356 184 q4 30 -40 18'),
    _castle_front(top=False, swing=True),
    _castle_front(flag=True) + motion('M334 40 q12 7 26 0', 'M334 54 q12 7 26 0', 'M334 68 q12 7 26 0'),
]


# ── Make a flower garden ─────────────────────────────────────────────────
_GY = 230  # top of the base plate
_STALKS = [(120, 2), (168, 3), (216, 2), (264, 3)]


def _stalks(skip_top=False):
    s = ''
    for i, (x, n) in enumerate(_STALKS):
        for k in range(n - (1 if skip_top and i == 3 else 0)):
            s += brick(x, _GY - (k + 1) * BH, 1)
    return s


def _flower(cx, cy):
    s = ''.join(f'<circle cx="{cx + 10 * math.cos(a):.1f}" cy="{cy + 10 * math.sin(a):.1f}" r="7.5"/>'
                for a in (i * math.pi / 3 + math.pi / 6 for i in range(6)))
    return s + f'<circle cx="{cx}" cy="{cy}" r="6"/>'


def _flower_at(i):
    x, n = _STALKS[i]
    return _flower(x + 8, _GY - n * BH - 14)


def _fence(x):
    s = ''.join(f'<polygon points="{x + i * U + 3},{_GY - BH} {x + i * U + 3},{_GY - BH - 22} {x + i * U + 8},{_GY - BH - 29} '
                f'{x + i * U + 13},{_GY - BH - 22} {x + i * U + 13},{_GY - BH}"/>' for i in range(3))
    return s + f'<rect x="{x}" y="{_GY - BH - 16}" width="48" height="6" rx="1"/>' + brick(x, _GY - BH, 3, studs=False)


_gplate = _plate(56, _GY, 18)
D[_key('Make a flower garden')] = [
    _gplate + _stalks(skip_top=True) + brick(310, 120, 1)
    + arrow('M318 144 q6 26 -38 30'),
    _gplate + _stalks() + ''.join(_flower_at(i) for i in range(3)) + _flower(324, 70)
    + arrow('M336 96 q10 30 -50 46'),
    _gplate + _stalks() + ''.join(_flower_at(i) for i in range(4)) + _fence(56) + _fence(296)
    + arrow('M60 120 q-6 30 20 50'),
    _gplate + _stalks() + ''.join(_flower_at(i) for i in range(4)) + _fence(56) + _fence(296)
    + _hops([(128, 158), (176, 140), (224, 158), (272, 140)], 30),
]
