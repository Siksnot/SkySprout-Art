"""Diagrams for the first Kindness challenges (make someone laugh, set the
table, thank-you note, three compliments, tidy something, a picture for a
grandparent, share a toy). Simple round-headed people and plain objects in
ink; the golden accent is only for arrows and dashed motion lines showing
what moves or is given."""
import math
import re

from style import INK, arrow, dot, ghost, ground, motion, thin
from craft import heart, scribble, sun
from craft_3 import grip

D = {}


def key(title):
    return re.sub(r'[^a-z0-9]+', '_', title.lower()).strip('_')[:48]


# ── Shared bits ──────────────────────────────────────────────────────────
def g(body, x=0, y=0, s=1, rot=0):
    t = f'translate({x} {y})'
    if rot:
        t += f' rotate({rot})'
    if s != 1:
        t += f' scale({s})'
    return f'<g transform="{t}">{body}</g>'


def face(cx, cy, r=24, mouth='smile', eyes='dot', hair='child'):
    """A round face. mouth: smile, grin, laugh, talk, flat, tongue. eyes: dot, happy, tired, wink.
    hair: child, sib (bunches), adult, gran (bun and glasses), none."""
    s = ''
    if hair == 'sib':
        s += (f'<circle cx="{cx - r * 1.02:.1f}" cy="{cy - r * .35:.1f}" r="{r * .3:.1f}"/>'
              f'<circle cx="{cx + r * 1.02:.1f}" cy="{cy - r * .35:.1f}" r="{r * .3:.1f}"/>')
    if hair == 'gran':
        s += f'<circle cx="{cx}" cy="{cy - r * 1.15:.1f}" r="{r * .38:.1f}"/>'
    s += f'<circle cx="{cx}" cy="{cy}" r="{r}"/>'
    ex, ey = r * .36, cy - r * .08
    dr = r * .07 + 1
    if eyes == 'dot':
        s += dot(cx - ex, ey, dr) + dot(cx + ex, ey, dr)
    elif eyes == 'happy':
        s += ''.join(thin(f'M{x - r * .14:.1f} {ey + r * .04:.1f} q{r * .14:.1f} {-r * .2:.1f} {r * .28:.1f} 0')
                     for x in (cx - ex, cx + ex))
    elif eyes == 'tired':
        s += ''.join(thin(f'M{x - r * .15:.1f} {ey:.1f} h{r * .3:.1f}') + dot(x, ey + r * .06, dr * .8)
                     for x in (cx - ex, cx + ex))
    elif eyes == 'wink':
        s += (thin(f'M{cx - ex - r * .15:.1f} {ey:.1f} q{r * .15:.1f} {r * .12:.1f} {r * .3:.1f} 0')
              + f'<circle cx="{cx + ex:.1f}" cy="{ey:.1f}" r="{r * .16:.1f}"/>' + dot(cx + ex, ey, dr * .9))
    m = cy + r * .35
    if mouth == 'smile':
        s += thin(f'M{cx - r * .3:.1f} {m:.1f} q{r * .3:.1f} {r * .25:.1f} {r * .6:.1f} 0')
    elif mouth in ('grin', 'laugh'):
        k = 1.25 if mouth == 'laugh' else 1
        s += (f'<path d="M{cx - r * .38 * k:.1f} {m - r * .1:.1f} q{r * .38 * k:.1f} {r * .55 * k:.1f} '
              f'{r * .76 * k:.1f} 0 Z" stroke-width="1.8"/>')
    elif mouth == 'talk':
        s += f'<ellipse cx="{cx}" cy="{m + r * .02:.1f}" rx="{r * .16:.1f}" ry="{r * .13:.1f}" stroke-width="1.8"/>'
    elif mouth == 'flat':
        s += thin(f'M{cx - r * .22:.1f} {m + r * .06:.1f} h{r * .44:.1f}')
    elif mouth == 'tongue':
        s += (f'<path d="M{cx - r * .1:.1f} {m + r * .05:.1f} v{r * .2:.1f} q{r * .15:.1f} {r * .2:.1f} '
              f'{r * .3:.1f} 0 v{-r * .2:.1f}" stroke-width="1.8"/>'
              + thin(f'M{cx - r * .36:.1f} {m - r * .02:.1f} q{r * .36:.1f} {r * .2:.1f} {r * .72:.1f} 0'))
    if hair in ('child', 'sib'):
        s += thin(f'M{cx - r * .92:.1f} {cy - r * .4:.1f} q{r * .3:.1f} {-r * .85:.1f} {r * 1.1:.1f} {-r * .7:.1f} '
                  f'q{r * .6:.1f} {r * .02:.1f} {r * .8:.1f} {r * .5:.1f}')
    elif hair == 'adult':
        s += (f'<path d="M{cx - r * .95:.1f} {cy - r * .2:.1f} q{-r * .05:.1f} {-r * .8:.1f} {r * .95:.1f} {-r * .8:.1f} '
              f'q{r:.1f} 0 {r * .95:.1f} {r * .8:.1f} q{-r * .5:.1f} {-r * .25:.1f} {-r * .9:.1f} {-r * .5:.1f} '
              f'q{-r * .5:.1f} {r * .35:.1f} {-r:.1f} {r * .5:.1f} Z" fill="{INK}" stroke-width="1.6"/>')
    elif hair == 'gran':
        s += (thin(f'M{cx - r * .92:.1f} {cy - r * .25:.1f} q{r * .17:.1f} {-r * .83:.1f} {r * .92:.1f} {-r * .83:.1f} '
                   f'q{r * .75:.1f} 0 {r * .92:.1f} {r * .83:.1f}')
              + f'<circle cx="{cx - ex:.1f}" cy="{ey:.1f}" r="{r * .27:.1f}" fill="none" stroke-width="1.6"/>'
              + f'<circle cx="{cx + ex:.1f}" cy="{ey:.1f}" r="{r * .27:.1f}" fill="none" stroke-width="1.6"/>'
              + thin(f'M{cx - r * .09:.1f} {ey:.1f} h{r * .18:.1f}'))
    return s


def _arm(sx, sy, ex, ey, cx=None, cy=None, hand_=True):
    if cx is None:
        cx, cy = (sx + ex) / 2 + (ex - sx) * .3, (sy + ey) / 2 - 6
    d = f'M{sx} {sy} Q{cx} {cy} {ex} {ey}'
    s = (f'<path d="{d}" fill="none" stroke-width="7"/>'
         f'<path d="{d}" fill="none" stroke="#fff" stroke-width="2.2"/>')
    if hand_:
        s += f'<circle cx="{ex}" cy="{ey}" r="6"/>'
    return s


def person(cx, by, s=1.0, arms=None, who='child', mouth='smile', eyes='dot', front='', tilt=0):
    """A simple person standing, feet at by. who: child, sib, adult, gran.
    arms: list of (side, end x, end y[, ctrl x, ctrl y[, hand]]) in local units, shoulders at (+-18, -top+8).
    front: extra drawing (local units) put over the body, under the arms."""
    adult = who in ('adult', 'gran')
    leg = 60 if adult else 40
    top = leg + (66 if adult else 56)
    b = (f'<rect x="-14" y="{-leg}" width="10" height="{leg}" rx="3"/>'
         f'<rect x="4" y="{-leg}" width="10" height="{leg}" rx="3"/>')
    body = f'<path d="M-22 {-leg} L-18 {-top + 4} Q0 {-top - 4} 18 {-top + 4} L22 {-leg} Z"/>'
    hy = -top - 26
    head = f'<rect x="-5" y="{-top - 6}" width="10" height="8"/>' + face(0, hy, 24, mouth, eyes, who)
    arms = arms if arms is not None else [(-1, -30, -44), (1, 30, -44)]
    a = ''
    for arm in arms:
        side, ex, ey = arm[:3]
        c = arm[3:5] if len(arm) >= 5 else (None, None)
        h = arm[5] if len(arm) >= 6 else True
        a += _arm(18 * side, -top + 8, ex, ey, *c, hand_=h)
    inner = b + body + head + front + a
    if tilt:
        inner = f'<g transform="rotate({tilt} 0 {-leg})">{body + head + front + a}</g>'
        inner = b + inner
    return g(inner, cx, by, s)


def sitter(cx, by, s=1.0, arms=None, who='child', mouth='smile', eyes='dot', front=''):
    """A person sitting cross-legged on the floor, seen from the front; seat at by."""
    adult = who in ('adult', 'gran')
    tall = 66 if adult else 56
    lap = ('<path d="M-44 0 Q-46 -22 -20 -22 L20 -22 Q46 -22 44 0 Z"/>'
           + thin('M-20 -6 Q0 -16 20 -6') + '<ellipse cx="-30" cy="-4" rx="9" ry="6"/>'
           + '<ellipse cx="30" cy="-4" rx="9" ry="6"/>')
    top = 18 + tall
    body = f'<path d="M-22 -16 L-18 {-top + 4} Q0 {-top - 4} 18 {-top + 4} L22 -16 Z"/>'
    hy = -top - 26
    head = f'<rect x="-5" y="{-top - 6}" width="10" height="8"/>' + face(0, hy, 24, mouth, eyes, who)
    arms = arms if arms is not None else [(-1, -30, -26), (1, 30, -26)]
    a = ''
    for arm in arms:
        side, ex, ey = arm[:3]
        c = arm[3:5] if len(arm) >= 5 else (None, None)
        h = arm[5] if len(arm) >= 6 else True
        a += _arm(18 * side, -top + 8, ex, ey, *c, hand_=h)
    return g(body + lap + head + front + a, cx, by, s)


def bubble(hx=70, hy=232, inside='', who='child'):
    """A child's head with a thought cloud up and to the right."""
    return (face(hx, hy, 34, 'smile', 'dot', who)
            + '<circle cx="112" cy="190" r="5"/><circle cx="128" cy="172" r="8"/>'
            '<path d="M120 150 C90 140 96 92 132 90 C140 54 200 50 216 76 C240 46 300 54 304 86 '
            'C350 84 362 136 330 150 C340 182 290 196 270 176 C250 200 196 198 186 176 C150 192 112 176 120 150 Z"/>'
            + inside + arrow(f'M{hx - 12} {hy - 40} q-6 -26 12 -42', dashed=True))


def speech(x, y, w, h, tail_x, tail_y, inside=''):
    """A speech bubble with its corner at (x, y) and a tail pointing to (tail_x, tail_y)."""
    bx = min(max(tail_x, x + 18), x + w - 30)
    return (f'<path d="M{x + 14} {y} H{x + w - 14} Q{x + w} {y} {x + w} {y + 14} V{y + h - 14} '
            f'Q{x + w} {y + h} {x + w - 14} {y + h} H{bx + 22} L{tail_x} {tail_y} L{bx + 6} {y + h} '
            f'H{x + 14} Q{x} {y + h} {x} {y + h - 14} V{y + 14} Q{x} {y} {x + 14} {y} Z"/>' + inside)


def note_icon(x, y, s=1.0):
    """A musical note."""
    return g(f'<ellipse cx="0" cy="0" rx="7" ry="5.5" transform="rotate(-20)" fill="{INK}"/>'
             '<path d="M6 -2 V-30 q12 4 12 16" fill="none"/>', x, y, s)


def flower(x, y, r=9, stem=26, sw=1.8):
    petals = ''.join(f'<circle cx="{x + r * math.cos(a):.1f}" cy="{y + r * math.sin(a):.1f}" r="{r * .62:.1f}" '
                     f'stroke-width="{sw}"/>' for a in [i * math.pi * 2 / 5 - math.pi / 2 for i in range(5)])
    st = (f'<path d="M{x} {y + r} V{y + r + stem}" fill="none" stroke-width="{sw}"/>'
          f'<path d="M{x} {y + r + stem * .6} q{r * .9} {-r * .9} {r * 1.5} {-r * .5} q{-r * .4} {r * .9} {-r * 1.5} {r * .5} Z" '
          f'stroke-width="{sw}"/>') if stem else ''
    return st + petals + f'<circle cx="{x}" cy="{y}" r="{r * .45:.1f}" stroke-width="{sw}"/>'


def cup_side(x, y, s=1.0, tea=False):
    """A mug standing on (x, y), seen from the side."""
    b = ('<path d="M12 -12 q12 0 12 9 q0 9 -12 9" fill="none"/>'
         '<path d="M-14 -24 H14 L12 0 Q12 4 8 4 H-8 Q-12 4 -12 0 Z"/>'
         '<ellipse cx="0" cy="-24" rx="14" ry="3.5"/>')
    if tea:
        b = '<ellipse cx="0" cy="6" rx="24" ry="5"/>' + b + thin('M-4 -32 q-5 -6 0 -12 q5 -6 0 -12 M5 -32 q-5 -6 0 -12')
    return g(b, x, y, s)


def cat(x, y, s=1.0):
    """A sitting cat, bottom at (x, y)."""
    return g('<path d="M16 -4 q22 2 18 -22" fill="none"/>'
             '<path d="M-16 0 Q-20 -30 -8 -38 H8 Q20 -30 16 0 Z"/>'
             '<path d="M-14 -40 L-12 -62 L-4 -54 H4 L12 -62 L14 -40 Q14 -28 0 -28 Q-14 -28 -14 -40 Z"/>'
             + dot(-5, -44, 1.8) + dot(5, -44, 1.8)
             + thin('M-2 -38 l2 2 l2 -2 M-6 0 v-10 M6 0 v-10'), x, y, s)


def toy_car(x, y, s=1.0, flip=False):
    """A little toy car, wheels resting on y, centred on x."""
    b = ('<path d="M-36 -12 V-24 Q-36 -28 -30 -28 H-18 L-8 -44 H16 L28 -28 H32 Q38 -28 38 -22 V-12 Z"/>'
         + thin('M-4 -40 V-28 M-10 -28 L-4 -40 H14 L22 -28 Z')
         + '<circle cx="-20" cy="-10" r="9"/><circle cx="22" cy="-10" r="9"/>'
         + dot(-20, -10, 2.4) + dot(22, -10, 2.4))
    t = f'translate({x} {y}) scale({-s if flip else s} {s})'
    return f'<g transform="{t}">{b}</g>'


def plate_top(x, y, rx=26, ry=15):
    return (f'<ellipse cx="{x}" cy="{y}" rx="{rx}" ry="{ry}"/>'
            f'<ellipse cx="{x}" cy="{y}" rx="{rx * .66:.1f}" ry="{ry * .62:.1f}" fill="none" stroke-width="1.6"/>')


def fork(x, y, s=1.0):
    return g('<path d="M0 -16 V14" fill="none" stroke-width="3"/>'
             '<path d="M-4 -24 V-15 Q-4 -12 0 -12 Q4 -12 4 -15 V-24 M0 -24 V-13" fill="none" stroke-width="1.6"/>', x, y, s)


def knife(x, y, s=1.0):
    return g('<path d="M0 -2 V14" fill="none" stroke-width="3"/>'
             '<path d="M-2 -2 V-22 Q3 -20 3 -8 V-2 Z" stroke-width="1.6"/>', x, y, s)


def cup_top(x, y, r=8):
    return f'<circle cx="{x}" cy="{y}" r="{r}"/><circle cx="{x}" cy="{y}" r="{r * .6:.1f}" fill="none" stroke-width="1.4"/>'


def place(x, y, cutlery=True, cup=True, plate=True):
    s = plate_top(x, y) if plate else ''
    if cutlery:
        s += fork(x - 36, y + 2, .8) + knife(x + 36, y + 2, .8)
    if cup:
        s += cup_side(x + 36, y - 20, .55)
    return s


TCX, TCY, TRX, TRY = 200, 196, 168, 64


def table(cx=TCX, cy=TCY, rx=TRX, ry=TRY):
    """A round table seen from slightly above, legs showing below."""
    return (f'<path d="M{cx - rx * .6:.1f} {cy + ry * .5:.1f} V{cy + ry + 26} M{cx + rx * .6:.1f} {cy + ry * .5:.1f} '
            f'V{cy + ry + 26}" fill="none" stroke-width="5"/>'
            f'<path d="M{cx - rx} {cy} V{cy + 8} A{rx} {ry} 0 0 0 {cx + rx} {cy + 8} V{cy}"/>'
            f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}"/>')


def note_card(x, y, w=200, h=150, rows=3, n=(5, 4, 3)):
    """A card lying slightly tilted, with joined-up 'writing' rows."""
    s = f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="3"/>'
    for i in range(rows):
        s += scribble(x + 22, y + 42 + i * 34, n[i] if i < len(n) else 3, 26)
    return s


def postbox(x, y):
    """A round-topped post box standing on y, centred on x."""
    return (f'<rect x="{x - 46}" y="{y - 8}" width="92" height="12" rx="2"/>'
            f'<path d="M{x - 38} {y - 8} V{y - 150} Q{x - 38} {y - 196} {x} {y - 196} Q{x + 38} {y - 196} {x + 38} {y - 150} '
            f'V{y - 8} Z"/>'
            f'<path d="M{x - 42} {y - 150} H{x + 42}" fill="none" stroke-width="3"/>'
            f'<rect x="{x - 22}" y="{y - 134}" width="44" height="10" rx="4" fill="{INK}"/>'
            f'<rect x="{x - 16}" y="{y - 90}" width="32" height="24" rx="2" fill="none" stroke-width="1.6"/>')


def envelope(x, y, w=56, h=36, rot=0):
    return g(f'<rect x="{-w / 2}" y="{-h / 2}" width="{w}" height="{h}" rx="2"/>'
             + thin(f'M{-w / 2} {-h / 2} L0 {h * .1} L{w / 2} {-h / 2}'), x, y, 1, rot)


def shoe(x, y, s=1.0, rot=0, flip=False):
    """A trainer seen from the side, sole on y, toe to the right (left when flipped)."""
    b = ('<path d="M-22 0 V-22 Q-22 -26 -17 -26 H-4 Q0 -18 6 -16 L18 -12 Q26 -10 26 -4 V0 Z"/>'
         + thin('M-22 -5 H26 M-2 -20 l4 4 M2 -22 l4 4'))
    t = f'translate({x} {y}) rotate({rot}) scale({-s if flip else s} {s})'
    return f'<g transform="{t}">{b}</g>'


def pair(x, y, s=1.0):
    """A neat pair of shoes, one just behind the other."""
    return shoe(x + 6, y - 8, s) + shoe(x, y, s)


def door(x=150, y=34, w=110, h=206):
    return (f'<rect x="{x - 10}" y="{y - 10}" width="{w + 20}" height="{h + 10}" fill="none"/>'
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}"/>'
            f'<rect x="{x + 16}" y="{y + 18}" width="{w - 32}" height="{h * .36:.0f}" fill="none" stroke-width="1.6"/>'
            f'<rect x="{x + 16}" y="{y + h * .5:.0f}" width="{w - 32}" height="{h * .38:.0f}" fill="none" stroke-width="1.6"/>'
            f'<circle cx="{x + w - 14}" cy="{y + h * .46:.0f}" r="5"/>')


def crayon(tx, ty, a=0, s=1.0):
    """A crayon with its tip at (tx, ty), body going off at a degrees."""
    return g('<path d="M0 0 L16 -6 V6 Z"/><rect x="16" y="-7" width="64" height="14" rx="2"/>'
             + thin('M26 -7 V7 M70 -7 V7') + '<path d="M3 -1 L3 1" stroke-width="3"/>', tx, ty, s, a)


def crayon_held(tx, ty, a=-40):
    r = math.radians(a)
    return crayon(tx, ty, a) + grip(tx + 46 * math.cos(r), ty + 46 * math.sin(r), a + 180 - 60)


def pen(tx, ty, a=0):
    return g('<path d="M0 0 L12 -4 V4 Z"/><rect x="12" y="-6" width="10" height="12" rx="1"/>'
             '<rect x="22" y="-7" width="62" height="14" rx="3"/>' + thin('M66 -7 V7'), tx, ty, 1, a)


def pen_held(tx, ty, a=-40):
    r = math.radians(a)
    return pen(tx, ty, a) + grip(tx + 44 * math.cos(r), ty + 44 * math.sin(r), a + 180 - 60)


def thumbs_up(x, y, s=1.0):
    """A thumbs-up fist, wrist at (x, y)."""
    return g('<path d="M-12 0 V-30 H8 Q18 -30 18 -22 V-6 Q18 0 10 0 Z"/>'
             '<path d="M-12 -28 Q-12 -40 -4 -50 Q0 -58 6 -52 Q8 -46 4 -38 L2 -30" />'
             + thin('M-12 -20 H16 M-12 -12 H16'), x, y, s)


def heart_path(cx, cy, s):
    return (f'M{cx} {cy + s * .8} C{cx - s * 1.4} {cy - s * .1} {cx - s * .6} {cy - s * 1.1} {cx} {cy - s * .4} '
            f'C{cx + s * .6} {cy - s * 1.1} {cx + s * 1.4} {cy - s * .1} {cx} {cy + s * .8}')


def sparkle(x, y, r=10):
    return motion(f'M{x} {y - r} V{y - r * .4} M{x} {y + r * .4} V{y + r} M{x - r} {y} H{x - r * .4} '
                  f'M{x + r * .4} {y} H{x + r}')


def burst(x, y, r0, r1, angles):
    """Short dashed rays round (x, y): laughter, shouting, shine."""
    return motion(*[f'M{x + r0 * math.cos(math.radians(a)):.1f} {y + r0 * math.sin(math.radians(a)):.1f} '
                    f'L{x + r1 * math.cos(math.radians(a)):.1f} {y + r1 * math.sin(math.radians(a)):.1f}'
                    for a in angles])


def sofa(x0=30, x1=262, seat=196, floor=256):
    return (f'<path d="M{x0 + 16} {floor - 14} v14 M{x1 - 16} {floor - 14} v14" fill="none" stroke-width="5"/>'
            f'<rect x="{x0 + 14}" y="{seat - 86}" width="{x1 - x0 - 28}" height="96" rx="14"/>'
            f'<rect x="{x0 + 18}" y="{seat}" width="{x1 - x0 - 36}" height="{floor - 14 - seat}" rx="8"/>'
            f'<rect x="{x0}" y="{seat - 30}" width="30" height="{floor - 14 - seat + 30}" rx="12"/>'
            f'<rect x="{x1 - 30}" y="{seat - 30}" width="30" height="{floor - 14 - seat + 30}" rx="12"/>')


def sofa_sitter(cx, seat, floor, who='adult', mouth='flat', eyes='tired', arms=None):
    """A grown-up sitting on the sofa seat, seen from the front."""
    leg = floor - seat
    b = (f'<rect x="-20" y="-6" width="18" height="18" rx="6"/><rect x="2" y="-6" width="18" height="18" rx="6"/>'
         f'<rect x="-17" y="8" width="12" height="{leg - 8}" rx="3"/><rect x="5" y="8" width="12" height="{leg - 8}" rx="3"/>'
         f'<ellipse cx="-11" cy="{leg}" rx="11" ry="5"/><ellipse cx="11" cy="{leg}" rx="11" ry="5"/>')
    top = 70
    body = f'<path d="M-24 4 L-20 {-top + 4} Q0 {-top - 4} 20 {-top + 4} L24 4 Z"/>'
    head = f'<rect x="-5" y="{-top - 6}" width="10" height="8"/>' + face(0, -top - 26, 24, mouth, eyes, who)
    arms = arms if arms is not None else [(-1, -26, -4), (1, 26, -4)]
    a = ''.join(_arm(18 * s_, -top + 8, ex, ey) for s_, ex, ey in arms)
    return g(body + b + head + a, cx, seat)


# ── Make someone in the family laugh ─────────────────────────────────────
D[key('Make someone in the family laugh')] = [
    bubble(inside=face(176, 122, 30, 'tongue', 'wink', 'none')
           + note_icon(242, 140) + note_icon(276, 112, .9) + note_icon(300, 140, .8)),

    ground(256) + sofa() + sofa_sitter(146, 196, 256)
    + person(330, 256, .95, arms=[(-1, -50, -96, -36, -96), (1, 30, -44)])
    + arrow('M266 112 C246 86 222 86 196 98', dashed=True),

    ground(262)
    + person(200, 262, 1.1, arms=[(-1, -54, -150, -44, -110), (1, 54, -150, 44, -110)],
             mouth='tongue', eyes='wink', tilt=-8)
    + motion('M126 120 q-12 12 0 24 q12 12 0 24', 'M276 120 q12 12 0 24 q-12 12 0 24'),

    ground(262)
    + person(118, 262, 1.0, arms=[(-1, -30, -44), (1, 46, -60)], mouth='laugh', eyes='happy')
    + person(272, 262, .95, who='adult', arms=[(-1, -36, -76), (1, 34, -62)], mouth='laugh', eyes='happy')
    + burst(272, 101, 34, 48, (-150, -115, -65, -30))
    + burst(118, 136, 32, 44, (-150, -115, -65)),
]


# ── Help set the table without being asked ───────────────────────────────
def _bust(x, y, r, who):
    return (f'<path d="M{x - r * 1.3:.1f} {y + r * 2.1:.1f} Q{x - r * 1.3:.1f} {y + r * 1.05:.1f} {x} {y + r * 1.05:.1f} '
            f'Q{x + r * 1.3:.1f} {y + r * 1.05:.1f} {x + r * 1.3:.1f} {y + r * 2.1:.1f}"/>'
            + face(x, y, r, 'smile', 'dot', who))


def _open_hand(x, y, s=1.0, n=4):
    """A hand held up, palm out, n fingers up and the rest folded."""
    fing = ''
    xs = (-12, -4, 4, 12)
    for i, fx in enumerate(xs):
        hgt = (20, 24, 23, 18)[i] if i < n else 6
        fing += f'<rect x="{fx - 3.6}" y="{-12 - hgt}" width="7.2" height="{hgt + 6}" rx="3.6"/>'
    palm = '<path d="M-16 -12 H16 V4 Q16 16 4 16 H-6 Q-16 16 -16 6 Z"/>'
    thumb = '<path d="M-15 0 Q-26 -6 -24 -14 Q-20 -18 -14 -10" />'
    return g(fing + thumb + palm, x, y, s)


_family_counted = (person(226, 256, .62, who='adult') + person(270, 256, .62, who='gran')
                   + person(312, 256, .62) + person(350, 256, .55, who='sib'))

D[key('Help set the table without being asked')] = [
    ground(256)
    + person(110, 256, 1.05, arms=[(-1, -30, -44), (1, 44, -126, 40, -96, False)])
    + _open_hand(160, 113, 1.1)
    + _family_counted
    + motion('M226 132 q22 -26 44 0', 'M270 132 q21 -26 42 0', 'M312 132 q19 -20 38 6'),

    person(118, 160, 1.0, arms=[(-1, -30, -44), (1, 92, -28, 70, -70)])
    + table()
    + plate_top(68, 204) + plate_top(200, 238) + plate_top(240, 158)
    + plate_top(210, 128, 26, 15) + '<circle cx="212" cy="134" r="6"/>'
    + ghost('M306 204 m-26 0 a26 15 0 1 0 52 0 a26 15 0 1 0 -52 0')
    + arrow('M244 136 C286 136 304 160 306 182'),

    table()
    + place(84, 202) + place(200, 236) + place(316, 202) + place(200, 160, cup=False)
    + ghost('M228 140 H244 L243 127 H229 Z')
    + cup_side(300, 70, 1.0)
    + arrow('M286 84 C270 98 252 108 240 118'),

    ground(268)
    + person(72, 268, 1.0, arms=[(-1, -30, -44), (1, 26, -112, 40, -100)], mouth='talk')
    + table(262, 222, 112, 40)
    + plate_top(182, 222, 20, 11) + plate_top(262, 246, 20, 11) + plate_top(342, 222, 20, 11)
    + plate_top(262, 198, 20, 11)
    + motion('M110 128 q14 14 0 28', 'M124 116 q22 26 0 52', 'M138 104 q30 38 0 76')
    + arrow('M168 150 C200 130 232 136 248 160', dashed=True),
]


# ── Write a thank-you note to someone ────────────────────────────────────
_board = '<rect x="140" y="88" width="46" height="34" rx="2"/>' + thin('M148 100 q6 -6 12 0 t12 0 M148 112 q6 -6 12 0 t12 0')

CX0, CY0 = 92, 64

D[key('Write a thank-you note to someone')] = [
    bubble(inside=_board + _bust(196, 110, 20, 'adult') + heart(246, 116, 14) + _bust(290, 110, 20, 'gran')),

    note_card(CX0, CY0, 216, 156, rows=3, n=(6, 5, 2))
    + pen_held(178, CY0 + 110, -40)
    + arrow(f'M{CX0 + 30} {CY0 + 134} H{CX0 + 76}'),

    note_card(CX0, CY0, 216, 156, rows=2, n=(6, 5))
    + heart(CX0 + 50, CY0 + 118, 14) + flower(CX0 + 104, CY0 + 108, 8, 22)
    + pen_held(CX0 + 140, CY0 + 116, -40)
    + motion(f'M{CX0 + 152} {CY0 + 96} l6 -8', f'M{CX0 + 160} {CY0 + 112} l10 -2'),

    ground(262) + postbox(280, 262)
    + person(110, 262, 1.0, arms=[(-1, -30, -44), (1, 122, -128, 80, -110)])
    + envelope(242, 134, 50, 32, -6)
    + '<circle cx="232" cy="134" r="6"/>'
    + arrow('M192 102 C214 90 240 92 264 112'),
]


# ── Give three people a compliment today ─────────────────────────────────
D[key('Give three people a compliment today')] = [
    bubble(inside=face(192, 122, 30, 'grin', 'dot', 'none') + heart(270, 124, 24)),

    ground(262)
    + person(110, 262, 1.0, arms=[(-1, -30, -44), (1, 34, -50)], mouth='talk')
    + person(300, 262, .82, who='sib', mouth='grin', eyes='happy')
    + speech(144, 28, 92, 62, 140, 112, heart(190, 60, 15))
    + sparkle(352, 104, 10) + arrow('M240 66 C262 70 270 82 278 94', dashed=True),

    ground(262)
    + person(110, 262, 1.0, arms=[(-1, -30, -44), (1, 48, -104, 46, -76, False)])
    + thumbs_up(158, 162, 1.0)
    + person(296, 262, .95, who='adult', mouth='grin', eyes='happy', arms=[(-1, -30, -60), (1, 30, -60)])
    + arrow('M174 104 C200 80 226 80 248 94', dashed=True),

    face(90, 160, 44, 'grin', 'happy', 'child') + face(200, 150, 50, 'grin', 'happy', 'adult')
    + face(310, 160, 44, 'grin', 'happy', 'sib')
    + heart(90, 80, 12) + heart(200, 62, 14) + heart(310, 80, 12)
    + sparkle(36, 110, 10) + sparkle(364, 110, 10) + sparkle(145, 236, 9) + sparkle(255, 236, 9),
]


# ── Tidy something that isn't yours ──────────────────────────────────────
_mat = '<path d="M134 246 H276 L286 262 H124 Z"/>'
_messy = (shoe(92, 254, 1.0, -20) + shoe(118, 262, 1.0, 10, True) + shoe(300, 260, 1.0, 160)
          + shoe(326, 262, 1.0) + shoe(158, 270, .95, -6, True) + shoe(244, 274, 1.0, 14))

D[key("Tidy something that isn't yours")] = [
    motion('M200 222 C330 216 380 236 366 266 C350 290 80 292 46 272 C22 254 60 222 200 222')
    + door(150, 30, 110, 210) + ground(246, 24, 376) + _mat + _messy,

    ground(262)
    + person(110, 262, 1.0, arms=[(-1, -30, -44), (1, 42, -132, 40, -100)], mouth='talk')
    + speech(150, 32, 96, 64, 140, 112, pair(194, 76, .95))
    + person(306, 262, .95, who='adult', arms=[(-1, -30, -60), (1, 30, -60)])
    + motion('M268 102 q-8 16 0 32', 'M344 102 q8 16 0 32'),

    ground(232) + pair(66, 232) + pair(140, 232) + shoe(214, 232)
    + ghost('M246 224 V202 Q246 198 251 198 H264 Q268 206 274 208 L286 212 Q294 214 294 220 V224 Z')
    + grip(296, 134, 80) + shoe(304, 156, 1.1, -10)
    + arrow('M318 168 C314 184 296 194 278 198'),

    door(150, 30, 110, 210) + ground(246, 24, 376) + _mat
    + pair(52, 246) + pair(102, 246) + pair(302, 246) + pair(352, 246)
    + sparkle(80, 196, 10) + sparkle(330, 196, 10),
]


# ── Draw a picture for a grandparent ─────────────────────────────────────
PX0, PY0, PW, PH = 96, 50, 208, 168


def _paper(fl=2, sun_=False, words=False):
    s = f'<rect x="{PX0}" y="{PY0}" width="{PW}" height="{PH}" rx="2"/>'
    s += ''.join(flower(PX0 + 40 + i * 52, PY0 + 70, 12, 46) for i in range(fl))
    s += thin(f'M{PX0 + 14} {PY0 + 130} H{PX0 + PW - 14}')
    if sun_:
        s += sun(PX0 + PW - 36, PY0 + 34, 12)
    return s


D[key('Draw a picture for a grandparent')] = [
    bubble(inside=flower(170, 104, 11, 34) + flower(196, 116, 9, 24) + cup_side(244, 146, 1.1, tea=True)
           + cat(298, 158, .9), who='child'),

    _paper(2, True)
    + flower(PX0 + 144, PY0 + 70, 12, 0)
    + ghost(f'M{PX0 + 144} {PY0 + 104} V{PY0 + 128}')
    + crayon_held(PX0 + 144, PY0 + 102, -40)
    + arrow(f'M{PX0 + 128} {PY0 + 84} V{PY0 + 120}'),

    _paper(2, True)
    + scribble(PX0 + 24, PY0 + 156, 4, 26) + heart(PX0 + 186, PY0 + 150, 9)
    + pen_held(PX0 + 130, PY0 + 154, -40)
    + arrow(f'M{PX0 + 30} {PY0 + 184} H{PX0 + 120}'),

    ground(262)
    + person(110, 262, 1.0, arms=[(-1, -30, -44), (1, 72, -84, 52, -110)])
    + '<rect x="180" y="132" width="56" height="72" rx="2"/>' + flower(200, 154, 7, 20, 1.6) + sun(222, 148, 6)
    + '<circle cx="182" cy="178" r="6"/>'
    + person(306, 262, .95, who='gran', mouth='grin', arms=[(-1, -64, -88, -50, -110), (1, 30, -60)])
    + motion(heart_path(208, 64, 16))
    + arrow('M164 120 C176 100 186 96 192 96')
    + arrow('M224 96 C232 96 242 102 250 112'),
]


# ── Share a toy with your brother or sister ──────────────────────────────
D[key('Share a toy with your brother or sister')] = [
    ground(266)
    + person(200, 266, 1.05, arms=[(-1, -44, -58, -50, -80, False), (1, 44, -58, 50, -80, False)])
    + toy_car(200, 232, 1.25)
    + '<circle cx="154" cy="205" r="6.5"/><circle cx="248" cy="205" r="6.5"/>'
    + sparkle(116, 170, 12) + sparkle(286, 170, 12),

    ground(262)
    + person(110, 262, 1.0, arms=[(-1, -30, -44), (1, 78, -84, 56, -110)])
    + toy_car(206, 184, .9) + '<circle cx="188" cy="178" r="6"/>'
    + person(310, 262, .8, who='sib', mouth='grin', arms=[(-1, -48, -76, -40, -100), (1, 30, -44)])
    + arrow('M174 126 C206 104 240 110 260 140'),

    ground(226)
    + sitter(86, 226, 1.0, arms=[(-1, -30, -26), (1, 78, -14, 60, -40)], mouth='grin')
    + toy_car(200, 226, 1.0)
    + sitter(314, 226, .86, who='sib', mouth='grin', eyes='happy', arms=[(-1, -40, -26), (1, 30, -26)])
    + arrow('M170 160 C196 144 222 144 246 160'),

    ground(220)
    + sitter(86, 220, 1.0, mouth='grin', eyes='happy')
    + sitter(314, 220, .86, who='sib', mouth='grin', eyes='happy')
    + toy_car(200, 220, .9)
    + arrow('M146 150 C180 122 222 122 256 150')
    + arrow('M256 246 C222 270 178 270 146 246'),
]
