"""Builds build/review/index.html, the page the parent checks diagrams on,
from whatever has been drawn into build/diagrams.

    python3 tool/diagrams/review_page.py
"""
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
sys.path.insert(0, str(ROOT / 'tool'))
from build_site import KINDS, catalog  # noqa: E402

WORK = ROOT / 'build/diagrams'


def main():
    items = []
    for c in catalog():
        k = c['key']
        pics = [WORK / f'{k}_{i}.webp' for i in range(1, len(c['steps']) + 1)]
        if not all(p.exists() for p in pics):
            continue
        v = hashlib.sha1(b''.join((WORK / f'{k}_{i}.svg').read_bytes() for i in range(1, len(pics) + 1))).hexdigest()[:10]
        items.append({'key': k, 'title': c['title'], 'cat': c['cat'], 'steps': c['steps'], 'v': v})
    page = (HERE / 'review_template.html').read_text()
    page = page.replace('/*ITEMS*/[]', json.dumps(items, ensure_ascii=False))
    page = page.replace('/*KINDS*/{}', json.dumps(KINDS, ensure_ascii=False))
    out = ROOT / 'build/review/index.html'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(page)
    files = {f'img/{k["key"]}_{i}.webp': str(WORK / f'{k["key"]}_{i}.webp')
             for k in items for i in range(1, len(k['steps']) + 1)}
    (out.parent / 'files.json').write_text(json.dumps(files, indent=1))
    print(f'Wrote {out.relative_to(ROOT)} with {len(items)} challenges, {len(files)} pictures')


if __name__ == '__main__':
    main()
