"""Diagrams for the last Drawing challenges (underwater city, T-shirt, dragon,
drawing with your other hand, a movie poster, a picture for the fridge).
Paper is a sheet seen slightly from above with the child's drawing on it in
plain ink lines; colouring in is shown as hatching. The blue accent is only
for arrows and dashed motion lines."""
import math
import random
import re

from style import arrow, dot, ghost, ground, motion, thin
from craft import scribble, sun
from craft_3 import hold_pen, limb, mitt, star
from kind import cat, crayon, crayon_held, face, g, person, speech, sparkle, toy_car
from kind_2 import qmark
from kind_3 import bed

D = {}


def key(title):
    return re.sub(r'[^a-z0-9]+', '_', title.lower()).strip('_')[:48]


# ── Shared bits ──────────────────────────────────────────────────────────
_clip = [0]


def sheet(x0, y0, x1, y1, k=12):
    """A sheet of paper seen slightly from above: the far edge a little narrower."""
    return (f'<path d="M{x0} {y1 + 4} H{x1}" fill="none" stroke-width="1.4"/>'
            f'<polygon points="{x0 + k},{y0} {x1 - k},{y0} {x1},{y1} {x0},{y1}"/>')


def sheet_pts(x0, y0, x1, y1, k=12):
    return f'{x0 + k},{y0} {x1 - k},{y0} {x1},{y1} {x0},{y1}'


def clipped(pts, body, extra=''):
    """body clipped to the polygon pts (and to the shapes in extra, if given)."""
    _clip[0] += 1
    i = _clip[0]
    s = f'<clipPath id="k{i}"><polygon points="{pts}"/></clipPath>'
    inner = body
    if extra:
        s += f'<clipPath id="e{i}">{extra}</clipPath>'
        inner = f'<g clip-path="url(#e{i})">{body}</g>'
    return s + f'<g clip-path="url(#k{i})">{inner}</g>'


def hatch(x0, y0, x1, y1, gap=9, sw=1.3):
    """Diagonal colouring-in lines over a box (clip them to a shape)."""
    d = ''
    w, h = x1 - x0, y1 - y0
    t = -h
    while t < w:
        d += f'M{x0 + t:.1f} {y1} L{x0 + t + h:.1f} {y0} '
        t += gap
    return f'<path d="{d}" fill="none" stroke-width="{sw}"/>'


def waves(x0, x1, y, amp=3, wl=22):
    d = f'M{x0} {y}'
    x, up = x0, 1
    while x + wl / 2 <= x1:
        d += f' q{wl / 4} {-amp * up * 2} {wl / 2} 0'
        x += wl / 2
        up = -up
    return d


def wob(pts, seed=1, amp=2.4, closed=False):
    """A shaky line through pts, as drawn with the wrong hand."""
    rnd = random.Random(seed)
    if closed:
        pts = pts + [pts[0]]
    out = []
    for (ax, ay), (bx, by) in zip(pts, pts[1:]):
        n = max(2, int(math.hypot(bx - ax, by - ay) / 9))
        for i in range(n):
            t = i / n
            j = amp if 0 < i else amp * .4
            out.append((ax + (bx - ax) * t + rnd.uniform(-j, j), ay + (by - ay) * t + rnd.uniform(-j, j)))
    out.append(pts[-1])
    d = f'M{out[0][0]:.1f} {out[0][1]:.1f} ' + ' '.join(f'L{x:.1f} {y:.1f}' for x, y in out[1:])
    return f'<path d="{d}" fill="none" stroke-width="2"/>'


def pencil(x, y, rot=0, s=1.0):
    """A pencil with its point at (x, y), lying along rot."""
    return (f'<g transform="translate({x} {y}) rotate({rot}) scale({s})">'
            '<path d="M0 0 L16 -7 V7 Z"/><path d="M0 0 L5 -2.2 V2.2 Z" fill="#1d1d1f"/>'
            '<rect x="16" y="-7" width="54" height="14"/>'
            '<path d="M16 0 H70" fill="none" stroke-width="1.4"/>'
            '<rect x="70" y="-7" width="8" height="14"/><rect x="78" y="-7" width="10" height="14" rx="4"/></g>')


def hold_crayon(tx, ty, a, turn=60, flip=False):
    from craft_3 import grip
    r = math.radians(a)
    return crayon(tx, ty, a) + grip(tx + 46 * math.cos(r), ty + 46 * math.sin(r),
                                    a + 180 + (-turn if flip else turn), flip=flip)


def hold_pencil(tx, ty, a, turn=60, flip=False):
    from craft_3 import grip
    r = math.radians(a)
    return pencil(tx, ty, a) + grip(tx + 40 * math.cos(r), ty + 40 * math.sin(r),
                                    a + 180 + (-turn if flip else turn), flip=flip)


# ── Draw an underwater city ──────────────────────────────────────────────
UX0, UY0, UX1, UY1 = 60, 34, 340, 250
UPTS = sheet_pts(UX0, UY0, UX1, UY1)
SAND = 212


def _sea(rows_upto=None, part_x=None):
    """Wavy sea lines over the page; rows_upto/part_x show it half done."""
    d = ''
    y = UY0 + 14
    while y < SAND:
        if rows_upto is not None and y > rows_upto:
            break
        x1 = UX1 + 10
        if rows_upto is not None and y + 16 > rows_upto and part_x is not None:
            x1 = part_x
        d += waves(UX0 - 10, x1, y) + ' '
        y += 16
    return clipped(UPTS, f'<path d="{d}" fill="none" stroke-width="1.4"/>')


def _sand():
    d = f'M{UX0 + 2} {SAND} q20 -8 40 -2 q24 6 46 -2 q26 -8 50 0 q24 6 48 -2 q22 -6 44 0 q24 6 48 -2'
    s = clipped(UPTS, f'<path d="{d} V{UY1} H{UX0} Z" stroke="none"/>' + thin(d))
    s += ''.join(dot(x, y, 1.4) for x, y in ((92, 228), (130, 238), (176, 226), (214, 238), (262, 228),
                                               (300, 240), (110, 244), (240, 244), (320, 226)))
    return s


def dome(cx, by, r):
    s = f'<path d="M{cx - r} {by} A{r} {r * .9} 0 0 1 {cx + r} {by} Z"/>'
    s += f'<circle cx="{cx}" cy="{by - r * .45:.1f}" r="{r * .22:.1f}" stroke-width="1.6"/>'
    s += thin(f'M{cx - r * .7:.1f} {by - r * .35:.1f} q{r * .1:.1f} {-r * .35:.1f} {r * .35:.1f} {-r * .55:.1f}')
    return s + f'<rect x="{cx - 6}" y="{by - 14}" width="12" height="14" rx="5" stroke-width="1.6"/>'


def tower(cx, by, w, h):
    s = (f'<path d="M{cx - w / 2} {by} V{by - h + w / 2} A{w / 2} {w / 2} 0 0 1 {cx + w / 2} {by - h + w / 2} V{by} Z"/>'
         f'<path d="M{cx} {by - h} V{by - h - 12}" fill="none" stroke-width="1.6"/>' + dot(cx, by - h - 14, 3))
    for i in range(int((h - w) // 22)):
        s += f'<circle cx="{cx}" cy="{by - 20 - i * 22}" r="5" stroke-width="1.6"/>'
    return s


def _city(last=True):
    s = (tower(110, SAND + 2, 26, 104) + dome(158, SAND + 2, 34)
         + tower(214, SAND - 2, 30, 140) + dome(270, SAND - 2, 30)
         + thin(f'M188 {SAND - 18} H199 M229 {SAND - 24} H242'))
    return s + (tower(312, SAND, 20, 76) if last else '')


def fish(x, y, s=1.0, flip=False):
    t = f'translate({x} {y}) scale({-s if flip else s} {s})'
    return (f'<g transform="{t}"><path d="M-12 0 L-24 -9 V9 Z"/><ellipse cx="0" cy="0" rx="15" ry="9"/>'
            + dot(8, -2, 1.8) + thin('M-3 -7 q4 7 0 14') + '</g>')


def octopus(x, y, s=1.0):
    legs = ''.join(f'<path d="M{x0} 4 c{dx * .2} 8 {dx * .9} 6 {dx} 14 c{dx * .1} 6 {-dx * .3} 9 {-dx * .5} 6" '
                   f'fill="none" stroke-width="3"/>'
                   for x0, dx in ((-14, -12), (-6, -6), (6, 6), (14, 12)))
    return g(legs + '<path d="M-18 6 Q-22 -26 0 -26 Q22 -26 18 6 Z"/>'
             + dot(-6, -8, 2) + dot(6, -8, 2) + thin('M-4 0 q4 4 8 0'), x, y, s)


def bubbles(x, y, rs=(5, 4, 3)):
    return ''.join(f'<circle cx="{x + (i % 2) * 5}" cy="{y - i * 13}" r="{r}" stroke-width="1.6"/>'
                   for i, r in enumerate(rs))


def sub(x, y, s=1.0):
    """A little submarine facing left."""
    return g('<path d="M30 -6 L42 -14 V2 Z"/>'
             '<rect x="-6" y="-38" width="22" height="18" rx="4"/><path d="M4 -38 V-48 H-6" fill="none"/>'
             '<ellipse cx="0" cy="-8" rx="36" ry="17"/>'
             '<circle cx="-16" cy="-8" r="5" stroke-width="1.6"/><circle cx="0" cy="-8" r="5" stroke-width="1.6"/>'
             '<circle cx="16" cy="-8" r="5" stroke-width="1.6"/>', x, y, s)


D[key('Draw an underwater city')] = [
    sheet(UX0, UY0, UX1, UY1) + _sea(UY0 + 14 + 16 * 6, 226)
    + crayon_held(226, UY0 + 14 + 16 * 6, -40)
    + arrow(f'M100 {UY0 + 136} H196'),

    sheet(UX0, UY0, UX1, UY1) + _sea() + _sand() + _city(False)
    + f'<path d="M302 {SAND} V{SAND - 40}" fill="none"/>'
    + f'<path d="M302 {SAND - 40} V{SAND - 66} A10 10 0 0 1 322 {SAND - 66} V{SAND}" fill="none" stroke="#fff" stroke-width="6"/>'
    + ghost(f'M302 {SAND - 40} V{SAND - 66} A10 10 0 0 1 322 {SAND - 66} V{SAND}')
    + hold_pen(302, SAND - 42, -50)
    + arrow(f'M288 {SAND - 6} V{SAND - 50}'),

    sheet(UX0, UY0, UX1, UY1) + _sea() + _sand() + _city()
    + octopus(268, 146, 1.1) + fish(150, 84) + fish(290, 70, .8, True) + fish(166, 140, .7)
    + bubbles(250, 98) + bubbles(286, 108, (3, 4)) + bubbles(96, 104, (4, 3))
    + motion('M124 84 H104', 'M310 70 H326')
    + arrow('M120 72 C140 54 170 54 190 70', dashed=True),

    sheet(UX0, UY0, UX1, UY1) + _sea() + _sand() + _city()
    + octopus(268, 146, 1.1) + fish(166, 140, .7)
    + sub(150, 82) + bubbles(204, 72, (3, 4))
    + motion('M198 82 H222', 'M196 94 H214')
    + arrow('M110 74 C96 74 84 84 82 98', dashed=True),
]


# ── Design a T-shirt ─────────────────────────────────────────────────────
TX0, TY0, TX1, TY1 = 64, 30, 336, 254
TPTS = sheet_pts(TX0, TY0, TX1, TY1)
TEE = ('M-24 0 Q0 22 24 0 L62 12 L86 48 L58 64 L50 50 V138 H-50 V50 L-58 64 L-86 48 L-62 12 Z')


def tee(cx=200, top=60, s=1.0):
    return f'<path transform="translate({cx} {top}) scale({s})" d="{TEE}"/>'


def tee_line(cx=200, top=60, s=1.0):
    return f'<path transform="translate({cx} {top}) scale({s})" d="{TEE}" fill="none"/>'


def dino(x, y, s=1.0):
    """A friendly little dinosaur facing right, feet at y."""
    return g('<path d="M-30 -14 Q-44 -12 -52 -4 Q-34 -6 -22 -2"/>'
             '<rect x="-16" y="-10" width="9" height="12" rx="3"/><rect x="6" y="-10" width="9" height="12" rx="3"/>'
             '<path d="M-26 -8 Q-28 -34 0 -34 Q14 -34 16 -44 V-56 Q16 -64 26 -64 Q40 -64 40 -54 Q40 -46 28 -46 '
             'Q24 -36 24 -24 Q24 -6 6 -6 Z"/>' + dot(30, -56, 2)
             + thin('M-14 -32 l4 -6 l4 6 M-2 -34 l4 -6 l4 6'), x, y, s)


def _tee_deco():
    return (star(176, 112, 20) + dino(222, 170, .8))


D[key('Design a T-shirt')] = [
    sheet(TX0, TY0, TX1, TY1)
    + f'<path transform="translate(200 56)" d="M-24 0 Q0 22 24 0 L62 12 L86 48 L58 64 L50 50 V96" fill="none"/>'
    + ghost('M250 152 V194 H150 V106 L142 120 L114 104 L138 68 L176 56')
    + hold_pen(250, 152, 40)
    + arrow('M234 120 V170'),

    sheet(TX0, TY0, TX1, TY1)
    + clipped('100,40 236,40 236,210 100,210', hatch(100, 50, 300, 200, 9), tee(200, 56))
    + tee_line(200, 56)
    + hold_crayon(236, 150, 40)
    + arrow('M150 214 H226'),

    sheet(TX0, TY0, TX1, TY1)
    + clipped(TPTS, hatch(100, 50, 300, 200, 9), tee(200, 56))
    + tee_line(200, 56)
    + _tee_deco()
    + sparkle(130, 150, 10) + sparkle(270, 150, 10),

    ground(270)
    + person(150, 270, 1.0, arms=[(-1, -62, -150, -50, -110), (1, 62, -150, 50, -110)], mouth='grin')
    + '<rect x="78" y="22" width="144" height="112" rx="2"/>'
    + clipped('78,22 222,22 222,134 78,134', hatch(80, 26, 220, 134, 6), tee(150, 34, .58))
    + tee_line(150, 34, .58)
    + f'<g transform="translate(150 34) scale(.58) translate(-200 -56)">{_tee_deco()}</g>'
    + '<circle cx="88" cy="130" r="6"/><circle cx="212" cy="130" r="6"/>'
    + person(318, 270, .95, who='adult', arms=[(-1, -30, -50), (1, 30, -50)], mouth='grin')
    + arrow('M234 66 C262 52 280 60 290 76'),
]


# ── Draw a dragon ────────────────────────────────────────────────────────
DX0, DY0, DX1, DY1 = 54, 30, 346, 254
DPTS = sheet_pts(DX0, DY0, DX1, DY1)
BCX, BCY, BRX, BRY = 180, 170, 58, 33
HCX, HCY, HRX, HRY = 268, 98, 26, 18
TAIL = 'M136 184 C104 200 76 190 72 156 C88 176 108 172 128 158 Z'
NECK = 'M214 148 Q228 122 248 106 L270 114 Q250 136 234 168 Z'
WING = 'M208 142 Q208 92 190 52 Q164 80 130 70 Q146 90 118 106 Q150 116 138 134 Q162 128 176 142 Z'
LEGS = [(146, 192), (162, 198), (200, 198), (216, 192)]


def _legs():
    return ''.join(limb(f'M{x} {y - 10} V226', 14) + f'<ellipse cx="{x + 4}" cy="228" rx="10" ry="4.5"/>'
                   for x, y in LEGS)


def _tri(px, py, nx, ny, w=6, h=12):
    tx, ty = -ny, nx
    return (f'<polygon points="{px + tx * w:.1f},{py + ty * w:.1f} {px - tx * w:.1f},{py - ty * w:.1f} '
            f'{px + nx * h:.1f},{py + ny * h:.1f}"/>')


def _spikes():
    s = ''
    for a in (196, 210, 224, 238):  # the back, behind the wing
        r = math.radians(a)
        px, py = BCX + BRX * math.cos(r), BCY + BRY * math.sin(r)
        nx, ny = math.cos(r) / BRX, math.sin(r) / BRY
        k = math.hypot(nx, ny)
        s += _tri(px, py, nx / k, ny / k)
    for t in (.25, .55):  # along the neck
        px, py = 214 + (248 - 214) * t, 148 + (106 - 148) * t - 4 * t
        s += _tri(px, py, -.78, -.62)
    s += _tri(108, 172, -.3, -.95, 5, 10) + _tri(90, 172, -.7, -.7, 5, 10)
    return s


def _head(eye=True):
    s = (f'<polygon points="254,84 256,64 266,82"/><polygon points="270,82 278,64 282,84"/>'
         f'<ellipse cx="{HCX}" cy="{HCY}" rx="{HRX}" ry="{HRY}"/>')
    if eye:
        s += dot(272, 92, 2.8) + thin('M276 108 Q284 110 290 104') + dot(288, 96, 1.6)
    return s


def dragon(stage, colour=False):
    """stage 1: two ovals; 2: neck, tail, legs; 3: wings and spikes."""
    body = f'<ellipse cx="{BCX}" cy="{BCY}" rx="{BRX}" ry="{BRY}"/>'
    if stage == 1:
        return body + f'<ellipse cx="{HCX}" cy="{HCY}" rx="{HRX}" ry="{HRY}"/>'
    s = ''
    if stage >= 3:
        s += _spikes() + f'<path d="{WING}"/>' + thin('M190 52 L122 102 M190 52 L142 130')
    s += f'<path d="{TAIL}"/>' + '<polygon points="72,156 62,140 80,146"/>' + _legs() + body
    if colour:
        s += clipped(DPTS, hatch(60, 100, 280, 210, 9), body + f'<path d="{TAIL}"/>')
    s += f'<path d="{NECK}"/>'
    if colour:
        s += clipped(DPTS, hatch(200, 100, 280, 170, 9), f'<path d="{NECK}"/>')
    return s + _head()


def fire():
    """Flames from the dragon's mouth, pointing right."""
    return ('<g transform="translate(290 107) scale(.85) translate(-290 -107)"><path d="M290 104 C304 98 316 90 328 80 L328 94 L344 90 L334 104 L348 112 L332 116 L340 130 '
            'C322 122 306 114 290 110 Z"/>'
            + '<path d="M302 106 C310 104 316 100 322 96 L322 104 L332 106 L322 112 L326 120 C316 116 310 112 302 110 Z" '
            'stroke-width="1.6"/></g>'
            + motion('M322 76 l6 -8', 'M322 136 l6 8'))


D[key('Draw a dragon')] = [
    sheet(DX0, DY0, DX1, DY1) + dragon(1)
    + hold_pencil(BCX + 50, BCY + 16, 40)
    + arrow('M110 140 C112 114 150 104 178 108'),

    sheet(DX0, DY0, DX1, DY1) + dragon(2)
    + hold_pencil(236, 166, 40)
    + arrow('M114 200 C90 204 70 194 64 176', dashed=True),

    sheet(DX0, DY0, DX1, DY1) + dragon(3)
    + motion('M116 72 q-10 -10 -4 -24', 'M100 94 q-12 -8 -10 -24')
    + sparkle(296, 136, 10),

    sheet(DX0, DY0, DX1, DY1) + dragon(3, colour=True) + fire()
    + hold_crayon(232, 178, 22),
]


# ── Draw with your other hand ────────────────────────────────────────────
OX0, OY0, OX1, OY1 = 70, 40, 330, 250


def wobbly_house(x=150, by=196, seed=3, amp=2.6):
    if not amp:
        return (f'<path d="M{x - 40} {by} V{by - 60} L{x} {by - 98} L{x + 40} {by - 60} V{by} Z"/>'
                f'<rect x="{x - 10}" y="{by - 34}" width="20" height="34" fill="none"/>'
                f'<rect x="{x + 14}" y="{by - 52}" width="16" height="16" fill="none"/>'
                + thin(f'M{x + 22} {by - 52} V{by - 36} M{x + 14} {by - 44} H{x + 30}'))
    return (wob([(x - 40, by), (x - 40, by - 60), (x, by - 98), (x + 40, by - 60), (x + 40, by)], seed, amp, True)
            + wob([(x - 10, by), (x - 10, by - 34), (x + 10, by - 34), (x + 10, by)], seed + 1, amp)
            + wob([(x + 14, by - 52), (x + 30, by - 52), (x + 30, by - 36), (x + 14, by - 36)], seed + 2, amp, True))


def wobbly_kid(x=250, by=196, seed=7, amp=2.6):
    if not amp:
        return (f'<circle cx="{x}" cy="{by - 70}" r="14" fill="none"/>' + dot(x - 5, by - 72, 1.8) + dot(x + 5, by - 72, 1.8)
                + thin(f'M{x - 5} {by - 65} q5 4 10 0')
                + f'<path d="M{x} {by - 56} V{by - 24} M{x} {by - 24} L{x - 12} {by} M{x} {by - 24} L{x + 12} {by} '
                  f'M{x - 18} {by - 46} L{x + 18} {by - 46}" fill="none"/>')
    pts = [(x + 14 * math.cos(a), by - 70 + 14 * math.sin(a)) for a in [i * math.pi / 5 for i in range(10)]]
    return (wob(pts, seed, amp * .6, True) + dot(x - 5, by - 73, 1.8) + dot(x + 6, by - 71, 1.8)
            + wob([(x - 6, by - 64), (x + 6, by - 66)], seed + 1, 1.2)
            + wob([(x, by - 56), (x + 2, by - 24)], seed + 2, amp)
            + wob([(x + 2, by - 24), (x - 12, by)], seed + 3, amp) + wob([(x + 2, by - 24), (x + 14, by)], seed + 4, amp)
            + wob([(x - 20, by - 44), (x + 18, by - 48)], seed + 5, amp))


D[key('Draw with your other hand')] = [
    sheet(OX0, OY0 + 30, OX1, OY1)
    + hold_pen(150, 150, 120, flip=True)
    + mitt(286, 236, 1.0)
    + arrow('M292 172 C276 112 206 90 162 112', dashed=True),

    sheet(OX0, OY0, OX1, OY1) + wobbly_house(180, 190)
    + hold_pen(220, 190, 120, flip=True)
    + motion('M240 172 q6 -4 2 -8 q-4 -4 2 -8', 'M254 180 q6 -4 2 -8 q-4 -4 2 -8'),

    sheet(OX0, OY0, OX1, OY1) + wobbly_house(150, 190) + wobbly_kid(252, 190)
    + hold_pen(264, 190, 120, flip=True)
    + motion('M282 166 q6 -4 2 -8 q-4 -4 2 -8', 'M296 176 q6 -4 2 -8 q-4 -4 2 -8'),

    sheet(24, 40, 192, 188, 8) + g(wobbly_house(150, 214) + wobbly_kid(252, 214), 22, 38, .6)
    + sheet(208, 40, 376, 188, 8) + g(wobbly_house(150, 214, amp=0) + wobbly_kid(252, 214, amp=0), 206, 38, .6)
    + face(200, 248, 28, 'laugh', 'happy', 'child')
    + motion('M160 244 h-14', 'M164 222 l-12 -8', 'M240 244 h14', 'M236 222 l12 -8')
    + arrow('M172 232 C150 222 128 212 110 196', dashed=True),
]


# ── Draw a poster for your favourite movie ────────────────────────────────
PX0, PY0, PX1, PY1 = 118, 18, 282, 276
PPTS = sheet_pts(PX0, PY0, PX1, PY1, 10)


TITLE = ['M140 66 C136 44 146 34 154 40 C160 46 150 62 158 66', 'C166 70 172 44 182 40 C192 36 190 66 200 66',
         'C210 66 206 38 220 38 C230 38 226 64 236 66', 'C246 68 254 50 252 40 C250 32 240 36 244 50 C246 60 254 66 262 62']


def title(n=4):
    """A big outlined squiggle, like bubble writing with no real letters."""
    return limb(' '.join(TITLE[:n]), 15)


def hero(x=200, by=210, s=.62):
    cape = '<path d="M-20 -86 L-44 -14 Q0 -4 44 -14 L20 -86 Z"/>'
    mask = ('<path d="M-24 -126 Q0 -132 24 -126 V-114 Q0 -120 -24 -114 Z" fill="#1d1d1f"/>'
            '<circle cx="-9" cy="-120" r="4" fill="#fff" stroke="none"/>'
            '<circle cx="9" cy="-120" r="4" fill="#fff" stroke="none"/>')
    badge = star(0, -66, 9)
    return (g(cape, x, by, s)
            + person(x, by, s, arms=[(-1, -36, -54, -40, -80), (1, 36, -54, 40, -80)], mouth='grin',
                     front=mask + badge))


def mini_pic(x=226, y=196, w=46, h=40):
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="2"/>'
            + toy_car(x + w / 2, y + h - 6, .5) + thin(f'M{x + 4} {y + h - 6} H{x + w - 4}'))


def poster(stage):
    s = sheet(PX0, PY0, PX1, PY1, 10) + title()
    if stage >= 2:
        s += hero()
    if stage >= 3:
        s += mini_pic() + star(140, 120, 9) + star(262, 112, 8) + star(144, 236, 8) + star(140, 176, 6)
    return s


D[key('Draw a poster for your favourite movie')] = [
    sheet(PX0, PY0, PX1, PY1, 10) + title(3)
    + ghost('M236 66 C246 68 254 50 252 40 C250 32 240 36 244 50 C246 60 254 66 262 62')
    + hold_pen(236, 66, 40)
    + arrow('M144 92 H224'),

    poster(2) + hold_pen(232, 150, -50)
    + sparkle(150, 150, 10),

    poster(3) + hold_pen(272, 196, -50)
    + sparkle(142, 120, 16) + sparkle(144, 236, 14),

    ground(272) + bed(24, 272, 170)
    + f'<g transform="translate(150 6) scale(.52) translate(-{PX0} -{PY0})">'
      f'<rect x="{PX0}" y="{PY0}" width="{PX1 - PX0}" height="{PY1 - PY0}" rx="2"/>{title()}{hero()}'
      f'{mini_pic()}{star(140, 120, 9)}{star(262, 112, 8)}{star(144, 236, 8)}</g>'
    + '<g transform="rotate(-30 152 10)"><rect x="140" y="4" width="24" height="10" stroke-width="1.6"/></g>'
    + '<g transform="rotate(30 236 10)"><rect x="224" y="4" width="24" height="10" stroke-width="1.6"/></g>'
    + '<g transform="rotate(30 152 140)"><rect x="140" y="134" width="24" height="10" stroke-width="1.6"/></g>'
    + '<g transform="rotate(-30 236 140)"><rect x="224" y="134" width="24" height="10" stroke-width="1.6"/></g>'
    + person(310, 272, 1.0, arms=[(-1, -70, -132, -50, -130), (1, 30, -44)], mouth='grin')
    + motion('M226 160 l-6 8', 'M246 162 l6 8', 'M214 148 h-10'),
]


# ── Draw a picture for a grown-up's fridge ───────────────────────────────
def fridge(x, y, w, h, freezer=.32):
    fy = y + h * freezer
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8"/>'
            f'<path d="M{x} {fy:.0f} H{x + w}" fill="none"/>'
            f'<rect x="{x + 10}" y="{y + 16}" width="6" height="{h * freezer - 32:.0f}" rx="3"/>'
            f'<rect x="{x + 10}" y="{fy + 16:.0f}" width="6" height="{h * .3:.0f}" rx="3"/>')


def cat_pic(x, y, w=90, h=80):
    """The child's drawing: a cat in the sun."""
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="2"/>'
            + cat(x + w * .42, y + h - 12, w / 150) + sun(x + w - 18, y + 16, w / 16)
            + thin(f'M{x + 8} {y + h - 12} H{x + w - 8}'))


def seated_kid(x=126, seat=196, floor=262):
    """A child sitting on a chair, seen from the side, facing right; legs in front."""
    chair = (f'<path d="M{x - 30} {floor} V{seat - 70}" fill="none" stroke-width="6"/>'
             f'<path d="M{x - 30} {seat} H{x + 30}" fill="none" stroke-width="7"/>'
             f'<path d="M{x - 30} {seat} V{floor} M{x + 26} {seat} V{floor}" fill="none" stroke-width="4"/>')
    body = (limb(f'M{x - 4} {seat - 10} H{x + 40}', 16)
            + limb(f'M{x + 40} {seat - 10} L{x + 44} {floor - 6}', 14)
            + f'<path d="M{x + 40} {floor - 10} q0 -4 6 -4 h14 q6 0 6 6 v4 h-26 Z"/>'
            + f'<rect x="{x - 20}" y="{seat - 74}" width="30" height="68" rx="10"/>')
    head = (f'<circle cx="{x - 2}" cy="{seat - 102}" r="24"/>' + dot(x + 8, seat - 106, 2.3)
            + thin(f'M{x + 4} {seat - 92} q6 4 12 -1')
            + thin(f'M{x - 24} {seat - 108} q6 -22 26 -18 q14 -10 22 6'))
    return chair + body + head


def kitchen_table(x0=196, x1=372, top=174, floor=262):
    return (f'<path d="M{x0 + 14} {top + 8} V{floor} M{x1 - 14} {top + 8} V{floor}" fill="none" stroke-width="6"/>'
            f'<path d="M{x0} {top} L{x0 + 14} {top - 22} H{x1 - 8} L{x1} {top} Z"/>'
            f'<rect x="{x0}" y="{top}" width="{x1 - x0}" height="8"/>')


def cupboard(x, y, w=140, h=56):
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}"/>'
            + thin(f'M{x + w / 2} {y} V{y + h} M{x + w / 2 - 10} {y + h - 14} v8 M{x + w / 2 + 10} {y + h - 14} v8'))


D[key("Draw a picture for a grown-up's fridge")] = [
    ground(268) + fridge(24, 70, 84, 198)
    + person(178, 268, 1.0, arms=[(-1, -30, -44), (1, 36, -70, 34, -90)], mouth='talk')
    + person(312, 268, .95, who='adult', arms=[(-1, -40, -60), (1, 30, -50)], mouth='smile')
    + speech(118, 18, 82, 66, 168, 112, qmark(159, 50, 1.3))
    + speech(234, 10, 124, 70, 300, 92, cat(282, 70, .5) + sun(328, 34, 9))
    + motion('M146 134 l-9 -4', 'M144 148 h-10'),

    ground(262) + cupboard(230, 22)
    + kitchen_table(184)
    + '<polygon points="206,170 216,154 312,154 308,170"/>' + thin('M250 164 q8 -6 14 0 q8 -4 12 2')
    + seated_kid(110)
    + limb('M104 150 Q160 136 222 150', 12)
    + crayon(232, 162, -118, .55) + '<circle cx="224" cy="150" r="7"/>'
    + motion('M246 140 q6 -8 12 0', 'M262 132 q6 -8 12 0'),

    sheet(70, 30, 330, 248)
    + cat(178, 186, 1.4) + sun(282, 72, 18) + thin('M96 186 H304')
    + scribble(218, 222, 3, 20) + thin('M226 238 h8 m6 0 h8 m6 0 h10')
    + hold_pen(280, 222, -40)
    + arrow('M210 206 H272'),

    ground(272) + fridge(118, 20, 150, 252, .3)
    + cat_pic(146, 120, 98, 86)
    + '<circle cx="232" cy="124" r="9" fill="#1d1d1f"/>'
    + person(330, 272, 1.0, arms=[(-1, -80, -156, -50, -150), (1, 30, -44)], mouth='grin')
    + motion('M224 106 l-6 -8', 'M240 102 v-10')
    + sparkle(96, 120, 11),
]
