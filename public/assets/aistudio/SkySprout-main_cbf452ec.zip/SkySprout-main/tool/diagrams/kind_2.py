"""Diagrams for more Kindness challenges (cup of water, how was your day, big hug,
read a story, carry the shopping, say sorry, let someone choose the game).
People are simple round-headed figures; speech is a bubble with squiggles or a
small icon, never words. The accent is only for arrows and motion lines."""
import math
import re

from craft_3 import grip, mitt  # noqa: F401
from style import INK, arrow, dot, ghost, ground, hand, motion, thin

D = {}


def key(title):
    return re.sub(r'[^a-z0-9]+', '_', title.lower()).strip('_')[:48]


# ── People ───────────────────────────────────────────────────────────────
SIZES = {  # head r, torso half-width, torso height, leg length, limb width
    'adult': (28, 33, 90, 80, 17),
    'kid': (30, 27, 62, 50, 15),
    'small': (24, 21, 48, 38, 13),
}


def limb(d, w=13):
    """An outlined arm or leg along path d."""
    return (f'<path d="{d}" fill="none" stroke="{INK}" stroke-width="{w}"/>'
            f'<path d="{d}" fill="none" stroke="#fff" stroke-width="{w - 4.8}"/>')


def head(cx, cy, r=25, mouth='smile', adult=False, look=0, brows=None):
    """A round head. look shifts the eyes sideways (-1 left .. 1 right)."""
    ex = r * .2 * look
    s = f'<circle cx="{cx}" cy="{cy}" r="{r}"/>'
    if adult:  # hair cap, bun and round glasses
        s = (f'<circle cx="{cx + r * .55}" cy="{cy - r * 1.02:.1f}" r="{r * .36:.1f}"/>' + s
             + f'<path d="M{cx - r:.1f} {cy - 2} C{cx - r * 1.05:.1f} {cy - r * 1.2:.1f} {cx + r * 1.05:.1f} {cy - r * 1.2:.1f} '
               f'{cx + r:.1f} {cy - 2} C{cx + r * .6:.1f} {cy - r * .8:.1f} {cx - r * .2:.1f} {cy - r * .75:.1f} {cx - r:.1f} {cy - 2} Z" fill="{INK}"/>'
             + f'<circle cx="{cx - r * .36 + ex:.1f}" cy="{cy}" r="{r * .25:.1f}" fill="none" stroke-width="1.6"/>'
             + f'<circle cx="{cx + r * .36 + ex:.1f}" cy="{cy}" r="{r * .25:.1f}" fill="none" stroke-width="1.6"/>')
    else:
        s += thin(f'M{cx - r * .88:.1f} {cy - r * .5:.1f} q{r * .3:.1f} {-r * .78:.1f} {r:.1f} {-r * .48:.1f} '
                  f'q{r * .6:.1f} {-r * .42:.1f} {r * .88:.1f} {r * .24:.1f}')
    s += dot(cx - r * .36 + ex, cy, r * .07 + 1) + dot(cx + r * .36 + ex, cy, r * .07 + 1)
    if brows == 'up':
        s += thin(f'M{cx - r * .5 + ex:.1f} {cy - r * .38:.1f} q{r * .14:.1f} {-r * .14:.1f} {r * .28:.1f} 0 '
                  f'M{cx + r * .22 + ex:.1f} {cy - r * .38:.1f} q{r * .14:.1f} {-r * .14:.1f} {r * .28:.1f} 0')
    elif brows == 'sad':
        s += thin(f'M{cx - r * .52 + ex:.1f} {cy - r * .3:.1f} l{r * .3:.1f} {-r * .1:.1f} '
                  f'M{cx + r * .52 + ex:.1f} {cy - r * .3:.1f} l{-r * .3:.1f} {-r * .1:.1f}')
    mx = cx + ex * .7
    my = cy + r * .42
    if mouth == 'smile':
        s += f'<path d="M{mx - r * .28:.1f} {my - r * .06:.1f} q{r * .28:.1f} {r * .26:.1f} {r * .56:.1f} 0" fill="none"/>'
    elif mouth == 'grin':
        s += (f'<path d="M{mx - r * .38:.1f} {my - r * .12:.1f} q{r * .38:.1f} {r * .48:.1f} {r * .76:.1f} 0 Z"/>')
    elif mouth == 'open':
        s += f'<ellipse cx="{mx:.1f}" cy="{my:.1f}" rx="{r * .16:.1f}" ry="{r * .14:.1f}"/>'
    elif mouth == 'big':
        s += f'<ellipse cx="{mx:.1f}" cy="{my + 1:.1f}" rx="{r * .22:.1f}" ry="{r * .2:.1f}" fill="{INK}"/>'
    elif mouth == 'flat':
        s += thin(f'M{mx - r * .18:.1f} {my:.1f} h{r * .36:.1f}')
    elif mouth == 'sad':
        s += f'<path d="M{mx - r * .24:.1f} {my + r * .08:.1f} q{r * .24:.1f} {-r * .2:.1f} {r * .48:.1f} 0" fill="none"/>'
    return s


def person(cx, by, kind='kid', arms=((-1, None), (1, None)), mouth='smile', look=0, legs='stand',
           brows=None, front_arms=True):
    """A standing (or sitting) figure with its feet at by.

    arms: (side, end) pairs; end is the absolute hand point (x, y), or (x, y, cx, cy) with an
    elbow control point, or None for an arm hanging down. legs: stand, walk, sit_r, sit_l.
    """
    r, w, th, ll, lw = SIZES[kind]
    adult = kind == 'adult'
    if legs.startswith('sit'):
        hip = by - lw * .9
    elif legs == 'kneel':
        hip = by - ll * .42
    else:
        hip = by - ll
    yb, yt = hip + 4, hip - th
    hy = yt - r + 2
    s = ''
    # legs
    if legs == 'stand':
        for dx in (-w * .45, w * .45):
            s += limb(f'M{cx + dx:.1f} {hip} V{by - 3}', lw)
            s += f'<ellipse cx="{cx + dx + (4 if dx > 0 else -4):.1f}" cy="{by - 1}" rx="{lw * .7:.1f}" ry="{lw * .38:.1f}"/>'
    elif legs == 'walk':
        for dx, fx in ((-w * .3, -ll * .5), (w * .3, ll * .55)):
            s += limb(f'M{cx + dx:.1f} {hip} L{cx + dx + fx:.1f} {by - 3}', lw)
            s += f'<ellipse cx="{cx + dx + fx + 5:.1f}" cy="{by - 1}" rx="{lw * .7:.1f}" ry="{lw * .38:.1f}"/>'
    elif legs == 'none':  # legs drawn separately (e.g. sitting on a sofa, in front of the seat)
        pass
    elif legs == 'kneel':
        for dx in (-w * .45, w * .45):
            s += limb(f'M{cx + dx:.1f} {hip} V{by - 6}', lw)
            s += f'<ellipse cx="{cx + dx:.1f}" cy="{by - 3}" rx="{lw * .62:.1f}" ry="{lw * .5:.1f}"/>'
    else:  # sitting on the floor, legs stretched out to one side
        d = 1 if legs == 'sit_r' else -1
        for j, dx in enumerate((-w * .4, w * .4)):
            fx = cx + d * (w + ll * .95) - d * j * 8
            fy = by - lw * .55 - j * 3
            s += limb(f'M{cx + dx:.1f} {hip - 4} Q{cx + d * w:.1f} {fy:.1f} {fx:.1f} {fy:.1f}', lw)
            s += f'<ellipse cx="{fx + d * 3:.1f}" cy="{fy - lw * .45:.1f}" rx="{lw * .38:.1f}" ry="{lw * .7:.1f}"/>'
    body = (f'<path d="M{cx - w} {yb} V{yt + 12} Q{cx - w} {yt} {cx - w + 12} {yt} H{cx + w - 12} '
            f'Q{cx + w} {yt} {cx + w} {yt + 12} V{yb} Z"/>')
    a = ''
    for side, end in arms:
        sx, sy = cx + side * (w - 7), yt + 11
        if end is None:
            end = (cx + side * (w + 6), yb - 6)
        if len(end) == 2:
            ex, ey = end
            mx, my = (sx + ex) / 2 + side * 10, (sy + ey) / 2 + 10
        else:
            ex, ey, mx, my = end
        a += limb(f'M{sx:.1f} {sy:.1f} Q{mx:.1f} {my:.1f} {ex:.1f} {ey:.1f}', lw)
        a += f'<circle cx="{ex:.1f}" cy="{ey:.1f}" r="{lw * .62:.1f}"/>'
    hd = head(cx, hy, r, mouth, adult, look, brows)
    if front_arms:
        return s + body + hd + a
    return s + a + body + hd


def top_of(by, kind='kid', legs='stand'):
    """Head-top y and head centre y of person() with feet at by."""
    r, w, th, ll, lw = SIZES[kind]
    hip = by - lw * .9 if legs.startswith('sit') else by - ll * .42 if legs == 'kneel' else by - ll
    hy = hip - th - r + 2
    return hy - r, hy


# ── Bubbles and small things ─────────────────────────────────────────────
def bubble(x, y, w, h, tx, ty, inside=''):
    """A speech bubble (x, y top-left) with its tail pointing at (tx, ty)."""
    cx, cy = x + w / 2, y + h / 2
    bx = min(max(tx, x + 22), x + w - 22)
    by_ = y + h if ty > cy else y
    sgn = 1 if ty > cy else -1
    body = f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{min(h / 2, 22)}"/>'
    tail = (f'<path d="M{bx - 10} {by_ - sgn * 2} L{tx} {ty} L{bx + 10} {by_ - sgn * 2}"/>'
            f'<path d="M{bx - 8.5} {by_ - sgn * 1.2} H{bx + 8.5}" stroke="#fff" stroke-width="3.5"/>')
    return body + tail + inside


def think(x, y, w, h, tx, ty, inside=''):
    """A cloudy thought bubble, with little circles trailing down to (tx, ty)."""
    cx, cy = x + w / 2, y + h / 2
    n = 9
    pts = []
    for i in range(n):
        a = 2 * math.pi * i / n
        pts.append((cx + w / 2 * math.cos(a), cy + h / 2 * math.sin(a)))
    d = f'M{pts[0][0]:.1f} {pts[0][1]:.1f}'
    for i in range(n):
        p, q = pts[i], pts[(i + 1) % n]
        mx, my = (p[0] + q[0]) / 2, (p[1] + q[1]) / 2
        ox, oy = mx - cx, my - cy
        k = .28
        d += f' Q{mx + ox * k:.1f} {my + oy * k:.1f} {q[0]:.1f} {q[1]:.1f}'
    # trailing dots from the cloud's edge toward the head
    ex, ey = tx - cx, ty - cy
    L = math.hypot(ex, ey)
    ux, uy = ex / L, ey / L
    edge = 1 / math.sqrt((ux / (w / 2 * 1.1)) ** 2 + (uy / (h / 2 * 1.1)) ** 2)
    c = ''
    for f, rr in ((.3, 7), (.62, 4.5)):
        t = edge + (L - edge) * f
        c += f'<circle cx="{cx + ux * t:.1f}" cy="{cy + uy * t:.1f}" r="{rr}"/>'
    return f'<path d="{d} Z"/>' + c + inside


def squiggle(x, y, w, n=1, gap=13):
    """Wavy lines standing for talk or writing."""
    s = ''
    for j in range(n):
        d = f'M{x} {y + j * gap}'
        k = int(w // 12)
        for i in range(k):
            d += f' q3 {-5 if i % 2 == 0 else 5} 6 0 q3 {5 if i % 2 == 0 else -5} 6 0'
        s += thin(d)
    return s


def qmark(cx, cy, s=1.0):
    """A question-mark shape."""
    return (f'<g transform="translate({cx} {cy}) scale({s})">'
            '<path d="M-7 -8 Q-7 -17 1 -17 Q9 -17 9 -9 Q9 -3 2 0 Q0 1 0 6" fill="none" stroke-width="3"/>'
            f'<circle cx="0" cy="13" r="2.4" fill="{INK}" stroke="none"/></g>')


def heart(cx, cy, s=12, fill='#fff'):
    return (f'<path d="M{cx} {cy + s * .9} C{cx - s * 1.7} {cy - s * .1} {cx - s * .7} {cy - s * 1.3} {cx} {cy - s * .4} '
            f'C{cx + s * .7} {cy - s * 1.3} {cx + s * 1.7} {cy - s * .1} {cx} {cy + s * .9} Z" fill="{fill}"/>')


def sun(cx, cy, r=10):
    rays = ''.join(f'M{cx + (r + 4) * math.cos(a):.1f} {cy + (r + 4) * math.sin(a):.1f} '
                   f'L{cx + (r + 9) * math.cos(a):.1f} {cy + (r + 9) * math.sin(a):.1f} '
                   for a in [i * math.pi / 4 for i in range(8)])
    return f'<circle cx="{cx}" cy="{cy}" r="{r}"/>' + thin(rays)


def cup(cx, by, w=30, h=40, water=.7):
    """A plain tumbler seen a little from above, base centre at (cx, by)."""
    t, b = w / 2, w * .38
    s = (f'<path d="M{cx - t} {by - h} L{cx - b} {by} Q{cx} {by + 5} {cx + b} {by} L{cx + t} {by - h}"/>'
         f'<ellipse cx="{cx}" cy="{by - h}" rx="{t}" ry="{w * .16:.1f}"/>')
    if water:
        wy = by - h * water
        wt = b + (t - b) * water
        s += thin(f'M{cx - wt:.1f} {wy:.1f} Q{cx} {wy + 5:.1f} {cx + wt:.1f} {wy:.1f}')
    return s


def door(x, y, w=80, h=170, open_=True):
    """A front door frame; open_ swings the door in toward the viewer on the left."""
    s = f'<path d="M{x - 6} {y + h} V{y - 6} H{x + w + 6} V{y + h}" fill="none"/>'
    s += f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="#fff" stroke-width="1.6"/>'
    if open_:
        s += (f'<path d="M{x} {y} L{x - w * .55} {y + 18} V{y + h + 12} L{x} {y + h} Z"/>'
              + dot(x - w * .45, y + h * .55, 3))
    return s


def couch(x, y, w=230):
    """A sofa seen from the front; seat top at y."""
    return (f'<rect x="{x}" y="{y - 70}" width="{w}" height="72" rx="14"/>'
            f'<rect x="{x - 16}" y="{y - 26}" width="30" height="66" rx="10"/>'
            f'<rect x="{x + w - 14}" y="{y - 26}" width="30" height="66" rx="10"/>'
            f'<rect x="{x + 14}" y="{y}" width="{w - 28}" height="34" rx="6"/>'
            + thin(f'M{x + w / 2} {y + 2} V{y + 32}')
            + f'<path d="M{x + 4} {y + 40} v10 M{x + w - 4} {y + 40} v10" fill="none"/>')


def book_open(cx, cy, w=70, h=46, pic='sun', tilt=0):
    """An open picture book, spine at cx."""
    hw = w / 2
    s = (f'<g transform="rotate({tilt} {cx} {cy})">'
         f'<path d="M{cx} {cy - h / 2 + 4} Q{cx - hw * .5} {cy - h / 2 - 4} {cx - hw} {cy - h / 2} V{cy + h / 2} '
         f'Q{cx - hw * .5} {cy + h / 2 - 6} {cx} {cy + h / 2 + 4} Q{cx + hw * .5} {cy + h / 2 - 6} {cx + hw} {cy + h / 2} '
         f'V{cy - h / 2} Q{cx + hw * .5} {cy - h / 2 - 4} {cx} {cy - h / 2 + 4} Z"/>'
         + thin(f'M{cx} {cy - h / 2 + 4} V{cy + h / 2 + 4}'))
    if pic == 'sun':
        s += sun(cx - hw * .5, cy - 2, h * .13)
    elif pic == 'star':
        s += star(cx - hw * .5, cy, h * .24)
    s += squiggle(cx + hw * .16, cy - h * .2, hw * .66, 3, h * .2)
    return s + '</g>'


def star(cx, cy, r=12):
    pts = []
    for i in range(10):
        a = -math.pi / 2 + i * math.pi / 5
        rr = r if i % 2 == 0 else r * .45
        pts.append(f'{cx + rr * math.cos(a):.1f},{cy + rr * math.sin(a):.1f}')
    return f'<polygon points="{" ".join(pts)}"/>'


def tap(x, y):
    """A kitchen tap on the back of a sink; the spout mouth at (x, y)."""
    return (f'<path d="M{x - 64} {y + 74} V{y - 26} Q{x - 64} {y - 46} {x - 44} {y - 46} H{x - 8} '
            f'Q{x + 10} {y - 46} {x + 10} {y - 28} V{y} H{x - 10} V{y - 24} Q{x - 10} {y - 30} {x - 16} {y - 30} '
            f'H{x - 42} Q{x - 48} {y - 30} {x - 48} {y - 24} V{y + 74} H{x - 64} Z"/>'
            f'<rect x="{x - 78}" y="{y - 4}" width="44" height="12" rx="6"/>')


def hands(*pts, kind='kid'):
    """Hand circles drawn again on top of something held."""
    r = SIZES[kind][4] * .62
    return ''.join(f'<circle cx="{x}" cy="{y}" r="{r:.1f}"/>' for x, y in pts)


def fist(x, y, side=1, arm=(60, 50), w=19):
    """A hand wrapped round the side of something at (x, y), its arm going off by arm (dx, dy)."""
    ax, ay = arm
    return (limb(f'M{x + side * 10} {y + 4} q{ax * .5:.1f} {ay * .2:.1f} {side * abs(ax)} {ay}', w)
            + f'<rect x="{x - 16}" y="{y - 14}" width="32" height="30" rx="11"/>'
            + thin(f'M{x - side * 14} {y - 4} h{side * 16} M{x - side * 14} {y + 5} h{side * 16}')
            + f'<path d="M{x - side * 2} {y - 14} q{side * -8} -10 {side * -16} -6" fill="none"/>')


# ── Make a grown-up a cup of water ───────────────────────────────────────
D[key('Make a grown-up a cup of water')] = [
    ground(278)
    + person(300, 276, 'adult', look=-1)
    + person(110, 276, 'kid', look=1, mouth='open')
    + bubble(40, 22, 124, 66, 118, 104, cup(82, 74, 26, 34) + qmark(132, 56, 1.1))
    + motion('M150 150 l12 -6', 'M152 162 h14'),
    # filling at the tap
    '<rect x="70" y="180" width="270" height="88" rx="16"/>'
    + '<rect x="86" y="192" width="238" height="64" rx="12"/>'
    + tap(200, 106)
    + motion('M194 114 V156', 'M206 114 V156')
    + cup(200, 240, 56, 78, .45)
    + fist(232, 206, 1, (90, 60))
    + arrow('M150 236 V176'),
    ground(278)
    + person(180, 276, 'kid', arms=((-1, (158, 214, 140, 204)), (1, (202, 214, 220, 204))), look=1, legs='walk', mouth='flat')
    + cup(180, 238, 40, 52, .7) + hands((158, 214), (202, 214))
    + arrow('M250 262 H350', dashed=True),
    ground(278)
    + person(100, 276, 'kid', arms=((-1, None), (1, (190, 202, 170, 186))), look=1, mouth='grin')
    + person(310, 276, 'adult', arms=((-1, (224, 198, 256, 196)), (1, None)), look=-1)
    + cup(207, 220, 34, 48, .7) + hands((190, 202)) + hands((224, 198), kind='adult')
    + arrow('M132 92 Q190 50 246 84'),
]


def arm(x0, y0, cx, cy, x1, y1, kind='kid', hand=True):
    lw = SIZES[kind][4]
    s = limb(f'M{x0} {y0} Q{cx} {cy} {x1} {y1}', lw)
    return s + (f'<circle cx="{x1}" cy="{y1}" r="{lw * .62:.1f}"/>' if hand else '')


def bag(hx, hy, w=46, h=48, full=True):
    """A shopping bag hanging from a hand at (hx, hy)."""
    top = hy + 16
    s = ''
    if full:  # a loaf and some leaves poking out
        s += (f'<rect x="{hx - w / 2 + 6}" y="{top - 16}" width="14" height="26" rx="6" transform="rotate(-14 {hx - w / 2 + 13} {top})"/>'
              f'<path d="M{hx + 8} {top + 2} q-2 -16 8 -20 M{hx + 10} {top + 2} q8 -12 16 -10" fill="none"/>')
    s += (f'<path d="M{hx - w / 2} {top} H{hx + w / 2} L{hx + w / 2 - 3} {top + h} H{hx - w / 2 + 3} Z"/>'
          f'<path d="M{hx - 12} {top} Q{hx - 10} {hy - 4} {hx} {hy - 4} Q{hx + 10} {hy - 4} {hx + 12} {top}" fill="none"/>')
    return s


def tin(cx, by, w=30, h=38):
    return (f'<path d="M{cx - w / 2} {by - h} V{by} Q{cx} {by + 6} {cx + w / 2} {by} V{by - h}"/>'
            f'<ellipse cx="{cx}" cy="{by - h}" rx="{w / 2}" ry="{w * .18:.1f}"/>'
            + thin(f'M{cx - w / 2} {by - h * .62} Q{cx} {by - h * .62 + 6} {cx + w / 2} {by - h * .62} '
                   f'M{cx - w / 2} {by - h * .22} Q{cx} {by - h * .22 + 6} {cx + w / 2} {by - h * .22}'))


def dice(cx, cy, s=22, rot=0):
    pips = ((-.27, -.27), (.27, .27), (0, 0))
    return (f'<g transform="rotate({rot} {cx} {cy})"><rect x="{cx - s / 2}" y="{cy - s / 2}" width="{s}" height="{s}" rx="{s * .2:.1f}"/>'
            + ''.join(dot(cx + a * s, cy + b * s, s * .08 + .6) for a, b in pips) + '</g>')


def board(x, y, w=150, h=56):
    """A board game lying on the floor, seen from slightly above: a winding path of squares."""
    k = 22  # slant
    s = f'<path d="M{x + k} {y} H{x + w + k} L{x + w} {y + h} H{x} Z"/>'
    s += f'<path d="M{x + k} {y} H{x + w + k} L{x + w} {y + h} H{x} Z" fill="none" transform="translate(0 7)" stroke-width="1.6"/>'
    cells = ''
    n = 6
    for row, fy in ((0, .3), (1, .72)):
        for i in range(n):
            fx = .1 + i * .8 / n
            cx = x + k * (1 - fy) + w * fx
            cy = y + h * fy
            cells += f'<path d="M{cx:.1f} {cy - 5:.1f} h{w * .1:.1f} l-3 10 h{-w * .1:.1f} Z" stroke-width="1.6"/>'
    return s + cells


def storm(cx, cy, s=1.0):
    """A small storm cloud with a lightning bolt."""
    return (f'<g transform="translate({cx} {cy}) scale({s})">'
            '<path d="M-34 8 C-46 8 -46 -12 -32 -12 C-30 -28 -8 -30 -2 -18 C6 -30 30 -26 28 -8 C42 -8 42 8 30 8 Z" fill="#fff"/>'
            f'<path d="M2 10 L-6 24 H2 L-4 36 L10 20 H2 L8 10" fill="{INK}" stroke-width="1.4"/></g>')


def blocks_down(x, y):
    """A knocked-over tower of toy blocks on the floor, feet level y."""
    return (f'<rect x="{x}" y="{y - 18}" width="18" height="18"/>'
            f'<rect x="{x + 22}" y="{y - 19}" width="18" height="18" transform="rotate(18 {x + 31} {y - 10})"/>'
            f'<rect x="{x + 8}" y="{y - 36}" width="18" height="18" transform="rotate(-28 {x + 17} {y - 27})"/>'
            f'<rect x="{x + 34}" y="{y - 42}" width="18" height="18" transform="rotate(40 {x + 43} {y - 33})"/>')


# ── Ask someone how their day was and listen ─────────────────────────────
D[key('Ask someone how their day was and listen')] = [
    ground(278)
    + '<rect x="238" y="30" width="112" height="246" stroke-width="1.6"/>'
    + '<path d="M232 276 V24 H356 V276" fill="none"/>'
    + '<path d="M238 30 L208 44 V286 L238 276 Z"/>' + dot(216, 160, 3)
    + person(294, 276, 'adult', arms=((-1, None), (1, (348, 74, 352, 120))), look=-1)
    + bag(268, 205, 34, 38, False)
    + person(84, 276, 'kid', arms=((-1, None), (1, (140, 120, 140, 160))), look=1, legs='walk', mouth='grin')
    + arrow('M130 262 H192', dashed=True) + motion('M364 64 q8 8 6 20', 'M330 50 q8 -6 18 -4'),
    ground(278)
    + person(300, 276, 'adult', look=-1)
    + person(110, 276, 'kid', look=1, mouth='open')
    + bubble(36, 20, 130, 66, 118, 104, sun(78, 53, 12) + qmark(132, 54, 1.1))
    + motion('M150 150 l12 -6', 'M152 162 h14'),
    ground(278)
    + person(300, 276, 'adult', look=-1, mouth='open')
    + person(110, 276, 'kid', arms=((-1, None), (1, (150, 134, 168, 166))), look=1, mouth='flat')
    + bubble(160, 18, 110, 52, 270, 70, squiggle(176, 38, 78, 2, 14))
    + motion('M232 104 q-12 16 0 32', 'M214 96 q-16 24 0 48', 'M196 88 q-20 32 0 64'),
    ground(278)
    + person(300, 276, 'adult', look=-1, mouth='grin')
    + person(110, 276, 'kid', look=1, mouth='grin')
    + bubble(30, 22, 92, 60, 104, 106, qmark(76, 52, 1.1))
    + bubble(180, 14, 96, 38, 272, 62, squiggle(194, 33, 66, 1))
    + arrow('M150 116 Q200 92 246 108') + arrow('M254 140 Q206 164 158 150'),
]


# ── Give someone a big hug ───────────────────────────────────────────────
D[key('Give someone a big hug')] = [
    ground(278)
    + person(300, 276, 'adult', look=-1)
    + person(124, 276, 'kid', arms=((-1, (64, 150, 80, 180)), (1, (184, 150, 168, 180))), look=1, mouth='grin')
    + bubble(56, 16, 116, 62, 124, 104, heart(86, 46, 12) + qmark(140, 48, 1.1))
    + motion('M50 136 l-10 -10', 'M44 154 h-14', 'M198 136 l10 -10'),
    ground(278)
    + arm(202, 161, 172, 150, 140, 178, 'adult', hand=False)
    + person(228, 276, 'adult', arms=((1, None),), look=-1, mouth='grin', legs='kneel')
    + person(160, 276, 'kid', arms=((1, (262, 204, 220, 214)),), look=1, mouth='grin')
    + hands((140, 178), kind='adult')
    + heart(194, 62, 14)
    + arrow('M66 168 Q80 194 108 204') + arrow('M330 168 Q316 194 290 204'),
    ground(278)
    + person(300, 276, 'adult', look=-1, mouth='grin')
    + person(110, 276, 'kid', look=1, mouth='open')
    + bubble(40, 20, 110, 66, 116, 104, heart(95, 50, 15))
    + motion('M150 150 l12 -6', 'M152 162 h14', 'M168 36 l12 -6', 'M168 58 h14'),
    ground(278)
    + person(196, 276, 'kid', arms=((-1, None), (1, (236, 122, 252, 156))), look=1, mouth='smile')
    + '<rect x="188" y="112" width="54" height="14" rx="7"/>'
    + person(326, 276, 'small', legs='sit_l', look=-1, mouth='sad', brows='sad')
    + person(66, 276, 'small', legs='sit_r', look=1, mouth='flat')
    + arrow('M240 112 Q290 96 318 150', dashed=True) + arrow('M152 112 Q100 100 74 150', dashed=True),
]


# ── Read a story to someone younger ──────────────────────────────────────
def _shelf():
    s = '<rect x="50" y="34" width="230" height="236" rx="4"/>' + '<path d="M50 150 H280" fill="none"/>'
    x = 62
    for i, (bw, bh) in enumerate(((20, 92), (26, 100), (16, 84), (0, 0), (24, 96), (18, 88), (28, 104), (20, 90))):
        if bw == 0:
            s += ghost(f'M{x} 148 V54 H{x + 30} V148')
            x += 36
            continue
        s += f'<rect x="{x}" y="{148 - bh}" width="{bw}" height="{bh}" rx="2"/>' + thin(f'M{x + 4} {148 - bh + 14} h{bw - 8}')
        x += bw + 2
    x = 60
    for bw, bh in ((24, 96), (20, 90), (30, 100), (18, 84), (26, 100), (22, 92), (34, 106), (20, 90)):
        s += f'<rect x="{x}" y="{268 - bh}" width="{bw}" height="{bh}" rx="2"/>' + thin(f'M{x + 4} {268 - bh + 14} h{bw - 8}')
        x += bw + 2
    return s


SEAT = 226  # sofa seat top in the story pictures


def _sofa_legs(cx, kind, fy):
    """Legs of someone sitting on the sofa seat, seen from the front: the lap rests on the seat,
    knees at its front edge, and the shins hang down in front of the seat cushion to feet at fy."""
    r, w, th, ll, lw = SIZES[kind]
    s = f'<rect x="{cx - w:.1f}" y="{SEAT - 6}" width="{2 * w:.1f}" height="{lw + 4:.1f}" rx="{lw * .55:.1f}"/>'
    for dx in (-w * .45, w * .45):
        s += limb(f'M{cx + dx:.1f} {SEAT + lw * .5:.1f} V{fy - 3}', lw)
        s += f'<ellipse cx="{cx + dx:.1f}" cy="{fy - 1}" rx="{lw * .62:.1f}" ry="{lw * .42:.1f}"/>'
    s += thin(f'M{cx:.1f} {SEAT - 2} V{SEAT + lw - 4:.1f}')
    return s


def _sofa_pair(book_pic='sun', younger_arm=None, older_mouth='smile', younger_mouth='smile', older_look=1, younger_look=-1):
    s = ('<rect x="40" y="96" width="320" height="130" rx="18"/>'
         '<rect x="22" y="160" width="40" height="96" rx="12"/><rect x="338" y="160" width="40" height="96" rx="12"/>')
    # Both sit on the seat (hips at its top); their legs are drawn after the cushion, in front of it.
    s += person(150, SEAT + 2 + SIZES['kid'][3], 'kid', arms=((-1, None), (1, (164, 226, 160, 240))), look=older_look,
                mouth=older_mouth, legs='none')
    s += person(262, SEAT + 2 + SIZES['small'][3], 'small', arms=((-1, younger_arm or (244, 226, 244, 246)), (1, None)),
                look=younger_look, mouth=younger_mouth, legs='none')
    s += ('<rect x="58" y="226" width="284" height="34" rx="6"/>' + thin('M200 228 V258')
          + '<path d="M64 260 v14 M336 260 v14" fill="none"/>')
    s += _sofa_legs(150, 'kid', 276) + _sofa_legs(262, 'small', 266)
    s += book_open(204, 206, 84, 52, book_pic, 0)
    s += hands((164, 226), (244, 226) if younger_arm is None else younger_arm[:2])
    return s


D[key('Read a story to someone younger')] = [
    _shelf()
    + f'<g transform="rotate(12 330 150)"><rect x="304" y="100" width="56" height="100" rx="3"/>'
    + star(332, 140, 14) + thin('M314 172 h36 M314 182 h26') + '</g>'
    + fist(330, 196, 1, (40, 60))
    + arrow('M188 86 Q240 60 296 88'),
    _sofa_pair()
    + motion('M232 158 L212 178', 'M236 172 L222 186'),
    ground(278)
    + person(140, 276, 'kid', arms=((-1, (104, 206, 92, 186)), (1, (176, 206, 188, 186))), look=0, mouth='big', brows='up')
    + book_open(140, 206, 92, 56, 'star', 0) + hands((98, 206), (182, 206))
    + motion('M182 132 l10 -8 l6 10 l10 -8', 'M184 152 l12 0 l4 8 l12 0')
    + person(318, 276, 'small', legs='sit_l', look=-1, mouth='grin'),
    _sofa_pair('star', (222, 192, 246, 222), older_mouth='grin', younger_mouth='grin', younger_look=-1)
    + bubble(84, 14, 110, 52, 146, 116, heart(112, 40, 11) + qmark(158, 40, 1))
    + arrow('M212 176 Q192 168 188 190'),
]


# ── Help carry the shopping in ───────────────────────────────────────────
def _cupboard(gap=True):
    s = ('<rect x="86" y="30" width="200" height="236" rx="4"/>'
         '<path d="M86 116 H286 M86 196 H286" fill="none"/>'
         '<path d="M286 30 L340 44 V252 L286 266 Z"/>' + dot(300, 150, 3))
    s += tin(116, 112, 28, 40) + tin(150, 112, 28, 40) + tin(186, 112, 28, 40)
    s += tin(122, 192, 30, 34) + '<rect x="146" y="140" width="46" height="52" rx="3"/>' + thin('M152 152 h34 M152 162 h26')
    s += tin(126, 262, 34, 46) + tin(170, 262, 34, 46) + tin(232, 262, 34, 46)
    if gap:
        s += ghost('M220 192 V160 M252 192 V160 M220 160 Q236 154 252 160')
    return s


def _flat_bag(x, y, w=150, h=110):
    return (f'<path d="M{x + 40} {y} Q{x + 40} {y - 34} {x + w / 2} {y - 34} Q{x + w - 40} {y - 34} {x + w - 40} {y}" fill="none"/>'
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="4"/>')


D[key('Help carry the shopping in')] = [
    ground(278)
    + '<rect x="238" y="30" width="112" height="246" stroke-width="1.6"/>'
    + '<path d="M232 276 V24 H356 V276" fill="none"/>'
    + '<path d="M238 30 L208 44 V286 L238 276 Z"/>' + dot(216, 160, 3)
    + person(294, 276, 'adult', arms=((-1, (250, 192, 256, 160)), (1, (338, 192, 332, 160))), look=-1)
    + bag(250, 192) + bag(338, 192) + hands((250, 192), (338, 192), kind='adult')
    + person(90, 276, 'kid', arms=((-1, (144, 196, 120, 210)), (1, (150, 176, 136, 196))), look=1, mouth='grin')
    + motion('M164 166 l10 -6', 'M166 184 h14', 'M164 202 l10 6'),
    ground(278)
    + person(170, 276, 'kid', arms=((-1, None), (1, (212, 200, 206, 194))), look=1, legs='walk', mouth='smile')
    + bag(212, 200, 40, 42) + hands((212, 200))
    + arrow('M260 262 H350', dashed=True),
    '<g transform="translate(-36 0)">' + _cupboard() + '</g>'
    + tin(340, 206, 32, 40) + fist(340, 200, 1, (34, 70))
    + arrow('M322 160 Q280 116 212 150'),
    '<path d="M30 240 H370" fill="none"/>'
    + '<path d="M106 132 Q106 106 130 106 Q154 106 154 132" fill="none"/>'
    + '<rect x="70" y="132" width="100" height="98" rx="3"/>'
    + '<path d="M170 132 L224 112 V206 L170 230 Z"/>'
    + '<path d="M182 128 Q190 104 206 108" fill="none"/>'
    + fist(220, 168, 1, (34, 66))
    + arrow('M232 104 Q176 40 120 98')
    + '<rect x="282" y="210" width="80" height="14" rx="3"/><rect x="286" y="196" width="72" height="14" rx="3"/>'
    + '<rect x="290" y="182" width="64" height="14" rx="3"/>'
]


# ── Say sorry for something, even a small thing ──────────────────────────
D[key('Say sorry for something, even a small thing')] = [
    ground(278)
    + person(110, 276, 'kid', arms=((-1, None), (1, (118, 170, 160, 200))), look=1, mouth='flat', brows='sad')
    + think(160, 18, 190, 120, 140, 116, storm(255, 66, 1.3))
    + motion('M236 120 l-4 12', 'M262 122 l-4 12', 'M288 118 l-4 12'),
    ground(278)
    + person(90, 276, 'kid', look=1, legs='walk', mouth='flat')
    + person(250, 276, 'small', legs='sit_r', look=-1, mouth='sad', brows='sad')
    + blocks_down(318, 276)
    + arrow('M138 258 Q172 246 206 258', dashed=True),
    ground(278)
    + person(110, 276, 'kid', arms=((-1, (124, 214, 100, 214)), (1, (132, 214, 146, 214))), look=1, mouth='open', brows='sad')
    + person(250, 276, 'small', legs='sit_r', look=-1, mouth='flat')
    + blocks_down(318, 276)
    + bubble(150, 28, 132, 70, 142, 120, heart(186, 62, 13) + squiggle(212, 54, 50, 2, 16))
    + motion('M152 150 l12 -6', 'M154 162 h14'),
    ground(278)
    + person(120, 276, 'kid', arms=((-1, None), (1, (192, 98, 162, 160))), look=1, mouth='grin')
    + person(278, 276, 'kid', arms=((-1, (208, 98, 238, 160)), (1, None)), look=-1, mouth='grin')
    + motion('M200 70 V56', 'M176 76 l-10 -10', 'M224 76 l10 -10', 'M170 98 h-14', 'M230 98 h14'),
]


# ── Let someone else choose the game ─────────────────────────────────────
D[key('Let someone else choose the game')] = [
    ground(278)
    + person(110, 276, 'kid', look=1, mouth='open')
    + person(290, 276, 'small', look=-1, mouth='smile')
    + bubble(30, 26, 96, 60, 106, 104, qmark(78, 56, 1.1))
    + think(220, 14, 140, 92, 284, 140, '<rect x="246" y="42" width="44" height="34" rx="3"/>'
            + thin('M252 50 h8 v8 h8 v8 h8 M282 46 v8') + dot(258, 68, 3) + dot(278, 54, 3)
            + f'<circle cx="320" cy="58" r="16"/>' + thin('M304 58 q16 -10 32 0 M320 42 V74'))
    + motion('M150 150 l12 -6', 'M152 162 h14'),
    ground(278)
    + person(64, 276, 'kid', legs='kneel', arms=((-1, None), (1, (128, 226, 110, 196))), look=1, mouth='smile')
    + person(340, 276, 'small', legs='kneel', arms=((-1, (280, 238, 290, 216)), (1, None)), look=-1, mouth='grin')
    + board(112, 200, 168, 62)
    + hands((128, 226)) + dice(150, 248, 18, 12)
    + '<circle cx="206" cy="218" r="7" fill="#1d1d1f"/><circle cx="184" cy="252" r="7"/>' + hands((280, 238))
    + arrow('M210 206 Q228 186 248 204'),
    ground(278)
    + person(120, 276, 'kid', arms=((-1, None), (1, (214, 176, 196, 206))), look=1, mouth='grin', brows='up')
    + dice(222, 160, 22, 18) + hands((214, 176))
    + board(214, 230, 150, 40)
    + arrow('M240 146 Q300 120 320 214', dashed=True) + motion('M234 138 l6 -10', 'M248 150 l10 -4'),
    ground(278)
    + person(100, 276, 'kid', arms=((-1, None), (1, (194, 196, 160, 210))), look=1, mouth='grin')
    + person(300, 276, 'small', arms=((-1, (206, 198, 240, 214)), (1, None)), look=-1, mouth='grin')
    + board(140, 252, 120, 22)
    + motion('M200 172 v-12', 'M200 220 v12', 'M184 176 l-6 -8', 'M216 176 l6 -8'),
]
