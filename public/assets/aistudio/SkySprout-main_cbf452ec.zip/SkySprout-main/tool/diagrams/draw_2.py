"""Diagrams for more Drawing challenges (a creature with a superpower, a house
on another planet, a secret family sketch, a dream bedroom, a new ice cream
flavour, a circles-only picture, favourite food with a face). The child's
drawing sits on a sheet of paper seen slightly from above; colouring in is
shown as light hatching. The blue accent is only for arrows and motion lines."""
import math
import re

from style import INK, arrow, dot, ghost, motion, ground, thin
from craft import scribble, star
from kind import bubble, burst, crayon_held, g, pen_held, person, sofa, sofa_sitter, sparkle
from craft_3 import grip

D = {}


def key(title):
    return re.sub(r'[^a-z0-9]+', '_', title.lower()).strip('_')[:48]


# ── Shared bits ──────────────────────────────────────────────────────────
X0, Y0, X1, Y1 = 64, 38, 336, 256


def sheet(x0=X0, y0=Y0, x1=X1, y1=Y1):
    """A sheet of paper lying on the table, seen slightly from above (a little narrower at the top)."""
    return (f'<path d="M{x0} {y1} L{x1} {y1} L{x1} {y1 + 4} L{x0} {y1 + 4} Z" stroke-width="1.6"/>'
            f'<path d="M{x0 + 7} {y0} H{x1 - 7} L{x1} {y1} H{x0} Z"/>')


def pencil(tx, ty, a=0):
    """A pencil with its point at (tx, ty), body going off at a degrees."""
    return g('<path d="M0 0 L16 -6 V6 Z"/>' + f'<path d="M0 0 L5 -2 V2 Z" fill="{INK}" stroke-width="1.4"/>'
             '<rect x="16" y="-6" width="58" height="12" rx="1"/>' + thin('M16 0 H74')
             + '<rect x="74" y="-6" width="12" height="12" rx="3"/>', tx, ty, 1, a)


def pencil_held(tx, ty, a=-40):
    r = math.radians(a)
    return pencil(tx, ty, a) + grip(tx + 44 * math.cos(r), ty + 44 * math.sin(r), a + 180 - 60)


_hid = [0]


def hatch(d, bbox, gap=7, ang=45):
    """Light colouring-in strokes clipped to the shape d (bbox = x0, y0, x1, y1)."""
    _hid[0] += 1
    cid = f'h{_hid[0]}'
    x0, y0, x1, y1 = bbox
    span = (x1 - x0) + (y1 - y0)
    k = math.tan(math.radians(ang))
    lines = ''.join(f'M{x0 + i:.1f} {y1} L{x0 + i + (y1 - y0) / k:.1f} {y0} ' for i in range(-span, span, gap))
    return (f'<clipPath id="{cid}"><path d="{d}"/></clipPath>'
            f'<path d="{lines}" clip-path="url(#{cid})" fill="none" stroke-width="1.3"/>')


def held_sheet(x, y, w=56, h=72, inside=''):
    """A sheet held up by a hand at its lower-left edge (x, y = top-left corner)."""
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="2"/>' + inside


# ── Invent a creature and give it a superpower ───────────────────────────
CX, CY, CR = 176, 140, 42


def _legs():
    s = ''
    for a in (115, 140, 162, 65, 40, 18):
        r = math.radians(a)
        sx, sy = CX + CR * math.cos(r), CY + CR * math.sin(r)
        ex, ey = CX + (CR + 26) * math.cos(r), CY + (CR + 26) * math.sin(r) + 10
        s += f'<path d="M{sx:.1f} {sy:.1f} L{ex:.1f} {ey:.1f}" fill="none"/>'
        s += f'<ellipse cx="{ex:.1f}" cy="{ey + 2:.1f}" rx="7" ry="4"/>'
    return s


def _creature(stage):
    s = ''
    if stage >= 2:
        s += _legs()
        # eyes on stalks
        s += (f'<path d="M{CX - 16} {CY - 36} L{CX - 24} {CY - 58} M{CX + 16} {CY - 36} L{CX + 24} {CY - 58}" fill="none"/>')
    s += f'<circle cx="{CX}" cy="{CY}" r="{CR}"/>'
    if stage >= 2:
        s += (f'<circle cx="{CX - 26}" cy="{CY - 66}" r="13"/><circle cx="{CX + 26}" cy="{CY - 66}" r="13"/>'
              + dot(CX - 22, CY - 66, 4.5) + dot(CX + 22, CY - 66, 4.5)
              + f'<path d="M{CX - 18} {CY + 6} Q{CX} {CY + 26} {CX + 18} {CY + 6} Z"/>'
              + f'<path d="M{CX - 6} {CY + 10} v6 h6 v-5" fill="none" stroke-width="1.6"/>'
              + thin(f'M{CX - 24} {CY - 14} q4 -4 8 0 M{CX + 16} {CY - 14} q4 -4 8 0'))
    return s


def _rainbow():
    s = ''
    for i in range(3):
        k = i * 9
        s += (f'<path d="M{CX + 14} {CY + 14 - k * .5} C{CX + 50} {CY - 40 - k} {CX + 96 + k} {CY - 50 - k} '
              f'{CX + 120 + k * .6} {CY + 10 - k * .4}" fill="none" stroke-width="1.8"/>')
    return s + star(CX + 138, CY + 26, 9) + star(CX + 116, CY + 40, 6) + star(CX + 144, CY - 4, 6)


D[key('Invent a creature and give it a superpower')] = [
    sheet()
    + '<circle cx="122" cy="150" r="34"/>'
    + '<ellipse cx="198" cy="150" rx="20" ry="50"/>'
    + '<polygon points="'
    + ' '.join(f'{276 + (36 if i % 2 == 0 else 22) * math.cos(-math.pi / 2 + i * math.pi / 8):.1f},'
               f'{150 + (36 if i % 2 == 0 else 22) * math.sin(-math.pi / 2 + i * math.pi / 8):.1f}' for i in range(16))
    + '"/>'
    + arrow('M88 106 A50 50 0 0 1 160 110'),

    sheet() + _creature(2)
    + pen_held(CX + 54, CY + 42, -40)
    + arrow('M290 70 C260 60 236 64 218 74', dashed=True),

    sheet() + _creature(2) + _rainbow()
    + motion(f'M{CX + 128} {CY + 52} l-4 8', f'M{CX + 150} {CY + 44} l8 6', f'M{CX + 156} {CY + 22} l10 0'),

    sheet() + g(_creature(2), 0, -14)
    + scribble(104, 236, 4, 24) + scribble(218, 236, 3, 22)
    + pen_held(286, 232, -40)
    + arrow('M108 248 H200'),
]


# ── Draw a house on another planet ───────────────────────────────────────
GROUND = ('M78 204 C92 188 106 188 118 198 C130 210 144 184 160 186 C176 188 182 204 200 198 '
          'C220 190 232 178 250 188 C266 198 278 206 296 194 C306 188 314 190 322 196')
HX, HY, HR = 170, 192, 54


def _ground(full=True):
    s = f'<path d="{GROUND}" fill="none"/>'
    s += ('<ellipse cx="120" cy="226" rx="16" ry="5" stroke-width="1.8"/>'
          '<ellipse cx="236" cy="232" rx="20" ry="6" stroke-width="1.8"/>'
          '<ellipse cx="292" cy="218" rx="10" ry="4" stroke-width="1.8"/>'
          '<ellipse cx="180" cy="240" rx="9" ry="3" stroke-width="1.8"/>') if full else ''
    return s


def _dome(alien=False):
    s = (f'<path d="M{HX} {HY - HR - 4} V{HY - HR - 26}" fill="none"/><circle cx="{HX}" cy="{HY - HR - 30}" r="5"/>'
         f'<path d="M{HX - HR} {HY} A{HR} {HR} 0 0 1 {HX + HR} {HY} Z"/>'
         + thin(f'M{HX - HR + 8} {HY - 22} Q{HX} {HY - 30} {HX + HR - 8} {HY - 22}')
         + f'<path d="M{HX + 18} {HY} V{HY - 14} A10 10 0 0 1 {HX + 38} {HY - 14} V{HY} Z"/>'
         + f'<circle cx="{HX - 16}" cy="{HY - 26}" r="21"/>')
    if alien:
        ax, ay = HX - 12, HY - 20
        s += (f'<path d="M{ax - 4} {ay - 9} L{ax - 7} {ay - 17} M{ax + 4} {ay - 9} L{ax + 7} {ay - 17}" fill="none" stroke-width="1.6"/>'
              f'<circle cx="{ax - 7}" cy="{ay - 18}" r="2.2" fill="{INK}" stroke="none"/>'
              f'<circle cx="{ax + 7}" cy="{ay - 18}" r="2.2" fill="{INK}" stroke="none"/>'
              f'<circle cx="{ax}" cy="{ay}" r="10" stroke-width="1.8"/>'
              + dot(ax - 3, ay - 1, 1.6) + dot(ax + 3, ay - 1, 1.6)
              + thin(f'M{ax - 3} {ay + 4} q3 3 6 0')
              + thin(f'M{ax - 9} {ay + 5} L{ax - 16} {ay - 6}') + f'<circle cx="{ax - 17}" cy="{ay - 9}" r="3.5" stroke-width="1.6"/>')
    return s


def _sky():
    return ('<circle cx="112" cy="84" r="18"/><circle cx="106" cy="80" r="4" stroke-width="1.6"/>'
            '<circle cx="118" cy="92" r="3" stroke-width="1.6"/>'
            '<path d="M286 66 A20 20 0 1 0 300 100 A15 15 0 1 1 286 66 Z"/>'
            + star(236, 70, 9) + star(170, 64, 6) + star(322 - 16, 140, 6) + star(84, 134, 6)
            + dot(146, 92) + dot(262, 112) + dot(208, 102))


D[key('Draw a house on another planet')] = [
    sheet()
    + f'<path d="{GROUND.split(" C266")[0]}" fill="none"/>'
    + ghost('M250 188 C266 198 278 206 296 194 C306 188 314 190 322 196')
    + '<ellipse cx="120" cy="226" rx="16" ry="5" stroke-width="1.8"/><ellipse cx="180" cy="240" rx="9" ry="3" stroke-width="1.8"/>'
    + crayon_held(250, 188, -40)
    + arrow('M96 168 C130 154 170 152 214 160'),

    sheet() + _ground() + _dome()
    + crayon_held(HX + 46, HY - 27, -40)
    + arrow('M104 186 A68 68 0 0 1 166 118'),

    sheet() + _ground() + _dome() + _sky()
    + crayon_held(306, 140, -40)
    + motion('M286 128 l-8 -4', 'M294 118 l-4 -8'),

    sheet() + _ground() + _dome(alien=True) + _sky()
    + motion(f'M{HX - 44} {HY - 50} q-6 8 0 16', f'M{HX - 52} {HY - 56} q-8 14 0 28'),
]


# ── Draw someone in your family without them knowing ────────────────────
def _book(cx, cy):
    return (f'<path d="M{cx} {cy - 12} Q{cx - 14} {cy - 18} {cx - 28} {cy - 14} V{cy + 10} Q{cx - 14} {cy + 6} {cx} {cy + 12} '
            f'Q{cx + 14} {cy + 6} {cx + 28} {cy + 10} V{cy - 14} Q{cx + 14} {cy - 18} {cx} {cy - 12} Z"/>'
            + thin(f'M{cx} {cy - 12} V{cy + 12}'))


def _reader(cx, seat, floor, mouth='smile', eyes='dot', book=True):
    """A grown-up on the sofa holding a book open in front of them (or, surprised, hands up by their face)."""
    if not book:
        return (sofa_sitter(cx, seat, floor, 'adult', mouth, eyes, arms=[(-1, -36, -88), (1, 36, -88)])
                + _book(cx, seat - 6))
    return (sofa_sitter(cx, seat, floor, 'adult', mouth, eyes, arms=[(-1, -26, -34), (1, 26, -34)])
            + _book(cx, seat - 34)
            + f'<circle cx="{cx - 27}" cy="{seat - 34}" r="6"/><circle cx="{cx + 27}" cy="{seat - 34}" r="6"/>')


SK = 200  # the sketch's centre on the sheet


def _sketch(stage):
    """A drawing of a grown-up sitting reading: 1 = faint outline, 2 = finished sketch."""
    seat = ('M96 196 H304 M96 196 V150 Q96 140 108 140 H120 M304 196 V150 Q304 140 292 140 H280 '
            'M108 236 V196 M292 236 V196')
    head = f'M{SK + 26} 96 A26 26 0 1 0 {SK - 26} 96 A26 26 0 1 0 {SK + 26} 96'
    body = f'M{SK - 30} 196 L{SK - 26} 128 Q{SK} 118 {SK + 26} 128 L{SK + 30} 196'
    legs = f'M{SK - 22} 196 V236 M{SK - 4} 196 V236 M{SK + 4} 196 V236 M{SK + 22} 196 V236'
    if stage == 1:
        return ghost(seat) + ghost(head) + ghost(body) + ghost(legs)
    return (thin(seat) + f'<path d="{body} Z"/>' + thin(legs)
            + f'<path d="{head}"/>'
            + f'<path d="M{SK - 26} 92 Q{SK - 26} 66 {SK} 68 Q{SK + 26} 66 {SK + 26} 92 Q{SK + 10} 82 {SK} 76 '
              f'Q{SK - 10} 84 {SK - 26} 92 Z" fill="{INK}" stroke-width="1.6"/>'
            + dot(SK - 9, 98, 2) + dot(SK + 9, 98, 2) + thin(f'M{SK - 7} 108 q7 5 14 0')
            + thin(f'M{SK - 10} 128 L{SK} 140 L{SK + 10} 128 M{SK} 146 v0 M{SK} 160 v0')
            + dot(SK, 150, 1.8) + dot(SK, 166, 1.8)
            + _book(SK, 168)
            + f'<circle cx="{SK - 28}" cy="168" r="5"/><circle cx="{SK + 28}" cy="168" r="5"/>'
            + thin(f'M{SK - 30} 150 L{SK - 28} 163 M{SK + 30} 150 L{SK + 28} 163'))


D[key('Draw someone in your family without them knowing')] = [
    ground(256) + sofa(24, 232, 196, 256) + _reader(128, 196, 256)
    + person(320, 256, .95)
    + arrow('M300 112 C268 92 230 88 196 100', dashed=True),

    sheet() + _sketch(1)
    + pencil_held(SK + 30, 152, -40)
    + arrow('M160 124 A44 44 0 0 1 172 60'),

    sheet() + _sketch(2)
    + pencil_held(SK + 30, 154, -40)
    + motion(f'M{SK + 40} 170 l8 4', f'M{SK + 44} 158 l10 0'),

    ground(262) + sofa(18, 214, 196, 256)
    + _reader(116, 196, 256, mouth='talk', eyes='dot', book=False)
    + person(342, 262, .95, mouth='grin', arms=[(-1, -64, -88, -50, -110), (1, 30, -44)])
    + held_sheet(222, 128, 56, 76, inside=g('<circle cx="0" cy="-18" r="7" stroke-width="1.6"/>'
                                             '<path d="M-9 14 L-8 -6 Q0 -9 8 -6 L9 14 Z" stroke-width="1.6"/>'
                                             + thin('M-7 2 h14'), 250, 168))
    + f'<circle cx="278" cy="174" r="6"/>'
    + burst(116, 100, 34, 46, (-150, -115, -65, -30))
    + arrow('M260 116 C236 92 200 86 170 96'),
]


# ── Draw your dream bedroom ──────────────────────────────────────────────
BW0, BWY0, BW1, BWY1 = 136, 70, 264, 166


def _room(partial=False):
    s = f'<rect x="{BW0}" y="{BWY0}" width="{BW1 - BW0}" height="{BWY1 - BWY0}" fill="none"/>'
    s += f'<path d="M{BW0} {BWY0} L{X0 + 14} {Y0 + 12} M{BW1} {BWY0} L{X1 - 14} {Y0 + 12} M{BW0} {BWY1} L{X0 + 4} {Y1 - 6}" fill="none"/>'
    if not partial:
        s += f'<path d="M{BW1} {BWY1} L{X1 - 4} {Y1 - 6}" fill="none"/>'
    return s


CAR = ('M162 226 V200 Q162 192 172 192 H196 L210 176 H232 L242 192 H286 Q300 192 302 206 L304 226 Z')


def _bed():
    return (f'<path d="{CAR}"/>'
            + '<rect x="172" y="198" width="26" height="12" rx="5" stroke-width="1.8"/>'
            + thin('M204 200 Q240 194 290 204 M212 192 L218 180 H230 L236 192')
            + '<path d="M292 192 L298 176 H310 L306 192" stroke-width="1.8"/>'
            + '<circle cx="184" cy="228" r="11"/><circle cx="280" cy="228" r="11"/>'
            + dot(184, 228, 2.4) + dot(280, 228, 2.4))


def _things():
    tank = ('<rect x="214" y="90" width="40" height="30" rx="2"/>'
            + thin('M216 98 q5 -3 9 0 t9 0 t9 0 t9 0')
            + '<path d="M228 110 q6 -6 12 0 q-6 6 -12 0 Z M228 110 l-5 -4 v8 Z" stroke-width="1.6"/>'
            + thin('M210 122 H258'))
    slide = ('<path d="M96 120 V232 M114 120 V232" fill="none"/>'
             + thin('M96 140 H114 M96 162 H114 M96 184 H114 M96 206 H114')
             + '<path d="M114 120 H128 C140 150 140 200 160 224 L152 230 C130 204 128 156 114 134 Z"/>')
    toys = ('<circle cx="140" cy="238" r="9"/>' + thin('M131 238 H149 M140 229 V247')
            + '<circle cx="168" cy="98" r="10"/><circle cx="160" cy="89" r="4"/><circle cx="176" cy="89" r="4"/>'
            + '<ellipse cx="168" cy="115" rx="10" ry="9"/>' + dot(165, 97, 1.4) + dot(171, 97, 1.4)
            + thin(f'M{BW0 + 14} 126 H{BW0 + 52}'))
    return slide + tank + toys


D[key('Draw your dream bedroom')] = [
    sheet() + _room(partial=True)
    + ghost(f'M{BW1} {BWY1} L{X1 - 4} {Y1 - 6}')
    + crayon_held(BW1, BWY1, -40)
    + arrow(f'M{BW1 - 10} {BWY1 + 20} L{X1 - 40} {Y1 - 14}'),

    sheet() + _room() + _bed()
    + crayon_held(304, 204, -40)
    + motion('M140 214 h-18', 'M140 226 h-26'),

    sheet() + _room() + _bed() + _things()
    + crayon_held(246, 108, -40)
    + sparkle(196, 140, 9) + sparkle(84, 104, 9),

    sheet() + _room()
    + hatch(f'M{BW0} {BWY0} H{BW1} V{BWY1} H{BW0} Z', (BW0, BWY0, BW1, BWY1), 14)
    + _bed() + _things()
    + hatch(CAR, (162, 176, 304, 226), 7)
    + '<circle cx="184" cy="228" r="11"/><circle cx="280" cy="228" r="11"/>' + dot(184, 228, 2.4) + dot(280, 228, 2.4)
    + hatch('M214 90 H254 V120 H214 Z', (214, 90, 254, 120), 6, -45)
    + hatch('M114 120 H128 C140 150 140 200 160 224 L152 230 C130 204 128 156 114 134 Z', (110, 116, 162, 232), 6, -45)
    + crayon_held(286, 160, -40)
    + motion('M262 150 l10 -8 l6 10 l10 -8')
    + sparkle(96, 64, 9),
]


# ── Design a new flavour of ice cream and its tub ────────────────────────
def strawberry(x, y, s=1.0):
    return g('<path d="M0 22 C-22 10 -22 -12 -10 -14 Q0 -16 10 -14 C22 -12 22 10 0 22 Z"/>'
             '<path d="M-10 -14 L-6 -22 L0 -16 L6 -22 L10 -14 Z" stroke-width="1.8"/>'
             + dot(-6, -4, 1.6) + dot(6, -4, 1.6) + dot(0, 6, 1.6) + dot(-8, 8, 1.6) + dot(8, 8, 1.6), x, y, s)


def banana(x, y, s=1.0):
    return g('<path d="M-26 -14 C-20 16 18 22 30 -4 Q32 -10 28 -10 C14 6 -8 4 -20 -16 Z"/>'
             '<path d="M28 -10 L32 -14" fill="none"/>' + thin('M-22 -12 C-12 8 14 12 26 -4'), x, y, s)


def choc(x, y, s=1.0, rot=-12):
    return g('<rect x="-26" y="-18" width="52" height="36" rx="2"/>'
             + thin('M-9 -18 V18 M8 -18 V18 M-26 0 H26')
             + '<path d="M2 -18 H26 V18 H18 L12 10 L6 18 L2 10 Z" stroke-width="1.8"/>', x, y, s, rot)


def scoop(cx, cy, r=34):
    return (f'<path d="M{cx - r - 4} {cy + 8} Q{cx - r - 6} {cy - r} {cx} {cy - r} Q{cx + r + 6} {cy - r} {cx + r + 4} {cy + 8} '
            f'q-8 8 -16 2 q-8 8 -18 2 q-8 8 -18 2 q-8 8 -18 2 q-8 8 -18 2 Z"/>')


SC = (190, 122)


def _cone():
    cx, cy = SC
    return (f'<path d="M{cx - 34} {cy + 10} L{cx} {cy + 104} L{cx + 34} {cy + 10} Z"/>'
            + thin(f'M{cx - 26} {cy + 22} L{cx + 12} {cy + 72} M{cx - 8} {cy + 12} L{cx + 22} {cy + 50} '
                   f'M{cx + 26} {cy + 22} L{cx - 12} {cy + 72} M{cx + 8} {cy + 12} L{cx - 22} {cy + 50}')
            + scoop(cx, cy, 40))


def _swirl():
    cx, cy = SC
    return (thin(f'M{cx - 34} {cy - 4} C{cx - 20} {cy - 30} {cx + 6} {cy + 8} {cx + 14} {cy - 18} '
                 f'C{cx + 20} {cy - 34} {cx - 4} {cy - 40} {cx - 12} {cy - 26}')
            + thin(f'M{cx - 10} {cy + 2} C{cx + 6} {cy - 4} {cx + 18} {cy + 6} {cx + 34} {cy - 6}')
            + dot(cx - 22, cy - 18, 2) + dot(cx + 22, cy - 16, 2) + dot(cx - 2, cy - 10, 2) + dot(cx + 10, cy + 4, 2))


def _tub(cx=200, top=100, w=150, h=120, s=1.0):
    hw, bw = w / 2, w / 2 - 16
    b = (f'<path d="M{-hw} 0 L{-bw} {h} Q0 {h + 10} {bw} {h} L{hw} 0 Z"/>'
         f'<rect x="{-hw - 6}" y="-14" width="{w + 12}" height="16" rx="5"/>'
         + scoop(0, -16, 30).replace('<path', '<path stroke-width="2.2"')
         + f'<path d="M{-hw + 12} 34 H{hw - 12} L{hw - 16} 92 H{-hw + 16} Z" stroke-width="1.8"/>')
    return g(b, cx, top, s)


TUB = (200, 108)

D[key('Design a new flavour of ice cream and its tub')] = [
    bubble(inside=strawberry(170, 120) + banana(226, 124) + choc(286, 122)),

    sheet() + _cone() + _swirl()
    + crayon_held(SC[0] + 40, SC[1] + 2, -40)
    + motion(f'M{SC[0] + 52} {SC[1] + 14} l10 4', f'M{SC[0] + 48} {SC[1] + 24} l6 8'),

    sheet() + _tub(*TUB)
    + strawberry(TUB[0] - 44, TUB[1] + 64, .55)
    + scribble(TUB[0] - 24, TUB[1] + 70, 3, 18) + scribble(TUB[0] - 50, TUB[1] + 90, 3, 16)
    + pen_held(TUB[0] - 4, TUB[1] + 88, -40)
    + arrow(f'M{TUB[0] - 44} {TUB[1] + 108} H{TUB[0] + 30}'),

    ground(262)
    + person(84, 262, 1.0, arms=[(-1, -30, -44), (1, 70, -84, 52, -110)])
    + held_sheet(152, 120, 62, 80, inside=_tub(183, 142, s=.3))
    + '<circle cx="154" cy="178" r="6"/>'
    + person(270, 262, .95, who='adult', mouth='grin', eyes='happy', arms=[(-1, -40, -70), (1, 30, -60)])
    + person(344, 262, .78, who='sib', mouth='grin', eyes='happy',
             arms=[(-1, -40, -130, -40, -100), (1, 40, -130, 40, -100)])
    + arrow('M150 104 C186 80 214 84 236 100'),
]


# ── Draw something using only circles ───────────────────────────────────
CAT = [(108, 170, 22), (146, 156, 24), (186, 166, 25), (226, 152, 26), (272, 132, 32)]


def _cat_body():
    return ''.join(f'<circle cx="{x}" cy="{y}" r="{r}"/>' for x, y, r in CAT)


def _cat_bits():
    hx, hy, _ = CAT[-1]
    s = ''
    for i, (x, y, r) in enumerate(CAT[:-1]):
        s += f'<circle cx="{x}" cy="{y + r + 6}" r="5"/>'
        s += f'<circle cx="{x - 6}" cy="{y - 4}" r="{r * .26:.1f}" stroke-width="1.8"/>'
        s += f'<circle cx="{x + 8}" cy="{y + 8}" r="{r * .18:.1f}" stroke-width="1.8"/>'
    s += (f'<circle cx="{hx - 14}" cy="{hy - 32}" r="4" stroke-width="1.8"/><circle cx="{hx + 12}" cy="{hy - 33}" r="4" stroke-width="1.8"/>'
          f'<circle cx="{hx - 18}" cy="{hy - 41}" r="6"/><circle cx="{hx + 16}" cy="{hy - 42}" r="6"/>'
          f'<circle cx="{hx - 10}" cy="{hy - 6}" r="9"/><circle cx="{hx + 12}" cy="{hy - 6}" r="9"/>'
          + dot(hx - 8, hy - 6, 3.4) + dot(hx + 14, hy - 6, 3.4)
          + f'<circle cx="{hx + 2}" cy="{hy + 14}" r="5" stroke-width="1.8"/>')
    return s


def _cup_top(x, y, r=30):
    return (f'<path d="M{x + r - 2} {y - 8} q18 -2 18 8 q0 10 -18 8" fill="none" stroke-width="5"/>'
            f'<path d="M{x + r - 2} {y - 8} q18 -2 18 8 q0 10 -18 8" fill="none" stroke="#fff" stroke-width="1"/>'
            f'<circle cx="{x}" cy="{y}" r="{r}"/><circle cx="{x}" cy="{y}" r="{r - 6}" fill="none" stroke-width="1.6"/>')


D[key('Draw something using only circles')] = [
    sheet()
    + '<circle cx="116" cy="88" r="30"/><circle cx="104" cy="196" r="22"/><circle cx="160" cy="140" r="12"/>'
    + '<circle cx="186" cy="80" r="16"/><circle cx="210" cy="212" r="26"/><circle cx="150" cy="226" r="9"/>'
    + '<circle cx="300" cy="216" r="14"/><circle cx="294" cy="72" r="10"/>'
    + ghost('M264 140 m-36 0 a36 36 0 1 0 72 0 a36 36 0 1 0 -72 0')
    + _cup_top(264, 140, 33)
    + crayon_held(264 + 25, 140 + 25, -10)
    + arrow('M214 128 A52 52 0 0 1 252 88'),

    sheet() + _cat_body()
    + arrow('M88 214 C150 238 220 226 266 186'),

    sheet() + _cat_body() + _cat_bits()
    + crayon_held(CAT[2][0] + 6, CAT[2][1] + CAT[2][2] + 6, 10)
    + arrow('M120 96 C132 100 136 110 138 120', dashed=True),

    sheet() + _cat_body()
    + ''.join(hatch(f'M{x - r} {y} a{r} {r} 0 1 0 {2 * r} 0 a{r} {r} 0 1 0 {-2 * r} 0', (x - r, y - r, x + r, y + r), 6,
                    45 if i % 2 else -45) for i, (x, y, r) in enumerate(CAT))
    + _cat_bits()
    + crayon_held(194, 198, 10)
    + motion('M146 222 l10 -8 l6 10 l10 -8')
    + sparkle(96, 82, 10) + sparkle(310, 222, 9),
]


# ── Draw your favourite food with a face ─────────────────────────────────
PZ = [(96, 78), (240, 78), (168, 204)]


def _pizza():
    (ax, ay), (bx, by), (cx, cy) = PZ
    return (f'<path d="M{ax} {ay} L{cx} {cy} L{bx} {by} Z"/>'
            + f'<path d="M{ax - 8} {ay - 4} Q{(ax + bx) / 2} {ay - 22} {bx + 8} {by - 4} Q{bx + 10} {by + 8} {bx - 2} {by + 8} '
              f'Q{(ax + bx) / 2} {ay - 6} {ax + 2} {ay + 8} Q{ax - 10} {ay + 8} {ax - 8} {ay - 4} Z"/>'
            + '<circle cx="130" cy="104" r="9"/><circle cx="198" cy="102" r="10"/><circle cx="168" cy="166" r="8"/>'
            + '<circle cx="142" cy="138" r="5" stroke-width="1.8"/><circle cx="196" cy="140" r="6" stroke-width="1.8"/>')


def _pizza_face():
    return ('<circle cx="152" cy="118" r="9"/><circle cx="182" cy="118" r="9"/>'
            + dot(154, 119, 3.4) + dot(184, 119, 3.4)
            + '<path d="M150 136 Q167 156 184 136 Z"/>')


def _pizza_limbs():
    return ('<path d="M114 112 Q96 118 84 100" fill="none"/><circle cx="82" cy="96" r="6"/>'
            '<path d="M222 112 Q240 120 252 104" fill="none"/><circle cx="254" cy="100" r="6"/>'
            '<path d="M160 190 V232 M176 190 V232" fill="none"/>'
            '<path d="M160 232 h-14 q-4 -6 4 -8 h10 Z M176 232 h14 q4 -6 -4 -8 h-10 Z"/>')


D[key('Draw your favourite food with a face')] = [
    sheet() + _pizza()
    + crayon_held(PZ[2][0], PZ[2][1], -40)
    + arrow('M84 108 C100 150 124 186 148 208'),

    sheet() + _pizza() + _pizza_face()
    + arrow('M110 60 C130 46 150 50 160 66', dashed=True)
    + arrow('M270 176 C246 176 214 166 194 152', dashed=True),

    sheet() + _pizza() + _pizza_face() + _pizza_limbs()
    + crayon_held(258, 100, -10)
    + motion('M86 82 l-1 -9', 'M98 88 l5 -8'),

    sheet() + _pizza() + _pizza_face() + _pizza_limbs()
    + '<path d="M276 112 H312 Q324 112 324 124 V150 Q324 162 312 162 H276 Q264 162 264 150 V146 L222 146 '
      'L264 130 V124 Q264 112 276 112 Z"/>'
    + scribble(272, 144, 2, 22)
    + motion('M300 100 l2 -9', 'M316 104 l6 -7'),
]
