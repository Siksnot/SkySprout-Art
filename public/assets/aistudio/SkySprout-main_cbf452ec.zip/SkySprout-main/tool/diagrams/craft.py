"""Diagrams for the Craft challenges (sock puppet, paper crown, box robot,
bookmark, paper plane, animal mask, card). Paper, socks and boxes are clean
outlines; fold and cut lines are dashed ink; the accent is only for arrows
and motion lines."""
import math

from style import arrow, dot, ghost, ground, hand, motion, thin

D = {}


# ── Shared bits ──────────────────────────────────────────────────────────
def g(body, x=0, y=0, s=1, rot=0):
    t = f'translate({x} {y})'
    if rot:
        t += f' rotate({rot})'
    if s != 1:
        t += f' scale({s})'
    return f'<g transform="{t}">{body}</g>'


def face(cx, cy, r=26, hair=True):
    s = (f'<circle cx="{cx}" cy="{cy}" r="{r}"/>'
         + dot(cx - r * .35, cy - r * .08) + dot(cx + r * .35, cy - r * .08)
         + thin(f'M{cx - r * .3} {cy + r * .35} q{r * .3} {r * .25} {r * .6} 0'))
    if hair:
        s += f'<path d="M{cx - r * .92} {cy - r * .4} q{r * .3} {-r * .85} {r * 1.1} {-r * .7} q{r * .6} {r * .02} {r * .8} {r * .5}" fill="none"/>'
    return s


def person(cx, by, s=1.0, arms=None, adult=False, head=True):
    """A simple child (or grown-up) standing, feet at by. arms: list of (shoulder side, end dx, end dy)
    in local units; default both arms hang down."""
    leg = 60 if adult else 40
    top = leg + (66 if adult else 56)
    b = (f'<rect x="-14" y="{-leg}" width="10" height="{leg}" rx="3"/>'
         f'<rect x="4" y="{-leg}" width="10" height="{leg}" rx="3"/>')
    arms = arms if arms is not None else [(-1, -30, -44), (1, 30, -44)]
    a = ''
    for side, ex, ey in arms:
        sx = 18 * side
        a += (f'<path d="M{sx} {-top + 8} Q{ex * .8} {(ey - top + 8) / 2 - 6} {ex} {ey}" fill="none" stroke-width="7"/>'
              f'<path d="M{sx} {-top + 8} Q{ex * .8} {(ey - top + 8) / 2 - 6} {ex} {ey}" fill="none" stroke="#fff" stroke-width="2.2"/>'
              f'<circle cx="{ex}" cy="{ey}" r="6"/>')
    body = f'<path d="M-22 {-leg} L-18 {-top + 4} Q0 {-top - 4} 18 {-top + 4} L22 {-leg} Z"/>'
    h = ''
    if head:
        hy = -top - 26
        h = f'<rect x="-5" y="{-top - 6}" width="10" height="8"/>' + face(0, hy, 24, hair=not adult)
        if adult:  # grown-up: a bun and round glasses
            h = (f'<circle cx="0" cy="{hy - 28}" r="9"/>' + h
                 + f'<path d="M-22 {hy - 6} q4 -20 22 -20 q18 0 22 20" fill="none"/>'
                 + f'<circle cx="-8.5" cy="{hy - 2}" r="6.5" fill="none" stroke-width="1.6"/>'
                 + f'<circle cx="8.5" cy="{hy - 2}" r="6.5" fill="none" stroke-width="1.6"/>'
                 + thin(f'M-2 {hy - 3} h4'))
    return g(b + body + a + h, cx, by, s)


def scissors(x, y, rot=0, s=1.0, opn=22):
    """Scissors with the blade tips pointing along +x from the pivot at (x, y)."""
    blade = 'M0 -3 L54 -2 Q58 0 54 2 L0 4 Z'
    b = (f'<g transform="rotate({-opn / 2})"><path d="{blade}"/></g>'
         f'<g transform="rotate({opn / 2})"><path d="{blade}"/></g>'
         '<path d="M0 0 L-20 -10 M0 0 L-20 10" fill="none" stroke-width="4"/>'
         '<ellipse cx="-30" cy="-13" rx="12" ry="8"/><ellipse cx="-30" cy="13" rx="12" ry="8"/>'
         + dot(0, 0, 2.6))
    return g(b, x, y, s, rot)


def pen(x, y, rot=-50, s=1.0):
    """A felt pen, tip at (x, y), body running off at angle rot (degrees, -90 = straight up)."""
    b = ('<path d="M0 0 L12 -4 V4 Z"/>'
         '<rect x="12" y="-7" width="64" height="14" rx="3"/>'
         '<rect x="76" y="-8" width="14" height="16" rx="3"/>'
         + thin('M24 -7 V7'))
    return g(b, x, y, s, rot)


def fist(x=0, y=0, rot=0, s=1.0):
    """A mitten fist closed round something at (x, y); the forearm runs off along +x (turned by rot)."""
    b = ('<path d="M14 -11 L66 -11 M14 11 L66 11" fill="none"/>'
         '<rect x="14" y="-11" width="52" height="22" stroke="none"/>'
         '<rect x="64" y="-15" width="20" height="30" rx="3"/>'
         '<path d="M-18 -6 Q-18 -19 -6 -19 H6 Q18 -19 18 -6 V6 Q18 19 6 19 H-6 Q-18 19 -18 6 Z"/>'
         + thin('M-18 -4 h9 M-18 6 h9') + '<path d="M-10 -19 Q0 -30 12 -18" fill="none"/>')
    return g(b, x, y, s, rot)


def pen_held(x, y, rot=-50, s=1.0, arm=70):
    """A felt pen held in a fist, tip at (x, y)."""
    return g(pen(0, 0, 0) + fist(40, 0, arm), x, y, s, rot)


def scissors_held(x, y, rot=0, s=1.0, opn=22, arm=-150, hs=1.0):
    return g(scissors(0, 0, 0, 1, opn) + fist(-30, 0, arm, hs), x, y, s, rot)


def tape(x, y, w=40, h=14, rot=0):
    z = 3
    pts = [(0, 0), (w, 0), (w - z, h / 4), (w, h / 2), (w - z, 3 * h / 4), (w, h), (0, h),
           (z, 3 * h / 4), (0, h / 2), (z, h / 4)]
    p = ' '.join(f'{a - w / 2},{b - h / 2}' for a, b in pts)
    return g(f'<polygon points="{p}"/>', x, y, 1, rot)


def tape_roll(x, y, r=24):
    return (f'<circle cx="{x}" cy="{y}" r="{r}"/><circle cx="{x}" cy="{y}" r="{r - 11}"/>'
            + f'<path d="M{x - r} {y} V{y + r + 14} l4 3 l-4 3"  fill="none"/>')


def star(cx, cy, r, fill=False):
    pts = []
    for i in range(10):
        a = -math.pi / 2 + i * math.pi / 5
        rr = r if i % 2 == 0 else r * .45
        pts.append(f'{cx + rr * math.cos(a):.1f},{cy + rr * math.sin(a):.1f}')
    return f'<polygon points="{" ".join(pts)}" stroke-width="1.8"/>'


def heart(cx, cy, s, sw=1.8):
    return (f'<path d="M{cx} {cy + s * .8} C{cx - s * 1.4} {cy - s * .1} {cx - s * .6} {cy - s * 1.1} {cx} {cy - s * .4} '
            f'C{cx + s * .6} {cy - s * 1.1} {cx + s * 1.4} {cy - s * .1} {cx} {cy + s * .8} Z" stroke-width="{sw}"/>')


def heart_d(cx, cy, s):
    return (f'M{cx} {cy + s * .8} C{cx - s * 1.4} {cy - s * .1} {cx - s * .6} {cy - s * 1.1} {cx} {cy - s * .4} '
            f'C{cx + s * .6} {cy - s * 1.1} {cx + s * 1.4} {cy - s * .1} {cx} {cy + s * .8}')


def sun(cx, cy, r):
    rays = ''.join(f'M{cx + (r + 4) * math.cos(a):.1f} {cy + (r + 4) * math.sin(a):.1f} '
                   f'L{cx + (r + 11) * math.cos(a):.1f} {cy + (r + 11) * math.sin(a):.1f} '
                   for a in [i * math.pi / 4 for i in range(8)])
    return f'<circle cx="{cx}" cy="{cy}" r="{r}" stroke-width="1.8"/>' + f'<path d="{rays}" fill="none" stroke-width="1.8"/>'


def scribble(x, y, n, w=22):
    """Joined-up 'handwriting' loops (no real letters)."""
    d = f'M{x} {y}'
    for i in range(n):
        h = (14, 20, 10, 18, 12)[i % 5]
        d += f' c{w * .2} -{h * .2} {w * .55} -{h} {w * .35} -{h} c-{w * .25} 0 -{w * .2} {h * .7} {w * .15} {h} c{w * .15} {h * .1} {w * .3} -{h * .05} {w * .45} -{h * .15}'
    return thin(d)




# ── Make a puppet from a sock ────────────────────────────────────────────
_SOCK = ('M-30 0 C-34 -50 -42 -110 -12 -140 C18 -170 90 -164 112 -132 Q118 -122 106 -118 '
         'L40 -104 L100 -86 Q110 -78 98 -70 C70 -56 40 -50 30 -30 C27 -20 30 -10 30 0 Z')
_HAIR = ''.join(f'M{x} {y} q-10 -8 -4 -18 q8 -7 1 -16 ' for x, y in ((-18, -134), (0, -148), (20, -154), (40, -154)))


def _puppet(eyes=2, extras=False, arm=True):
    s = f'<path d="{_HAIR}" fill="none"/>' if extras else ''
    if arm:  # the wrist and sleeve the sock is pulled over
        s += '<path d="M-24 0 L-22 46 M24 0 L22 46" fill="none"/><rect x="-30" y="44" width="60" height="22" rx="4"/>'
    s += (f'<path d="{_SOCK}"/>'
          + thin('M-31 -22 H29') + ''.join(thin(f'M{x} -20 V-2') for x in (-20, -10, 0, 10, 20)))
    for i, (ex, ey) in enumerate(((26, -122), (62, -132))):
        if i < eyes:
            s += f'<circle cx="{ex}" cy="{ey}" r="13"/>' + dot(ex + 4, ey + 1, 4.5)
    if extras:  # a paper tongue hanging over the lower lip
        s += ('<path d="M64 -94 L98 -84 C114 -80 122 -66 114 -56 C106 -48 96 -54 96 -62 C96 -70 84 -78 62 -86 Z"/>'
              + thin('M84 -82 q16 6 20 18'))
    return s


def _flat_sock(x, y):
    return g('<path d="M0 0 H40 V82 L82 100 Q98 110 90 128 Q82 142 64 136 L10 118 Q-4 112 0 98 Z"/>'
             + thin('M0 14 H40') + ''.join(thin(f'M{i} 2 V12') for i in (8, 16, 24, 32)), x, y)


_PX, _PY = 196, 214

D['make_a_puppet_from_a_sock'] = [
    _flat_sock(36, 70) + g(_puppet(eyes=0), _PX + 30, _PY)
    + arrow('M100 64 C130 30 170 40 186 76')
    + motion(f'M{_PX + 30 + 128} {_PY - 120} q10 18 0 34'),
    g(_puppet(eyes=1), _PX, _PY)
    + ghost(f'M{_PX + 62 - 13} {_PY - 132} a13 13 0 1 0 26 0 a13 13 0 1 0 -26 0')
    + f'<circle cx="{_PX + 150}" cy="52" r="13"/>' + dot(_PX + 154, 53, 4.5)
    + arrow(f'M{_PX + 132} 48 C{_PX + 104} 34 {_PX + 76} 50 {_PX + 68} {_PY - 152}'),
    g(_puppet(eyes=2, extras=True), _PX, _PY)
    + arrow(f'M{_PX + 150} {_PY - 10} C{_PX + 152} {_PY - 34} {_PX + 142} {_PY - 54} {_PX + 124} {_PY - 62}')
    + arrow(f'M{_PX - 84} {_PY - 186} C{_PX - 64} {_PY - 206} {_PX - 40} {_PY - 196} {_PX - 28} {_PY - 172}'),
    g(_puppet(eyes=2, extras=True, arm=False), 186, 246)
    + '<path d="M36 196 H364 Q372 196 372 204 V266 H28 V204 Q28 196 36 196 Z"/>'
    + thin('M28 222 H372 M140 222 V266 M260 222 V266')
    + motion('M318 124 q10 16 0 32', 'M332 112 q18 28 0 56', 'M346 100 q26 40 0 80'),
]


# ── Make a crown from paper and decorate it ──────────────────────────────
def _zig(x0, x1, yb, h, ph, n, bend=0):
    """A crown band: straight sides, n zigzag points on top, bottom edge bowed by bend."""
    w = (x1 - x0) / n
    yt = yb - h
    d = f'M{x0} {yb} V{yt}'
    for i in range(n):
        d += f' L{x0 + (i + .5) * w:.1f} {yt - ph} L{x0 + (i + 1) * w:.1f} {yt}'
    d += f' V{yb} Q{(x0 + x1) / 2} {yb + bend} {x0} {yb} Z'
    return d


def _crown_strip_cut(k):
    x0, x1, yb, h, ph, n = 30, 370, 170, 30, 36, 8
    w = (x1 - x0) / n
    yt = yb - h
    d = f'M{x0} {yb} V{yt}'
    for i in range(k):
        d += f' L{x0 + (i + .5) * w:.1f} {yt - ph} L{x0 + (i + 1) * w:.1f} {yt}'
    xk = x0 + k * w
    d += f' V{yt - ph} H{x1} V{yb} Z'
    gz = ''.join(f'M{x0 + i * w:.1f} {yt} L{x0 + (i + .5) * w:.1f} {yt - ph} L{x0 + (i + 1) * w:.1f} {yt} '
                 for i in range(k, n))
    return f'<path d="{d}"/>' + ghost(gz), xk, yt


def _gems(cx, y, w, k=1.0):
    return (star(cx, y, 9 * k) + f'<circle cx="{cx - w * .3}" cy="{y}" r="{6 * k}" stroke-width="1.8"/>'
            + f'<circle cx="{cx + w * .3}" cy="{y}" r="{6 * k}" stroke-width="1.8"/>'
            + heart(cx - w * .15, y, 6 * k) + heart(cx + w * .15, y, 6 * k))


def _crown_on(cx, yb, w=132, deco=False):
    return (f'<path d="{_zig(cx - w / 2, cx + w / 2, yb, 30, 30, 5, 14)}"/>'
            + (_gems(cx, yb - 12, w) if deco else ''))


_strip, _xk, _yt = _crown_strip_cut(3)
_kid_crown = person(200, 280, 1.25)

D['make_a_crown_from_paper_and_decorate_it'] = [
    _strip + f'<polygon points="78,198 100,198 89,222" stroke-width="1.8"/>'
    + scissors_held(_xk, _yt, -59, 1.2, 24, 150)
    + arrow(f'M{_xk + 40} {_yt - 62} C{_xk + 80} {_yt - 74} {_xk + 120} {_yt - 70} {_xk + 150} {_yt - 52}'),
    # the band goes round the head; the ends overlap at the side and get taped
    _kid_crown + _crown_on(200, 100)
    + thin('M244 70 V112 M256 70 V110') + tape(250, 90, 40, 20, 90)
    + hand(318, 152, 1.3, flip=True)
    + arrow('M130 124 C96 104 104 50 150 36', dashed=True),
    f'<path d="{_zig(90, 290, 200, 48, 44, 5, 22)}"/>' + _gems(190, 180, 230, 1.5)
    + pen_held(259, 172, -50)
    + motion('M100 80 l-10 -10', 'M190 62 v-14', 'M280 80 l10 -10'),
    _kid_crown + _crown_on(200, 100, deco=True)
    + motion('M110 54 l-12 -12', 'M96 104 h-18', 'M290 54 l12 -12', 'M304 104 h18', 'M200 32 v-12'),
]


# ── Build a robot from a cardboard box ───────────────────────────────────
DX, DY = 30, -22


def box(x, yb, w, h):
    yt = yb - h
    return (f'<rect x="{x}" y="{yt}" width="{w}" height="{h}"/>'
            f'<path d="M{x + w} {yt} L{x + w + DX} {yt + DY} V{yb + DY} L{x + w} {yb} Z"/>'
            f'<path d="M{x} {yt} L{x + w} {yt} L{x + w + DX} {yt + DY} L{x + DX} {yt + DY} Z"/>'
            + thin(f'M{x + w / 2} {yt} L{x + w / 2 + DX} {yt + DY}'))


def _tube(x, y, L, d=22):
    """A tube lying sideways from x to x + L (L < 0 for leftwards), open end at x + L."""
    x0 = min(x, x + L)
    return (f'<rect x="{x0}" y="{y}" width="{abs(L)}" height="{d}" stroke="none"/>'
            + f'<path d="M{x} {y} H{x + L} M{x} {y + d} H{x + L}" fill="none"/>'
            + f'<ellipse cx="{x + L}" cy="{y + d / 2}" rx="6" ry="{d / 2}"/>')


def _robot(x, yb, arms=False, face_=False, buttons=False, antenna=False):
    BW, BHt, HW, HH = 120, 112, 72, 56
    hx, hyb = x + (BW - HW) / 2 + DX / 2, yb - BHt + DY / 2
    s = _tube(x + 4, yb - BHt + 20, -50) if arms else ''
    s += box(x, yb, BW, BHt)
    if arms:
        s += _tube(x + BW + DX / 2, yb - BHt + 24, 50)
    if antenna:
        s += (f'<path d="M{hx + HW / 2 + 8} {hyb - HH - 8} V{hyb - HH - 34}" fill="none"/>'
              f'<circle cx="{hx + HW / 2 + 8}" cy="{hyb - HH - 40}" r="6"/>')
    s += box(hx, hyb, HW, HH)
    if face_:
        s += (f'<circle cx="{hx + 20}" cy="{hyb - 32}" r="9"/>' + dot(hx + 20, hyb - 32, 3.5)
              + f'<circle cx="{hx + 52}" cy="{hyb - 32}" r="9"/>' + dot(hx + 52, hyb - 32, 3.5)
              + f'<rect x="{hx + 22}" y="{hyb - 16}" width="28" height="8" rx="2" stroke-width="1.8"/>'
              + thin(f'M{hx + 29} {hyb - 16} v8 M{hx + 36} {hyb - 16} v8 M{hx + 43} {hyb - 16} v8'))
    if buttons:
        bx, by = x + 26, yb - BHt + 34
        s += (f'<circle cx="{bx}" cy="{by}" r="7" stroke-width="1.8"/><circle cx="{bx + 22}" cy="{by}" r="7" stroke-width="1.8"/>'
              + f'<circle cx="{bx + 66}" cy="{by + 6}" r="16" stroke-width="1.8"/>'
              + thin(f'M{bx + 66} {by + 6} l8 -10') + dot(bx + 66, by + 6, 2.2)
              + thin(f'M{bx + 52} {by + 6} h-4 M{bx + 66} {by - 10} v-4 M{bx + 80} {by + 6} h4')
              + f'<rect x="{bx - 8}" y="{by + 32}" width="40" height="16" rx="3" stroke-width="1.8"/>'
              + thin(f'M{bx - 2} {by + 40} h28'))
    return s


_RX, _RY = 128, 252

D['build_a_robot_from_a_cardboard_box'] = [
    ground(252) + box(52, 252, 120, 112) + box(250, 252, 72, 56)
    + arrow('M100 70 C110 90 112 100 112 118') + arrow('M286 128 C292 146 292 156 290 170'),
    ground(_RY) + _robot(_RX, _RY)
    + tape(_RX + 79, _RY - 128, 34, 14, 90) + tape(_RX + 113, _RY - 128, 34, 14, 90)
    + tape_roll(330, 170) + arrow('M318 136 C306 102 270 98 250 110'),
    ground(_RY) + _robot(_RX, _RY, arms=True, face_=True, buttons=True)
    + pen_held(_RX + 58, _RY - 30, -30, 1, 60)
    + arrow(f'M{_RX - 76} {_RY - 150} C{_RX - 66} {_RY - 130} {_RX - 62} {_RY - 118} {_RX - 52} {_RY - 106}'),
    ground(_RY) + _robot(_RX + 60, _RY, arms=True, face_=True, buttons=True, antenna=True)
    + person(86, _RY, 1, arms=[(-1, -30, -44), (1, 40, -150)])
    + motion(f'M{_RX + 168} 42 l10 -10', f'M{_RX + 184} 80 h16', f'M{_RX + 70} 42 l-10 -10'),
]


# ── Make a bookmark for someone in the family ────────────────────────────
def _strip(x=50, y=128, w=300, h=44):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="4"/>'


_NAME = scribble(70, 162, 6, 26)

D['make_a_bookmark_for_someone_in_the_family'] = [
    '<rect x="60" y="96" width="280" height="150" rx="3"/>'
    + '<path d="M60 140 H196" fill="none"/>' + ghost('M200 140 H340')
    + scissors_held(200, 140, 0, 1.0, 26, 140)
    + arrow('M246 120 C276 108 306 108 330 120'),
    _strip() + _NAME + pen_held(220, 160, -55)
    + motion('M232 176 l8 8', 'M218 182 l0 10'),
    _strip() + _NAME + heart(270, 152, 13) + star(306, 150, 14) + heart(246, 140, 5)
    + f'<circle cx="334" cy="150" r="5"/>'
    + '<path d="M334 150 C350 170 340 200 356 224 M334 150 C330 180 318 196 328 226" fill="none" stroke-width="1.8"/>'
    + pen_held(270, 142, -60)
    + motion('M244 108 l-6 -8', 'M228 122 h-10'),
    # the bookmark peeks out of a book, handed over to a grown-up's hand
    f'<g transform="rotate(-90 202 92)">{_strip(162, 80, 70, 24)}</g>'
    + heart(202, 72, 6)
    + '<path d="M150 112 H250 V242 H150 Z"/>' + '<path d="M250 112 L262 104 V234 L250 242" />'
    + thin('M254 116 V236 M258 112 V234') + thin('M162 112 V242')
    + heart(200, 176, 14)
    + hand(116, 268) + hand(318, 262, 1.25, flip=True)
    + arrow('M120 70 C170 30 250 30 300 70'),
]


# ── Fold a paper plane and see how far it flies ──────────────────────────
_SX0, _SX1, _ST, _SB = 125, 275, 40, 252
_MID = 200

D['fold_a_paper_plane_and_see_how_far_it_flies'] = [
    ghost(f'M{_MID} {_ST} H{_SX1} V{_SB} H{_MID}')
    + f'<rect x="{_SX0}" y="{_ST}" width="{_MID - _SX0}" height="{_SB - _ST}"/>'
    + f'<path d="M{_MID} {_ST} L{_MID + 46} {_ST - 12} V{_SB + 10} L{_MID} {_SB} Z"/>'
    + arrow(f'M{_MID + 70} {_ST + 2} C{_MID + 40} {_ST - 34} {_SX0 - 10} {_ST - 30} {_SX0 + 10} {_ST + 14}')
    + arrow(f'M{_SX0 - 20} {_SB - 30} C{_SX0 - 40} {_SB + 30} {_SX1 + 40} {_SB + 30} {_SX1 + 20} {_SB - 30}', dashed=True),
    f'<path d="M{_SX0} {_ST + 75} V{_SB} H{_SX1} V{_ST} H{_MID} Z"/>'
    + f'<path d="M{_MID} {_ST} L{_SX0} {_ST + 75} L{_MID} {_ST + 75} Z"/>'
    + thin(f'M{_MID} {_ST + 75} V{_SB}')
    + ghost(f'M{_MID} {_ST} L{_SX1} {_ST + 75}')
    + arrow(f'M{_SX1 + 12} {_ST + 6} C{_SX1 + 10} {_ST + 60} {_MID + 50} {_ST + 76} {_MID + 12} {_ST + 70}'),
    # left: corners folded in again to a long point, then folded in half.
    # right: seen from the side, each wing folds down along the dashed line.
    '<path d="M80 52 L42 156 V250 H118 V156 Z"/>'
    + thin('M80 52 L64 250 M80 52 L96 250') + ghost('M80 52 V250')
    + arrow('M36 150 C40 106 120 106 124 150')
    + '<path d="M354 196 L168 196 L168 92 Z"/>'
    + ghost('M352 192 L168 160')
    + arrow('M232 104 C262 110 268 148 252 172'),
    ground(258) + person(66, 258, 1, arms=[(-1, -28, -44), (1, 46, -132)])
    + g('<path d="M58 0 L-14 -12 L4 8 Z"/><path d="M58 0 L4 8 L-6 26 Z"/>', 310, 72, 1, 8)
    + motion('M118 120 C170 70 230 60 288 70', 'M250 100 h-30', 'M262 118 h-22'),
]


# ── Make a mask of your favourite animal ─────────────────────────────────
_MX, _MY = 200, 150


def _plate(cx=_MX, cy=_MY, r=92):
    return f'<circle cx="{cx}" cy="{cy}" r="{r}"/><circle cx="{cx}" cy="{cy}" r="{r - 14}" fill="none" stroke-width="1.6"/>'


def _eye(x, y, cut=True):
    d = f'M{x - 20} {y} Q{x} {y - 16} {x + 20} {y} Q{x} {y + 16} {x - 20} {y} Z'
    return f'<path d="{d}"/>' if cut else ghost(d)


def _lion_face(cx=_MX, cy=_MY):
    return (f'<path d="M{cx - 12} {cy + 14} H{cx + 12} Q{cx + 12} {cy + 22} {cx} {cy + 30} Q{cx - 12} {cy + 22} {cx - 12} {cy + 14} Z"/>'
            + f'<path d="M{cx} {cy + 30} V{cy + 38} M{cx} {cy + 38} q-10 12 -22 2 M{cx} {cy + 38} q10 12 22 2" fill="none"/>')


def _mane(cx=_MX, cy=_MY, R=112, n=16):
    d = ''
    for i in range(n):
        a0, a1 = 2 * math.pi * i / n, 2 * math.pi * (i + 1) / n
        p0 = (cx + R * .86 * math.cos(a0), cy + R * .86 * math.sin(a0))
        p1 = (cx + R * .86 * math.cos(a1), cy + R * .86 * math.sin(a1))
        am = (a0 + a1) / 2
        c = (cx + R * 1.12 * math.cos(am), cy + R * 1.12 * math.sin(am))
        d += f'<path d="M{p0[0]:.1f} {p0[1]:.1f} Q{c[0]:.1f} {c[1]:.1f} {p1[0]:.1f} {p1[1]:.1f} L{cx} {cy} Z"/>'
    return d


def _ear(x, y):
    return f'<circle cx="{x}" cy="{y}" r="22"/>' + thin(f'M{x - 10} {y - 4} q10 -10 20 0')


def _whiskers(cx=_MX, cy=_MY):
    return thin(f'M{cx - 24} {cy + 24} l-40 -6 M{cx - 24} {cy + 30} l-40 4 '
                f'M{cx + 24} {cy + 24} l40 -6 M{cx + 24} {cy + 30} l40 4')


def _mask(cx, cy, right_ear=True):
    ears = _ear(cx - 62, cy - 66) + (_ear(cx + 62, cy - 66) if right_ear else '')
    return (_mane(cx, cy) + ears + _plate(cx, cy) + _eye(cx - 34, cy - 18) + _eye(cx + 34, cy - 18)
            + _lion_face(cx, cy) + _whiskers(cx, cy))


D['make_a_mask_of_your_favourite_animal'] = [
    # a grown-up's (bigger) hand does the cutting
    _plate(170, 150) + _eye(136, 132) + _eye(204, 132, cut=False)
    + scissors_held(252, 150, 200, 1.0, 20, 220, 1.35)
    + arrow('M184 106 Q204 92 226 104'),
    _plate() + _eye(_MX - 34, _MY - 18) + _eye(_MX + 34, _MY - 18) + _lion_face()
    + pen_held(_MX + 22, _MY + 40, -40)
    + motion(f'M{_MX + 32} {_MY + 58} l8 6', f'M{_MX + 22} {_MY + 62} l2 10'),
    _mask(_MX, _MY, right_ear=False)
    + ghost(f'M{_MX + 40} {_MY - 66} a22 22 0 1 0 44 0 a22 22 0 1 0 -44 0')
    + _ear(352, 48)
    + arrow('M344 78 C340 100 318 104 292 92'),
    ground(282) + person(200, 282, 1, arms=[(-1, -30, -44), (1, 36, -34)])
    + '<path d="M236 248 V186" fill="none" stroke-width="6"/><path d="M236 248 V186" fill="none" stroke="#fff" stroke-width="1.6"/>'
    + g(_mask(0, 0), 200, 140, .55) + tape(236, 196, 22, 12, 90)
    + '<circle cx="236" cy="248" r="6"/>'
    + motion('M290 120 q12 18 0 36', 'M304 108 q22 30 0 60', 'M110 120 q-12 18 0 36', 'M96 108 q-22 30 0 60'),
]


# ── Make a card for someone you love ─────────────────────────────────────
def _card_front(x=128, y=40, w=144, h=220):
    return (f'<path d="M{x} {y} L{x + w + 16} {y - 10} V{y + h - 8} L{x} {y + h} Z"/>'
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}"/>' + heart(x + w / 2, y + h * .62, 34, 2.2))


D['make_a_card_for_someone_you_love'] = [
    ghost('M200 70 H320 V230 H200')
    + '<rect x="80" y="70" width="120" height="160"/>'
    + '<path d="M200 70 L256 52 V250 L200 230 Z"/>'
    + thin('M200 70 V230')
    + arrow('M290 70 C270 20 150 18 120 56'),
    _card_front() + f'<circle cx="236" cy="78" r="13" stroke-width="1.8"/>'
    + pen_held(250, 82, -40)
    + motion('M222 56 l-6 -8', 'M214 78 h-10', 'M222 100 l-6 8'),
    '<path d="M60 58 L200 40 V258 L60 240 Z"/><path d="M200 40 L340 58 V240 L200 258 Z"/>'
    + scribble(222, 100, 4, 22) + scribble(222, 136, 4, 22) + scribble(222, 172, 3, 22)
    + heart(240, 214, 10)
    + pen_held(286, 172, -45, 1, 100)
    + motion('M296 186 l8 8', 'M284 192 l0 10'),
    ground(276) + person(110, 276, 1, arms=[(-1, -30, -44), (1, 52, -84)])
    + person(296, 276, 1.05, arms=[(-1, -48, -88), (1, 30, -50)], adult=True)
    + '<rect x="160" y="166" width="54" height="68" rx="2"/>' + heart(187, 202, 12)
    + motion(heart_d(200, 98, 18)) + arrow('M160 140 C180 118 210 116 236 128'),
]
