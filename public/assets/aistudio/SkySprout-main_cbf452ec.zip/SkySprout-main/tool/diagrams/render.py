"""Turns the diagrams into the app's step pictures.

    python3 tool/diagrams/render.py            # every kind
    python3 tool/diagrams/render.py lego       # one kind (or one file: lego_2)
    python3 tool/diagrams/render.py lego --sheet   # also a contact sheet per challenge, to check them
    python3 tool/diagrams/render.py --install build_a_dinosaur ...   # put approved ones in the app

Drawing writes build/diagrams/<challenge>_<step>.webp (1200 x 900) for review;
--install copies a challenge's pictures into assets/catalog/img, where the app
and website use them. A kind's diagrams can be split over several files:
lego.py, lego_2.py and so on. Needs Node with Playwright and Pillow.
"""
import importlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

from PIL import Image

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
OUT = ROOT / 'assets/catalog/img'
WORK = ROOT / 'build/diagrams'
sys.path.insert(0, str(HERE))
from style import svg  # noqa: E402

KINDS = ['lego', 'craft', 'draw', 'outdoor', 'kind', 'cook']

SHOT = r'''
const { chromium } = require('playwright');
(async () => {
  const files = JSON.parse(process.argv[2]);
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1200, height: 900 } });
  for (const f of files) { await p.goto('file://' + f); await p.screenshot({ path: f.replace(/\.svg$/, '.png') }); }
  await b.close();
})();
'''


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('-')]
    if '--install' in sys.argv:
        OUT.mkdir(parents=True, exist_ok=True)
        n = 0
        for key in args:
            for f in sorted(WORK.glob(f'{key}_[0-9].webp')):
                shutil.copy(f, OUT / f.name)
                n += 1
        return print(f'Installed {n} pictures into {OUT.relative_to(ROOT)}')
    sheet = '--sheet' in sys.argv
    WORK.mkdir(parents=True, exist_ok=True)
    files, groups = [], {}
    mods = []
    for kind in args or KINDS:
        for f in sorted(HERE.glob(f'{kind}*.py')):
            if f.stem == kind or f.stem.startswith(kind + '_'):
                mods.append((f.stem.split('_')[0], importlib.import_module(f.stem)))
    for kind, mod in mods:
        for key, steps in mod.D.items():
            for i, body in enumerate(steps, 1):
                f = WORK / f'{key}_{i}.svg'
                f.write_text(svg(body, kind))
                files.append(str(f))
                groups.setdefault(key, []).append(f)
    if not files:
        return print('Nothing to draw')
    shot = WORK / f'shot_{os.getpid()}.js'
    shot.write_text(SHOT)
    node_path = subprocess.run(['npm', 'root', '-g'], capture_output=True, text=True).stdout.strip()
    subprocess.run(['node', str(shot), json.dumps(files)], check=True, env={**os.environ, 'NODE_PATH': node_path})
    shot.unlink()
    for f in files:
        png = Path(f).with_suffix('.png')
        Image.open(png).convert('RGB').save(png.with_suffix('.webp'), quality=80, method=6)
    if sheet:
        for key, fs in groups.items():
            ims = [Image.open(f.with_suffix('.png')) for f in fs]
            cols = 2 if len(ims) <= 4 else 3
            rows = (len(ims) + cols - 1) // cols
            s = Image.new('RGB', (cols * 1200, rows * 900), 'white')
            for i, im in enumerate(ims):
                s.paste(im, ((i % cols) * 1200, (i // cols) * 900))
                # a thin grey frame so steps are easy to tell apart
            s = s.resize((cols * 400, rows * 300))
            s.save(WORK / f'sheet_{key}.png')
    print(f'Drew {len(files)} pictures into {WORK.relative_to(ROOT)}')


if __name__ == '__main__':
    main()
