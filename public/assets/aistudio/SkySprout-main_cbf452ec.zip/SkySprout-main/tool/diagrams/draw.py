"""Diagrams for the first Drawing challenges (family of superheroes, treasure
island map, when I grow up, a four-box comic, a dream pet, the view from the
window, a chore robot). The child's paper is a sheet seen slightly from above
with their drawing on it in simple lines; the blue accent is only for arrows
and dashed motion lines."""
import math
import re

from style import INK, arrow, dot, ghost, ground, motion, thin
from craft import scribble, star, sun
from craft_3 import dog
from kind import bubble, g, pen_held, crayon_held, person, speech
from kind_3 import ball, block, book, car, cloud, face, teddy, bed
from kind_3 import speech as speech3
from kind_3 import cat as cat_stand
from kind import cat as cat_sit

D = {}


def key(title):
    return re.sub(r'[^a-z0-9]+', '_', title.lower()).strip('_')[:48]


# ── The sheet of paper ───────────────────────────────────────────────────
# A sheet lying on the table, seen slightly from above: its own 236 x 200
# drawing space is squashed a little and leans, so what the child draws on it
# is written in sheet units (u across, v down) and lands on the page through P().
SX, SY, SW, SH, SA, SK, SQ = 88, 42, 236, 200, 1.12, .12, .9


def P(u, v):
    return round(SX + SA * u - SK * v, 1), round(SY + SQ * v, 1)


def sheet(inner=''):
    c = [P(0, 0), P(SW, 0), P(SW, SH), P(0, SH)]
    pts = ' '.join(f'{x},{y}' for x, y in c)
    under = ' '.join(f'{x + 3},{y + 4}' for x, y in c)
    return (f'<polygon points="{under}" stroke-width="1.6"/><polygon points="{pts}"/>'
            f'<g stroke-width="1.9" transform="matrix({SA} 0 {-SK} {SQ} {SX} {SY})">{inner}</g>')


def pen_at(u, v, a=-40):
    """A hand holding a felt pen with its tip on the sheet at (u, v)."""
    x, y = P(u, v)
    return pen_held(x, y, a)


def crayon_at(u, v, a=-40):
    x, y = P(u, v)
    return crayon_held(x, y, a)


def arr(*uv, dashed=False):
    """An accent arrow through sheet points: start, (control, control,) end."""
    p = [P(u, v) for u, v in uv]
    if len(p) == 2:
        d = f'M{p[0][0]} {p[0][1]} L{p[1][0]} {p[1][1]}'
    elif len(p) == 3:
        d = f'M{p[0][0]} {p[0][1]} Q{p[1][0]} {p[1][1]} {p[2][0]} {p[2][1]}'
    else:
        d = f'M{p[0][0]} {p[0][1]} C{p[1][0]} {p[1][1]} {p[2][0]} {p[2][1]} {p[3][0]} {p[3][1]}'
    return arrow(d, dashed)


def squig(x, y, n=3, s=.6):
    """A short line of pretend writing."""
    return g(scribble(0, 0, n, 22), x, y, s)


def line(d, w=2):
    return f'<path d="{d}" fill="none" stroke-width="{w}"/>'


def heart_ink(cx, cy, s):
    return (f'<path d="M{cx} {cy + s * .8} C{cx - s * 1.4} {cy - s * .1} {cx - s * .6} {cy - s * 1.1} {cx} {cy - s * .4} '
            f'C{cx + s * .6} {cy - s * 1.1} {cx + s * 1.4} {cy - s * .1} {cx} {cy + s * .8} Z" stroke-width="1.8"/>')


# ── Draw your family as superheroes ──────────────────────────────────────
def fig(x, by, h, who='dad', cape=False, mask=False, arms='down', cw=.28):
    """A stick-figure person in the child's drawing, feet at by, h tall."""
    r = h * .14
    hy = by - h + r
    ny = by - h + 2 * r
    sh = ny + h * .1
    hip = by - h * .42
    s = ''
    if cape:
        s += (f'<path d="M{x - 4:.1f} {sh - 3:.1f} L{x - h * cw:.1f} {by - h * .14:.1f} '
              f'Q{x:.1f} {by - h * .04:.1f} {x + h * cw:.1f} {by - h * .14:.1f} L{x + 4:.1f} {sh - 3:.1f} Z"/>')
    if who == 'mum':
        sk = by - h * .32
        s += (f'<path d="M{x:.1f} {ny:.1f} L{x - h * .18:.1f} {sk:.1f} H{x + h * .18:.1f} Z"/>'
              + line(f'M{x - h * .07:.1f} {sk:.1f} L{x - h * .1:.1f} {by:.1f} M{x + h * .07:.1f} {sk:.1f} L{x + h * .1:.1f} {by:.1f}'))
    else:
        s += line(f'M{x} {ny:.1f} V{hip:.1f} M{x - h * .14:.1f} {by:.1f} L{x} {hip:.1f} L{x + h * .14:.1f} {by:.1f}')
    ends = {'down': [(-1, h * .24, sh + h * .26), (1, h * .24, sh + h * .26)],
            'up': [(-1, h * .22, hy - r * 1.4), (1, h * .22, hy - r * 1.4)],
            'one': [(-1, h * .24, sh + h * .26), (1, h * .26, hy - r * 1.2)]}[arms]
    for side, dx, ey in ends:
        sx = x + side * (h * .05 if who == 'mum' else 0)
        s += line(f'M{sx:.1f} {sh:.1f} L{x + side * dx:.1f} {ey:.1f}')
    if who == 'mum':
        s += (f'<path d="M{x - r * 1.1:.1f} {hy + r * 1.3:.1f} Q{x - r * 1.5:.1f} {hy - r * 1.4:.1f} {x:.1f} {hy - r * 1.25:.1f} '
              f'Q{x + r * 1.5:.1f} {hy - r * 1.4:.1f} {x + r * 1.1:.1f} {hy + r * 1.3:.1f} Z"/>')
    s += f'<circle cx="{x}" cy="{hy:.1f}" r="{r:.1f}"/>'
    if who == 'dad':
        s += line(f'M{x - r * .6:.1f} {hy - r * .8:.1f} l-2 -5 M{x:.1f} {hy - r:.1f} v-6 M{x + r * .6:.1f} {hy - r * .8:.1f} l2 -5', 1.6)
    elif who == 'kid':
        s += line(f'M{x - r * .2:.1f} {hy - r:.1f} q-3 -7 3 -9 M{x + r * .3:.1f} {hy - r:.1f} q2 -6 7 -5', 1.6)
    elif who == 'baby':
        s += line(f'M{x:.1f} {hy - r:.1f} q-1 -6 4 -6 q4 1 1 4', 1.6)
    ey_ = hy - r * .1
    if mask:
        s += (f'<rect x="{x - r * 1.05:.1f}" y="{ey_ - r * .36:.1f}" width="{r * 2.1:.1f}" height="{r * .62:.1f}" '
              f'rx="{r * .3:.1f}" fill="{INK}" stroke="none"/>'
              f'<circle cx="{x - r * .38:.1f}" cy="{ey_ - r * .05:.1f}" r="{r * .14 + .4:.1f}" fill="#fff" stroke="none"/>'
              f'<circle cx="{x + r * .38:.1f}" cy="{ey_ - r * .05:.1f}" r="{r * .14 + .4:.1f}" fill="#fff" stroke="none"/>')
    else:
        s += dot(x - r * .38, ey_, 1.5) + dot(x + r * .38, ey_, 1.5)
    s += line(f'M{x - r * .4:.1f} {hy + r * .4:.1f} q{r * .4:.1f} {r * .3:.1f} {r * .8:.1f} 0', 1.6)
    return s


FAM = [(40, 'dad', 96), (106, 'mum', 90), (166, 'kid', 70), (214, 'baby', 48)]
FB = 164  # where their feet stand on the sheet


def flyer(x, y, h, mask=True):
    """Dad flying to the right, hips at (x, y), arms out in front."""
    r = h * .14
    hx = x + h * .56
    s = (f'<path d="M{x + h * .34:.1f} {y - 1:.1f} Q{x + h * .14:.1f} {y - 16:.1f} {x - h * .08:.1f} {y - 22:.1f} '
         f'l2 6 l-5 4 l3 5 Q{x + h * .14:.1f} {y - 4:.1f} {x + h * .34:.1f} {y + 1:.1f} Z"/>'
         + line(f'M{x + h * .38:.1f} {y} H{x:.1f} L{x - h * .42:.1f} {y - 6:.1f} M{x:.1f} {y} L{x - h * .4:.1f} {y + 10:.1f}')
         + line(f'M{x + h * .32:.1f} {y} L{x + h * .86:.1f} {y - 14:.1f} M{x + h * .32:.1f} {y} L{x + h * .84:.1f} {y + 2:.1f}')
         + f'<circle cx="{hx:.1f}" cy="{y - r * .9:.1f}" r="{r:.1f}"/>')
    ey = y - r
    if mask:
        s += (f'<rect x="{hx - r * 1.05:.1f}" y="{ey - r * .36:.1f}" width="{r * 2.1:.1f}" height="{r * .62:.1f}" '
              f'rx="{r * .3:.1f}" fill="{INK}" stroke="none"/>'
              f'<circle cx="{hx - r * .38:.1f}" cy="{ey - r * .05:.1f}" r="{r * .14 + .4:.1f}" fill="#fff" stroke="none"/>'
              f'<circle cx="{hx + r * .38:.1f}" cy="{ey - r * .05:.1f}" r="{r * .14 + .4:.1f}" fill="#fff" stroke="none"/>')
    s += line(f'M{hx - r * .4:.1f} {ey + r * .5:.1f} q{r * .4:.1f} {r * .3:.1f} {r * .8:.1f} 0', 1.6)
    s += line(f'M{hx - r * .6:.1f} {ey - r * .8:.1f} l-2 -5 M{hx:.1f} {ey - r:.1f} v-6 M{hx + r * .6:.1f} {ey - r * .8:.1f} l2 -5', 1.6)
    return s


def family(cape=False, mask=False, powers=False):
    s = ''
    for x, who, h in FAM:
        if powers and who == 'dad':
            s += flyer(50, 42, 84)
            continue
        arms = 'down'
        if powers:
            arms = {'mum': 'one', 'kid': 'up', 'baby': 'up'}[who]
        s += fig(x, FB, h, who, cape, mask, arms)
    if powers:
        # mum: lightning from her hand; kid: lifting a giant weight; baby: magic stars
        mx, _, mh = FAM[1]
        hx, hy = mx + mh * .26, FB - mh + mh * .14 - mh * .14 * 1.2
        s += g('<path d="M0 0 l4 -22 l-6 0 l8 -28 l2 21 l6 0 l-12 29 Z" stroke-width="1.8"/>', hx, hy, 1, 28)
        kx, _, kh = FAM[2]
        by = FB - kh + kh * .14 - kh * .14 * 1.4
        s += (line(f'M{kx - kh * .22 - 10:.1f} {by:.1f} H{kx + kh * .22 + 10:.1f}', 3)
              + f'<rect x="{kx - kh * .22 - 18:.1f}" y="{by - 11:.1f}" width="10" height="22" rx="3"/>'
              + f'<rect x="{kx + kh * .22 + 8:.1f}" y="{by - 11:.1f}" width="10" height="22" rx="3"/>'
              + star(200, 112, 6) + star(230, 106, 6) + star(216, 90, 5))
    return s


NAMES = ''.join(squig(x - 16, 190, 2, .62) for x, _, _ in FAM[:3])
SPEED = motion('M12 30 H2', 'M10 42 H0', 'M14 54 H4')

D[key('Draw your family as superheroes')] = [
    sheet(family()) + pen_at(227, 141)
    + arr((14, 186), (226, 186)),

    sheet(family(cape=True, mask=True)) + pen_at(226, 150)
    + arrow('M30 156 C40 124 60 118 78 126'),

    sheet(family(cape=True, mask=True, powers=True) + SPEED),

    sheet(family(cape=True, mask=True, powers=True) + SPEED + NAMES + squig(200, 190, 1, .62))
    + pen_at(216, 190, 35),
]


# ── Draw a map of a treasure island ──────────────────────────────────────
ISLE = [(24, 110),
        ('C', (18, 86), (34, 70), (52, 74)),
        ('C', (60, 74), (62, 60), (74, 52)),
        ('C', (92, 40), (110, 50), (118, 42)),
        ('C', (132, 28), (164, 30), (172, 46)),
        ('C', (180, 58), (196, 48), (208, 62)),
        ('C', (222, 78), (204, 92), (214, 104)),
        ('C', (226, 120), (214, 138), (196, 136)),
        ('C', (184, 136), (186, 156), (166, 160)),
        ('C', (150, 164), (144, 152), (130, 160)),
        ('C', (110, 172), (76, 176), (64, 160)),
        ('C', (58, 152), (46, 160), (34, 150)),
        ('C', (20, 140), (30, 124), (24, 110)),
        ]


def _d(segs):
    d = f'M{segs[0][0]} {segs[0][1]}'
    for _, c1, c2, e in segs[1:]:
        d += f' C{c1[0]} {c1[1]} {c2[0]} {c2[1]} {e[0]} {e[1]}'
    return d


def _pts(segs, n=40):
    """Points along the outline, n per curve."""
    out, p0 = [], segs[0]
    for _, c1, c2, e in segs[1:]:
        for i in range(n):
            t = i / n
            out.append(tuple((1 - t) ** 3 * a + 3 * (1 - t) ** 2 * t * b + 3 * (1 - t) * t * t * c + t ** 3 * d
                             for a, b, c, d in zip(p0, c1, c2, e)))
        p0 = e
    return out


ISLE_D = _d(ISLE) + ' Z'
_P = _pts(ISLE)
_k = int(len(_P) * .5)
HALF = 'M' + ' L'.join(f'{x:.1f} {y:.1f}' for x, y in _P[:_k + 1])


def waves(pts):
    return ''.join(line(f'M{x} {y} q5 -5 10 0 t10 0', 1.6) for x, y in pts)


SEA = waves([(10, 22), (200, 14), (216, 164), (12, 178), (110, 188), (8, 60)])


def palm(x, y, s=1.0):
    return g(line('M0 0 Q4 -20 -2 -38', 3)
             + '<path d="M-2 -38 Q-18 -46 -28 -34 Q-16 -40 -2 -38 Z" stroke-width="1.6"/>'
             + '<path d="M-2 -38 Q14 -48 26 -36 Q12 -42 -2 -38 Z" stroke-width="1.6"/>'
             + '<path d="M-2 -38 Q-12 -32 -16 -20 Q-8 -32 -2 -38 Z" stroke-width="1.6"/>'
             + '<path d="M-2 -38 Q10 -32 14 -20 Q6 -32 -2 -38 Z" stroke-width="1.6"/>'
             + '<path d="M-2 -38 Q-4 -50 4 -56 Q0 -48 -2 -38 Z" stroke-width="1.6"/>', x, y, s)


def mountain():
    return ('<path d="M62 106 L94 54 L126 106 Z"/>'
            + line('M82 73 L88 78 L94 70 L100 78 L106 73', 1.6)
            + '<path d="M108 106 L128 78 L148 106 Z"/>')


BEACH = (line('M70 146 C96 154 118 152 134 146 C152 154 172 146 182 134', 1.6)
         + ''.join(dot(x, y, 1.2) for x, y in ((80, 156), (98, 162), (114, 158), (148, 158),
                                                  (166, 150), (176, 142), (90, 166), (122, 166), (156, 162))))

ISLAND_THINGS = mountain() + palm(48, 132, .8) + palm(64, 140, .7) + BEACH

PATH = ((130, 154), (126, 142), (130, 130), (142, 122), (156, 120), (166, 112), (166, 100),
        (162, 90), (166, 80), (176, 72))
X = line('M168 50 L196 76 M196 50 L168 76', 5)


def trail(n=len(PATH)):
    return ''.join(dot(u, v, 2.4) for u, v in PATH[:n])


_e = _P[_k]
D[key('Draw a map of a treasure island')] = [
    sheet(SEA + ghost(ISLE_D) + f'<path d="{HALF}" fill="none"/>') + pen_at(*_e, -40)
    + arr((226, 108), (232, 132), (214, 156)),

    sheet(SEA + f'<path d="{ISLE_D}"/>' + ISLAND_THINGS) + pen_at(182, 134, -40),

    sheet(SEA + f'<path d="{ISLE_D}"/>' + ISLAND_THINGS + trail()) + pen_at(176, 72, -40)
    + arr((118, 156), (108, 132), (122, 120)),

    sheet(SEA + f'<path d="{ISLE_D}"/>' + ISLAND_THINGS + trail(9) + X)
    + motion('M{0} {1} l-8 -8'.format(*P(164, 44)), 'M{0} {1} l8 -8'.format(*P(200, 44)),
             'M{0} {1} h12'.format(*P(204, 63)), 'M{0} {1} h-12'.format(*P(160, 63))),
]


# ── Draw what you want to be when you grow up ────────────────────────────
def helmet(x, y, s=1.0):
    """A firefighter's helmet."""
    return g('<path d="M-30 6 Q-34 14 -24 14 H30 Q40 14 34 4 L24 0 Z"/>'
             '<path d="M-24 6 Q-26 -30 2 -32 Q28 -30 26 2 Z"/>'
             + thin('M2 -32 V-4')
             + '<path d="M-6 -16 h14 l-2 14 h-10 Z" stroke-width="1.6"/>', x, y, s)


def stethoscope(x, y, s=1.0):
    return g(line('M-14 -30 V-8 Q-14 10 0 10 Q14 10 14 -8 V-30', 3)
             + '<circle cx="-14" cy="-32" r="3"/><circle cx="14" cy="-32" r="3"/>'
             + line('M0 10 V22 Q0 34 14 34 Q24 34 24 24', 3)
             + '<circle cx="24" cy="20" r="8"/>', x, y, s)


def brush(x, y, s=1.0, rot=-40):
    return g('<rect x="0" y="-4" width="44" height="8" rx="4"/>'
             '<rect x="-12" y="-6" width="12" height="12" rx="1"/>'
             '<path d="M-12 -6 Q-30 -6 -34 0 Q-30 6 -12 6 Z"/>', x, y, s, rot)


def astronaut(x, by, s=1.0):
    """A child's drawing of an astronaut, feet at (x, by)."""
    return g('<rect x="-30" y="-108" width="60" height="22" rx="4"/>'  # backpack
             + line('M-20 -82 Q-44 -70 -40 -52 M20 -82 Q44 -70 40 -52', 9)
             + line('M-20 -82 Q-44 -70 -40 -52 M20 -82 Q44 -70 40 -52', 0).replace('stroke-width="0"', 'stroke="#fff" stroke-width="4.6"')
             + '<circle cx="-40" cy="-50" r="6"/><circle cx="40" cy="-50" r="6"/>'
             + '<rect x="-24" y="-90" width="48" height="58" rx="10"/>'
             + '<rect x="-10" y="-76" width="20" height="14" rx="2" stroke-width="1.6"/>'
             + dot(-4, -69, 1.6) + dot(4, -69, 1.6)
             + '<rect x="-20" y="-34" width="16" height="26" rx="3"/><rect x="4" y="-34" width="16" height="26" rx="3"/>'
             + '<path d="M-24 -10 H-2 V0 H-26 Q-28 -8 -24 -10 Z"/><path d="M2 -10 H24 Q28 -8 26 0 H2 Z"/>'
             + '<circle cx="0" cy="-118" r="28"/>'
             + '<rect x="-19" y="-132" width="38" height="28" rx="12"/>'
             + dot(-7, -120, 1.8) + dot(7, -120, 1.8) + line('M-6 -112 q6 5 12 0', 1.6)
             + line('M12 -146 q10 4 12 14', 1.6), x, by, s)


def rocket(x, by, s=1.0, flame=True):
    b = ('<path d="M-18 -40 L-36 -6 V2 L-18 -8 Z"/><path d="M18 -40 L36 -6 V2 L18 -8 Z"/>'
         '<path d="M-18 -8 V-110 Q-18 -150 0 -168 Q18 -150 18 -110 V-8 Z"/>'
         + line('M-18 -124 H18', 1.6)
         + '<circle cx="0" cy="-92" r="10"/><circle cx="0" cy="-92" r="5" stroke-width="1.4"/>'
         + '<path d="M-12 -8 H12 L8 0 H-8 Z"/>')
    if flame:
        b += '<path d="M-8 0 Q-12 16 -4 14 Q-2 26 2 16 Q8 24 8 10 Q12 6 8 0 Z" stroke-width="1.8"/>'
    return g(b, x, by, s)


SKY = star(28, 30, 7) + star(206, 26, 6) + star(214, 70, 4) + star(46, 70, 4)
MOON = line('M10 182 Q60 172 118 180 T226 178', 2) + '<ellipse cx="60" cy="190" rx="9" ry="3" stroke-width="1.4"/>' \
       + '<ellipse cx="190" cy="190" rx="7" ry="2.5" stroke-width="1.4"/>'

D[key('Draw what you want to be when you grow up')] = [
    bubble(inside=helmet(170, 132, .9) + stethoscope(234, 126, .95) + brush(294, 112, .95, 125)),

    sheet(SKY + astronaut(100, 184, .95)) + pen_at(144, 136, -40)
    + arr((48, 84), (26, 100), (34, 126)),

    sheet(SKY + MOON + astronaut(70, 180, .78) + rocket(168, 176, .86)) + pen_at(198, 166, -40)
    + arr((80, 50), (110, 14), (150, 20), dashed=True),

    ground(266)
    + person(96, 266, 1.0, arms=[(-1, -30, -44), (1, 72, -84, 52, -110)], mouth='talk')
    + '<rect x="166" y="132" width="62" height="78" rx="2"/>'
    + astronaut(186, 196, .3) + rocket(212, 194, .3, False)
    + '<circle cx="168" cy="178" r="6"/>'
    + person(306, 266, .95, who='adult', mouth='grin', eyes='happy', arms=[(-1, -50, -70), (1, 30, -60)])
    + speech(130, 26, 96, 62, 124, 104, heart_ink(160, 56, 12) + rocket(204, 84, .26, False))
    + motion('M134 116 l12 -4', 'M132 132 h14'),
]



# ── Draw a comic with four boxes ─────────────────────────────────────────
BOX = [(14, 12), (124, 12), (14, 104), (124, 104)]
BW_, BH_ = 98, 82


def boxes(n=4):
    return ''.join(f'<rect x="{x}" y="{y}" width="{BW_}" height="{BH_}" fill="none"/>' for x, y in BOX[:n])


def kitty(x, by, s=1.0, pose='sit'):
    """A little cat in the comic: sit (facing us), run (to the right), sleep (curled up)."""
    if pose == 'sit':
        return cat_sit(x, by, s)
    if pose == 'run':
        return g(cat_stand(0, 0, 1), x, by, s).replace(
            f'translate({x} {by})', f'translate({x} {by}) scale(-1 1)')
    # asleep: a curled body, ears, closed eyes and a tail round the front
    return g('<ellipse cx="0" cy="-16" rx="30" ry="16"/>'
             '<path d="M-30 -14 Q-36 4 -4 2 Q22 0 26 -6" fill="none"/>'
             '<path d="M-26 -36 L-24 -48 L-16 -40 Z"/><path d="M-10 -40 L-2 -48 L-2 -36 Z"/>'
             '<circle cx="-14" cy="-28" r="13"/>'
             + thin('M-22 -28 q3 3 6 0 M-12 -28 q3 3 6 0'), x, by, s)


def moon(x, y, r=9):
    return f'<path d="M{x} {y - r} A{r} {r} 0 1 0 {x} {y + r} A{r * .7:.1f} {r * .7:.1f} 0 1 1 {x} {y - r} Z" stroke-width="1.6"/>'


def comic(talk=False):
    s = boxes()
    # 1: a cat sits; 2: a ball rolls by; 3: the cat chases it; 4: the cat sleeps
    s += kitty(48, 88, .62) + ball(80, 80, 7)
    s += kitty(152, 88, .62) + ball(200, 80, 7) + thin('M180 76 h-8 M182 84 h-10')
    s += kitty(70, 180, .52, 'run') + ball(100, 172, 7) + thin('M30 150 h-8 M32 160 h-10')
    s += kitty(176, 182, .8, 'sleep') + moon(204, 122)
    if talk:
        s += speech3(60, 18, 106, 42, 52, 56, 62, squig(68, 36, 2, .5))
        s += speech3(170, 18, 216, 42, 162, 56, 172, squig(178, 36, 2, .5))
        s += speech3(62, 110, 108, 134, 88, 144, 74, squig(70, 128, 2, .5))
    return s


def mini_comic():
    """Four little boxes inside the thought cloud."""
    out = ''
    for i, x in enumerate((90, 154, 218, 282)):
        out += f'<rect x="{x}" y="74" width="60" height="60" rx="2" stroke-width="1.8"/>'
    out += kitty(120, 128, .56) + ball(190, 112, 10) + thin('M172 106 h-10 M172 118 h-12')
    out += kitty(240, 128, .46, 'run') + ball(268, 120, 7)
    out += kitty(314, 128, .7, 'sleep')
    return out


D[key('Draw a comic with four boxes')] = [
    sheet(boxes(3) + line('M124 104 H222 V150') + ghost('M222 150 V186 H124 V104'))
    + pen_at(222, 150, -40) + arr((210, 197), (136, 197)),

    face(58, 244, 32) + cloud(214, 110, 146, 74, 11, tail=((96, 200, 5), (110, 184, 7)), inside=mini_comic())
    + arrow('M104 150 H326'),

    sheet(comic()) + pen_at(212, 124, -40),

    sheet(comic(talk=True)) + pen_at(182, 34, -22),
]


# ── Draw a pet you would love to have ────────────────────────────────────
def penguin(x, by, s=1.0):
    """A penguin standing, feet at (x, by): dark flippers and back cap, white tummy."""
    return g(f'<ellipse cx="-14" cy="-2" rx="12" ry="5"/><ellipse cx="14" cy="-2" rx="12" ry="5"/>'
             f'<path d="M-30 -48 Q-50 -30 -44 -12 Q-34 -22 -28 -30 Z" fill="{INK}"/>'
             f'<path d="M30 -48 Q50 -30 44 -12 Q34 -22 28 -30 Z" fill="{INK}"/>'
             '<path d="M0 -104 C26 -104 34 -78 34 -50 C34 -18 22 -4 0 -4 C-22 -4 -34 -18 -34 -50 C-34 -78 -26 -104 0 -104 Z"/>'
             f'<path d="M0 -104 C20 -104 30 -90 32 -72 C26 -80 18 -88 0 -84 C-18 -88 -26 -80 -32 -72 C-30 -90 -20 -104 0 -104 Z" fill="{INK}"/>'
             + thin('M-24 -62 C-26 -40 -18 -18 0 -14 C18 -18 26 -40 24 -62')
             + dot(-9, -72, 3) + dot(9, -72, 3)
             + '<path d="M-7 -64 L7 -64 L0 -54 Z" stroke-width="1.8"/>', x, by, s)


def dragon(x, by, s=1.0):
    """A friendly little dragon facing right, feet at (x, by): wing, back spikes, pointy tail."""
    return g('<path d="M-24 -24 Q-48 -22 -52 -36 Q-54 -46 -48 -50" fill="none"/>'
             '<path d="M-48 -50 l-6 -6 l9 -2 Z" stroke-width="2"/>'
             + line('M-12 0 V-14 M12 0 V-14', 6)
             + '<path d="M14 -38 Q20 -58 30 -62 L38 -54 Q28 -50 28 -34 Z"/>'
             + '<ellipse cx="0" cy="-28" rx="28" ry="18"/>'
             + '<path d="M-24 -38 L-22 -50 L-14 -44 Z M-12 -45 L-8 -56 L-2 -46 Z" stroke-width="2"/>'
             + '<path d="M0 -42 L-2 -88 Q6 -78 12 -82 Q14 -72 22 -74 Q16 -60 12 -44 Z"/>'
             + thin('M0 -46 L4 -80 M6 -46 L14 -74')
             + '<path d="M24 -70 Q40 -80 54 -70 Q58 -60 46 -58 L32 -56 Q18 -60 24 -70 Z"/>'
             '<path d="M28 -73 l-2 -9 l8 5 Z" stroke-width="1.8"/>'
             + dot(38, -68, 2.2) + dot(52, -66, 1.4)
             + thin('M42 -60 q6 2 10 -1'), x, by, s)


def fish(x, y, s=1.0):
    return g('<path d="M-16 0 Q-4 -12 12 0 Q-4 12 -16 0 Z"/><path d="M12 0 L22 -8 V8 Z"/>'
             + dot(-9, -2, 1.6), x, y, s)


def pet_bed(x, y, s=1.0):
    """A little bed: headboard, legs, pillow and a blanket. Bottom of the legs at (x, y), left end x."""
    return g('<rect x="0" y="-52" width="10" height="52" rx="2"/>'
             '<rect x="70" y="-26" width="8" height="26" rx="2"/>'
             '<rect x="6" y="-26" width="68" height="12" rx="2"/>'
             '<rect x="14" y="-38" width="22" height="12" rx="6"/>'
             '<path d="M34 -32 Q34 -36 38 -36 H74 V-14 H38 Q34 -14 34 -20 Z"/>'
             + thin('M42 -30 H70'), x, y, s)


D[key('Draw a pet you would love to have')] = [
    bubble(inside=dog(140, 156, 1.0) + penguin(214, 160, .6) + dragon(276, 166, .92)),

    sheet(penguin(112, 176, 1.4)) + pen_at(174, 158, -40)
    + arr((8, 110), (44, 110)),

    sheet(penguin(70, 170, 1.05) + pet_bed(128, 170, 1.15) + fish(178, 64, 1.2)
          + '<ellipse cx="182" cy="74" rx="30" ry="7" stroke-width="1.8"/>') + pen_at(200, 64, -40),

    sheet(penguin(112, 190, 1.05) + squig(78, 52, 3, .7))
    + pen_at(142, 46, -40) + arr((72, 64), (142, 64)),
]


# ── Draw the view from your window ───────────────────────────────────────
def house(x, by, w=40, h=34, door=True):
    s = (f'<rect x="{x}" y="{by - h}" width="{w}" height="{h}"/>'
         f'<path d="M{x - 6} {by - h} L{x + w / 2} {by - h - w * .6:.1f} L{x + w + 6} {by - h} Z"/>'
         f'<rect x="{x + w * .14:.1f}" y="{by - h * .74:.1f}" width="{w * .26:.1f}" height="{w * .22:.1f}" stroke-width="1.6"/>')
    if door:
        s += f'<rect x="{x + w * .56:.1f}" y="{by - h * .56:.1f}" width="{w * .26:.1f}" height="{h * .56:.1f}" stroke-width="1.6"/>'
    return s


def tree(x, by, s=1.0):
    return g('<rect x="-5" y="-34" width="10" height="34" rx="2"/>'
             '<path d="M0 -84 C22 -84 30 -66 24 -54 C32 -44 20 -28 4 -34 C-6 -26 -26 -32 -24 -46 '
             'C-34 -56 -22 -76 -10 -74 C-8 -80 -4 -84 0 -84 Z"/>', x, by, s)


def cloud_puff(x, y, s=1.0):
    return g('<path d="M-22 6 Q-30 -4 -18 -8 Q-16 -20 -2 -16 Q8 -26 18 -12 Q30 -10 24 6 Z"/>', x, y, s)


# the window drawn on the sheet: frame, sill and a cross of glazing bars
WX0, WY0, WX1, WY1 = 40, 24, 196, 160


def win_frame():
    return (f'<rect x="{WX0}" y="{WY0}" width="{WX1 - WX0}" height="{WY1 - WY0}" fill="none" stroke-width="3"/>'
            f'<rect x="{WX0 + 8}" y="{WY0 + 8}" width="{WX1 - WX0 - 16}" height="{WY1 - WY0 - 16}" fill="none"/>'
            f'<rect x="{WX0 - 14}" y="{WY1}" width="{WX1 - WX0 + 28}" height="12" rx="2"/>')


def win_bars():
    mx, my = (WX0 + WX1) / 2, (WY0 + WY1) / 2
    return (f'<rect x="{mx - 4}" y="{WY0 + 8}" width="8" height="{WY1 - WY0 - 16}"/>'
            f'<rect x="{WX0 + 8}" y="{my - 4}" width="{WX1 - WX0 - 16}" height="8"/>')


def win_view(sunny=True):
    s = (house(58, 152, 44, 36) + house(118, 152, 36, 30, False) + tree(166, 152, .82)
         + line(f'M{WX0 + 8} 152 H{WX1 - 8}', 1.6))
    if sunny:
        s += sun(76, 54, 10)
    return s


def grey_sky():
    """Pencil hatching over the sky part of the window, with two clouds left white."""
    lines = ''.join(f'M{x} {WY0 + 8} l-60 70 ' for x in range(WX0 + 10, WX1 + 60, 7))
    return (f'<clipPath id="sky"><rect x="{WX0 + 8}" y="{WY0 + 8}" width="{WX1 - WX0 - 16}" height="96"/></clipPath>'
            f'<path d="{lines}" fill="none" stroke-width="1.2" clip-path="url(#sky)"/>'
            + cloud_puff(84, 58, 1.1))


D[key('Draw the view from your window')] = [
    # the real window in the wall, the child seen from behind, hands on the sill, looking out
    '<rect x="92" y="16" width="216" height="176" stroke-width="3"/>'
    '<rect x="102" y="26" width="196" height="156"/>'
    + house(116, 168, 50, 42) + house(186, 168, 40, 34, False) + tree(262, 168, .95)
    + cloud_puff(146, 52) + thin('M102 168 H298')
    + '<rect x="196" y="26" width="8" height="156"/><rect x="102" y="100" width="196" height="8"/>'
    + '<rect x="78" y="192" width="244" height="14" rx="2"/>'
    + ground(284, 40, 360)
    + '<rect x="183" y="236" width="14" height="48" rx="3"/><rect x="203" y="236" width="14" height="48" rx="3"/>'
    + '<path d="M176 240 L178 196 Q200 186 222 196 L224 240 Z"/>'
    + '<path d="M180 202 Q166 200 164 194" fill="none" stroke-width="7"/><path d="M180 202 Q166 200 164 194" fill="none" stroke="#fff" stroke-width="2.2"/>'
    + '<path d="M220 202 Q234 200 236 194" fill="none" stroke-width="7"/><path d="M220 202 Q234 200 236 194" fill="none" stroke="#fff" stroke-width="2.2"/>'
    + '<circle cx="164" cy="192" r="6"/><circle cx="236" cy="192" r="6"/>'
    + '<rect x="195" y="182" width="10" height="8"/>'
    + '<circle cx="178" cy="164" r="5"/><circle cx="222" cy="164" r="5"/>'
    + f'<circle cx="200" cy="160" r="22" fill="{INK}"/>'
    + '<path d="M190 144 q6 -4 12 -2 M186 152 q8 -6 18 -4 M206 146 q6 0 10 4" fill="none" stroke="#fff" stroke-width="1.6"/>'
    + arrow('M222 132 C236 112 250 96 262 84', dashed=True),

    sheet(win_frame()) + pen_at(WX1 + 14, WY1 + 6, -40)
    + arr((WX0 - 10, WY1 + 24), (WX1 + 2, WY1 + 24)),

    sheet(win_frame() + win_view() + win_bars())
    + pen_at(192, 150, -40),

    sheet(win_frame() + grey_sky() + win_view(False) + win_bars())
    + crayon_at(182, 80, -40)
    + motion('M{0} {1} l12 -18 l4 16 l12 -18 l4 16 l12 -18'.format(*P(116, 80))),
]


# ── Draw a robot that does chores for you ────────────────────────────────
def robot(x=118, by=180, tools=False, label=False):
    """A friendly round robot on one wheel. tools: a mop arm and a broom arm."""
    s = ''
    # arms first so the body sits over their shoulders
    if tools:
        # left arm holds a mop down to the floor, right arm a broom
        s += (line(f'M{x - 40} {by - 70} Q{x - 64} {by - 66} {x - 70} {by - 92}', 4)
              + line(f'M{x - 80} {by - 116} L{x - 66} {by - 8}', 3)
              + f'<circle cx="{x - 70}" cy="{by - 92}" r="7"/>'
              + f'<path d="M{x - 82} {by - 10} Q{x - 66} {by - 16} {x - 50} {by - 10} L{x - 44} {by + 4} '
                f'L{x - 52} {by - 2} L{x - 58} {by + 6} L{x - 64} {by - 2} L{x - 72} {by + 6} L{x - 76} {by - 2} '
                f'L{x - 86} {by + 4} Z"/>'
              + line(f'M{x + 40} {by - 70} Q{x + 64} {by - 66} {x + 70} {by - 92}', 4)
              + line(f'M{x + 64} {by - 124} L{x + 78} {by - 30}', 3)
              + f'<circle cx="{x + 70}" cy="{by - 92}" r="7"/>'
              + f'<path d="M{x + 64} {by - 32} H{x + 92} L{x + 100} {by - 2} H{x + 56} Z"/>'
              + thin(f'M{x + 66} {by - 22} L{x + 64} {by - 2} M{x + 74} {by - 22} L{x + 74} {by - 2} '
                     f'M{x + 84} {by - 22} L{x + 86} {by - 2}'))
    else:
        s += (line(f'M{x - 40} {by - 70} Q{x - 64} {by - 66} {x - 64} {by - 44}', 4)
              + line(f'M{x + 40} {by - 70} Q{x + 64} {by - 66} {x + 64} {by - 44}', 4)
              + f'<path d="M{x - 70} {by - 36} q6 -12 12 0" fill="none"/>'
              + f'<path d="M{x + 58} {by - 36} q6 -12 12 0" fill="none"/>')
    s += (f'<circle cx="{x}" cy="{by - 14}" r="14"/>' + dot(x, by - 14, 3)
          + f'<circle cx="{x}" cy="{by - 66}" r="44"/>'
          + f'<rect x="{x - 6}" y="{by - 118}" width="12" height="10"/>'
          + f'<rect x="{x - 36}" y="{by - 166}" width="72" height="52" rx="14"/>'
          + line(f'M{x} {by - 166} V{by - 184}') + f'<circle cx="{x}" cy="{by - 188}" r="5"/>'
          + f'<circle cx="{x - 15}" cy="{by - 144}" r="8"/>' + dot(x - 15, by - 144, 3)
          + f'<circle cx="{x + 15}" cy="{by - 144}" r="8"/>' + dot(x + 15, by - 144, 3)
          + line(f'M{x - 12} {by - 128} q12 8 24 0', 2))
    if label:
        s += (f'<rect x="{x - 30}" y="{by - 84}" width="60" height="26" rx="4" stroke-width="2"/>'
              + squig(x - 24, by - 64, 2, .6))
    else:
        s += (f'<circle cx="{x - 14}" cy="{by - 70}" r="5" stroke-width="1.8"/>'
              f'<circle cx="{x + 2}" cy="{by - 70}" r="5" stroke-width="1.8"/>'
              f'<circle cx="{x + 18}" cy="{by - 70}" r="5" stroke-width="1.8"/>')
    return s


MESS = (g(bed(0, 0, 120, made=False, pull=.4), 136, 160, .6)
        + thin('M124 160 H328')
        + ball(222, 151, 9) + book(236, 144, -10).replace('translate(236 144)', 'translate(236 144) scale(.75)')
        + g(block(-8, -8, 16), 280, 150, 1, 20) + g(teddy(0, 0, .55), 300, 158, 1, 80))


def rb(x, by, s=.8, **kw):
    return g(robot(0, 0, **kw), x, by, s)


D[key("Draw a robot that does chores for you")] = [
    bubble(inside=MESS),

    sheet(rb(112, 188)) + pen_at(168, 156, -40)
    + arr((56, 100), (34, 126), (52, 160)),

    sheet(rb(112, 188, tools=True))
    + motion('M{0} {1} q-8 6 -18 2'.format(*P(40, 192)), 'M{0} {1} q-6 5 -14 2'.format(*P(44, 182))),

    sheet(rb(112, 188, label=True)) + pen_at(130, 134, 5),
]
