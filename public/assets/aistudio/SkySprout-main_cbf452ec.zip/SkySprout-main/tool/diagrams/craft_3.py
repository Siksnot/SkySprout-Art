"""Diagrams for more Craft challenges (box car, pinwheel, paper plate monster,
toilet roll binoculars, bottle shaker, family flag)."""
import random

from style import INK, arrow, dot, ghost, ground, hand, motion, thin

D = {}


# ── Shared bits ──────────────────────────────────────────────────────────
def key(title):
    import re
    return re.sub(r'[^a-z0-9]+', '_', title.lower()).strip('_')[:48]


def mitt(x, y, s=1.0, rot=0, flip=False, grown=False):
    """The kit's mitten hand, turned by rot degrees. A grown-up's hand is bigger and has a sleeve."""
    if grown:
        s *= 1.3
    cuff = ''
    if grown:
        cuff = (f'<g transform="scale({-s if flip else s} {s})"><path d="M-10 16 H26 L28 46 H-12 Z"/>'
                f'<path d="M-10 22 H26" fill="none" stroke-width="1.6"/></g>')
    return f'<g transform="translate({x} {y}) rotate({rot})">{cuff}{hand(0, 0, s, flip)}</g>'


def grip(px, py, ang, s=1.0, grown=False, flip=False):
    """A hand whose fingertips close round (px, py), fingers pointing at ang degrees."""
    import math
    if grown:
        s *= 1.3
    gx, gy = (-30 if flip else 30) * s, -26 * s
    base = math.degrees(math.atan2(-.75, -1 if flip else 1))
    rot = ang - base
    r = math.radians(rot)
    wx = px - (gx * math.cos(r) - gy * math.sin(r))
    wy = py - (gx * math.sin(r) + gy * math.cos(r))
    cuff = ''
    if grown:
        cuff = (f'<g transform="scale({-s if flip else s} {s})"><path d="M-10 14 H26 L28 46 H-12 Z"/>'
                f'<path d="M-10 22 H26" fill="none" stroke-width="1.6"/></g>')
    return f'<g transform="translate({wx:.1f} {wy:.1f}) rotate({rot:.1f})">{cuff}{hand(0, 0, s, flip)}</g>'


def hold_pen(tx, ty, a, turn=60, flip=False):
    """A felt pen with its tip at (tx, ty), body going off at a degrees, held by a hand."""
    import math
    r = math.radians(a)
    gx, gy = tx + 40 * math.cos(r), ty + 40 * math.sin(r)
    return pen(tx, ty, a) + grip(gx, gy, a + 180 + (-turn if flip else turn), flip=flip)


def limb(d, w=13):
    """An outlined arm or leg along path d."""
    return (f'<path d="{d}" fill="none" stroke="{INK}" stroke-width="{w}"/>'
            f'<path d="{d}" fill="none" stroke="#fff" stroke-width="{w - 4.8}"/>')


def face(cx, cy, r=30, mouth='smile'):
    s = (f'<circle cx="{cx}" cy="{cy}" r="{r}"/>'
         + dot(cx - r * .36, cy - r * .1, r * .07 + 1) + dot(cx + r * .36, cy - r * .1, r * .07 + 1)
         + thin(f'M{cx - r * .88:.1f} {cy - r * .5:.1f} q{r * .3:.1f} {-r * .78:.1f} {r:.1f} {-r * .48:.1f} '
                f'q{r * .6:.1f} {-r * .42:.1f} {r * .88:.1f} {r * .24:.1f}'))
    if mouth == 'smile':
        s += f'<path d="M{cx - r * .3:.1f} {cy + r * .35:.1f} q{r * .3:.1f} {r * .25:.1f} {r * .6:.1f} 0" fill="none"/>'
    elif mouth == 'grin':
        s += (f'<path d="M{cx - r * .42:.1f} {cy + r * .26:.1f} q{r * .42:.1f} {r * .5:.1f} {r * .84:.1f} 0 Z"/>'
              + thin(f'M{cx - r * .4:.1f} {cy + r * .3:.1f} H{cx + r * .4:.1f}'))
    elif mouth == 'blow':
        s += f'<circle cx="{cx + r * .2:.1f}" cy="{cy + r * .42:.1f}" r="{r * .13:.1f}"/>'
    elif mouth == 'open':
        s += f'<ellipse cx="{cx}" cy="{cy + r * .42:.1f}" rx="{r * .2:.1f}" ry="{r * .16:.1f}"/>'
    return s


def torso(cx, yt, yb, w=30):
    return (f'<path d="M{cx - w} {yb} V{yt + 12} Q{cx - w} {yt} {cx - w + 12} {yt} H{cx + w - 12} '
            f'Q{cx + w} {yt} {cx + w} {yt + 12} V{yb} Z"/>')


def scissors(x, y, rot=0, s=1.0):
    """Open scissors: pivot at (x, y), blades pointing along rot."""
    return (f'<g transform="translate({x} {y}) rotate({rot}) scale({s})">'
            '<path d="M-14 -12 L-4 -2" fill="none"/><path d="M-14 12 L-4 2" fill="none"/>'
            '<ellipse cx="-24" cy="-14" rx="11" ry="8"/><ellipse cx="-24" cy="14" rx="11" ry="8"/>'
            '<path d="M-4 -4 L42 -16 Q46 -14 42 -10 L2 4 Z"/>'
            '<path d="M-4 4 L42 16 Q46 14 42 10 L2 -4 Z"/>'
            f'</g>' + dot(x, y, 2))


def pen(x, y, rot=0, s=1.0):
    """A felt pen with its tip at (x, y), lying along rot (0 = body to the right of the tip)."""
    return (f'<g transform="translate({x} {y}) rotate({rot}) scale({s})">'
            '<path d="M0 0 L10 -4 V4 Z"/><rect x="10" y="-6" width="8" height="12" rx="1"/>'
            '<rect x="18" y="-7" width="62" height="14" rx="3"/>'
            '<path d="M60 -7 V7" fill="none" stroke-width="1.6"/></g>')


def tape(x, y, w=30, h=11, rot=0):
    """A strip of sticky tape centred on (x, y)."""
    return (f'<g transform="translate({x} {y}) rotate({rot})">'
            f'<path d="M{-w / 2} {-h / 2} H{w / 2} l-2 {h / 4} l2 {h / 4} l-2 {h / 4} l2 {h / 4} H{-w / 2} '
            f'l2 {-h / 4} l-2 {-h / 4} l2 {-h / 4} Z" stroke-width="1.6"/></g>')


def heart(cx, cy, s=14):
    return (f'<path d="M{cx} {cy + s * .9} C{cx - s * 1.7} {cy - s * .1} {cx - s * .7} {cy - s * 1.3} {cx} {cy - s * .4} '
            f'C{cx + s * .7} {cy - s * 1.3} {cx + s * 1.7} {cy - s * .1} {cx} {cy + s * .9} Z"/>')


def star(cx, cy, r=14):
    import math
    pts = []
    for i in range(10):
        a = -math.pi / 2 + i * math.pi / 5
        rr = r if i % 2 == 0 else r * .45
        pts.append(f'{cx + rr * math.cos(a):.1f},{cy + rr * math.sin(a):.1f}')
    return f'<polygon points="{" ".join(pts)}"/>'


def ball(cx, cy, r=16):
    k = r * .35
    return (f'<circle cx="{cx}" cy="{cy}" r="{r}"/>'
            f'<polygon points="{cx},{cy - k} {cx + k},{cy - k * .3} {cx + k * .6},{cy + k * .8} '
            f'{cx - k * .6},{cy + k * .8} {cx - k},{cy - k * .3}" fill="{INK}" stroke="none"/>'
            + thin(f'M{cx} {cy - k} V{cy - r} M{cx + k} {cy - k * .3} L{cx + r * .95} {cy - r * .3} '
                   f'M{cx + k * .6} {cy + k * .8} L{cx + r * .6} {cy + r * .8} M{cx - k * .6} {cy + k * .8} '
                   f'L{cx - r * .6} {cy + r * .8} M{cx - k} {cy - k * .3} L{cx - r * .95} {cy - r * .3}'))


def dog(x, y, s=1.0):
    """A little dog standing, facing right; feet at (x, y)."""
    return (f'<g transform="translate({x} {y}) scale({s})">'
            '<path d="M-18 -14 q-12 -6 -12 -20" fill="none"/>'
            '<path d="M-14 0 V-12 M-6 0 V-12 M10 0 V-12 M18 0 V-12" fill="none"/>'
            '<rect x="-20" y="-30" width="44" height="20" rx="10"/>'
            '<circle cx="28" cy="-36" r="12"/><path d="M22 -46 q-10 6 -6 20 q6 -2 8 -12" />'
            '<circle cx="31" cy="-38" r="1.8" fill="#1d1d1f" stroke="none"/>'
            '<circle cx="40" cy="-33" r="2.4" fill="#1d1d1f" stroke="none"/></g>')


def think_bubble(x, y, inside):
    head = face(x, y, 34, 'smile')
    bubble = ('<circle cx="112" cy="190" r="5"/><circle cx="128" cy="172" r="8"/>'
              '<path d="M120 150 C90 140 96 92 132 90 C140 54 200 50 216 76 C240 46 300 54 304 86 '
              'C350 84 362 136 330 150 C340 182 290 196 270 176 C250 200 196 198 186 176 C150 192 112 176 120 150 Z"/>')
    return head + bubble + inside


# ── Turn an old box into a car you can sit in ────────────────────────────
BX, BY, BW, BHh, DX, DY = 70, 136, 210, 90, 56, -40


def _box(inside='', front=''):
    x, y, w, h = BX, BY, BW, BHh
    rim = f'<path d="M{x} {y} H{x + w} L{x + w + DX} {y + DY} H{x + DX} Z"/>'
    corner = thin(f'M{x + DX} {y + DY} V{y}')
    face_ = f'<rect x="{x}" y="{y}" width="{w}" height="{h}"/>'
    side = f'<path d="M{x + w} {y} L{x + w + DX} {y + DY} V{y + DY + h} L{x + w} {y + h} Z"/>'
    return rim + corner + inside + face_ + side + front


def _plate(cx, cy, r=30):
    return f'<circle cx="{cx}" cy="{cy}" r="{r}"/>' + f'<circle cx="{cx}" cy="{cy}" r="{r * .7:.1f}" fill="none" stroke-width="1.6"/>'


W1, W2, WY = (122, BY + 58), (232, BY + 58), 30


def _wheels():
    return (_plate(*W1) + _plate(*W2)
            + tape(W1[0], W1[1] - 30, rot=-8) + tape(W2[0], W2[1] - 30, rot=6))


def _lights():
    x, y = BX + BW, BY
    return (f'<ellipse cx="{x + 14}" cy="{y + 8}" rx="8" ry="11" transform="rotate(-30 {x + 14} {y + 8})"/>'
            f'<ellipse cx="{x + 42}" cy="{y - 12}" rx="8" ry="11" transform="rotate(-30 {x + 42} {y - 12})"/>'
            f'<path d="M{x + 14} {y + 52} L{x + 42} {y + 32} V{y + 46} L{x + 14} {y + 66} Z" stroke-width="2"/>')


def _steering(cx=258, cy=112):
    return (f'<circle cx="{cx}" cy="{cy}" r="24"/><circle cx="{cx}" cy="{cy}" r="17" fill="none" stroke-width="1.6"/>'
            + dot(cx, cy, 4) + thin(f'M{cx - 17} {cy} H{cx + 17} M{cx} {cy} V{cy + 17}'))


_cut_flap = (f'<path d="M{BX + DX} {BY + DY} V{BY + DY - 46} H{BX + BW + DX} V{BY + DY}"/>'
)

D[key('Turn an old box into a car you can sit in')] = [
    ground(BY + BHh) + _cut_flap + _box()
    + '<path d="M22 268 H112 L130 252 H40 Z"/>'
    + scissors(BX + DX + 40, BY + DY - 4, 0) + grip(BX + DX + 18, BY + DY - 4, 20, grown=True)
    + arrow(f'M{BX + DX + 110} {BY + DY - 14} H{BX + BW + DX - 10}')
    + arrow(f'M{BX + 4} {BY + 20} C{BX - 40} {BY + 40} {BX - 50} {BY + 80} {BX - 20} {BY + 108}', dashed=True),
    ground(BY + BHh) + _box()
    + _plate(*W1) + tape(W1[0], W1[1] - 30, rot=-8)
    + f'<circle cx="{W2[0]}" cy="{W2[1]}" r="30" fill="none" stroke-width="1.6" stroke-dasharray="4 5"/>'
    + _plate(330, 50) + arrow('M292 54 C250 60 236 100 236 150'),
    ground(BY + BHh) + _box(inside=_steering()) + _wheels() + _lights()
    + hold_pen(BX + BW + 34, BY + 30, -40)
    + motion(f'M{BX + BW + 10} {BY + 18} l8 -4 l-4 10 l8 -4'),
    ground(BY + BHh)
    + _box(inside=limb(f'M{BX + 120} {BY - 18} Q{BX + 160} {BY - 6} {BX + 182} {BY - 24}')
           + torso(BX + 110, BY - 34, BY, 24) + face(BX + 110, BY - 64, 28, 'grin') + _steering()
           + f'<circle cx="{BX + 184}" cy="{BY - 26}" r="8"/>')
    + _wheels() + _lights()
    + motion('M20 150 H54', 'M30 176 H58', 'M20 202 H54'),
]


# ── Make a pinwheel that spins ───────────────────────────────────────────
def _pin_pts(cx, cy, a, f=.5):
    """The square's corners, and where each cut from a corner stops (f of the way in)."""
    c = [(cx - a, cy - a), (cx + a, cy - a), (cx + a, cy + a), (cx - a, cy + a)]
    e = [(x + f * (cx - x), y + f * (cy - y)) for x, y in c]
    return c, e


def _lerp(p, q, t):
    return (p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1]))


def _stop(cx, cy, ex, ey, w=7):
    """A short ink bar across a cut where the scissors stop."""
    import math
    dx, dy = cx - ex, cy - ey
    n = math.hypot(dx, dy)
    px, py = -dy / n * w, dx / n * w
    return f'<path d="M{ex - px:.1f} {ey - py:.1f} L{ex + px:.1f} {ey + py:.1f}" fill="none" stroke-width="3.2"/>'


def pinwheel(cx, cy, a=80, folded=(), cuts=True):
    """The paper square seen from the front, cut from each corner. In each quarter k
    in `folded`, the point on the clockwise side of corner k curls into the middle."""
    c, e = _pin_pts(cx, cy, a)
    d = f'M{c[0][0]} {c[0][1]}'
    for k in range(4):
        n = c[(k + 1) % 4]
        if k in folded:
            p = _lerp(c[k], n, .5)
            q = _lerp(e[k], p, .45)
            d += f' L{cx} {cy} Q{q[0]:.1f} {q[1]:.1f} {p[0]:.1f} {p[1]:.1f}'
        d += f' L{n[0]} {n[1]}'
    s = f'<path d="{d} Z"/>'
    if cuts:
        for k in range(4):
            if k not in folded:
                s += thin(f'M{c[k][0]} {c[k][1]} L{e[k][0]:.1f} {e[k][1]:.1f}')
    return s


def _held_pinwheel(cx, cy, a, rot=0):
    """A finished pinwheel pinned to a pencil's rubber; the pencil goes down behind it."""
    return (f'<path d="M{cx - 9} {cy} H{cx + 9} V{cy + 130} L{cx} {cy + 152} L{cx - 9} {cy + 130} Z"/>'
            + thin(f'M{cx - 9} {cy + 130} H{cx + 9} M{cx - 3} {cy + 144} H{cx + 3}')
            + f'<g transform="rotate({rot} {cx} {cy})">{pinwheel(cx, cy, a, folded=(0, 1, 2, 3), cuts=False)}</g>'
            + f'<circle cx="{cx}" cy="{cy}" r="5"/>' + dot(cx, cy, 2))


def _cut_step():
    cx, cy, a = 224, 136, 100
    c, e = _pin_pts(cx, cy, a)
    s = f'<rect x="{cx - a}" y="{cy - a}" width="{2 * a}" height="{2 * a}"/>'
    for k in range(4):
        s += ghost(f'M{c[k][0]} {c[k][1]} L{e[k][0]:.1f} {e[k][1]:.1f}') + _stop(cx, cy, *e[k])
    s += dot(cx, cy, 4.5)
    # cutting in from the bottom-left corner: the cut so far is solid
    s += scissors(c[3][0] - 4, c[3][1] + 4, -45, 1.15)
    s += arrow(f'M{c[3][0] + 40} {c[3][1] - 6} L{e[3][0] + 12} {e[3][1] + 12}')
    return s


def _fold_step():
    cx, cy, a = 200, 150, 104
    c, e = _pin_pts(cx, cy, a)
    s = pinwheel(cx, cy, a, folded=(0,))
    s += dot(cx, cy, 4)
    # where the folded point used to be
    p0 = _lerp(c[0], c[1], .5)
    s += ghost(f'M{e[0][0]:.1f} {e[0][1]:.1f} L{c[0][0]} {c[0][1]} L{p0[0]:.1f} {p0[1]:.1f}')
    s += thin(f'M{e[0][0]:.1f} {e[0][1]:.1f} L{p0[0]:.1f} {p0[1]:.1f}')
    for k in (1, 2, 3):
        n = c[(k + 1) % 4]
        # a dot on the point that folds: just inside the corner, on its clockwise side
        m = _lerp(c[k], _lerp(e[k], _lerp(c[k], n, .5), .5), .3)
        s += dot(*m, 4.5)
        start = _lerp(m, (cx, cy), .1)
        end = _lerp((cx, cy), _lerp(c[k], n, .5), .16)
        ctl = _lerp(_lerp(c[k], n, .45), (cx, cy), .25)
        s += arrow(f'M{start[0]:.1f} {start[1]:.1f} Q{ctl[0]:.1f} {ctl[1]:.1f} {end[0]:.1f} {end[1]:.1f}')
    return s


def _pin_step():
    import math
    cx, cy = 140, 118
    s = _held_pinwheel(cx, cy, 64)
    # a fist holding the pencil upright
    s += (limb(f'M{cx - 12} {cy + 116} Q{cx - 50} {cy + 130} {cx - 74} {cy + 196}', 16)
          + f'<rect x="{cx - 17}" y="{cy + 92}" width="30" height="32" rx="11"/>'
          + thin(f'M{cx - 17} {cy + 103} H{cx - 2} M{cx - 17} {cy + 113} H{cx - 2}')
          + f'<path d="M{cx + 13} {cy + 100} Q{cx + 20} {cy + 98} {cx + 18} {cy + 108}" fill="none"/>')
    # the pin comes in from the right, its point going into the middle
    t = math.radians(18)
    ux, uy = math.cos(t), math.sin(t)
    hx, hy = cx + 128 * ux, cy + 128 * uy
    s += (f'<path d="M{hx:.1f} {hy:.1f} L{cx + 6 * ux:.1f} {cy + 6 * uy:.1f}" fill="none" stroke-width="3"/>'
          f'<circle cx="{hx:.1f}" cy="{hy:.1f}" r="7"/>')
    s += grip(hx + 16 * ux, hy + 16 * uy, 198, grown=True)
    ox, oy = 20 * uy, -20 * ux
    s += arrow(f'M{hx - 6 * ux + ox:.1f} {hy - 6 * uy + oy:.1f} L{cx + 52 * ux + ox:.1f} {cy + 52 * uy + oy:.1f}')
    return s


D[key('Make a pinwheel that spins')] = [
    _cut_step(),
    _fold_step(),
    _pin_step(),
    face(78, 116, 40, 'blow') + torso(78, 160, 284, 30)
    + limb('M102 196 Q170 240 246 236')
    + _held_pinwheel(270, 116, 54, rot=20) + '<circle cx="270" cy="236" r="11"/>'
    + motion('M116 128 C150 126 176 118 206 108', 'M116 146 C152 146 180 142 212 136', 'M114 164 C146 168 172 168 204 166')
    + arrow('M232 40 C266 14 330 22 350 62 C362 90 356 120 344 138'),
]


# ── Make a monster from a paper plate ────────────────────────────────────
def _hatch(cx, cy, r, upto=None, step=11):
    upto = r if upto is None else upto
    lines = ' '.join(f'M{cx + t - r} {cy + r} l{2 * r} {-2 * r}' for t in range(-r, upto, step))
    return (f'<clipPath id="pl"><circle cx="{cx}" cy="{cy}" r="{r}"/></clipPath>'
            f'<path d="{lines}" clip-path="url(#pl)" fill="none" stroke-width="1.2"/>')


def _mouth(cx, cy, done=True):
    s = (f'<path d="M{cx - 72} {cy} Q{cx} {cy + 18} {cx + 72} {cy} Q{cx + 62} {cy + 72} {cx} {cy + 74} '
         f'Q{cx - 62} {cy + 72} {cx - 72} {cy} Z"/>')
    teeth = [cx - 50, cx - 26, cx, cx + 24, cx + 48]
    for i, t in enumerate(teeth):
        if not done and i == len(teeth) - 1:
            break
        ty = cy + 9 - (abs(t - cx) / 72) ** 2 * 9
        s += f'<path d="M{t - 9} {ty:.1f} L{t} {ty + 18:.1f} L{t + 9} {ty - 1:.1f}" fill="#fff"/>'
    for t in (cx - 22, cx + 22):
        s += f'<path d="M{t - 8} {cy + 70} L{t} {cy + 54} L{t + 8} {cy + 70}" fill="#fff"/>'
    return s


def _eye(cx, cy, r=20):
    return f'<circle cx="{cx}" cy="{cy}" r="{r}"/>' + dot(cx + 3, cy + 4, r * .35)


def _horns_hair(cx, cy):
    return (f'<path d="M{cx - 66} {cy - 70} Q{cx - 104} {cy - 106} {cx - 84} {cy - 136} Q{cx - 70} {cy - 104} {cx - 36} {cy - 90} Z"/>'
            f'<path d="M{cx + 66} {cy - 70} Q{cx + 104} {cy - 106} {cx + 84} {cy - 136} Q{cx + 70} {cy - 104} {cx + 36} {cy - 90} Z"/>'
            f'<path d="M{cx - 28} {cy - 90} l2 -26 l10 18 l6 -24 l10 22 l8 -24 l8 22 l10 -18 l2 26 Z"/>')


def monster(cx=200, cy=150, r=100, stage=4, hatch_upto=None):
    s = ''
    if stage >= 3:
        s += _horns_hair(cx, cy)
    s += f'<circle cx="{cx}" cy="{cy}" r="{r}"/>'
    s += _hatch(cx, cy, r, hatch_upto)
    s += f'<circle cx="{cx}" cy="{cy}" r="{r * .76}" fill="none" stroke-width="1.6"/>'
    if stage >= 2:
        s += _mouth(cx, cy, done=stage > 2 or hatch_upto == -1)
    if stage >= 3:
        s += _eye(cx - 34, cy - 46)
    if stage >= 4:
        s += _eye(cx + 34, cy - 46)
    return s


D[key('Make a monster from a paper plate')] = [
    monster(170, 150, 100, 1, hatch_upto=10)
    + motion('M140 214 l22 -22 l-4 18 l22 -22') + hold_pen(184, 186, -45),
    monster(170, 150, 100, 2)
    + ghost('M209 159 L218 176 L227 156')
    + arrow('M176 124 Q202 124 210 146') + hold_pen(222, 172, 40),
    monster(200, 160, 100, 3)
    + f'<circle cx="234" cy="114" r="20" fill="none" stroke-width="1.6" stroke-dasharray="4 5"/>'
    + _eye(340, 62) + arrow('M318 70 C284 76 262 86 252 98'),
    f'<g transform="translate(140 118) scale(.62) translate(-200 -150)">{monster()}</g>'
    + limb('M276 228 Q230 222 196 160')
    + torso(300, 210, 284, 34) + face(300, 168, 40, 'grin')
    + '<circle cx="194" cy="156" r="10"/>'
    + motion('M354 150 q10 14 0 28', 'M366 138 q18 26 0 52'),
]


# ── Make a pair of binoculars from toilet rolls ──────────────────────────
TW, TH, TY = 56, 124, 84  # tube width, height, top


def _tube(x, deco=0):
    """A toilet roll tube standing up. deco 1 = stripes and dots, 2 = zigzag and spots, 0 = plain;
    a deco below zero only half done."""
    rx, ry = TW / 2, 9
    cx, yb = x + rx, TY + TH
    s = (f'<path d="M{x} {TY} V{yb} A{rx} {ry} 0 0 0 {x + TW} {yb} V{TY}"/>'
         f'<ellipse cx="{cx}" cy="{TY}" rx="{rx}" ry="{ry}"/>'
         f'<ellipse cx="{cx}" cy="{TY}" rx="{rx - 6}" ry="{ry - 4}" stroke-width="1.6"/>')

    def band(y):
        return thin(f'M{x} {y} A{rx} {ry} 0 0 0 {x + TW} {y}')
    if abs(deco) == 1:
        for y in (TY + 26, TY + 36, TY + 84, TY + 94):
            s += band(y)
        if deco > 0:
            s += dot(cx - 14, TY + 62, 3.4) + dot(cx, TY + 58, 3.4) + dot(cx + 14, TY + 62, 3.4)
    if abs(deco) == 2:
        zz = ''.join(f' l7 {-10 if i % 2 == 0 else 10}' for i in range(8))
        s += thin(f'M{x} {TY + 40}{zz}')
        if deco > 0:
            s += thin(f'M{x} {TY + 90}{zz}')
            s += ''.join(f'<circle cx="{cx + dx}" cy="{TY + dy}" r="5" stroke-width="1.6"/>'
                         for dx, dy in ((-12, 64), (10, 66), (-2, 112)))
    return s


def _band(x0, y, h=13):
    rx = TW / 2
    return (f'<path d="M{x0} {y} A{rx} 8 0 0 0 {x0 + TW} {y} A{rx} 8 0 0 0 {x0 + 2 * TW} {y} V{y + h} '
            f'A{rx} 8 0 0 1 {x0 + TW} {y + h} A{rx} 8 0 0 1 {x0} {y + h} Z" stroke-width="1.8"/>')


_bx0 = 200 - TW


def _pair():
    return (_tube(_bx0, 1) + _tube(_bx0 + TW, 2)
            + _band(_bx0, TY + 4) + _band(_bx0, TY + TH - 26))


def _strap(done=True):
    l, r = _bx0 + 4, _bx0 + 2 * TW - 4
    l, r = _bx0 - 2, _bx0 + 2 * TW + 2
    s = f'<path d="M{l} {TY + 40} C{l - 40} 0 {r + 40} 0 {r} {TY + 40}" fill="none"/>'
    s += tape(l, TY + 40, 26, 11, 90)
    if done:
        s += tape(r, TY + 40, 26, 11, 90)
    return s


def _bird(x, y):
    return (f'<path d="M{x - 18} {y} q4 -14 18 -12 q10 -14 22 -4 l8 2 l-8 4 q2 16 -16 18 q-14 2 -20 -6 l-10 2 Z"/>'
            + dot(x + 18, y - 10, 1.8) + thin(f'M{x - 4} {y - 2} q8 6 18 -2'))


D[key('Make a pair of binoculars from toilet rolls')] = [
    ground(TY + TH + 10) + _tube(96, 1) + _tube(248, -2)
    + motion('M222 116 l10 -8 l0 10 l10 -8') + hold_pen(262, 124, -30, flip=False),
    ground(TY + TH + 10) + _pair()
    + arrow(f'M{_bx0 - 70} {TY + 64} H{_bx0 - 14}') + arrow(f'M{_bx0 + 2 * TW + 70} {TY + 64} H{_bx0 + 2 * TW + 14}'),
    ground(TY + TH + 10) + _pair() + _strap(False)
    + tape(330, 60, 24, 10, 20) + grip(334, 64, 200)
    + ghost(f'M{_bx0 + 2 * TW - 4} {TY + 27} h11 v26 h-11 Z')
    + arrow(f'M318 84 C306 110 290 124 {_bx0 + 2 * TW + 16} {TY + 44}'),
    ground(252)
    + torso(96, 166, 252, 30) + face(96, 124, 38, 'smile')
    + '<path d="M86 162 Q120 196 146 140" fill="none"/>'
    + '<rect x="122" y="96" width="58" height="28" rx="3"/><ellipse cx="180" cy="110" rx="5" ry="14"/>'
    + '<rect x="128" y="104" width="58" height="28" rx="3"/><ellipse cx="186" cy="118" rx="5" ry="14"/>'
    + limb('M110 196 Q134 172 150 140') + '<circle cx="152" cy="138" r="9"/>'
    # a tree with a bird on a branch, and a flower
    + '<path d="M316 252 V150 M316 182 L354 160 M316 196 L286 178"/>'
    + '<path d="M276 160 C252 150 262 104 296 108 C300 70 352 68 360 104 C384 108 384 150 358 156 C344 168 296 170 276 160 Z"/>'
    + thin('M316 252 V158') + _bird(346, 162)
    + '<path d="M236 252 V214"/>' + ''.join(f'<circle cx="{236 + dx}" cy="{206 + dy}" r="7"/>' for dx, dy in ((-8, 0), (8, 0), (0, -8), (0, 8)))
    + '<circle cx="236" cy="206" r="5"/>' + thin('M236 236 q10 -6 14 -16')
    + motion('M196 108 L310 152', 'M196 126 L308 176'),
]


# ── Make a shaker from a bottle and rice ─────────────────────────────────
def _rice(x0, x1, y0, y1, n, seed=3):
    rnd = random.Random(seed)
    s = ''
    for _ in range(n):
        x, y, a = rnd.uniform(x0, x1), rnd.uniform(y0, y1), rnd.uniform(0, 180)
        s += f'<ellipse cx="{x:.1f}" cy="{y:.1f}" rx="3.4" ry="1.8" stroke-width="1.2" transform="rotate({a:.0f} {x:.1f} {y:.1f})"/>'
    return s


SX, SB = 200, 250  # bottle centre line, bottom


def bottle(cx=SX, base=SB, lid=True, deco=0):
    s = (f'<path d="M{cx - 40} {base - 8} V130 C{cx - 40} 112 {cx - 16} 116 {cx - 16} 100 V90 H{cx + 16} V100 '
         f'C{cx + 16} 116 {cx + 40} 112 {cx + 40} 130 V{base - 8} Q{cx + 40} {base} {cx + 32} {base} H{cx - 32} '
         f'Q{cx - 40} {base} {cx - 40} {base - 8} Z"/>'
         + thin(f'M{cx - 16} 98 H{cx + 16}'))
    s += thin(f'M{cx - 38} {base - 22} Q{cx} {base - 32} {cx + 38} {base - 22}')
    s += _rice(cx - 34, cx + 34, base - 20, base - 6, 26)
    s += thin(f'M{cx - 28} 138 V{base - 40}')
    if deco:
        for y in (148, 196):
            s += (f'<path d="M{cx - 40} {y} Q{cx} {y + 8} {cx + 40} {y} V{y + 14} Q{cx} {y + 22} {cx - 40} {y + 14} Z" stroke-width="1.8"/>'
                  + thin(''.join(f'M{cx - 30 + i * 12} {y + 4 + (i in (2, 3)) * 3} l6 {8 + (i in (2, 3)) * 1}' for i in range(6))))
        s += heart(cx - 22, 182, 8) + f'<circle cx="{cx + 23}" cy="181" r="7"/>'
        if deco > 1:
            s += star(cx, 182, 10)
    if lid:
        s += lid_(cx, 72)
    return s


def lid_(cx, y):
    return (f'<rect x="{cx - 20}" y="{y}" width="40" height="22" rx="3"/>'
            + thin(''.join(f'M{cx - 12 + i * 8} {y + 4} V{y + 18}' for i in range(4))))


D[key('Make a shaker from a bottle and rice')] = [
    ground(SB) + bottle(lid=False) + lid_(306, SB - 22)
    + grip(148, 54, -50)
    + '<path d="M194 54 L164 20 L144 34 L163 78 Z"/>'
    + '<ellipse cx="179" cy="66" rx="18" ry="5.5" transform="rotate(-37 179 66)"/>'
    + _rice(184, 196, 74, 80, 2, seed=7) + _rice(190, 204, 80, 88, 2, seed=9)
    + motion('M212 58 l6 12', 'M222 72 l5 12'),
    ground(SB) + bottle() + grip(SX + 4, 64, 210, flip=False)
    + arrow(f'M{SX - 34} 92 C{SX - 30} 110 {SX + 30} 110 {SX + 36} 86'),
    ground(SB) + bottle(deco=1) + star(312, 88, 16) + grip(326, 100, 200)
    + star(SX, 182, 10).replace('/>', ' fill="none" stroke-width="1.6" stroke-dasharray="3 4"/>')
    + arrow(f'M296 100 C276 120 250 150 {SX + 16} 174'),
    '<g transform="translate(0 12)">' + limb('M168 140 Q140 200 128 240') + limb('M188 140 Q220 180 248 186 Q264 230 278 246')
    + limb('M156 96 Q118 110 96 92') + limb('M196 94 Q236 80 258 50')
    + f'<path d="M150 150 L154 80 Q154 70 166 70 H186 Q198 70 198 80 L204 150 Z"/>'
    + face(174, 40, 26, 'grin') + '<circle cx="96" cy="92" r="9"/>'
    + f'<g transform="translate(276 36) rotate(30) scale(.42) translate(-200 -170)">{bottle(deco=2)}</g>'
    + '<circle cx="262" cy="48" r="9"/>' + ground(256, 60, 340)
    + motion('M300 22 q14 8 14 24', 'M318 10 q22 14 20 40', 'M232 40 q-6 -16 6 -28', 'M108 236 l-14 6', 'M300 246 l14 6') + '</g>',
]


# ── Make a flag for your family ──────────────────────────────────────────
FX, FY, FW, FHt = 110, 70, 200, 130


def _flag_pictures(x=FX, y=FY, heart_done=True):
    s = dog(x + 46, y + 100, 1.0) + ball(x + 152, y + 40, 18)
    if heart_done:
        s += heart(x + 150, y + 96, 18)
    else:
        h = heart(x + 150, y + 96, 18)
        s += h.replace('Z"/>', 'Z" fill="none" stroke-dasharray="4 5" stroke-width="1.6"/>')
    return s


def _flag(x=FX, y=FY, heart_done=True):
    return f'<rect x="{x}" y="{y}" width="{FW}" height="{FHt}" rx="2"/>' + _flag_pictures(x, y, heart_done)


def _stick(x=FX - 12, y0=FY - 8, y1=282):
    return f'<rect x="{x}" y="{y0}" width="12" height="{y1 - y0}" rx="5"/>'


D[key('Make a flag for your family')] = [
    think_bubble(70, 232, dog(166, 152, .9) + ball(232, 124, 18) + heart(286, 128, 18))
    + arrow('M60 196 q-8 -30 10 -46', dashed=True),
    _flag(heart_done=False) + hold_pen(FX + 150, FY + 114, 40)
    + arrow(f'M{FX + 112} {FY + 70} C{FX + 120} {FY + 52} {FX + 142} {FY + 60} {FX + 148} {FY + 74}'),
    _stick() + _flag() + tape(FX - 6, FY + 20, 34, 12)
    + ghost(f'M{FX - 23} {FY + FHt - 26} h34 v12 h-34 Z')
    + tape(40, 120, 34, 12, -20)
    + arrow(f'M54 140 C62 170 70 176 {FX - 28} {FY + FHt - 20}'),
    torso(92, 200, 284, 30) + limb('M112 214 Q150 214 164 162')
    + face(92, 160, 32, 'grin')
    + '<rect x="164" y="26" width="12" height="214" rx="5"/>' + '<circle cx="170" cy="160" r="11"/>'
    + '<path d="M176 30 Q220 10 262 30 T348 30 V128 Q304 108 262 128 T176 128 Z"/>'
    + heart(234, 82, 18) + ball(304, 78, 18)
    + motion('M362 44 q12 22 0 44', 'M376 34 q20 32 0 64', 'M150 50 q-10 -16 4 -30'),
]
