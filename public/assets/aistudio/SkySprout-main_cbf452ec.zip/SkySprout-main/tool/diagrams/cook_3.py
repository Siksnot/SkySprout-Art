"""Diagrams for the last Kitchen challenges (a menu for tea, measuring for a recipe,
a salad all by yourself, chocolate crispy cakes, pancakes, a drink for everyone).
Worktops and tables are seen slightly from above; a grown-up's bigger hand with a
sleeve does anything hot. The orange accent is only for arrows and motion lines."""
import math
import re

from style import INK, arrow, dot, ghost, ground, motion, thin
from craft import scribble
from craft_3 import grip
from kind import _open_hand, person as kperson, table as round_table, plate_top
from kind_2 import bubble, cup, fist, hands, limb, person, qmark, squiggle, tap, book_open

D = {}


def key(title):
    return re.sub(r'[^a-z0-9]+', '_', title.lower()).strip('_')[:48]


# ── Shared bits ──────────────────────────────────────────────────────────
def g(body, x=0, y=0, s=1, rot=0):
    t = f'translate({x} {y})'
    if rot:
        t += f' rotate({rot})'
    if s != 1:
        t += f' scale({s})'
    return f'<g transform="{t}">{body}</g>'


def worktop(y, x0=16, x1=384):
    """The front edge of a kitchen worktop; things stand on it just above y."""
    return f'<rect x="{x0}" y="{y}" width="{x1 - x0}" height="14" rx="3"/>'


def bowl(cx, cy, rx, ry, d, inside='', level=None):
    """A bowl seen a little from above: rim ellipse centred (cx, cy), d deep. level draws a
    filling surface (0 = at the rim)."""
    s = f'<ellipse cx="{cx}" cy="{cy + d - 2:.1f}" rx="{rx * .42:.1f}" ry="{max(ry * .3, 4):.1f}"/>'
    s += f'<path d="M{cx - rx} {cy} C{cx - rx} {cy + d * 1.33:.1f} {cx + rx} {cy + d * 1.33:.1f} {cx + rx} {cy} Z"/>'
    s += f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}"/>'
    if level is not None:
        k = 1 - level
        s += (f'<ellipse cx="{cx}" cy="{cy + ry * .25 + d * level * .35:.1f}" rx="{rx * (.9 * k + .05):.1f}" '
              f'ry="{ry * (.75 * k + .05):.1f}" fill="none" stroke-width="1.6"/>')
    return s + inside


def held(px, py, ang, grown=False, flip=False):
    return grip(px, py, ang, grown=grown, flip=flip)


def spoon(x, y, rot, L=96, wood=True):
    """A spoon with its bowl at (x, y) and the handle going off at rot degrees."""
    b = (f'<rect x="10" y="-3.5" width="{L - 10}" height="7" rx="3.5"/>'
         '<ellipse cx="0" cy="0" rx="14" ry="9"/>')
    return g(b, x, y, 1, rot)


def held_spoon(x, y, rot, L=96, at=.72, turn=60, grown=False, flip=False, inside=''):
    r = math.radians(rot)
    return (spoon(x, y, rot, L) + inside
            + grip(x + L * at * math.cos(r), y + L * at * math.sin(r), rot + 180 + (turn if flip else -turn),
                   grown=grown, flip=flip))


def point(tx, ty, rot=0, s=1.0, arm=70):
    """A hand pointing one finger, fingertip at (tx, ty); rot 0 points straight up, arm below."""
    b = (limb(f'M0 46 V{46 + arm}', 15)
         + '<rect x="-5.5" y="0" width="11" height="34" rx="5.5"/>'
         + '<rect x="-16" y="20" width="32" height="32" rx="12"/>'
         + thin('M-16 33 H-6 M-16 42 H-6')
         + '<path d="M14 30 q10 -2 10 8 q-2 8 -10 6" />')
    return g(b, tx, ty, s, rot)


def jug(cx, by, w=70, h=90, level=.55, ticks=True, mark=None):
    """A measuring jug from the side: spout on the left, handle on the right. mark: which tick
    (0 = lowest) is drawn long, to read at."""
    x0, x1, top = cx - w / 2, cx + w / 2, by - h
    s = limb(f'M{x1 - 3} {top + 14} C{x1 + 30} {top + 10} {x1 + 30} {top + h * .62} {x1 - 4} {top + h * .66}', 10)
    s += (f'<path d="M{x0} {top} L{x0 + 5} {by - 6} Q{x0 + 6} {by} {x0 + 12} {by} H{x1 - 12} Q{x1 - 6} {by} {x1 - 5} {by - 6} '
          f'L{x1} {top} Z"/>'
          f'<path d="M{x0 + 6} {top - 3} L{x0 - 14} {top - 9} L{x0 + 2} {top + 12}"/>'
          f'<ellipse cx="{cx}" cy="{top}" rx="{w / 2}" ry="5"/>')
    if level:
        ly = by - h * level
        k = (by - ly) / h
        lx0, lx1 = x0 + 5 * k, x1 - 5 * k
        s += thin(f'M{lx0 + 2:.1f} {ly:.1f} Q{cx} {ly + 6:.1f} {lx1 - 2:.1f} {ly:.1f}')
    if ticks:
        for i in range(5):
            ty = by - 14 - i * (h - 26) / 4
            long_ = mark == i
            s += f'<path d="M{x0 + 7 + (ty - top) / h * 0:.1f} {ty:.1f} h{22 if long_ else 11}" fill="none" stroke-width="{2.4 if long_ else 1.6}"/>'
    return s


def hob(cx, y, w=300, rings=((-70, 0), (70, 0))):
    """A hob top seen a little from above, front edge at y, with control knobs on the front."""
    l, r = cx - w / 2, cx + w / 2
    s = (f'<path d="M{l + 26} {y - 50} H{r - 26} L{r} {y} H{l} Z"/>'
         f'<rect x="{l}" y="{y}" width="{w}" height="20" rx="3"/>')
    for i in range(4):
        kx = l + w * (.2 + i * .2)
        s += f'<circle cx="{kx:.1f}" cy="{y + 10}" r="5"/>' + thin(f'M{kx:.1f} {y + 6} v4')
    for dx, dy in rings:
        s += f'<ellipse cx="{cx + dx}" cy="{y - 24 + dy}" rx="44" ry="12" fill="none" stroke-width="1.6"/>'
    return s


def egg(x, y, s=1.0, rot=0):
    return g('<ellipse cx="0" cy="0" rx="12" ry="16"/>' + thin('M-5 -8 q3 -4 6 -4'), x, y, s, rot)


def flour_bag(x, by, w=66, h=104, open_=False):
    top = by - h
    s = (f'<path d="M{x} {by} H{x + w} V{top + 18} L{x + w - 8} {top} H{x + 8} L{x} {top + 18} Z"/>'
         + thin(f'M{x} {top + 18} H{x + w}'))
    if open_:
        s += f'<ellipse cx="{x + w / 2}" cy="{top + 2}" rx="{w / 2 - 8}" ry="5"/>' + dot(x + w / 2, top - 4, 1.8) + dot(x + w / 2 - 8, top - 2, 1.6)
    # a wheat ear on the front
    cx, cy = x + w / 2, top + 50
    s += thin(f'M{cx} {cy + 30} V{cy - 18}')
    for k in range(3):
        yy = cy - 12 + k * 12
        s += (f'<ellipse cx="{cx - 6}" cy="{yy}" rx="4" ry="7" transform="rotate(-30 {cx - 6} {yy})" stroke-width="1.6"/>'
              f'<ellipse cx="{cx + 6}" cy="{yy}" rx="4" ry="7" transform="rotate(30 {cx + 6} {yy})" stroke-width="1.6"/>')
    return s + f'<ellipse cx="{cx}" cy="{cy - 22}" rx="3.5" ry="6" stroke-width="1.6"/>'


def lettuce(cx, cy, r):
    n = 11
    d = ''
    for i in range(n + 1):
        a = 2 * math.pi * i / n
        x, y = cx + r * math.cos(a), cy + r * .9 * math.sin(a)
        if i == 0:
            d = f'M{x:.1f} {y:.1f}'
        else:
            am = 2 * math.pi * (i - .5) / n
            d += f' Q{cx + r * 1.22 * math.cos(am):.1f} {cy + r * 1.1 * math.sin(am):.1f} {x:.1f} {y:.1f}'
    return (f'<path d="{d} Z"/>'
            + thin(f'M{cx - r * .55:.1f} {cy + r * .5:.1f} Q{cx - r * .6:.1f} {cy - r * .3:.1f} {cx} {cy - r * .45:.1f} '
                   f'M{cx + r * .55:.1f} {cy + r * .5:.1f} Q{cx + r * .6:.1f} {cy - r * .3:.1f} {cx} {cy - r * .45:.1f} '
                   f'M{cx} {cy + r * .7:.1f} V{cy - r * .2:.1f}'))


def leaf(x, y, s=1.0, rot=0):
    """A torn lettuce piece."""
    return g('<path d="M-18 4 Q-22 -8 -12 -12 Q-8 -20 2 -16 Q12 -20 16 -10 Q24 -4 18 6 Q12 14 0 12 Q-14 14 -18 4 Z"/>'
             + thin('M-10 6 Q0 -2 10 -8'), x, y, s, rot)


def cuc_slice(x, y, r=12):
    return (f'<ellipse cx="{x}" cy="{y}" rx="{r}" ry="{r * .8:.1f}"/>'
            f'<ellipse cx="{x}" cy="{y}" rx="{r * .62:.1f}" ry="{r * .48:.1f}" fill="none" stroke-width="1.4"/>'
            + dot(x - r * .25, y, 1.4) + dot(x + r * .25, y, 1.4) + dot(x, y - r * .2, 1.4))


def tomato_bit(x, y, r=11, rot=0):
    return g(f'<path d="M{-r} 0 A{r} {r} 0 0 0 {r} 0 Z"/>'
             + thin(f'M0 0 V{r * .7:.1f} M{-r * .6:.1f} 0 L{-r * .4:.1f} {r * .5:.1f} M{r * .6:.1f} 0 L{r * .4:.1f} {r * .5:.1f}')
             + dot(-r * .3, r * .3, 1.4) + dot(r * .3, r * .3, 1.4), x, y, 1, rot)


def tomato(x, y, r=14):
    return (f'<circle cx="{x}" cy="{y}" r="{r}"/>'
            + thin(f'M{x - 6} {y - r + 2} l6 4 l6 -4 M{x} {y - r + 6} v-6'))


def bottle(cx, by, w=36, h=96, cap=True):
    """A squash bottle standing on (cx, by), an orange drawn on its label."""
    t = by - h
    s = (f'<path d="M{cx - w / 2} {by - 6} V{t + 34} Q{cx - w / 2} {t + 22} {cx - 8} {t + 14} V{t + 2} H{cx + 8} V{t + 14} '
         f'Q{cx + w / 2} {t + 22} {cx + w / 2} {t + 34} V{by - 6} Q{cx + w / 2} {by} {cx + w / 2 - 6} {by} '
         f'H{cx - w / 2 + 6} Q{cx - w / 2} {by} {cx - w / 2} {by - 6} Z"/>')
    if cap:
        s += f'<rect x="{cx - 10}" y="{t - 8}" width="20" height="12" rx="3"/>'
    s += (f'<rect x="{cx - w / 2 + 4}" y="{by - h * .62:.1f}" width="{w - 8}" height="{h * .42:.1f}" rx="3" fill="none" stroke-width="1.6"/>'
          f'<circle cx="{cx}" cy="{by - h * .4:.1f}" r="8" stroke-width="1.6"/>'
          + thin(f'M{cx} {by - h * .4 - 8:.1f} q4 -6 9 -4'))
    return s


def pot(cx, rim, rx=64, h=54):
    """A saucepan seen a little from above, its handle off to the left."""
    return (f'<path d="M{cx - rx + 4} {rim + 10} L{cx - rx - 84} {rim - 6}" fill="none" stroke="{INK}" stroke-width="14"/>'
            f'<path d="M{cx - rx + 4} {rim + 10} L{cx - rx - 84} {rim - 6}" fill="none" stroke="#fff" stroke-width="9"/>'
            f'<path d="M{cx - rx} {rim} V{rim + h - 8} Q{cx - rx} {rim + h + 8} {cx} {rim + h + 8} '
            f'Q{cx + rx} {rim + h + 8} {cx + rx} {rim + h - 8} V{rim} Z"/>'
            f'<ellipse cx="{cx}" cy="{rim}" rx="{rx}" ry="14"/>')


def pan(cx, cy, rx=86, ry=20, d=22, handle=1, L=96):
    """A frying pan seen a little from above; handle off to the right (handle=-1: left)."""
    hx = cx + handle * rx
    s = (f'<path d="M{hx - handle * 4} {cy - 2} L{hx + handle * L} {cy - 18}" fill="none" stroke="{INK}" stroke-width="14"/>'
         f'<path d="M{hx - handle * 4} {cy - 2} L{hx + handle * L} {cy - 18}" fill="none" stroke="#fff" stroke-width="9"/>')
    s += f'<path d="M{cx - rx} {cy} L{cx - rx + 8} {cy + d} Q{cx} {cy + d + ry * .9} {cx + rx - 8} {cy + d} L{cx + rx} {cy} Z"/>'
    s += f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}"/>'
    s += f'<ellipse cx="{cx}" cy="{cy + 3}" rx="{rx - 8}" ry="{ry - 5}" fill="none" stroke-width="1.6"/>'
    return s


def pancake(cx, cy, rx=50, ry=12, rot=0):
    return g(f'<ellipse cx="0" cy="0" rx="{rx}" ry="{ry}"/>'
             + dot(-rx * .4, -1, 2) + dot(rx * .1, -ry * .3, 2) + dot(rx * .45, 1, 2) + dot(-rx * .05, ry * .4, 1.8),
             cx, cy, 1, rot)


def berry(x, y, r=6):
    return f'<circle cx="{x}" cy="{y}" r="{r}"/>' + dot(x + r * .3, y - r * .3, 1.2)


def lemon(x, y, r=20, rot=0):
    """A lemon wedge: a half-slice with segments."""
    return g(f'<path d="M{-r} 0 A{r} {r} 0 0 0 {r} 0 Z"/>'
             f'<path d="M{-r + 5} 0 A{r - 5} {r - 5} 0 0 0 {r - 5} 0" fill="none" stroke-width="1.6"/>'
             + thin(f'M0 0 V{r - 6} M0 0 L{-(r - 6) * .7:.1f} {(r - 6) * .7:.1f} M0 0 L{(r - 6) * .7:.1f} {(r - 6) * .7:.1f}'),
             x, y, 1, rot)


def paper(x, y, w, h, rot=0):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="3" transform="rotate({rot} {x + w / 2} {y + h / 2})"/>'


def fancy(cx, y, w=120):
    """The menu's fancy heading: big loops with a curly underline and a star each side."""
    n = 5
    step = w / n
    s = scribble(cx - w / 2, y, n, step).replace('stroke-width="1.6"', 'stroke-width="2.8"')
    s += thin(f'M{cx - w / 2 - 4} {y + 10} q{w / 4} 8 {w / 2 + 4} 0 t{w / 2 + 4} 0')
    return s + _twinkle(cx - w / 2 - 16, y - 8) + _twinkle(cx + w / 2 + 18, y - 8)


def _twinkle(x, y, r=7):
    return f'<path d="M{x} {y - r} Q{x} {y} {x + r} {y} Q{x} {y} {x} {y + r} Q{x} {y} {x - r} {y} Q{x} {y} {x} {y - r} Z" stroke-width="1.6"/>'


def pasta_pic(x, y, s=1.0):
    """A bowl of spaghetti, drawn small as on the menu."""
    return g('<path d="M-20 0 Q-20 16 0 16 Q20 16 20 0 Z" stroke-width="1.8"/>'
             '<path d="M-17 0 Q-16 -14 -4 -12 Q2 -20 10 -12 Q18 -12 17 0" fill="none" stroke-width="1.6"/>'
             + thin('M-10 -2 q4 -8 8 0 q4 -8 8 0 M-6 -8 q5 -5 10 0'), x, y, s)


def peas_pic(x, y, s=1.0):
    """A pea pod and peas."""
    return g('<path d="M-22 4 Q-4 -12 22 -4 Q6 14 -22 4 Z" stroke-width="1.8"/>'
             + ''.join(f'<circle cx="{px}" cy="{py}" r="4.5" stroke-width="1.6"/>' for px, py in ((-10, 1), (0, -1), (10, -1)))
             + thin('M22 -4 q6 -4 4 -10'), x, y, s)


def cup_pic(x, y, s=1.0, part=1.0):
    """A small cup with a straw, drawn on the menu (part < 1: still being drawn)."""
    if part < 1:
        return g('<path d="M-12 -14 L-9 14 H2" fill="none" stroke-width="1.8"/>', x, y, s)
    return g('<path d="M-12 -14 H12 L9 14 H-9 Z" stroke-width="1.8"/>'
             + thin('M-11 -4 H11 M4 -14 L10 -26 H16'), x, y, s)


def menu_sheet(x, y, w, h, rows=0, drawing=False):
    s = f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="3"/>'
    s += fancy(x + w / 2, y + 72, w * .5)
    pics = (pasta_pic, peas_pic, cup_pic)
    for i in range(3):
        ry = y + 124 + i * 50
        if i < rows:
            s += pics[i](x + 40, ry) + squiggle(x + 78, ry, w - 110, 1)
        elif drawing and i == rows:
            s += cup_pic(x + 40, ry) + squiggle(x + 78, ry, 36, 1)
        else:
            s += ghost(f'M{x + 22} {ry + 6} H{x + w - 22}')
    return s


def pen_at(tx, ty, a=-40):
    """A felt pen held in a hand, its tip at (tx, ty)."""
    from kind import pen_held
    return pen_held(tx, ty, a)


# ── Make a menu for tonight's tea ────────────────────────────────────────
def _plate_icon(cx, cy, food=''):
    return (f'<ellipse cx="{cx}" cy="{cy}" rx="26" ry="12"/>'
            f'<ellipse cx="{cx}" cy="{cy}" rx="17" ry="7" fill="none" stroke-width="1.6"/>' + food)



MX, MY, MW, MH = 110, 22, 180, 256

D[key("Make a menu for tonight's tea")] = [
    ground(278)
    + person(300, 276, 'adult', look=-1, mouth='open')
    + person(96, 276, 'kid', look=1, mouth='open')
    + bubble(22, 18, 116, 64, 96, 104, _plate_icon(62, 52) + qmark(114, 50, 1.1))
    + bubble(150, 6, 110, 48, 282, 66, _plate_icon(194, 30, thin('M178 30 q4 -7 8 0 q4 -7 8 0 q4 -7 8 0 M182 25 q5 -5 10 0 q5 -5 10 0'))
             + '<circle cx="230" cy="22" r="4" stroke-width="1.6"/><circle cx="239" cy="26" r="4" stroke-width="1.6"/>'
             + '<circle cx="231" cy="32" r="4" stroke-width="1.6"/>')
    + motion('M136 150 l12 -6', 'M138 162 h14'),

    menu_sheet(MX, MY, MW, MH)
    + pen_at(MX + MW / 2 + 46, MY + 70)
    + arrow(f'M{MX + MW / 2 - 50} {MY + 102} H{MX + MW / 2 + 40}'),

    menu_sheet(MX, MY, MW, MH, rows=2, drawing=True)
    + pen_at(MX + 116, MY + 224)
    + motion(f'M{MX + 100} {MY + 240} l-6 6', f'M{MX + 114} {MY + 244} v8'),

    ground(278)
    + round_table(240, 206, 132, 46)
    + plate_top(150, 210, 22, 12) + plate_top(240, 236, 22, 12) + plate_top(330, 210, 22, 12)
    + '<path d="M212 196 L218 150 H262 L268 196 Z"/><path d="M218 150 L224 140 H256 L262 150" fill="none" stroke-width="1.6"/>'
    + squiggle(226, 160, 28, 1) + pasta_pic(240, 180, .55)
    + person(64, 276, 'kid', look=1, arms=((-1, None), (1, (214, 172, 150, 190))), mouth='grin')
    + hands((214, 172))
    + arrow('M240 104 V130'),
]


# ── Measure the ingredients for a recipe ────────────────────────────────
def _recipe_book(cx, cy):
    b = book_open(cx, cy, 104, 62, 'none', 0)
    # a little cake on the left page
    x, y = cx - 26, cy + 4
    return b + (f'<path d="M{x - 13} {y} V{y - 12} H{x + 13} V{y} Z" stroke-width="1.8"/>'
                f'<path d="M{x - 13} {y - 12} Q{x - 6} {y - 18} {x} {y - 13} Q{x + 6} {y - 18} {x + 13} {y - 12}" fill="none" stroke-width="1.8"/>'
                f'<circle cx="{x}" cy="{y - 20}" r="3" stroke-width="1.6"/>')


SC, ST, SF = 196, 168, 262   # scales centre x, platform y, worktop y


def _scales(ang=-90, inside_bowl='', bowl_=True, level=None):
    s = worktop(SF)
    s += f'<rect x="{SC - 92}" y="{ST + 10}" width="184" height="{SF - ST - 10}" rx="12"/>'
    s += f'<rect x="{SC - 10}" y="{ST}" width="20" height="12"/>'
    s += (f'<ellipse cx="{SC}" cy="{ST + 4}" rx="92" ry="12"/>'
          f'<ellipse cx="{SC}" cy="{ST}" rx="92" ry="12"/>')
    dx, dy, r = SC - 30, ST + 54, 28
    s += f'<circle cx="{dx}" cy="{dy}" r="{r}"/>'
    for k in range(8):
        a = math.radians(-90 + k * 26)
        r0 = 20 if k == 0 else 23
        s += (f'<path d="M{dx + r0 * math.cos(a):.1f} {dy + r0 * math.sin(a):.1f} L{dx + 27 * math.cos(a):.1f} '
              f'{dy + 27 * math.sin(a):.1f}" fill="none" stroke-width="{2.6 if k == 0 else 1.6}"/>')
    a = math.radians(ang)
    s += (f'<path d="M{dx} {dy} L{dx + 19 * math.cos(a):.1f} {dy + 19 * math.sin(a):.1f}" fill="none" stroke-width="2.8"/>'
          + dot(dx, dy, 3.4))
    s += f'<rect x="{SC + 34}" y="{ST + 42}" width="34" height="16" rx="8"/>'
    if bowl_:
        s += bowl(SC, ST - 38, 70, 16, 36, inside_bowl, level)
    return s


D[key('Measure the ingredients for a recipe')] = [
    ground(278)
    + person(104, 276, 'kid', look=1, arms=((-1, None), (1, (156, 200, 140, 214))), mouth='smile')
    + person(296, 276, 'adult', look=-1, arms=((-1, (248, 196, 262, 214)), (1, None)), mouth='open')
    + _recipe_book(202, 190) + hands((152, 200)) + hands((252, 196), kind='adult')
    + motion('M128 132 L168 168', 'M272 82 L230 164'),

    _scales()
    + point(SC + 51, ST + 50, -44, arm=34)
    + motion(f'M{SC + 30} {ST + 30} l-6 -6', f'M{SC + 50} {ST + 26} v-8', f'M{SC + 72} {ST + 34} l6 -6'),

    _scales(-90 + 64, inside_bowl=(f'<path d="M{SC - 44} {ST - 36} Q{SC - 30} {ST - 58} {SC - 4} {ST - 56} '
                                   f'Q{SC + 24} {ST - 58} {SC + 40} {ST - 36} Z"/>'
                                   + ''.join(dot(SC + x, ST + y, 1.5) for x, y in ((-24, -44), (-6, -50), (12, -44), (24, -40), (-12, -40)))))
    + flour_bag(24, SF, 62, 100, open_=True)
    + held_spoon(SC + 4, ST - 84, -8, 104, inside=f'<path d="M{SC - 9} {ST - 86} Q{SC + 4} {ST - 98} {SC + 15} {ST - 86} Z"/>')
    + motion(f'M{SC - 4} {ST - 72} v10', f'M{SC + 8} {ST - 72} v14')
    + arrow(f'M{SC - 30 + 36 * math.cos(math.radians(-62)):.1f} {ST + 54 + 36 * math.sin(math.radians(-62)):.1f} '
            f'A36 36 0 0 1 {SC - 30 + 36 * math.cos(math.radians(-14)):.1f} {ST + 54 + 36 * math.sin(math.radians(-14)):.1f}'),

    '<rect x="206" y="184" width="178" height="14" rx="3"/>'
    + '<rect x="214" y="198" width="162" height="78"/>' + thin('M295 204 V270') + dot(284, 236, 3) + dot(306, 236, 3)
    + ground(278, 24, 206)
    + jug(296, 184, 70, 86, .32, mark=1)
    + person(112, 276, 'kid', look=1, legs='kneel', mouth='smile')
    + arrow('M148 158 H244', dashed=True),
]


# ── Make a salad all by yourself ─────────────────────────────────────────
_sink = '<rect x="60" y="180" width="280" height="90" rx="16"/><rect x="76" y="192" width="248" height="66" rx="12"/>'

D[key('Make a salad all by yourself')] = [
    _sink + tap(200, 96)
    + lettuce(200, 176, 38)
    + fist(158, 186, -1, (-70, 70)) + fist(242, 186, 1, (70, 70))
    + motion('M194 104 V132', 'M206 104 V132', 'M170 138 l-8 -8', 'M230 138 l8 -8'),

    bowl(200, 214, 110, 26, 52, leaf(170, 214, .9, -10) + leaf(214, 218, .9, 20) + leaf(236, 210, .7, -30))
    + '<path d="M120 90 Q112 60 140 52 Q156 34 176 48 Q190 50 194 62 L186 70 L196 80 L186 90 L194 102 Q170 120 140 112 Q120 108 120 90 Z"/>'
    + '<path d="M280 90 Q288 60 260 52 Q244 34 224 48 Q210 50 208 62 L214 70 L204 80 L214 90 L206 102 Q230 120 260 112 Q280 108 280 90 Z"/>'
    + thin('M134 96 Q160 84 184 78 M266 96 Q240 84 216 78')
    + fist(126, 88, -1, (-62, 60)) + fist(274, 88, 1, (62, 60))
    + leaf(200, 150, .6, 15)
    + arrow('M176 30 Q150 22 128 36') + arrow('M224 30 Q250 22 272 36'),

    '<rect x="44" y="160" width="312" height="96" rx="14" transform="translate(0 8)" fill="none" stroke-width="1.6"/>'
    + '<rect x="44" y="160" width="312" height="96" rx="14"/>' + '<circle cx="334" cy="208" r="7"/>'
    + '<rect x="90" y="190" width="132" height="32" rx="16"/>' + cuc_slice(222, 206, 15)
    + cuc_slice(262, 210, 14) + cuc_slice(290, 216, 14) + tomato_bit(286, 184, 11, 0) + tomato_bit(312, 236, 10, -20)
    + fist(102, 196, -1, (-60, 60))
    + g('<path d="M-13 -58 H13 V-6 Q13 12 0 12 Q-13 12 -13 -6 Z"/>'
        + thin('M-13 -46 l4 4 l-4 4 l4 4 l-4 4 l4 4 l-4 4 l4 4 l-4 4 l4 4 l-4 4')
        + '<rect x="-11" y="-118" width="22" height="62" rx="9"/>' + thin('M-11 -100 h22 M-11 -90 h22 M-11 -80 h22'),
        240, 204, 1, 8)
    + fist(252, 120, 1, (70, -30))
    + motion('M282 150 v-24', 'M294 158 v-24'),

    bowl(200, 160, 128, 40, 84, level=None)
    + leaf(150, 156, 1.1, -10) + leaf(196, 148, 1.2, 15) + leaf(246, 160, 1.1, -25) + leaf(170, 172, .9, 30)
    + cuc_slice(222, 170, 12) + cuc_slice(126, 168, 11) + tomato_bit(260, 144, 10, 10) + tomato_bit(186, 132, 9, -10)
    + cuc_slice(276, 170, 11) + tomato_bit(150, 140, 9, 20)
    + held_spoon(160, 150, -120, 110) + held_spoon(240, 150, -60, 110, flip=True)
    + arrow('M84 196 C110 252 290 252 316 196') + motion('M182 114 q-8 10 -2 20', 'M218 114 q8 10 2 20'),
]


# ── Make blueberry muffins with a grown-up (key kept from the crispy cakes) ──
import cook_2 as _c2  # noqa: E402


def blueberry(x, y, r=4.5):
    return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{INK}"/>' + f'<circle cx="{x - r * .35:.1f}" cy="{y - r * .35:.1f}" r="{r * .25:.1f}" fill="#fff" stroke="none"/>'


def muffin(cx, cy, rx=24):
    """A baked blueberry muffin in its case, its big top spilling over the rim (case rim at cy)."""
    s = _c2.case(cx, cy, 0, rx)
    s += (f'<path d="M{cx - rx - 5} {cy + 2} Q{cx - rx - 8} {cy - 18} {cx - rx * .5:.1f} {cy - 26} '
          f'Q{cx} {cy - 34} {cx + rx * .5:.1f} {cy - 26} Q{cx + rx + 8} {cy - 18} {cx + rx + 5} {cy + 2} '
          f'Q{cx} {cy + 9} {cx - rx - 5} {cy + 2} Z"/>')
    s += thin(f'M{cx - rx * .5:.1f} {cy - 14} q4 -4 8 0 M{cx + rx * .2:.1f} {cy - 20} q4 -4 8 0')
    return s + ''.join(blueberry(cx + rx * fx, cy + fy, 3.6) for fx, fy in ((-.6, -8), (.1, -24), (.55, -10), (-.1, -4)))


MBX, MBY = 200, 132
_dry = (f'<path d="M{MBX - 80} {MBY + 12} Q{MBX - 44} {MBY - 26} {MBX - 4} {MBY - 22} Q{MBX + 40} {MBY - 28} {MBX + 80} {MBY + 12} '
        f'Q{MBX} {MBY + 26} {MBX - 80} {MBY + 12} Z"/>'
        + ''.join(dot(MBX + x, MBY + y, 1.6) for x, y in ((-44, 0), (-24, -12), (-6, -4), (12, -14), (30, -2), (48, 4), (-30, 10), (8, 8))))
_flour2 = (_c2.mixture(236, 184, 94, 14)
           + ''.join(dot(236 + x, 184 + y, 1.6) for x, y in ((-40, -2), (-14, -8), (10, 0), (34, -6), (52, 2))))

D[key('Make chocolate crispy cakes with a grown-up')] = [
    # 1. mix the flour, baking powder and sugar in a big bowl
    _c2.stir(MBX, MBY, _dry),

    # 2. pour the milk, oil and egg into the flour
    ground(276) + _c2.big_bowl(236, 176, 110, 26, mix=False) + _flour2
    + _c2.jug_r(118, 94, 50) + grip(76, 74, 60)
    + motion('M182 104 Q190 140 200 172'),

    # 3. stir in the blueberries and spoon into the 12 cases
    _c2.tin_and_spoon(berries=True),

    # 4. golden muffins, baked by a grown-up, cooling on the rack
    _c2.on_rack(muffin, steam=True),
]


# ── Make pancakes with a grown-up ────────────────────────────────────────
D[key('Make pancakes with a grown-up')] = [
    worktop(256)
    + flour_bag(34, 256, 70, 112)
    + '<ellipse cx="150" cy="248" rx="30" ry="8"/>' + egg(140, 230) + egg(162, 232, 1, 18)
    + jug(236, 256, 66, 92, .5, mark=2)
    + bowl(336, 196, 46, 14, 54)
    + arrow('M70 120 C120 60 300 60 330 168', dashed=True),

    bowl(200, 150, 126, 38, 90, level=.05)
    + thin('M150 160 C150 140 250 140 250 160 C250 180 168 178 172 160 C176 146 228 148 226 162')
    + fist(78, 152, -1, (-50, 80))
    + g('<path d="M0 -70 C-30 -46 -30 0 0 0 C30 0 30 -46 0 -70 Z" fill="none"/>'
        '<path d="M0 -70 C-12 -46 -12 0 0 0 C12 0 12 -46 0 -70 Z" fill="none"/>'
        '<rect x="-6" y="-128" width="12" height="62" rx="5"/>', 200, 160, 1, 30)
    + fist(252, 72, 1, (60, -20))
    + arrow('M120 206 C150 236 260 236 290 200'),

    hob(200, 266, 320, rings=((-30, 0),))
    + pan(160, 212, 92, 22, 24, L=72)
    + pancake(160, 100, 54, 13, -12)
    + grip(300, 186, 186, grown=True, flip=True)
    + arrow('M90 110 C66 140 74 184 94 204')
    + motion('M130 136 v18', 'M160 140 v20', 'M190 136 v18'),

    plate_top(196, 200, 140, 50)
    + pancake(196, 200, 72, 22) + pancake(196, 188, 70, 21) + pancake(196, 176, 68, 20)
    + lemon(160, 168, 22, 10)
    + berry(208, 166) + berry(222, 172) + berry(236, 164) + berry(220, 158)
    + ''.join(dot(x, y, 1.6) for x, y in ((180, 182), (192, 176), (200, 186), (250, 180), (176, 194), (244, 190)))
    + bowl(70, 76, 40, 12, 32, berry(60, 74) + berry(74, 72) + berry(84, 78) + berry(66, 80))
    + bowl(330, 76, 40, 12, 32, ''.join(dot(320 + i * 5, 76 + (i % 2) * 3, 1.6) for i in range(5)))
    + arrow('M100 96 C140 110 180 130 206 150', dashed=True)
    + arrow('M300 96 C270 120 250 140 236 156', dashed=True),
]


# ── Make a drink for everyone at tea ─────────────────────────────────────
_family = (kperson(226, 256, .62, who='adult') + kperson(270, 256, .62, who='gran')
           + kperson(312, 256, .62) + kperson(350, 256, .55, who='sib'))

JX, JB = 170, 262

D[key('Make a drink for everyone at tea')] = [
    ground(256)
    + kperson(110, 256, 1.05, arms=[(-1, -30, -44), (1, 44, -126, 40, -96, False)])
    + _open_hand(160, 113, 1.1)
    + _family
    + motion('M226 132 q22 -26 44 0', 'M270 132 q21 -26 42 0', 'M312 132 q19 -20 38 6'),

    worktop(JB)
    + jug(JX, JB, 96, 120, .5, ticks=False)
    + g(bottle(0, 0, 36, 96, cap=False), 266, 54, 1, -120)
    + fist(258, 54, 1, (64, 10))
    + motion(f'M{JX + 12} 106 Q{JX + 12} 150 {JX + 10} 196'),

    worktop(JB)
    + jug(JX, JB, 96, 120, .62, ticks=False)
    + g('<rect x="-4" y="-150" width="8" height="150" rx="4"/><ellipse cx="0" cy="0" rx="10" ry="6"/>', JX + 6, JB - 18, 1, 12)
    + fist(JX + 31, JB - 118, 1, (70, -30))
    + arrow(f'M{JX - 60} {JB - 64} C{JX - 50} {JB - 40} {JX + 40} {JB - 40} {JX + 52} {JB - 68}'),

    '<path d="M30 236 L60 170 H340 L370 236 Z"/><rect x="30" y="236" width="340" height="14" rx="3"/>'
    + '<path d="M50 250 V286 M350 250 V286" fill="none" stroke-width="5"/>'
    + cup(96, 222, 30, 40, .7) + cup(150, 222, 30, 40, .3) + cup(250, 222, 30, 40, 0) + cup(304, 222, 30, 40, 0)
    + g(jug(0, 0, 70, 90, .5, ticks=False), 248, 140, 1, -38)
    + fist(262, 62, 1, (60, 30))
    + motion('M146 98 Q148 140 150 196'),
]
