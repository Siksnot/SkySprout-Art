"""Diagrams for more Bricks challenges (spaceship, name letters, playground,
20 bricks, treasure chest). Bricks overlap by at least one stud wherever they
connect, or the build wouldn't hold together."""
from style import BH, U, arrow, brick, dot, ghost, ground, hand, motion, thin

D = {}


# ── Shared bits ──────────────────────────────────────────────────────────
def figure(cx, by, sit=False):
    """A little toy figure seen from the front, feet (or seat) at by."""
    leg = 8 if sit else 18
    t0, t1 = by - leg, by - leg - 20
    hy = t1 - 8
    s = (f'<rect x="{cx - 9}" y="{t0}" width="18" height="{leg}" rx="1.5"/>'
         + thin(f'M{cx} {t0 + 3} V{by}')
         + f'<polygon points="{cx - 9},{t0} {cx + 9},{t0} {cx + 7},{t1} {cx - 7},{t1}"/>'
         + thin(f'M{cx - 8} {t1 + 3} l-4 12 M{cx + 8} {t1 + 3} l4 12')
         + f'<rect x="{cx - 3}" y="{hy - 10}" width="6" height="4" rx="1"/>'
         + f'<circle cx="{cx}" cy="{hy}" r="7.5"/>'
         + dot(cx - 2.8, hy - 1.5, 1.2) + dot(cx + 2.8, hy - 1.5, 1.2)
         + thin(f'M{cx - 3} {hy + 2.5} q3 2.5 6 0'))
    return s


def plate(x, y, n):
    """A thin base plate, side view, top at y."""
    return (f'<rect x="{x}" y="{y}" width="{n * U}" height="8" rx="1.5"/>'
            + ''.join(f'<rect x="{x + i * U + 4}" y="{y - 4}" width="8" height="4" rx="1"/>' for i in range(n)))


def loose(x, y, n=2):
    return brick(x, y, n)


# ── Make a spaceship for two little figures ──────────────────────────────
_sx, _sy = 96, 168  # base brick: left end, top


def _ship_base(x, y):
    return brick(x, y, 12)


def _ship_crew(x, y):
    return figure(x + 5 * U, y - 4, sit=True) + figure(x + 7 * U + 4, y - 4, sit=True)


def _ship_body(x, y):
    # Side wall sits across the base studs; the nose wedge sits on the last two.
    wall = brick(x, y - BH, 6) + brick(x + 6 * U, y - BH, 4)
    back = brick(x, y - 2 * BH, 3)
    nose = (f'<path d="M{x + 10 * U} {y} V{y - BH} H{x + 11 * U} L{x + 12 * U + 30} {y + BH / 2} '
            f'L{x + 12 * U} {y + BH} V{y} Z"/>')
    glass = (f'<path d="M{x + 9 * U} {y - BH - 4} V{y - BH - 34} Q{x + 10 * U + 8} {y - BH - 30} {x + 11 * U + 6} {y - BH - 4} Z" '
             f'fill="none"/>' + thin(f'M{x + 9 * U + 6} {y - BH - 24} q6 2 9 9'))
    return wall + back + nose + glass


def _ship_parts(x, y):
    # Top engine overhangs the back wall by two studs; the lower engine and
    # the wing clip under the base.
    top = brick(x - 2 * U, y - 3 * BH, 4)
    low = brick(x - 2 * U, y + BH, 4, studs=False)
    noz = ''.join(f'<path d="M{x - 2 * U} {ey + 3} L{x - 2 * U - 12} {ey - 2} V{ey + BH + 2} L{x - 2 * U} {ey + BH - 3}"/>'
                  for ey in (y - 3 * BH, y + BH))
    wing = (brick(x + 3 * U, y + BH, 6, studs=False)
            + f'<path d="M{x + 3 * U} {y + 2 * BH} H{x + 9 * U} L{x + 5 * U} {y + 2 * BH + 26} H{x + 2 * U} Z"/>')
    return wing + low + top + noz


def _ship(x, y):
    return _ship_base(x, y) + _ship_crew(x, y) + _ship_body(x, y) + _ship_parts(x, y)


D['make_a_spaceship_for_two_little_figures'] = [
    ground(_sy + BH, 40, 360) + _ship_base(_sx, _sy) + _ship_crew(_sx, _sy)
    + arrow(f'M{_sx + 6 * U + 4} {_sy - 66} H{_sx + 3 * U}') + arrow(f'M{_sx + 6 * U + 4} {_sy - 66} H{_sx + 10 * U + 8}'),
    ground(_sy + BH, 40, 360) + _ship_base(_sx, _sy) + _ship_crew(_sx, _sy) + _ship_body(_sx, _sy)
    + arrow(f'M{_sx + 12 * U + 40} {_sy - 90} q10 30 -26 44'),
    _ship(_sx, _sy)
    + arrow(f'M{_sx - 50} {_sy - 110} q-10 30 14 50') + arrow(f'M{_sx + 6 * U} {_sy + 110} q34 -6 30 -40'),
    f'<g transform="rotate(-12 200 150)">{_ship(_sx + 16, _sy - 4)}</g>'
    + motion('M20 220 q12 -2 22 -8', 'M20 264 q16 -4 30 -14', 'M300 268 C210 296 120 290 70 262',
             'M346 110 C380 140 372 210 330 244'),
]


# ── Build your name in brick letters ─────────────────────────────────────
# Seen from above: a base plate with studs, letters built from 1-wide bricks.
C = 18


def _plate_top(x, y, cols, rows):
    s = f'<rect x="{x}" y="{y}" width="{cols * C}" height="{rows * C}" rx="3"/>'
    s += ''.join(f'<circle cx="{x + i * C + C / 2}" cy="{y + j * C + C / 2}" r="1.6" fill="#1d1d1f" stroke="none"/>'
                 for i in range(cols) for j in range(rows))
    return s


def _tb(x, y, c, r, w, h):
    """A brick seen from above at grid cell (c, r), w x h studs."""
    bx, by = x + c * C, y + r * C
    s = f'<rect x="{bx}" y="{by}" width="{w * C}" height="{h * C}" rx="2"/>'
    s += ''.join(f'<circle cx="{bx + i * C + C / 2}" cy="{by + j * C + C / 2}" r="4.6" stroke-width="2"/>'
                 for i in range(w) for j in range(h))
    return s


_S = [(0, 0, 3, 1), (0, 1, 1, 1), (0, 2, 3, 1), (2, 3, 1, 1), (0, 4, 3, 1)]
_A = [(0, 0, 3, 1), (0, 1, 1, 4), (2, 1, 1, 4), (1, 2, 1, 1)]
_M = [(0, 0, 1, 5), (4, 0, 1, 5), (1, 1, 1, 1), (2, 2, 1, 1), (3, 1, 1, 1)]
_ncols, _nrows = 19, 9
_nx, _ny = (400 - _ncols * C) // 2, (300 - _nrows * C) // 2


def _letter(parts, c0, r0, x=_nx, y=_ny, skip=()):
    return ''.join(_tb(x, y, c0 + c, r0 + r, w, h) for i, (c, r, w, h) in enumerate(parts) if i not in skip)


def _name(x=_nx, y=_ny):
    return (_plate_top(x, y, _ncols, _nrows) + _letter(_S, 2, 2, x, y)
            + _letter(_A, 7, 2, x, y) + _letter(_M, 12, 2, x, y))


def _counting_hand(x, y):
    # palm with three fingers up and two folded
    s = (f'<path d="M{x} {y} V{y - 40} Q{x} {y - 50} {x + 10} {y - 50} H{x + 50} Q{x + 60} {y - 50} {x + 60} {y - 40} V{y} Z"/>')
    for i in range(3):
        fx = x + 2 + i * 19
        s += f'<rect x="{fx}" y="{y - 96}" width="16" height="52" rx="8"/>'
    s += thin(f'M{x + 6} {y - 26} q24 8 48 0 M{x + 6} {y - 16} q24 8 48 0')
    s += f'<path d="M{x} {y - 30} q-26 -10 -24 -30 q10 -6 20 8" />'
    return s


D['build_your_name_in_brick_letters'] = [
    # say it, count it: a face talking and a hand with three fingers up
    '<circle cx="110" cy="150" r="46"/>' + dot(96, 140) + dot(124, 140)
    + '<ellipse cx="110" cy="166" rx="10" ry="8"/>'
    + thin('M70 128 q12 -30 44 -26 q24 2 36 26')
    + motion('M168 136 q10 14 0 28', 'M180 124 q18 26 0 52')
    + _counting_hand(250, 244)
    + arrow('M246 120 q30 -28 64 -6'),
    _plate_top(_nx, _ny, _ncols, _nrows) + _letter(_S, 2, 2, skip=(4,))
    + ghost(f'M{_nx + 2 * C} {_ny + 6 * C} h{3 * C} v{C} h{-3 * C} Z')
    + _tb(_nx + 6 * C, _ny + 9 * C + 26, 0, 0, 3, 1)
    + arrow(f'M{_nx + 6 * C - 6} {_ny + 9 * C + 34} C{_nx + 4 * C} {_ny + 9 * C + 34} {_nx + 3.5 * C} {_ny + 9 * C} {_nx + 3.5 * C} {_ny + 7 * C + 6}'),
    _name() + arrow(f'M{_nx + 3 * C} {_ny - 20} q{2.5 * C} -26 {5 * C} 0')
    + arrow(f'M{_nx + 8 * C} {_ny - 20} q{2.5 * C} -26 {5 * C} 0'),
    # standing up on a shelf, propped by two feet bricks behind
    f'<g transform="translate(66 {204 - _nrows * C * 0.78:.0f}) scale(0.78)">{_name(0, 0)}</g>'
    + '<path d="M40 204 H360 V218 H40 Z"/>' + thin('M70 218 l20 30 M330 218 l-20 30')
    + motion('M40 70 l-12 -12', 'M30 110 h-14', 'M360 70 l12 -12', 'M370 110 h14'),
]


# ── Make a playground for little figures ─────────────────────────────────
_px, _py, _PN = 16, 206, 23  # base plate: left end, top, studs


def _slide(x, y):
    # Staircase: each layer sits across the one below; the top one overhangs right
    # and the slide hooks over its last stud.
    s = (brick(x, y - BH, 4) + brick(x + U, y - 2 * BH, 3) + brick(x + 2 * U, y - 3 * BH, 2)
         + brick(x + 2 * U, y - 4 * BH, 3))
    tx, ty = x + 5 * U, y - 4 * BH
    s += (f'<path d="M{tx - 12} {ty - 6} H{tx} C{tx + 30} {ty} {tx + 36} {y - 10} {tx + 62} {y - 10} H{tx + 72} V{y} '
          f'H{tx + 60} C{tx + 30} {y} {tx + 24} {ty + 8} {tx - 12} {ty + 2} Z"/>')
    return s


def _seesaw(x, y, riders=False, ang=-10):
    # A 2-stud pivot brick with a hinge pin; the 6-stud plank turns on it.
    cx, cy = x + U, y - BH - 4
    s = brick(x, y - BH, 2)
    top = cy + 6 - BH
    g = (brick(cx - 3 * U, top, 6) + brick(cx - 3 * U, top - BH, 1) + brick(cx + 2 * U, top - BH, 1))
    if riders:
        g += figure(cx - 2.5 * U, top - BH - 4, sit=True) + figure(cx + 2.5 * U, top - BH - 4, sit=True)
    s += f'<g transform="rotate({ang} {cx} {cy})">{g}</g>'
    return s + f'<circle cx="{cx}" cy="{cy}" r="5"/>' + dot(cx, cy, 2)


def _bench(x, y):
    # two 1x1 legs, a 3-stud seat across them, a 1x1 back stacked on the seat
    return (brick(x, y - BH, 1) + brick(x + 2 * U, y - BH, 1) + brick(x, y - 2 * BH, 3)
            + brick(x, y - 3 * BH, 1) + brick(x, y - 4 * BH, 1))


def _fence(x, y):
    # a 3-stud fence piece: a low brick with posts and a rail on top
    s = brick(x, y - BH, 3, studs=False)
    s += ''.join(f'<rect x="{x + 3 + i * 21}" y="{y - BH - 30}" width="6" height="30" rx="1"/>' for i in range(3))
    s += f'<rect x="{x}" y="{y - BH - 34}" width="{3 * U}" height="8" rx="1.5"/>'
    return s


_SLX, _BNX, _SSX, _FNX = _px, _px + 9 * U, _px + 15 * U, _px + 20 * U
_base = plate(_px, _py, _PN)

D['make_a_playground_for_little_figures'] = [
    _base + _slide(_SLX, _py)
    + arrow(f'M{_SLX + 5 * U} {_py - 4 * BH - 22} C{_SLX + 8 * U} {_py - 4 * BH - 18} {_SLX + 8 * U} {_py - 34} {_SLX + 10 * U + 6} {_py - 26}', dashed=True),
    _base + _slide(_SLX, _py) + _seesaw(_SSX, _py)
    + arrow(f'M{_SSX - 2 * U} {_py - 100} q-8 22 6 42') + arrow(f'M{_SSX + 4 * U} {_py - 66} q8 -22 -6 -44'),
    _base + _slide(_SLX, _py) + _seesaw(_SSX, _py) + _bench(_BNX, _py) + _fence(_FNX, _py)
    + arrow(f'M{_BNX + 1.5 * U} {_py - 132} q14 24 0 50') + arrow(f'M{_FNX + 1.5 * U} {_py - 128} q14 24 0 50'),
    _base + _slide(_SLX, _py) + _seesaw(_SSX, _py, riders=True) + _bench(_BNX, _py) + _fence(_FNX, _py)
    + figure(_SLX + 3.5 * U, _py - 4 * BH - 4)
    + figure(_BNX + 2 * U, _py - 2 * BH - 4, sit=True)
    + motion(f'M{_SLX + 7 * U} {_py - 64} q16 10 22 30', f'M{_SSX + 6 * U + 4} {_py - 112} q16 22 2 46'),
]


# ── Build something using 20 bricks or fewer ─────────────────────────────
def _car(x, y):
    # chassis on top of two axle bricks; cab and roof stacked on the chassis
    return (brick(x + U, y, 1, studs=False) + brick(x + 5 * U, y, 1, studs=False)
            + f'<circle cx="{x + 1.5 * U}" cy="{y + BH}" r="14"/><circle cx="{x + 5.5 * U}" cy="{y + BH}" r="14"/>'
            + dot(x + 1.5 * U, y + BH, 4) + dot(x + 5.5 * U, y + BH, 4)
            + brick(x, y - BH, 7) + brick(x + U, y - 2 * BH, 4) + brick(x + U, y - 3 * BH, 3)
            + thin(f'M{x + 3 * U + 4} {y - 2 * BH + 4} h{U + 8} v10 h{-U - 8} Z'))


def _pile(x, y):
    return (brick(x, y - BH, 2, ) + brick(x + 2 * U + 6, y - BH, 1) + brick(x + 8, y - 2 * BH - 2, 2)
            + brick(x + 4 * U, y - BH, 2))


def _thinker(x, y):
    return (f'<circle cx="{x}" cy="{y}" r="32"/>'
            f'<path d="M{x - 16} {y - 6} q4 -5 8 0 M{x + 8} {y - 6} q4 -5 8 0" fill="none"/>'
            f'<path d="M{x - 8} {y + 14} q8 6 16 0" fill="none"/>')


D['build_something_using_20_bricks_or_fewer'] = [
    # a loose heap of bricks, then twenty laid out in rows of five
    brick(20, 196, 2) + brick(56, 196, 2) + brick(92, 196, 2)
    + f'<g transform="rotate(-10 52 186)">{brick(36, 176, 2)}</g>' + f'<g transform="rotate(8 92 184)">{brick(76, 174, 2)}</g>'
    + f'<g transform="rotate(14 66 160)">{brick(56, 152, 1)}</g>'
    + ''.join(brick(170 + c * 40, 96 + r * 32, 2) for r in range(4) for c in range(5))
    + arrow('M90 136 q24 -50 70 -36'),
    _thinker(70, 230)
    + '<circle cx="104" cy="190" r="4"/><circle cx="114" cy="174" r="6"/>'
    + '<path d="M118 148 C86 138 92 88 130 86 C138 46 202 42 218 70 C244 40 306 48 312 82 '
      'C360 80 372 136 338 150 C348 184 296 198 276 176 C254 202 196 200 186 176 C150 194 110 178 118 148 Z"/>'
    # a dog, a car and a house
    + '<path d="M138 142 h34 v-18 h-34 Z M142 142 v12 M168 142 v12 M138 126 q-8 -4 -8 -14" fill="none"/>'
    + '<circle cx="180" cy="116" r="10"/><path d="M174 108 q-6 8 -2 16" fill="none"/>' + dot(183, 114, 1.8)
    + '<path d="M200 140 v-16 l8 -10 h28 l8 10 h8 v16 Z" fill="none"/><circle cx="214" cy="142" r="6"/><circle cx="244" cy="142" r="6"/>'
    + '<path d="M276 146 v-26 l20 -18 l20 18 v26 Z M290 146 v-12 h10 v12" fill="none"/>'
    + arrow('M30 214 q-6 -30 16 -48', dashed=True),
    ground(232) + _car(150, 196) + _pile(40, 232) + brick(270, 214, 2) + brick(306, 214, 1)
    + arrow('M86 160 q30 -50 64 -40') + arrow('M296 190 q-10 -40 -50 -46'),
    ground(232) + _car(110, 196) + brick(280, 214, 2) + brick(318, 214, 1)
    + motion('M60 150 h36', 'M48 170 h44', 'M60 190 h30')
    + arrow('M300 150 q10 30 0 50', dashed=True),
]


# ── Make a treasure chest with a secret inside ───────────────────────────
_cx, _cy, _CW = 116, 230, 8 * U  # front wall: left end, bottom, width
DX, DY = 40, -30


def _box(x, yb):
    yt = yb - 3 * BH
    w = _CW
    front = (brick(x, yt + 2 * BH, 4, studs=False) + brick(x + 4 * U, yt + 2 * BH, 4, studs=False)
             + brick(x, yt + BH, 2, studs=False) + brick(x + 2 * U, yt + BH, 4, studs=False) + brick(x + 6 * U, yt + BH, 2, studs=False)
             + brick(x, yt, 4, studs=False) + brick(x + 4 * U, yt, 4, studs=False))
    side = (f'<path d="M{x + w} {yt} L{x + w + DX} {yt + DY} V{yb + DY} L{x + w} {yb} Z"/>'
            + ''.join(thin(f'M{x + w} {yt + k * BH} L{x + w + DX} {yt + k * BH + DY}') for k in (1, 2)))

    def p(a, k, dy=0):
        return f'{x + a + DX * k} {yt + DY * k + dy}'
    rim = f'<path d="M{p(0, 0)} L{p(w, 0)} L{p(w, 1)} L{p(0, 1)} Z"/>'
    hole = f'<path d="M{p(12, .25)} L{p(w - 12, .25)} L{p(w - 12, .75)} L{p(12, .75)} Z"/>'
    # inside: the back wall's inner face drops a little way into the box
    d = 8
    depth = thin(f'M{p(12, .75)} L{p(12 + d * DX / -DY, .75, d)} H{x + w - 12 + DX * .75 - d * DX / -DY}')
    return front + side + rim + hole + depth


def _lid(x, yb):
    """The lid, bottom edge at yb: a thin slab with studs on top."""
    w, t = _CW, 14
    yt = yb - t
    s = (f'<rect x="{x}" y="{yt}" width="{w}" height="{t}" rx="1.5"/>'
         f'<path d="M{x + w} {yt} L{x + w + DX} {yt + DY} V{yb + DY} L{x + w} {yb} Z"/>'
         f'<path d="M{x} {yt} L{x + w} {yt} L{x + w + DX} {yt + DY} L{x + DX} {yt + DY} Z"/>')
    for k in (.3, .7):
        for i in range(8):
            sx, sy = x + i * U + 4 + DX * k, yt + DY * k
            s += f'<rect x="{sx}" y="{sy - 4}" width="8" height="4" rx="1"/>'
    return s


def _keyhole(x, yb):
    kx, ky = x + _CW / 2, yb - 2 * BH + 6
    return (f'<rect x="{kx - 9}" y="{ky - 8}" width="18" height="20" rx="3"/>'
            f'<circle cx="{kx}" cy="{ky}" r="3" fill="#1d1d1f" stroke="none"/>'
            f'<path d="M{kx - 2} {ky + 1} L{kx - 3} {ky + 8} H{kx + 3} L{kx + 2} {ky + 1}" fill="#1d1d1f" stroke="none"/>')


def _coin(x, y, r=18):
    return (f'<circle cx="{x}" cy="{y}" r="{r}"/><circle cx="{x}" cy="{y}" r="{r - 6}" stroke-width="1.6"/>'
            + thin(f'M{x} {y - 6} l2 4 l4 1 l-3 3 l1 4 l-4 -2 l-4 2 l1 -4 l-3 -3 l4 -1 Z'))


def _chest(x, yb):
    return _box(x, yb) + _lid(x, yb - 3 * BH) + _keyhole(x, yb)


D['make_a_treasure_chest_with_a_secret_inside'] = [
    ground(_cy) + _box(_cx, _cy) + brick(_cx + 2 * U, 60, 4)
    + arrow(f'M{_cx + 6 * U + 12} 70 q40 0 30 50'),
    ground(_cy) + _box(_cx, _cy) + _lid(_cx, _cy - 3 * BH - 64)
    + arrow(f'M{_cx - 20} {_cy - 90} q-10 -30 6 -54'),
    ground(_cy) + _box(_cx, _cy)
    + _coin(_cx + 4 * U + 20, 70)
    + arrow(f'M{_cx + 4 * U + 44} 76 q16 22 -4 50')
    + motion(f'M{_cx + 4 * U - 6} 48 l-8 -8', f'M{_cx + 4 * U + 46} 48 l8 -8', f'M{_cx + 4 * U + 20} 40 v-14'),
    hand(70, 238) + _chest(56, 196) + hand(352, 250, flip=True)
    + arrow('M246 112 q54 -14 76 48')
    + motion('M48 86 l-10 -10', 'M140 58 v-16', 'M236 70 l10 -10'),
]
