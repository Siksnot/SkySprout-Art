"""Diagrams for the first Kitchen challenges (fruit kebab, sandwich, biscuits,
smoothie, a face on a plate, helping make tea, pizza). Worktops and boards are
seen slightly from above; people are the simple round-headed figures from
kind_2. Wherever a knife, heat, the oven or the blender comes in, a grown-up's
bigger hand with a sleeve does it. The orange accent is only for arrows and
dashed motion lines."""
import math
import random
import re

from style import INK, arrow, dot, ghost, ground, motion, thin
from craft_3 import grip, mitt
from kind_2 import arm, hands, limb, person, qmark, bubble
from kind import plate_top, fork
from outdoor_3 import bowl, rot_pt

D = {}


def key(title):
    return re.sub(r'[^a-z0-9]+', '_', title.lower()).strip('_')[:48]


def g(body, x=0, y=0, s=1, rot=0):
    t = f'translate({x} {y})'
    if rot:
        t += f' rotate({rot})'
    if s != 1:
        t += f' scale({s})'
    return f'<g transform="{t}">{body}</g>'


def pt(x, y, a, d):
    r = math.radians(a)
    return x + d * math.cos(r), y + d * math.sin(r)


# ── Tools ────────────────────────────────────────────────────────────────
def knife_sharp():
    """A kitchen knife lying flat, tip at the origin, handle along +x."""
    return ('<path d="M0 0 Q14 -12 68 -12 V7 H8 Q1 6 0 0 Z"/>'
            '<rect x="68" y="-9" width="50" height="17" rx="5"/>'
            + dot(84, -.5, 2.2) + dot(104, -.5, 2.2))


def knife_blunt():
    """A round-ended table knife, tip at the origin, handle along +x."""
    return ('<path d="M64 -6 H8 Q-2 -6 -2 0 Q-2 6 8 6 H64 Z"/>'
            '<rect x="64" y="-7" width="52" height="14" rx="7"/>')


def spoon_tool(L=110):
    """A spoon, the middle of its bowl at the origin, handle along +x."""
    return (f'<path d="M24 -3 L{L} -5 Q{L + 6} 0 {L} 5 L24 3 Z"/>'
            '<ellipse cx="6" cy="0" rx="20" ry="12"/>')


def held(tool, tx, ty, a, at=92, turn=60, flip=False, grown=False, s=1.0):
    """A tool with its tip at (tx, ty) lying along a degrees, gripped at distance `at`."""
    px, py = pt(tx, ty, a, at)
    return g(tool, tx, ty, 1, a) + grip(px, py, a + 180 + (-turn if flip else turn), s, grown=grown, flip=flip)


# ── Food ─────────────────────────────────────────────────────────────────
def grape(x, y, r=9):
    return f'<circle cx="{x}" cy="{y}" r="{r}"/>' + thin(f'M{x - r * .5:.1f} {y - r * .2:.1f} q{r * .1:.1f} {-r * .4:.1f} {r * .45:.1f} {-r * .45:.1f}')


def berry(x, y, s=1.0, rot=0, cut=False):
    """A strawberry (or a half one, cut=True), tip down."""
    b = '<path d="M0 15 C-15 6 -15 -10 0 -10 C15 -10 15 6 0 15 Z"/>'
    if cut:
        b += thin('M0 10 C-8 4 -8 -5 0 -5 C8 -5 8 4 0 10 Z')
    else:
        b += dot(-5, -2, 1.3) + dot(5, -2, 1.3) + dot(0, 4, 1.3) + dot(-3, 9, 1.2) + dot(3, 9, 1.2)
    b += '<path d="M-9 -10 L-5 -16 L-1 -11 L3 -17 L6 -11 L10 -15 L9 -9 Z"/>'
    return g(b, x, y, s, rot)


def nana(x, y, r=9):
    """A round slice of banana."""
    return (f'<circle cx="{x}" cy="{y}" r="{r}"/>'
            + dot(x, y - r * .3, 1.1) + dot(x - r * .28, y + r * .18, 1.1) + dot(x + r * .28, y + r * .18, 1.1))


def banana(x, y, s=1.0, rot=0, peeled=False):
    """A banana lying on its side, middle at (x, y)."""
    b = ('<path d="M-62 -8 Q0 40 60 -14 Q66 -20 62 -24 Q0 16 -56 -18 Q-64 -16 -62 -8 Z"/>'
         + thin('M-50 -10 Q0 22 52 -16'))
    if not peeled:
        b += '<path d="M60 -20 L72 -30 L76 -26 L64 -16" />'
    return g(b, x, y, s, rot)


def cucumber_slice(x, y, r=14):
    seeds = ''.join(dot(x + r * .38 * math.cos(a), y + r * .38 * math.sin(a), 1.2)
                    for a in [i * math.pi / 3 for i in range(6)])
    return (f'<circle cx="{x}" cy="{y}" r="{r}"/>'
            f'<circle cx="{x}" cy="{y}" r="{r * .78:.1f}" fill="none" stroke-width="1.4"/>' + seeds)


def carrot_stick(x, y, a=0, L=46):
    return g(f'<rect x="{-L / 2}" y="-5" width="{L}" height="10" rx="4"/>'
             + thin(f'M{-L * .2:.1f} -5 v4 M{L * .15:.1f} 5 v-4'), x, y, 1, a)


def bread(x, y, s=1.0, rot=0, butter=False):
    """A slice of bread from above, middle at (x, y), about 120 wide."""
    b = ('<path d="M-54 58 V-16 Q-64 -24 -60 -38 Q-54 -56 -28 -54 Q0 -64 28 -54 Q54 -56 60 -38 '
         'Q64 -24 54 -16 V58 Z"/>'
         + thin('M-44 48 V-14 Q-52 -22 -49 -32 Q-44 -46 -24 -44 Q0 -52 24 -44 Q44 -46 49 -32 '
                'Q52 -22 44 -14 V48 Z'))
    if butter:
        b += thin('M-30 -18 q10 -8 20 0 t20 0 t20 0 M-34 8 q10 -8 20 0 t20 0 t20 0 t10 0 M-30 32 q10 -8 20 0 t20 0 t20 0')
    return g(b, x, y, s, rot)


def cheese(x, y, s=1.0, rot=0):
    return g('<rect x="-24" y="-24" width="48" height="48" rx="2"/>'
             '<circle cx="-9" cy="-8" r="5" stroke-width="1.6"/><circle cx="10" cy="4" r="3.5" stroke-width="1.6"/>'
             '<circle cx="-4" cy="13" r="3" stroke-width="1.6"/><circle cx="12" cy="-14" r="2.5" stroke-width="1.6"/>',
             x, y, s, rot)


def board(x, y, w, h):
    """A chopping board from above with a hole to hang it by."""
    return (f'<rect x="{x}" y="{y + 7}" width="{w}" height="{h}" rx="16"/>'
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="16"/>'
            f'<circle cx="{x + w - 22}" cy="{y + h / 2}" r="7"/>')


def biscuit(x, y, r=30, icing=None, deco=''):
    """A round biscuit from above. icing: None, 'half' or 'full'."""
    s = f'<circle cx="{x}" cy="{y}" r="{r}"/>'
    if icing is None:
        s += ''.join(dot(x + r * .5 * math.cos(a), y + r * .5 * math.sin(a), 1.8)
                     for a in [i * math.pi / 3 + .3 for i in range(6)]) + dot(x, y, 1.8)
    else:
        n = 14
        rr = r * .82
        d = ''
        for i in range(n + 1):
            a = i * 2 * math.pi / n
            k = rr * (1 + .06 * math.sin(i * 2.7))
            d += f'{"M" if i == 0 else "L"}{x + k * math.cos(a):.1f} {y + k * math.sin(a):.1f} '
        s += f'<path d="{d}Z" stroke-width="1.8"/>'
    return s + deco


def sprinkles(x, y, r, n, seed=1):
    rnd = random.Random(seed)
    s = ''
    for _ in range(n):
        a = rnd.uniform(0, 2 * math.pi)
        d = r * math.sqrt(rnd.uniform(0, 1))
        px, py = x + d * math.cos(a), y + d * math.sin(a) * .9
        t = rnd.uniform(0, math.pi)
        s += (f'<path d="M{px - 3 * math.cos(t):.1f} {py - 3 * math.sin(t):.1f} '
              f'L{px + 3 * math.cos(t):.1f} {py + 3 * math.sin(t):.1f}" stroke-width="2.6"/>')
    return s


def big_plate(cx, cy, rx, ry):
    return (f'<ellipse cx="{cx}" cy="{cy + 5}" rx="{rx}" ry="{ry}"/>'
            f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}"/>'
            f'<ellipse cx="{cx}" cy="{cy}" rx="{rx * .78:.1f}" ry="{ry * .76:.1f}" fill="none" stroke-width="1.6"/>')


def glass(cx, by, w=50, h=86, level=.75, straw=True, tilt=0):
    """A tall glass of smoothie with a straw, base centre at (cx, by)."""
    t, b = w / 2, w * .4
    s = ''
    if straw:
        s += (f'<path d="M{cx + 4} {by - h * .4} L{cx + 10} {by - h - 18} L{cx + 24} {by - h - 30}" fill="none" '
              f'stroke-width="7"/><path d="M{cx + 4} {by - h * .4} L{cx + 10} {by - h - 18} L{cx + 24} {by - h - 30}" '
              f'fill="none" stroke="#fff" stroke-width="2.4"/>')
    s += (f'<path d="M{cx - t} {by - h} L{cx - b} {by} Q{cx} {by + 5} {cx + b} {by} L{cx + t} {by - h}" fill="#fff"/>'
          f'<ellipse cx="{cx}" cy="{by - h}" rx="{t}" ry="{w * .14:.1f}" fill="none"/>')
    wy = by - h * level
    wt = b + (t - b) * level
    s += f'<path d="M{cx - wt:.1f} {wy:.1f} Q{cx} {wy + 6:.1f} {cx + wt:.1f} {wy:.1f}" fill="none" stroke-width="1.8"/>'
    s += dot(cx - 8, wy + 20, 1.6) + dot(cx + 6, wy + 34, 1.6) + dot(cx - 2, wy + 48, 1.6)
    if tilt:
        return f'<g transform="rotate({tilt} {cx} {by})">{s}</g>'
    return s


def blender(cx, by, lid=True, inside=''):
    """A blender on its base, base bottom centre at (cx, by). Tick marks on the jug, no numbers."""
    s = (f'<path d="M{cx - 44} {by} L{cx - 38} {by - 40} H{cx + 38} L{cx + 44} {by} Z"/>'
         f'<circle cx="{cx}" cy="{by - 20}" r="7"/>'
         # jug handle on the right
         f'<path d="M{cx + 36} {by - 128} H{cx + 58} Q{cx + 66} {by - 128} {cx + 66} {by - 120} V{by - 70} '
         f'Q{cx + 66} {by - 62} {cx + 58} {by - 62} H{cx + 32}" fill="none" stroke-width="9"/>'
         f'<path d="M{cx + 36} {by - 128} H{cx + 58} Q{cx + 66} {by - 128} {cx + 66} {by - 120} V{by - 70} '
         f'Q{cx + 66} {by - 62} {cx + 58} {by - 62} H{cx + 32}" fill="none" stroke="#fff" stroke-width="4"/>'
         f'<path d="M{cx - 30} {by - 40} L{cx - 44} {by - 150} H{cx + 44} L{cx + 30} {by - 40} Z"/>'
         + inside
         + f'<path d="M{cx - 30} {by - 40} L{cx - 44} {by - 150} H{cx + 44} L{cx + 30} {by - 40}" fill="none"/>'
         + thin(f'M{cx - 12} {by - 46} l12 -6 l12 6 M{cx} {by - 52} v-8')
         + ''.join(thin(f'M{cx - 40 + (i * 11 / 8):.1f} {by - 140 + i * 11} h{8 if i % 2 == 0 else 5}')
                   for i in range(0, 8)))
    if lid:
        s += f'<rect x="{cx - 48}" y="{by - 160}" width="96" height="12" rx="4"/><rect x="{cx - 12}" y="{by - 168}" width="24" height="8" rx="3"/>'
    return s


def jug(x, y, rot=0, s=1.0):
    """A little milk jug, base centre at (x, y), spout on the left."""
    b = ('<path d="M14 -40 q18 0 18 14 q0 14 -16 16" fill="none" stroke-width="5"/>'
         '<path d="M14 -40 q18 0 18 14 q0 14 -16 16" fill="none" stroke="#fff" stroke-width="1.2"/>'
         '<path d="M-16 0 L-18 -36 L-28 -46 H18 L16 0 Z"/>'
         '<ellipse cx="0" cy="-44" rx="18" ry="4"/>')
    return g(b, x, y, s, rot)


def pizza_base(cx, cy, rx, ry, sauce=0.0, cheese_=False, tops=False):
    """A pizza base from slightly above. sauce: 0 none, .5 half-spread, 1 all over."""
    s = (f'<ellipse cx="{cx}" cy="{cy + 6}" rx="{rx}" ry="{ry}"/>'
         f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}"/>')
    if sauce:
        n = 22
        k = .8 if sauce >= 1 else .5
        d = ''
        for i in range(n + 1):
            a = i * 2 * math.pi / n
            w = 1 + .05 * math.sin(i * 3.1)
            d += f'{"M" if i == 0 else "L"}{cx + rx * k * w * math.cos(a):.1f} {cy + ry * k * w * math.sin(a):.1f} '
        s += f'<path d="{d}Z" stroke-width="1.8"/>'
        s += thin(f'M{cx - rx * k * .55:.1f} {cy:.1f} q{rx * k * .27:.1f} {-ry * k * .3:.1f} {rx * k * .55:.1f} 0 '
                  f't{rx * k * .55:.1f} 0')
    else:
        s += f'<ellipse cx="{cx}" cy="{cy}" rx="{rx * .84:.1f}" ry="{ry * .82:.1f}" fill="none" stroke-width="1.6"/>'
    if cheese_:
        rnd = random.Random(7)
        for _ in range(46):
            a = rnd.uniform(0, 2 * math.pi)
            d = math.sqrt(rnd.uniform(0, 1)) * .72
            px, py = cx + rx * d * math.cos(a), cy + ry * d * math.sin(a)
            t = rnd.uniform(0, math.pi)
            s += thin(f'M{px - 5 * math.cos(t):.1f} {py - 5 * math.sin(t):.1f} q3 -3 {10 * math.cos(t):.1f} {10 * math.sin(t):.1f}')
    if tops:
        for px, py in tops:
            s += pepperoni(cx + px, cy + py)
    return s


def pepperoni(x, y, r=11):
    return f'<circle cx="{x}" cy="{y}" r="{r}"/>' + dot(x - 3, y - 3, 1.5) + dot(x + 4, y + 1, 1.5) + dot(x - 1, y + 5, 1.5)


def mushroom(x, y, rot=0):
    return g('<path d="M-12 0 Q-12 -14 0 -14 Q12 -14 12 0 H5 V10 H-5 V0 Z"/>', x, y, 1, rot)


# ── Kitchen furniture ───────────────────────────────────────────────────
def counter(x0, x1, front, floor=272, depth=24, doors=2):
    """A kitchen worktop seen slightly from above, with cupboards under it."""
    back = front - depth
    w = x1 - x0 - 16
    s = f'<rect x="{x0 + 8}" y="{front + 10}" width="{w}" height="{floor - front - 10}"/>'
    for i in range(1, doors):
        s += thin(f'M{x0 + 8 + w * i / doors:.1f} {front + 10} V{floor}')
    for i in range(doors):
        kx = x0 + 8 + w * (i + .5) / doors + (12 if i % 2 == 0 else -12)
        s += f'<rect x="{kx - 3:.1f}" y="{front + 24}" width="6" height="16" rx="3"/>'
    s += (f'<path d="M{x0 + 8} {back} H{x1 - 8} L{x1} {front} V{front + 10} H{x0} V{front} Z"/>'
          + thin(f'M{x0} {front} H{x1}'))
    return s


def tap_on(bx, by_, mx, my):
    """A tap standing on the worktop at (bx, by_), its curved spout ending at (mx, my) to its left."""
    top = my - 26
    d = f'M{bx} {by_} V{top + 22} Q{bx} {top} {(bx + mx) / 2:.0f} {top} Q{mx} {top} {mx} {top + 18} V{my}'
    return (f'<ellipse cx="{bx}" cy="{by_}" rx="11" ry="4"/>' + limb(d, 11)
            + f'<rect x="{bx + 4}" y="{by_ - 26}" width="18" height="9" rx="4"/>')


def apron(cx, yt, hip):
    return (f'<path d="M{cx - 13} {yt + 6} H{cx + 13} V{yt + 22} Q{cx + 24} {yt + 26} {cx + 24} {hip + 12} '
            f'H{cx - 24} Q{cx - 24} {yt + 26} {cx - 13} {yt + 22} Z"/>'
            f'<rect x="{cx - 11}" y="{hip - 24}" width="22" height="16" rx="3" fill="none" stroke-width="1.6"/>'
            + thin(f'M{cx - 24} {yt + 30} q-8 4 -6 12 M{cx + 24} {yt + 30} q8 4 6 12'))


# Washing at the sink: the child stands behind the worktop, facing us.
def wash(extra='', with_apron=False):
    cx, by = 180, 240          # child's feet are hidden behind the cupboards
    yt, hip = 128, 190
    s = person(cx, by, 'kid', arms=(), mouth='smile', look=1)
    if with_apron:
        s += apron(cx, yt, hip)
    s += counter(30, 370, 214, 272, depth=30, doors=3) + ground(272, 16, 384)
    s += '<rect x="190" y="188" width="108" height="22" rx="8"/>'
    s += '<rect x="198" y="192" width="92" height="14" rx="5" fill="none" stroke-width="1.6"/>'
    s += tap_on(298, 190, 252, 150) + extra
    s += arm(cx + 20, yt + 11, 240, 150, 260, 184) + arm(cx - 20, yt + 11, 190, 200, 244, 186)
    s += motion('M248 156 V172', 'M256 156 V172')
    s += ('<circle cx="228" cy="172" r="4.5" stroke-width="1.6"/><circle cx="280" cy="172" r="5" stroke-width="1.6"/>'
          '<circle cx="276" cy="158" r="3" stroke-width="1.6"/>')
    return s


def _fruit_bowl():
    return bowl(92, 180, 32, grape(82, 178, 8) + grape(98, 176, 8) + berry(90, 168, .8))


def _loaf():
    return ('<path d="M60 206 V180 Q60 164 76 164 Q88 156 100 164 Q116 164 116 180 V206 Z"/>'
            + thin('M74 170 l8 10 M88 166 l8 10 M102 170 l8 10'))


def _biscuit_stack():
    return ('<ellipse cx="88" cy="204" rx="34" ry="7"/>'
            + ''.join(f'<rect x="66" y="{194 - i * 10}" width="44" height="10" rx="5"/>' for i in range(3)))


def _banana_side():
    return banana(90, 196, .55, -10)


def _base_side():
    return '<ellipse cx="90" cy="204" rx="40" ry="9"/>' + thin('M60 203 q30 6 60 0')


# ── Make a fruit kebab with a grown-up ───────────────────────────────────
GS = .8  # grip() makes a grown-up's hand 1.3 times bigger; this keeps it in scale


def _kebab(x0, y0, a, n=6, gap=26, start=70, r=11):
    """Fruit threaded on a stick from (x0, y0) along a degrees: grape, strawberry, banana."""
    s = ''
    for i in range(n):
        px, py = (round(v, 1) for v in pt(x0, y0, a, start + i * gap))
        k = i % 3
        if k == 0:
            s += grape(px, py, r)
        elif k == 1:
            s += berry(px, py, r / 11, a + 90, cut=True)
        else:
            s += nana(px, py, r)
    return s


def _stick(x0, y0, a, L):
    x1, y1 = pt(x0, y0, a, L)
    xb, yb = pt(x0, y0, a, L - 12)
    return (f'<path d="M{x0} {y0} L{xb:.1f} {yb:.1f}" fill="none" stroke-width="6"/>'
            f'<path d="M{x0} {y0} L{xb:.1f} {yb:.1f}" fill="none" stroke="#fff" stroke-width="1.6"/>'
            f'<path d="M{xb:.1f} {yb:.1f} L{x1:.1f} {y1:.1f}" stroke-width="2"/>')


KA = -44
_kx, _ky = pt(80, 262, KA, 30)
D[key('Make a fruit kebab with a grown-up')] = [
    wash(_fruit_bowl()),

    board(46, 84, 300, 150)
    + banana(124, 160, 1.0, 0, peeled=True)
    + nana(232, 118, 12) + nana(258, 132, 12) + nana(234, 148, 12)
    + berry(292, 196, 1.1, 0, cut=True) + berry(256, 202, 1.1, 20, cut=True) + berry(296, 118, 1.0, -20)
    + mitt(70, 158, GS, 50, grown=True)
    + held(knife_sharp(), 172, 106, 84, at=96, turn=60, grown=True, s=GS)
    + motion('M154 116 v-16', 'M198 116 v-16'),

    _stick(80, 262, KA, 260) + _kebab(80, 262, KA)
    + grip(_kx, _ky, 40)
    + grip(326, 60, -110, flip=True) + grape(318, 66, 12)
    + arrow('M300 82 Q286 102 268 100')
    + board(270, 200, 110, 70) + nana(300, 224, 9) + grape(326, 232, 8) + berry(350, 226, .8, 0, cut=True),

    ground(272)
    + _stick(258, 152, -90, 132) + _kebab(258, 152, -90, n=5, gap=20, start=36)
    + person(170, 272, 'kid', arms=((-1, None), (1, (258, 142, 250, 190))), mouth='grin', look=1)
    + motion('M298 48 l14 -10', 'M302 80 h18', 'M298 112 l14 10', 'M218 48 l-14 -10', 'M214 80 h-18'),
]


# ── Make your own sandwich ───────────────────────────────────────────────
def _butter_dish(x, y):
    return (f'<ellipse cx="{x}" cy="{y}" rx="34" ry="12"/>'
            f'<path d="M{x - 20} {y - 4} V{y - 20} L{x - 12} {y - 26} H{x + 20} V{y - 10} L{x + 12} {y - 4} Z"/>'
            + thin(f'M{x - 20} {y - 20} H{x + 12} L{x + 20} {y - 26} M{x + 12} {y - 20} V{y - 4}'))


D[key('Make your own sandwich')] = [
    wash(_loaf()),

    bread(126, 168) + bread(276, 168, butter=True)
    + thin('M86 172 q10 -8 20 0 t20 0 t20 0')
    + _butter_dish(346, 70)
    + held(knife_blunt(), 108, 150, -32, at=92, turn=60)
    + arrow('M86 208 Q126 224 166 208'),

    bread(126, 168, butter=True) + bread(276, 168, butter=True)
    + cheese(252, 142, 1, -4) + cheese(254, 194, 1, 5)
    + ghost('M278 120 h48 v48 h-48 Z')
    + grip(330, 46, -130, flip=True) + cheese(310, 62, 1, -8)
    + arrow('M286 96 Q278 110 290 124'),

    big_plate(200, 172, 150, 98)
    + '<path d="M128 108 H262 L128 242 Z" transform="translate(0 6)"/>'
    + '<path d="M128 108 H262 L128 242 Z"/>' + thin('M140 120 H236 L140 216 Z')
    + '<path d="M144 252 L278 118 V252 Z" transform="translate(0 6)"/>'
    + '<path d="M144 252 L278 118 V252 Z"/>' + thin('M168 240 L266 142 V240 Z')
    + thin('M134 236 q8 -4 6 -12 q8 -2 8 -10 q8 -2 8 -10 q8 -2 8 -10 q8 -2 8 -10 q8 -2 8 -10 q8 -2 8 -10')
    + held(knife_sharp(), 196, 186, -45, at=94, turn=60, grown=True, s=GS)
    + arrow('M110 150 Q94 120 108 96') + arrow('M296 200 Q312 232 294 254'),
]


# ── Decorate biscuits with a grown-up ────────────────────────────────────
_JX, _JY, _JR = 300, 112, -40
_jh = rot_pt(_JX, _JY, 30, -26, 1, _JR)
_js = rot_pt(_JX, _JY, -28, -46, 1, _JR)

D[key('Decorate biscuits with a grown-up')] = [
    wash(_biscuit_stack()),

    bowl(176, 168, 92, '<ellipse cx="176" cy="176" rx="74" ry="13" stroke-width="1.8"/>')
    + held(spoon_tool(120), 186, 176, -128, at=100, turn=60)
    + jug(_JX, _JY, _JR) + grip(_jh[0] + 4, _jh[1], 200, GS, grown=True, flip=True)
    + motion(f'M{_js[0] - 2:.0f} {_js[1] + 6:.0f} q-4 20 -6 40', f'M{_js[0] + 8:.0f} {_js[1] + 12:.0f} q-2 16 -4 32')
    + arrow('M120 196 Q176 222 232 196'),

    biscuit(186, 162, 92) + '<path d="M120 150 Q118 104 170 102 Q216 98 232 122 Q252 150 236 184 Q214 212 170 210 Q126 206 120 150 Z" stroke-width="1.8"/>'
    + held(knife_blunt(), 196, 150, -34, at=92, turn=60)
    + biscuit(344, 236, 30) + biscuit(56, 70, 30)
    + arrow('M110 230 Q182 272 254 236'),

    big_plate(200, 178, 170, 92)
    + biscuit(124, 152, 40, 'full', sprinkles(124, 152, 26, 12, 1))
    + biscuit(232, 140, 40, 'full', dot(220, 134, 2.6) + dot(244, 134, 2.6) + thin('M218 148 q14 12 28 0'))
    + biscuit(176, 220, 40, 'full', sprinkles(176, 220, 26, 12, 3))
    + biscuit(284, 210, 40, 'full', '<path d="M284 222 C266 210 272 194 284 202 C296 194 302 210 284 222 Z" stroke-width="1.8"/>')
    + grip(172, 70, 100)
    + motion('M172 86 l-4 18', 'M184 88 l2 18', 'M162 92 l-6 14', 'M176 110 l-2 10'),
]


# ── Make a smoothie with a grown-up ──────────────────────────────────────
def _peel(x, y):
    """A banana skin lying flat, three floppy strips."""
    return (f'<path d="M{x - 4} {y - 14} Q{x - 26} {y - 12} {x - 40} {y + 4} Q{x - 20} {y} {x - 2} {y - 6} Z"/>'
            f'<path d="M{x + 4} {y - 14} Q{x + 26} {y - 12} {x + 40} {y + 4} Q{x + 20} {y} {x + 2} {y - 6} Z"/>'
            f'<path d="M{x - 6} {y - 10} Q{x - 6} {y + 2} {x} {y + 6} Q{x + 6} {y + 2} {x + 6} {y - 10} Z"/>'
            f'<path d="M{x - 8} {y - 12} Q{x} {y - 22} {x + 8} {y - 12} Q{x} {y - 6} {x - 8} {y - 12} Z"/>'
            f'<rect x="{x - 2}" y="{y - 26}" width="5" height="9" rx="1"/>')


def _chunk(x, y):
    """A short piece of peeled banana, standing up."""
    return (f'<rect x="{x - 10}" y="{y - 22}" width="20" height="44" rx="9"/>'
            + thin(f'M{x - 4} {y - 14} q-2 14 0 28'))


AX, ABY, AYT, AHIP = 330, 264, 94, 184   # the grown-up behind the worktop

D[key('Make a smoothie with a grown-up')] = [
    wash(_banana_side()),

    ground(262)
    + blender(200, 262, lid=False, inside=grape(186, 206, 10) + grape(206, 210, 10) + berry(192, 186, 1, 10)
              + nana(216, 186, 11) + berry(184, 170, 1, -14))
    + '<rect x="290" y="250" width="70" height="12" rx="4"/><rect x="314" y="242" width="22" height="8" rx="3"/>'
    + _peel(86, 256)
    + grip(200, 62, 60) + _chunk(196, 76)
    + arrow('M222 84 Q236 100 220 116'),

    ground(272)
    + person(AX, ABY, 'adult', arms=(), look=-1)
    + arm(AX + 26, AYT + 11, AX + 44, AYT + 50, AX + 40, AHIP - 4, 'adult')
    + counter(150, 392, 200, 272, doors=2)
    + g(blender(0, 0, inside=motion('M-24 -116 q24 -16 48 0 q-24 18 -48 4', 'M-16 -80 q16 -10 32 0')), 236, 188, .72)
    + arm(AX - 26, AYT + 11, 280, 80, 244, 72, 'adult')
    + person(84, 272, 'kid', arms=((-1, None), (1, None)), mouth='open', look=1)
    + motion('M190 92 v22', 'M182 100 v14', 'M282 92 v22'),

    ground(250)
    + glass(176, 214, tilt=-10) + glass(232, 214, tilt=10)
    + grip(146, 160, 0) + grip(262, 160, 180, GS, grown=True, flip=True)
    + motion('M194 96 l-6 -12', 'M204 92 v-14', 'M214 96 l6 -12'),
]


# ── Make a face on a plate with fruit and veg ────────────────────────────
HAIR = [-150, -120, -90, -60, -30]


def _face(nose=True, smile=True, hair=True, missing=None):
    s = cucumber_slice(160, 138, 22) + cucumber_slice(240, 138, 22)
    s += grape(160, 138, 7) + grape(240, 138, 7)
    if nose:
        s += berry(200, 176, 1.1)
    if smile:
        for i in range(5):
            a = math.radians(30 + i * 30)
            s += nana(round(200 - 52 * math.cos(a), 1), round(200 + 26 * math.sin(a), 1), 10)
    if hair:
        for i, a in enumerate(HAIR):
            if i == missing:
                continue
            x, y = pt(200, 150, a, 0)
            x, y = 200 + 104 * math.cos(math.radians(a)), 150 + 78 * math.sin(math.radians(a))
            s += carrot_stick(round(x, 1), round(y, 1), a, 36)
    return s


def _hair_spot(i):
    a = HAIR[i]
    return 200 + 104 * math.cos(math.radians(a)), 150 + 78 * math.sin(math.radians(a))


_h4 = _hair_spot(4)

D[key('Make a face on a plate with fruit and veg')] = [
    board(36, 88, 296, 154)
    + '<rect x="60" y="108" width="104" height="34" rx="16"/>' + thin('M150 110 v30')
    + cucumber_slice(200, 124, 15) + cucumber_slice(224, 130, 15) + cucumber_slice(248, 124, 15)
    + carrot_stick(96, 182, -4) + carrot_stick(108, 198, 2) + carrot_stick(118, 212, -2)
    + grape(250, 192, 10) + grape(270, 196, 10) + grape(260, 214, 10) + grape(282, 216, 10)
    + held(knife_sharp(), 174, 100, 84, at=98, turn=60, grown=True, s=GS)
    + motion('M158 108 v-16', 'M192 96 v-16'),

    big_plate(200, 160, 150, 118)
    + cucumber_slice(160, 138, 22)
    + ghost('M218 138 a22 22 0 1 0 44 0 a22 22 0 1 0 -44 0')
    + grip(326, 46, -150, flip=True) + cucumber_slice(306, 56, 22)
    + arrow('M284 70 Q262 84 256 108'),

    big_plate(200, 160, 150, 118) + _face(missing=4)
    + grip(352, 46, -150, flip=True) + carrot_stick(334, 54, -30, 36)
    + arrow(f'M318 72 Q{_h4[0] + 20:.0f} {_h4[1] - 4:.0f} {_h4[0] + 6:.0f} {_h4[1] + 6:.0f}'),

    # close up: the child behind the table, the plate in front, a carrot stick at the mouth
    '<style>.ns *{vector-effect:non-scaling-stroke}</style>'
    + person(200, 240, 'kid', arms=(), mouth='big', look=0)
    + '<path d="M40 184 H360 L392 290 H8 Z"/>'
    + '<ellipse cx="200" cy="242" rx="132" ry="44"/><ellipse cx="200" cy="240" rx="104" ry="32" fill="none" stroke-width="1.6"/>'
    + '<g transform="translate(200 240) scale(.78 .34) translate(-200 -160)" class="ns">' + _face(missing=2) + '</g>'
    + arm(220, 139, 262, 170, 238, 128) + carrot_stick(222, 120, -24, 34) + hands((238, 128))
    + arm(180, 139, 150, 170, 150, 192)
    + motion('M166 104 l-14 -6', 'M164 118 h-16', 'M252 92 l12 -8'),
]


# ── Help a grown-up make tea tonight ─────────────────────────────────────
def _pan(x, y):
    """A saucepan, base middle at (x, y), handle out to the right."""
    return (f'<rect x="{x + 34}" y="{y - 30}" width="52" height="10" rx="5"/>'
            f'<path d="M{x - 34} {y - 36} V{y - 4} Q{x - 34} {y} {x - 30} {y} H{x + 30} Q{x + 34} {y} {x + 34} {y - 4} V{y - 36} Z"/>'
            f'<ellipse cx="{x}" cy="{y - 36}" rx="34" ry="6"/>')


def _hob(x, y):
    return f'<ellipse cx="{x}" cy="{y}" rx="46" ry="8"/><ellipse cx="{x}" cy="{y}" rx="34" ry="5" fill="none" stroke-width="1.6"/>'


def _wooden_spoon(x0, y0, x1, y1):
    return (limb(f'M{x0} {y0} L{x1} {y1}', 8)
            + f'<ellipse cx="{x0}" cy="{y0}" rx="7" ry="10" transform="rotate({math.degrees(math.atan2(y1 - y0, x1 - x0)) + 90:.0f} {x0} {y0})"/>')


D[key('Help a grown-up make tea tonight')] = [
    wash(with_apron=True),

    ground(272)
    + person(196, 272, 'adult', look=-1)
    + counter(234, 392, 196, 272, doors=2) + _hob(298, 182) + _pan(298, 180)
    + person(84, 272, 'kid', arms=((-1, None), (1, (128, 150))), mouth='open', look=1)
    + apron(84, 160, 222)
    + bubble(28, 20, 132, 62, 92, 98, qmark(56, 50, 1.1) + g(spoon_tool(40), 84, 64, .8, -60)
             + '<ellipse cx="128" cy="44" rx="16" ry="5"/><path d="M112 44 Q114 64 128 64 Q142 64 144 44"/>')
    + motion('M126 122 l12 -6', 'M128 134 h14'),

    ground(272)
    + person(96, 240, 'kid', arms=(), look=1) + apron(96, 128, 190)
    + person(AX, ABY, 'adult', arms=(), look=-1)
    + counter(16, 392, 214, 272, depth=30, doors=4)
    + bowl(96, 170, 40, '<ellipse cx="96" cy="174" rx="30" ry="6" stroke-width="1.6"/>')
    + _wooden_spoon(104, 172, 132, 128)
    + arm(76, 139, 56, 160, 60, 172) + arm(116, 139, 136, 150, 130, 138)
    + _hob(262, 200) + _pan(262, 198) + _wooden_spoon(254, 176, 276, 132)
    + arm(AX - 26, AYT + 11, 290, 150, 278, 136, 'adult') + arm(AX + 26, AYT + 11, 368, 150, 340, 172, 'adult')
    + arrow('M70 150 Q96 136 124 148')
    + motion('M232 152 q-8 -12 0 -24 q8 -12 0 -24', 'M296 152 q-8 -12 0 -24 q8 -12 0 -24'),

    ground(272)
    + person(100, 272, 'kid', arms=((-1, (68, 190)), (1, (132, 190))), legs='walk', look=1)
    + apron(100, 160, 222)
    + '<ellipse cx="100" cy="196" rx="40" ry="8"/><ellipse cx="100" cy="188" rx="40" ry="8"/><ellipse cx="100" cy="180" rx="40" ry="8"/>'
    + hands((64, 188), (136, 188))
    + '<path d="M240 214 V268 M354 214 V268" fill="none" stroke-width="6"/>'
    + '<path d="M210 194 H384 L392 206 V214 H202 V206 Z"/>' + thin('M202 206 H392')
    + plate_top(250, 200, 22, 6) + plate_top(346, 200, 22, 6)
    + ghost('M276 200 a22 6 0 1 0 44 0 a22 6 0 1 0 -44 0')
    + arrow('M150 160 Q200 122 290 186', dashed=True),
]


# ── Make a pizza with a grown-up, with your own toppings ─────────────────
def _cooker(x0=150, x1=280, top=110, floor=272):
    ox0, ox1, oy0, oy1 = x0 + 14, x1 - 14, top + 36, top + 114
    s = (f'<rect x="{x0}" y="{top}" width="{x1 - x0}" height="{floor - top}" rx="4"/>'
         f'<path d="M{x0} {top + 26} H{x1}" fill="none"/>'
         + ''.join(f'<circle cx="{x0 + 28 + i * 37}" cy="{top + 13}" r="7"/>'
                   + thin(f'M{x0 + 28 + i * 37} {top + 13} v-6') for i in range(3))
         + f'<rect x="{ox0}" y="{oy0}" width="{ox1 - ox0}" height="{oy1 - oy0}" rx="3"/>'
         + f'<rect x="{ox0 + 14}" y="{oy0 + 10}" width="{ox1 - ox0 - 28}" height="{oy1 - oy0 - 24}" fill="none" stroke-width="1.6"/>'
         + thin(f'M{ox0} {oy0} l14 10 M{ox1} {oy0} l-14 10 M{ox0} {oy1} l14 -14 M{ox1} {oy1} l-14 -14')
         + thin(f'M{ox0 + 20} {oy0 + 18} l8 6 l8 -6 l8 6 l8 -6 l8 6 l8 -6 l8 6 l8 -6 l8 6')
         + thin(f'M{ox0 + 6} {oy1 - 26} H{ox1 - 6}')
         # the open door, folded down toward us
         + f'<path d="M{ox0} {oy1} H{ox1} L{x1 + 4} {oy1 + 22} H{x0 - 4} Z"/>'
         + thin(f'M{ox0 + 10} {oy1 + 12} H{ox1 - 10}')
         + thin(f'M{x0 + 10} {floor - 16} H{x1 - 10}'))
    return s


def oven_glove(x, y, rot=0, s=1.0):
    """A padded oven glove, cuff at the bottom, fingers up; turned by rot."""
    return g('<path d="M-14 20 V-6 Q-14 -24 2 -24 Q18 -24 18 -6 V20 Z"/>'
             '<path d="M-14 4 Q-28 0 -26 -12 Q-22 -20 -14 -12"/>'
             '<rect x="-17" y="18" width="38" height="12" rx="3"/>'
             + thin('M-6 -16 V14 M4 -20 V14 M12 -14 V14'), x, y, s, rot)


D[key('Make a pizza with a grown-up, with your own toppings')] = [
    wash(_base_side()),

    pizza_base(186, 170, 140, 98, sauce=.5)
    + thin('M150 150 q10 -8 20 0 M196 188 q10 -8 20 0 M160 196 q8 -6 16 0 M214 140 q8 -6 16 0')
    + bowl(352, 56, 28, '<ellipse cx="352" cy="58" rx="20" ry="4" stroke-width="1.6"/>')
    + held(spoon_tool(110), 214, 172, -40, at=96, turn=60)
    + arrow('M96 220 Q140 270 240 262'),

    pizza_base(166, 190, 126, 86, sauce=1, cheese_=True, tops=[(-50, -20), (30, -36), (-10, 30)])
    + mushroom(90, 206, -20) + mushroom(226, 196, 10)
    + bowl(352, 214, 30, pepperoni(346, 214, 8) + pepperoni(360, 212, 8))
    + grip(196, 78, 100)
    + motion('M194 96 l-4 20', 'M206 98 l2 20', 'M184 102 l-6 16', 'M200 124 l-1 12'),

    ground(272) + _cooker()
    + '<rect x="196" y="200" width="112" height="7" rx="2"/><ellipse cx="248" cy="194" rx="46" ry="8"/>'
    + '<ellipse cx="232" cy="193" rx="6" ry="3" fill="none" stroke-width="1.6"/><ellipse cx="258" cy="195" rx="6" ry="3" fill="none" stroke-width="1.6"/>'
    + person(350, 272, 'adult', arms=((-1, (310, 204, 300, 150)), (1, None)), look=-1)
    + oven_glove(306, 204, -100, .9)
    + person(62, 272, 'kid', look=1)
    + arrow('M296 170 Q262 160 226 170')
    + motion('M190 182 q-6 -9 0 -18 q6 -9 0 -18', 'M214 182 q-6 -9 0 -18 q6 -9 0 -18'),
]
