"""Diagrams for the Bricks challenges. Bricks must overlap by at least one
stud wherever they connect, or the build wouldn't hold together."""
from style import BH, U, arrow, brick, dot, ghost, ground, motion, slope

D = {}


# ── Build a dinosaur ─────────────────────────────────────────────────────
def _dino_body(x, y):
    # The top layer sticks out 2 studs on the left to start the tail.
    return (brick(x, y, 4) + brick(x + 4 * U, y, 4)
            + brick(x - 2 * U, y - BH, 4) + brick(x + 2 * U, y - BH, 4) + brick(x + 6 * U, y - BH, 2))


def _dino_legs(x, y, missing=None):
    s = ''
    for i, lx in enumerate((0, 2 * U, 5 * U, 7 * U)):
        if i == missing:
            s += f'<rect x="{x + lx}" y="{y + BH}" width="{U}" height="{2 * BH}" fill="none" stroke-dasharray="4 5" stroke-width="1.6"/>'
        else:
            s += brick(x + lx, y + BH, 1, studs=False) + brick(x + lx, y + 2 * BH, 1, studs=False)
    return s


def _dino_neck(x, y):
    # Each neck brick sits one stud over the one below.
    s = ''.join(brick(x + i * U, y - (i + 2) * BH, 2) for i in range(4))
    hx, hy = x + 4 * U, y - 6 * BH
    return s + brick(hx, hy, 3) + dot(hx + 34, hy + 8)


def _dino_tail(x, y):
    # Each tail brick clips under the last stud of the one above.
    return brick(x - 5 * U, y, 4, studs=False) + brick(x - 7 * U, y + BH, 3, studs=False)


def _thought(x, y):
    head = (f'<circle cx="{x}" cy="{y}" r="34"/>'
            f'<path d="M{x-18} {y-6} q4 -5 8 0 M{x+10} {y-6} q4 -5 8 0" fill="none"/>'
            f'<path d="M{x-10} {y+14} q10 8 20 0" fill="none"/>'
            f'<path d="M{x-30} {y-18} q10 -26 34 -16 q20 -14 30 8" fill="none"/>')
    bubble = ('<circle cx="112" cy="190" r="5"/><circle cx="128" cy="172" r="8"/>'
              '<path d="M120 150 C90 140 96 92 132 90 C140 54 200 50 216 76 C240 46 300 54 304 86 '
              'C350 84 362 136 330 150 C340 182 290 196 270 176 C250 200 196 198 186 176 C150 192 112 176 120 150 Z"/>')
    return head + bubble


def _sauropod(x, y):
    return (f'<path d="M{x} {y} q20 -24 44 -6 q10 -30 14 -46 q2 -6 9 -4 q6 2 2 8 q-6 14 -10 46 q8 10 2 24 '
            f'M{x+8} {y} v12 M{x+20} {y+2} v12 M{x+34} {y+2} v12 M{x+48} {y} v12 M{x} {y} q-14 6 -22 2" fill="none"/>')


def _trex(x, y):
    return (f'<path d="M{x} {y+20} q16 -10 26 -28 q4 -10 16 -10 h12 q4 6 -4 9 h-10 q4 4 8 4 q0 6 -12 4 '
            f'q-6 10 -8 22 M{x+14} {y+16} v16 h6 M{x+30} {y+12} v20 h6 M{x+34} {y-4} l6 6" fill="none"/>'
            f'<path d="M{x+44} {y-25} l2 4 l2 -4 l2 4" fill="none" stroke-width="1.6"/>')


def _stego(x, y):
    return (f'<path d="M{x} {y} q28 -30 60 0 q-6 4 -14 2 M{x} {y} q-10 4 -18 -4 M{x+10} {y-2} v12 M{x+46} {y-2} v12" fill="none"/>'
            f'<path d="M{x+8} {y-14} l4 -10 l6 8 l4 -12 l7 10 l5 -12 l6 10 l5 -8 l4 8" fill="none"/>')


_bx, _by = 130, 180
D['build_a_dinosaur'] = [
    _thought(70, 232) + _sauropod(132, 150) + _trex(204, 140) + _stego(284, 136) + arrow('M60 196 q-8 -30 10 -46', dashed=True),
    ground() + _dino_body(_bx, _by) + _dino_legs(_bx, _by, missing=3)
    + brick(_bx + 7 * U, 60, 1, studs=False) + brick(_bx + 7 * U, 60 + BH, 1, studs=False)
    + arrow(f'M{_bx + 7 * U + 30} 80 q22 50 0 112', dashed=True),
    ground() + _dino_body(_bx, _by) + _dino_legs(_bx, _by) + _dino_neck(_bx + 7 * U, _by) + _dino_tail(_bx, _by)
    + arrow('M372 30 q16 22 -10 42') + arrow('M40 150 q-6 30 16 44'),
    ground() + _dino_body(_bx, _by) + _dino_legs(_bx, _by) + ''.join(slope(_bx + 8 + i * 22, _by - 2 * BH - 4) for i in range(4))
    + _dino_neck(_bx + 7 * U, _by) + _dino_tail(_bx, _by)
    + motion('M362 76 q10 10 0 22', 'M372 66 q18 21 0 42', 'M382 56 q26 31 0 62'),
]
