"""More diagrams for the Bricks challenges. Bricks overlap by at least one
stud wherever they connect, so every build pictured would hold together."""
import re

from style import BH, U, arrow, brick, dot, ghost, ground, hand, motion, slope, thin

D = {}


def key(title):
    return re.sub(r'[^a-z0-9]+', '_', title.lower()).strip('_')[:48].strip('_')


def row(x, y, sizes, studs=True):
    """Bricks side by side in one layer, sizes in studs."""
    s = ''
    for n in sizes:
        s += brick(x, y, n, studs)
        x += n * U
    return s


def plate(x, y, n, studs=True):
    """A flat plate: a third of a brick tall."""
    s = f'<rect x="{x}" y="{y}" width="{n * U}" height="9" rx="1.5"/>'
    if studs:
        s += ''.join(f'<rect x="{x + i * U + 4}" y="{y - 4}" width="8" height="4" rx="1"/>' for i in range(n))
    return s


def g(inner, t):
    return f'<g transform="{t}">{inner}</g>'


# ── Build a bridge that can hold a toy car ───────────────────────────────
def _books(x, n, y=238):
    widths = (96, 88, 94, 84, 92)
    s = ''
    for i in range(n):
        w = widths[i % 5]
        bx = x + (96 - w) / 2 + (3 if i % 2 else -2)
        by = y - (i + 1) * 14
        s += f'<rect x="{bx}" y="{by}" width="{w}" height="14" rx="2"/>' + thin(f'M{bx + 8} {by + 3} V{by + 11}')
    return s


def _piles():
    return _books(64, 5) + _books(240, 5)


def _car(x, y):
    """Toy car, front wheel bottom at y, facing right."""
    return (f'<path d="M{x + 14} {y - 24} L{x + 24} {y - 38} H{x + 48} L{x + 58} {y - 24}"/>'
            f'<rect x="{x}" y="{y - 26}" width="72" height="18" rx="6"/>'
            + thin(f'M{x + 36} {y - 37} V{y - 26}')
            + f'<circle cx="{x + 16}" cy="{y - 8}" r="8"/><circle cx="{x + 56}" cy="{y - 8}" r="8"/>'
            + dot(x + 16, y - 8, 2) + dot(x + 56, y - 8, 2))


_sx = 104  # the strip is 12 studs: 104 .. 296


def _strip(y, last=True):
    """Two thin layers of plates, the joins staggered so the strip holds together."""
    top = [2, 4, 4, 2] if last else [2, 4, 4]
    return row_p(_sx, y + 9, [4, 4, 4]) + row_p(_sx, y, top)


def row_p(x, y, sizes):
    s = ''
    for n in sizes:
        s += plate(x, y, n)
        x += n * U
    return s


def _strip2(y):
    # A layer of bricks on top, joins at 4 and 8 studs, away from the plate joins at 2, 6 and 10.
    return _strip(y) + row(_sx, y - BH, [4, 4, 4])


_k = key('Build a bridge that can hold a toy car')
D[_k] = [
    ground() + _piles() + hand(170, 211, 1.5)
    + motion('M40 160 H360'),
    ground() + _strip(220, last=False) + plate(_sx + 10 * U, 120, 2) + ghost(f'M{_sx + 160} 211 h32 v9 h-32 z')
    + arrow(f'M{_sx + 210} 116 q24 40 -6 84'),
    ground() + _strip(220) + row(_sx, 202, [4, 4]) + brick(_sx + 8 * U, 96, 4)
    + ghost(f'M{_sx + 128} 202 h64 v18 h-64 z')
    + arrow(f'M{_sx + 204} 92 q30 50 -2 102'),
    ground() + _piles() + _strip2(150) + _car(150, 128)
    + arrow('M128 92 q70 -40 150 0', dashed=True)
    + motion('M136 104 h-22', 'M136 116 h-30'),
]


# ── Build a house for your favourite toy ─────────────────────────────────
_hx, _hy = 96, 226  # wall's left edge; top of the base plate


def _teddy(x, y):
    """Teddy standing with feet at (x, y)."""
    return (f'<circle cx="{x - 12}" cy="{y - 66}" r="6"/><circle cx="{x + 12}" cy="{y - 66}" r="6"/>'
            f'<ellipse cx="{x - 20}" cy="{y - 28}" rx="6" ry="10"/><ellipse cx="{x + 20}" cy="{y - 28}" rx="6" ry="10"/>'
            f'<ellipse cx="{x - 9}" cy="{y - 5}" rx="9" ry="6"/><ellipse cx="{x + 9}" cy="{y - 5}" rx="9" ry="6"/>'
            f'<ellipse cx="{x}" cy="{y - 24}" rx="17" ry="20"/>'
            f'<circle cx="{x}" cy="{y - 54}" r="16"/><ellipse cx="{x}" cy="{y - 48}" rx="7" ry="5"/>'
            + dot(x - 6, y - 58) + dot(x + 6, y - 58) + dot(x, y - 50, 2))


def _base():
    return (f'<rect x="56" y="{_hy}" width="288" height="10" rx="1.5"/>'
            + ''.join(f'<rect x="{60 + i * U}" y="{_hy - 4}" width="8" height="4" rx="1"/>' for i in range(18)))


def _hrow(r, pieces):
    """One layer of the house; pieces are (first stud, studs) along a 13-stud wall."""
    y = _hy - (r + 1) * BH
    return ''.join(brick(_hx + a * U, y, n) for a, n in pieces)


# Door gap is studs 5..8 (rows 0-4); windows are studs 1..3 and 10..12 (rows 3-4).
_walls_low = (_hrow(0, [(0, 3), (3, 2), (8, 2), (10, 3)])
              + _hrow(1, [(0, 2), (2, 3), (8, 3), (11, 2)])
              + _hrow(2, [(0, 3), (3, 2), (8, 2), (10, 3)]))
_walls_win = (_hrow(3, [(0, 1), (3, 2), (8, 2), (12, 1)])
              + _hrow(4, [(0, 1), (3, 2), (8, 2), (12, 1)])
              + _hrow(5, [(0, 4), (4, 5), (9, 4)]))


def _roof():
    s = _hrow(6, [(0, 6), (6, 7)])
    s += _hrow(7, [(1, 4), (5, 7)])
    s += _hrow(8, [(2, 6), (8, 3)])
    s += _hrow(9, [(3, 7)])
    return s


_tx = _hx + int(6.5 * U)
_k = key('Build a house for your favourite toy')
D[_k] = [
    ground() + _base() + _teddy(_tx, _hy)
    + ghost(f'M{_hx} {_hy} V{_hy - 6 * BH} H{_hx + 13 * U} V{_hy}')
    + arrow(f'M{_tx + 60} 70 q30 30 -30 70', dashed=True),
    ground() + _base() + _teddy(_tx, _hy) + _walls_low.replace(brick(_hx + 10 * U, _hy - 3 * BH, 3), '')
    + brick(_hx + 10 * U, 70, 3) + ghost(f'M{_hx + 10 * U} {_hy - 3 * BH} h48 v18 h-48 z')
    + arrow(f'M{_hx + 13 * U + 12} 80 q24 40 -6 66'),
    ground() + _base() + _teddy(_tx, _hy) + _walls_low + _walls_win
    + arrow(f'M{_hx + 2 * U - 30} 60 q10 30 26 50'),
    ground() + _base() + _teddy(_tx, _hy) + _walls_low + _walls_win + _roof()
    + motion('M134 34 l-12 -10', 'M118 54 h-18', 'M266 34 l12 -10', 'M282 54 h18'),
]


# ── Make a rocket using only one colour ──────────────────────────────────
def mono(x, y, n, studs=True):
    """A brick in the chosen colour: marked with stripes."""
    return brick(x, y, n, studs) + ''.join(thin(f'M{x + i * U + 4} {y + BH - 4} L{x + i * U + 12} {y + 4}') for i in range(n))


def spotty(x, y, n):
    return brick(x, y, n) + ''.join(dot(x + i * U + 8, y + 9, 2.2) for i in range(n))


def _rocket(x, y):
    """Rocket body 2 studs wide at x; y is the top of its bottom fin brick's feet."""
    s = mono(x - 2 * U, y, 1, studs=False) + mono(x + 3 * U, y, 1, studs=False)
    s += mono(x - 2 * U, y - BH, 6)
    s += (f'<polygon points="{x - 2 * U},{y - BH} {x},{y - BH} {x},{y - 3 * BH}"/>'
          f'<polygon points="{x + 4 * U},{y - BH} {x + 2 * U},{y - BH} {x + 2 * U},{y - 3 * BH}"/>')
    s += _tube(x, y - 2 * BH)
    top = y - 7 * BH - 4
    s += f'<path d="M{x - 1} {top + 1} Q{x + 2} {top - 34} {x + U} {top - 46} Q{x + 2 * U - 2} {top - 34} {x + 2 * U + 1} {top + 1} Z"/>'
    s += dot(x + U, top - 18, 4)
    return s


def _tube(x, y, n=6):
    return ''.join(mono(x, y - i * BH, 2) for i in range(n))


_rx = 184
_k = key('Make a rocket using only one colour')
D[_k] = [
    ground()
    # the mixed-up pile
    + brick(40, 220, 2) + spotty(72, 220, 3) + mono(120, 220, 2) + brick(152, 220, 1)
    + g(mono(60, 196, 3), 'rotate(-8 84 205)') + g(spotty(110, 198, 2), 'rotate(10 126 207)')
    + g(brick(84, 176, 2), 'rotate(4 100 185)') + g(mono(140, 192, 1), 'rotate(-14 148 201)')
    # only the striped ones
    + mono(256, 220, 3) + mono(304, 220, 2) + mono(272, 202, 2) + mono(304, 202, 1) + mono(288, 184, 2)
    + arrow('M128 150 q60 -60 140 16'),
    ground() + _tube(_rx, 220, 5) + mono(_rx, 60, 2) + ghost(f'M{_rx} 130 h32 v18 h-32 z')
    + arrow(f'M{_rx + 48} 62 q36 30 2 76'),
    ground() + _rocket(_rx, 220) + arrow(f'M{_rx + 74} 36 q10 30 -20 44') + arrow(f'M{_rx + 110} 160 q10 30 -24 50'),
    g(_rocket(_rx, 220), 'translate(0 -22)')
    + motion(f'M{_rx + 8} 222 v34', f'M{_rx + 24} 222 v34', f'M{_rx - 18} 226 l-14 22', f'M{_rx + 50} 226 l14 22')
    + '<circle cx="150" cy="268" r="10"/><circle cx="168" cy="274" r="8"/><circle cx="232" cy="270" r="9"/><circle cx="250" cy="276" r="7"/>'
    + arrow(f'M{_rx + 80} 120 q10 -50 -10 -80'),
]


# ── Build an animal that doesn't exist yet ───────────────────────────────
def _fish(x, y, legs=False, k=1.3):
    """A drawn fish facing right, belly line at y; with chicken legs if legs."""
    s = (f'<g transform="translate({x} {y}) scale({k})" stroke-width="{2.4 / k:.2f}">'
         '<path d="M-4 -31 q6 -12 14 -1" fill="none"/>')
    if legs:
        s += '<path d="M-6 -12 V4 M-11 7 L-6 4 L-1 7 M6 -12 V4 M1 7 L6 4 L11 7" fill="none"/>'
    s += ('<path d="M-19 -20 L-32 -30 V-10 Z"/>'
          '<ellipse cx="0" cy="-20" rx="22" ry="12"/>'
          '<path d="M10 -30 q-5 10 0 20" fill="none"/>'
          '<path d="M-6 -18 q4 6 10 0" fill="none"/>'
          + dot(14, -23, 1.8) + '</g>')
    return s


def _chicken(x, y, k=1.3):
    """A drawn chicken facing left, feet at y, with long legs."""
    return (f'<g transform="translate({x} {y}) scale({k})" stroke-width="{2.4 / k:.2f}">'
            '<path d="M-4 -14 V0 M-9 3 L-4 0 L1 3 M6 -14 V0 M1 3 L6 0 L11 3" fill="none"/>'
            '<path d="M14 -30 C18 -46 32 -44 28 -32 C26 -26 20 -22 14 -20 Z"/>'
            '<ellipse cx="2" cy="-24" rx="15" ry="11"/>'
            '<path d="M-24 -38 l-8 3 l8 3 z"/><circle cx="-17" cy="-38" r="8"/>'
            '<path d="M-22 -46 q1 -6 5 -2 q2 -6 6 0" fill="none"/>'
            '<path d="M0 -26 q8 8 14 -2" fill="none"/>'
            + dot(-19, -40, 1.8) + '</g>')


def _head(x, y, r=30):
    return (f'<circle cx="{x}" cy="{y}" r="{r}"/>'
            f'<path d="M{x - 15} {y - 5} q4 -5 8 0 M{x + 7} {y - 5} q4 -5 8 0" fill="none"/>'
            f'<path d="M{x - 9} {y + 11} q9 8 18 0" fill="none"/>'
            f'<path d="M{x - 26} {y - 15} q8 -24 30 -15 q18 -12 26 8" fill="none"/>')


def slope_down(x, y, n=1):
    """A pointy brick hanging under another, tip pointing down."""
    return f'<polygon points="{x},{y} {x + n * U},{y} {x + n * U / 2},{y + BH}"/>'


_ax, _ay = 160, 184  # fish: bottom layer at _ay, middle layer runs _ax + U to _ax + 8U
_mid, _top = _ay - BH, _ay - 2 * BH


def _fish_body(last=True):
    """Narrow, wide, narrow: each layer overlaps the one below by at least a stud."""
    s = row(_ax + U, _ay, [3, 3]) + row(_ax + U, _mid, [4, 3]) + brick(_ax, _top, 3)
    return s + (brick(_ax + 3 * U, _top, 3) if last else '')


def _fish_legs():
    # Each leg clips under the bottom layer; each foot clips under its leg.
    return ''.join(brick(_ax + lx, _ay + BH, 1, studs=False) + brick(_ax + lx, _ay + 2 * BH, 2, studs=False)
                   for lx in (U, 5 * U))


def _fish_head():
    # The head brick sits on the last two studs of the middle layer.
    return (brick(_ax + 6 * U, _top, 2)
            + f'<circle cx="{_ax + 7 * U + 2}" cy="{_top + 9}" r="5"/>' + dot(_ax + 7 * U + 3, _top + 9, 2.2)
            + thin(f'M{_ax + 8 * U - 2} {_mid + 11} h-14'))


def _fish_tail():
    # The tail brick clips under the first stud of the top layer; two slopes make the fin.
    return (brick(_ax - 3 * U, _mid, 4) + slope(_ax - 3 * U, _mid - BH - 4, 2)
            + slope_down(_ax - 3 * U, _mid + BH, 2))


def _fish_fin():
    return slope(_ax + 2 * U, _top - BH - 4, 2)


def _fishlegs():
    return _fish_legs() + _fish_tail() + _fish_body() + _fish_head() + _fish_fin()


_k = key("Build an animal that doesn't exist yet")
D[_k] = [
    _head(62, 244)
    + '<circle cx="104" cy="200" r="5"/><circle cx="118" cy="184" r="8"/>'
    + '<path d="M130 166 C94 156 98 104 136 102 C140 58 200 42 222 72 C246 36 318 46 320 86 C366 82 380 142 346 158 '
      'C358 198 298 214 276 192 C254 216 196 214 184 192 C150 210 116 192 130 166 Z"/>'
    + _fish(172, 126) + _chicken(300, 126) + _fish(232, 182, legs=True)
    + arrow('M172 134 q4 20 22 26', dashed=True) + arrow('M286 136 q-4 22 -24 28', dashed=True),
    _fish_body(last=False) + brick(_ax + 3 * U, 70, 3)
    + ghost(f'M{_ax + 3 * U} {_top} h48 v18 h-48 z')
    + arrow(f'M{_ax + 6 * U + 14} 74 q26 34 -2 70'),
    ground() + _fishlegs()
    + arrow('M336 84 q4 40 -40 62') + arrow('M54 92 q2 40 40 48') + arrow('M150 66 q40 -10 46 50')
    + arrow('M340 196 q-10 30 -48 34'),
    ground() + g(_fishlegs(), 'translate(-50 0)') + _head(336, 150, 26)
    + motion('M300 136 q-8 14 0 28', 'M290 128 q-14 22 0 44'),
]


# ── Build the tallest tower you can that stands on its own ──────────────
_wx = 156  # tower's left edge, 12 studs wide at the bottom


def _trow(r, off, sizes):
    return row(_wx + off * U, 220 - r * BH, sizes)


def _tower_base():
    return _trow(0, 0, [4, 4, 4]) + _trow(1, 0, [2, 4, 4, 2])


def _tower_mid():
    return _trow(2, 2, [3, 2, 3]) + _trow(3, 2, [4, 4]) + _trow(4, 2, [3, 2, 3]) + _trow(5, 2, [4, 4])


def _tower_top():
    return (_trow(6, 3, [2, 2, 2]) + _trow(7, 3, [3, 3]) + _trow(8, 3, [2, 2, 2])
            + _trow(9, 4, [4]) + _trow(10, 4, [2, 2]) + _trow(11, 5, [2]))


def _kid(x, y):
    """A child standing, feet at y, one hand flat on top of the head."""
    hy = y - 132
    return (f'<path d="M{x - 10} {y - 56} V{y} h-10 M{x + 10} {y - 56} V{y} h10" fill="none"/>'
            f'<path d="M{x - 20} {y - 54} L{x - 16} {hy + 30} Q{x} {hy + 24} {x + 16} {hy + 30} L{x + 20} {y - 54} Z"/>'
            f'<path d="M{x - 16} {hy + 36} L{x - 28} {y - 70}" fill="none"/>'
            f'<path d="M{x + 16} {hy + 36} L{x + 36} {hy + 2} L{x + 16} {hy - 16}" fill="none"/>'
            f'<circle cx="{x}" cy="{hy + 4}" r="17"/>'
            f'<ellipse cx="{x + 8}" cy="{hy - 17}" rx="13" ry="5"/>'
            + dot(x - 6, hy + 2, 2) + dot(x + 6, hy + 2, 2) + thin(f'M{x - 5} {hy + 11} q5 4 10 0'))


_k = key('Build the tallest tower you can that stands on its own')
D[_k] = [
    ground() + _tower_base() + brick(_wx + 10 * U, 120, 2) + ghost(f'M{_wx + 10 * U} 202 h32 v18 h-32 z')
    + arrow(f'M{_wx + 12 * U + 6} 124 q20 40 -6 70'),
    ground() + _tower_base() + _trow(2, 2, [3, 2, 3]) + _trow(3, 2, [4, 4]) + _trow(4, 2, [3, 2, 3]) + _trow(5, 2, [4])
    + brick(_wx + 6 * U, 40, 4) + ghost(f'M{_wx + 6 * U} 130 h64 v18 h-64 z')
    + arrow(f'M{_wx + 10 * U + 10} 46 q26 40 -4 76'),
    ground() + _tower_base() + _tower_mid() + _tower_top() + arrow(f'M{_wx + 10 * U} 40 q-6 50 -40 60') + arrow(f'M{_wx + 2 * U} 40 q6 50 40 60'),
    ground() + _tower_base() + _tower_mid() + _tower_top() + _kid(76, 238)
    + motion(f'M100 106 H{_wx + 3 * U - 8}', f'M{_wx + 12 * U + 14} 18 V230'),
]


# ── Make a boat that floats in the bath ──────────────────────────────────
_bx = 104  # boat's left edge, 12 studs long


def _hull(y):
    return row(_bx, y, [4, 4, 4]) + row(_bx, y - BH, [2, 4, 4, 2])


def _walls(y):
    """y is the hull's bottom layer. Walls one layer up, higher at both ends."""
    w = y - 2 * BH
    return row(_bx, w, [4, 4, 4]) + brick(_bx, w - BH, 2) + brick(_bx + 10 * U, w - BH, 2)


def _bath():
    return ('<path d="M22 120 V210 Q22 274 90 274 H310 Q378 274 378 210 V120" fill="none"/>'
            '<path d="M14 120 H30 M370 120 H386" fill="none"/>')


def _water():
    return thin('M30 176 q14 -8 28 0 t28 0 t28 0 M298 176 q14 -8 28 0 t28 0 t14 0')


def _figure(x, y):
    """A small toy person, feet at y."""
    return (f'<rect x="{x - 12}" y="{y - 40}" width="24" height="40" rx="6"/>'
            f'<circle cx="{x}" cy="{y - 54}" r="13"/>' + dot(x - 4, y - 56, 2) + dot(x + 4, y - 56, 2)
            + thin(f'M{x - 4} {y - 50} q4 3 8 0') + f'<path d="M{x + 12} {y - 32} l14 -18" fill="none"/>')


_k = key('Make a boat that floats in the bath')
D[_k] = [
    ground() + row(_bx, 220, [4, 4, 4]) + row(_bx, 202, [2, 4, 4]) + brick(_bx + 10 * U, 110, 2)
    + ghost(f'M{_bx + 10 * U} 202 h32 v18 h-32 z') + arrow(f'M{_bx + 12 * U + 10} 112 q24 40 -4 82'),
    ground() + _hull(220) + row(_bx, 184, [4, 4, 4]) + brick(_bx, 166, 2) + brick(_bx + 10 * U, 70, 2)
    + ghost(f'M{_bx + 10 * U} 166 h32 v18 h-32 z') + arrow(f'M{_bx + 12 * U + 10} 74 q24 40 -4 84'),
    _bath() + _hull(186) + _walls(186) + _water()
    + '<circle cx="80" cy="196" r="6"/><circle cx="64" cy="210" r="4"/><circle cx="326" cy="194" r="5"/><circle cx="340" cy="208" r="7"/>'
    + arrow('M200 40 V96', dashed=True),
    _bath() + _figure(200, 166) + _hull(192) + _walls(192) + _water()
    + motion('M90 128 q-12 14 0 28', 'M76 118 q-18 24 0 48', 'M310 128 q12 14 0 28', 'M324 118 q18 24 0 48'),
]


# ── Build a robot with arms that move ────────────────────────────────────
_ox = 152  # body's left edge, 6 studs wide; body bottom layer at y=184 once it has legs


def _body(y):
    return row(_ox, y, [3, 3]) + row(_ox, y - BH, [2, 2, 2]) + row(_ox, y - 2 * BH, [3, 3])


def _legs():
    return (brick(_ox, 202, 2, studs=False) + brick(_ox - U, 220, 3, studs=False)
            + brick(_ox + 4 * U, 202, 2, studs=False) + brick(_ox + 4 * U, 220, 3, studs=False))


def _robot_head(smile=False):
    s = brick(_ox + 2 * U, 130, 2) + brick(_ox + U, 112, 4) + brick(_ox + U, 94, 4)
    s += f'<rect x="{_ox + 2 * U + 4}" y="74" width="4" height="16" rx="1"/><circle cx="{_ox + 2 * U + 6}" cy="70" r="5"/>'
    s += ''.join(f'<circle cx="{_ox + U + c}" cy="108" r="8"/>' + dot(_ox + U + c, 108, 3) for c in (18, 46))
    mouth = f'M{_ox + U + 22} 122 q10 6 20 0' if smile else f'M{_ox + U + 22} 123 h20'
    return s + thin(mouth)


def _bracket(side):
    """Hinge bracket on the body's top layer: one stud on the body, one sticking out to hold the pin."""
    return brick(_ox - U if side < 0 else _ox + 5 * U, _ox_top - BH, 2)


def _pin(side):
    """Front cheek of the bracket with the round pin through it, drawn over the arm's top."""
    px = _px(side)
    return (f'<path d="M{px - 7} {_ox_top} V{_py} a7 7 0 0 0 14 0 V{_ox_top}"/>'
            f'<circle cx="{px}" cy="{_py}" r="4.5"/>' + dot(px, _py, 2))


def _px(side):
    return _ox - 8 if side < 0 else _ox + 6 * U + 8


def _arm_shape(side):
    """Arm hanging straight down from the pin, round top wrapped around it."""
    px = _px(side)
    x0 = px - 8
    return (f'<path d="M{x0} {_py + 16} V{_py} a8 8 0 0 1 16 0 V{_py + 16} Z"/>'
            + brick(x0, _py + 16, 1, studs=False) + brick(x0, _py + 34, 1, studs=False)
            + f'<path d="M{x0 - 1} {_py + 52} v4 q9 10 18 0 v-4" fill="none"/>')


def _arm_ghost(side):
    px = _px(side)
    x0 = px - 8
    return ghost(f'M{x0} {_py + 52} V{_py} a8 8 0 0 1 16 0 V{_py + 52} Z')


def _arm(side, angle=0):
    a = _arm_shape(side)
    if angle:
        a = g(a, f'rotate({angle} {_px(side)} {_py})')
    return _bracket(side) + a + _pin(side)


_ox_top = 148  # top of the body's top layer
_py = _ox_top + 8  # pin centre, in the bracket's sticking-out stud
_k = key('Build a robot with arms that move')
D[_k] = [
    ground() + row(_ox, 220, [3, 3]) + row(_ox, 202, [2, 2, 2]) + row(_ox, 184, [3]) + brick(_ox + 3 * U, 96, 3)
    + ghost(f'M{_ox + 3 * U} 184 h48 v18 h-48 z') + arrow(f'M{_ox + 6 * U + 14} 100 q26 40 -4 76'),
    ground() + _legs() + _body(184) + _robot_head() + arrow(f'M{_ox + 8 * U + 10} 64 q16 30 -24 42')
    + arrow(f'M{_ox + 9 * U + 10} 170 q14 40 -32 56'),
    ground() + _legs() + _body(184) + _robot_head() + _arm(-1)
    + _bracket(1) + _arm_ghost(1) + _pin(1)
    + g(_arm_shape(1), 'translate(76 -20)')
    + arrow(f'M{_px(1) + 62} {_py - 30} q-26 -14 -48 22'),
    ground() + _legs() + _body(184) + _robot_head(smile=True) + _arm(-1) + _arm(1, angle=-125)
    + motion('M320 92 q14 16 4 36', 'M334 78 q24 26 6 62'),
]
