"""Diagrams for more Outdoors challenges (obstacle course, chalk drawing,
hopscotch, counting birds, a mud pie kitchen, a heart-shaped stone, kicking a
ball against a wall). Round-headed people drawn like the Kindness ones, in
any pose; the green accent is only for arrows and dashed motion lines."""
import math
import re

from style import INK, arrow, dot, ghost, ground, motion, thin
from craft_2 import _snail
from craft_3 import ball, grip
from kind import flower, pen_held
from kind_2 import SIZES, bubble, limb, qmark

D = {}


def key(title):
    return re.sub(r'[^a-z0-9]+', '_', title.lower()).strip('_')[:48]


# ── People ───────────────────────────────────────────────────────────────
def head(cx, cy, r=30, mouth='smile', adult=False, look=0, down=0, eyes='dot'):
    """A round head. look moves the eyes sideways (-1 .. 1), down moves them down."""
    ex, ey = r * .22 * look, r * .22 * down
    s = f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r}"/>'
    if adult:  # hair cap and bun
        s = (f'<circle cx="{cx - r * .5 * (1 if look >= 0 else -1):.1f}" cy="{cy - r * 1.02:.1f}" r="{r * .34:.1f}"/>' + s
             + f'<path d="M{cx - r:.1f} {cy - 2:.1f} C{cx - r * 1.05:.1f} {cy - r * 1.2:.1f} {cx + r * 1.05:.1f} {cy - r * 1.2:.1f} '
               f'{cx + r:.1f} {cy - 2:.1f} C{cx + r * .6:.1f} {cy - r * .8:.1f} {cx - r * .2:.1f} {cy - r * .75:.1f} '
               f'{cx - r:.1f} {cy - 2:.1f} Z" fill="{INK}"/>')
    else:
        s += thin(f'M{cx - r * .88:.1f} {cy - r * .5:.1f} q{r * .3:.1f} {-r * .78:.1f} {r:.1f} {-r * .48:.1f} '
                  f'q{r * .6:.1f} {-r * .42:.1f} {r * .88:.1f} {r * .24:.1f}')
    yy = cy + ey
    if eyes == 'happy':
        s += ''.join(thin(f'M{x - r * .13:.1f} {yy + r * .04:.1f} q{r * .13:.1f} {-r * .2:.1f} {r * .26:.1f} 0')
                     for x in (cx - r * .36 + ex, cx + r * .36 + ex))
    else:
        s += dot(cx - r * .36 + ex, yy, r * .07 + 1) + dot(cx + r * .36 + ex, yy, r * .07 + 1)
    mx, my = cx + ex * .7, cy + r * .42 + ey * .5
    if mouth == 'smile':
        s += f'<path d="M{mx - r * .28:.1f} {my - r * .06:.1f} q{r * .28:.1f} {r * .26:.1f} {r * .56:.1f} 0" fill="none"/>'
    elif mouth == 'grin':
        s += f'<path d="M{mx - r * .38:.1f} {my - r * .12:.1f} q{r * .38:.1f} {r * .48:.1f} {r * .76:.1f} 0 Z"/>'
    elif mouth == 'laugh':
        s += f'<path d="M{mx - r * .44:.1f} {my - r * .16:.1f} q{r * .44:.1f} {r * .66:.1f} {r * .88:.1f} 0 Z" fill="{INK}"/>'
    elif mouth == 'open':
        s += f'<ellipse cx="{mx:.1f}" cy="{my:.1f}" rx="{r * .16:.1f}" ry="{r * .14:.1f}"/>'
    elif mouth == 'flat':
        s += thin(f'M{mx - r * .18:.1f} {my:.1f} h{r * .36:.1f}')
    return s


def fig(hx, hy, kind='kid', legs=None, arms=None, lean=0, mouth='smile', look=0, down=0, eyes='dot',
        front='', arms_behind=False):
    """A person with the hips at (hx, hy).

    legs: two (foot x, foot y[, knee x, knee y][, toe]) tuples, left hip first; toe is 1 or -1 for which
    way the foot points, 0 for a front-on foot. arms: (side, hand x, hand y[, elbow-ish ctrl x, ctrl y][, hand?]).
    lean tips the body over at the hips (degrees, + leans right). front is drawn over the body, under the arms.
    """
    r, w, th, ll, lw = SIZES[kind]
    a = math.radians(lean)

    def P(x, y):
        return hx + x * math.cos(a) - y * math.sin(a), hy + x * math.sin(a) + y * math.cos(a)

    if legs is None:
        legs = ((hx - w * .45, hy + ll, 0), (hx + w * .45, hy + ll, 0))
    s = ''
    for i, lg in enumerate(legs):
        sx, sy = P((-1 if i == 0 else 1) * w * .45, 0)
        fx, fy = lg[0], lg[1]
        toe = lg[-1] if len(lg) in (3, 5) else 0
        if len(lg) >= 4:
            d = f'M{sx:.1f} {sy:.1f} L{lg[2]} {lg[3]} L{fx} {fy}'
        else:
            d = f'M{sx:.1f} {sy:.1f} L{fx} {fy}'
        s += limb(d, lw)
        s += f'<ellipse cx="{fx + toe * 5:.1f}" cy="{fy + 2:.1f}" rx="{lw * .7:.1f}" ry="{lw * .4:.1f}"/>'
    body = (f'<g transform="translate({hx} {hy}) rotate({lean})">'
            f'<path d="M{-w} 4 V{-th + 12} Q{-w} {-th} {-w + 12} {-th} H{w - 12} Q{w} {-th} {w} {-th + 12} V4 Z"/>'
            f'<rect x="-6" y="{-th - 8}" width="12" height="10"/></g>')
    hcx, hcy = P(0, -th - r + 2)
    hd = head(hcx, hcy, r, mouth, kind == 'adult', look, down, eyes)
    ar = ''
    for arm in arms or ((-1, None, None), (1, None, None)):
        side, ex, ey = arm[:3]
        sx, sy = P(side * (w - 7), -th + 11)
        if ex is None:
            ex, ey = P(side * (w + 6), -6)
        if len(arm) >= 5 and arm[3] is not None:
            mx, my = arm[3], arm[4]
        else:
            mx, my = (sx + ex) / 2 + side * 10, (sy + ey) / 2 + 10
        ar += limb(f'M{sx:.1f} {sy:.1f} Q{mx:.1f} {my:.1f} {ex:.1f} {ey:.1f}', lw)
        if not (len(arm) >= 6 and arm[5] is False):
            ar += f'<circle cx="{ex:.1f}" cy="{ey:.1f}" r="{lw * .62:.1f}"/>'
    if arms_behind:
        return ar + s + body + hd + front
    return s + body + hd + front + ar


def stand(cx, by, kind='kid', **kw):
    """A person standing with feet at by."""
    ll = SIZES[kind][3]
    w = SIZES[kind][1]
    return fig(cx, by - ll, kind, legs=((cx - w * .45, by - 2, 0), (cx + w * .45, by - 2, 0)), **kw)


def walk(cx, by, kind='kid', d=1, stride=1.0, **kw):
    """A person mid-step, walking towards d (1 right, -1 left)."""
    ll = SIZES[kind][3]
    w = SIZES[kind][1]
    h = by - ll + 3
    return fig(cx, h, kind, legs=((cx - w * .3 - d * ll * .45 * stride, by - 2, d),
                                  (cx + w * .3 + d * ll * .5 * stride, by - 2, d)), **kw)


def cross_legged(cx, by, kind='kid', **kw):
    """Sitting cross-legged on the ground (or a cushion) at by, seen from the front."""
    lap = (f'<path d="M{cx - 46} {by} Q{cx - 48} {by - 24} {cx - 20} {by - 24} H{cx + 20} '
           f'Q{cx + 48} {by - 24} {cx + 46} {by} Z"/>'
           + thin(f'M{cx - 20} {by - 7} Q{cx} {by - 17} {cx + 20} {by - 7}')
           + f'<ellipse cx="{cx - 31}" cy="{by - 5}" rx="10" ry="6"/><ellipse cx="{cx + 31}" cy="{by - 5}" rx="10" ry="6"/>')
    return fig(cx, by - 14, kind, legs=(), front=lap, **kw)


def hold(x, y, r=9.3):
    """A hand drawn again on top of something it holds."""
    return f'<circle cx="{x}" cy="{y}" r="{r}"/>'


def _sc(d, s):
    return re.sub(r'-?\d+\.?\d*', lambda m: f'{float(m.group()) * s:.1f}', d)


def palm(x, y, s=3.0, n=4, sleeve=True):
    """An open hand, palm towards us and fingers up, wrist at the bottom; n fingers up.
    Drawn at size s without thickening the line."""
    xs, hs = (-12, -4, 4, 12), (20, 24, 23, 18)
    out = ''
    if sleeve:
        out += '<path d="' + _sc('M-13 12 V26 H13 V12', s) + '"/>' + thin(_sc('M-13 20 H13', s))
    for i, fx in enumerate(xs):
        hgt = hs[i] if i < n else 6
        out += f'<rect x="{(fx - 3.6) * s:.1f}" y="{(-12 - hgt) * s:.1f}" width="{7.2 * s:.1f}" height="{(hgt + 6) * s:.1f}" rx="{3.6 * s:.1f}"/>'
    out += '<path d="' + _sc('M-15 0 Q-26 -6 -24 -14 Q-20 -18 -14 -10', s) + '"/>'
    out += '<path d="' + _sc('M-16 -12 H16 V4 Q16 16 4 16 H-6 Q-16 16 -16 6 Z', s) + '"/>'
    return f'<g transform="translate({x} {y})">{out}</g>'


def burst(x, y, r0, r1, angles):
    return motion(*[f'M{x + r0 * math.cos(math.radians(t)):.1f} {y + r0 * math.sin(math.radians(t)):.1f} '
                    f'L{x + r1 * math.cos(math.radians(t)):.1f} {y + r1 * math.sin(math.radians(t)):.1f}'
                    for t in angles])


# ── Things ───────────────────────────────────────────────────────────────
def cushion(cx, by, w=64, h=26):
    return (f'<rect x="{cx - w / 2}" y="{by - h}" width="{w}" height="{h}" rx="10"/>'
            + thin(f'M{cx - w / 2 + 8} {by - h / 2} H{cx + w / 2 - 8}') + dot(cx, by - h / 2, 2.6))


def bucket(cx, by, w=40, h=40, upside=False):
    t, b = (w * .36, w / 2) if upside else (w / 2, w * .36)
    s = f'<path d="M{cx - t} {by - h} L{cx - b} {by} Q{cx} {by + 5} {cx + b} {by} L{cx + t} {by - h} Z"/>'
    if upside:
        s += f'<ellipse cx="{cx}" cy="{by - h}" rx="{t}" ry="4"/>' + thin(f'M{cx - b + 2} {by - 8} Q{cx} {by - 3} {cx + b - 2} {by - 8}')
    else:
        s = (f'<path d="M{cx - t + 2} {by - h} Q{cx} {by - h - w * .7} {cx + t - 2} {by - h}" fill="none" stroke-width="1.8"/>'
             + s + f'<ellipse cx="{cx}" cy="{by - h}" rx="{t}" ry="{w * .14:.1f}"/>')
    return s


def cone(cx, by, h=46):
    return (f'<rect x="{cx - 20}" y="{by - 6}" width="40" height="6" rx="2"/>'
            f'<path d="M{cx - 14} {by - 6} L{cx - 4} {by - h} H{cx + 4} L{cx + 14} {by - 6} Z"/>'
            f'<path d="M{cx - 10} {by - h * .42:.1f} H{cx + 10} L{cx + 8} {by - h * .62:.1f} H{cx - 8} Z" fill="{INK}" stroke-width="1.4"/>')


def chair(x, by, flip=False):
    """A garden chair side-on, legs at by, back on the right (left if flip)."""
    k = -1 if flip else 1
    return (f'<path d="M{x - k * 22} {by} V{by - 44} H{x + k * 22} V{by} M{x + k * 22} {by - 44} V{by - 100}" fill="none" stroke-width="4"/>'
            f'<path d="M{x - k * 26} {by - 48} H{x + k * 24}" fill="none" stroke-width="6"/>')


def stopwatch(cx, cy, r=22, a1=-60, a2=40):
    """A stopwatch face with two hands and no numbers."""
    def hand_(ang, L, sw):
        t = math.radians(ang - 90)
        return f'<path d="M{cx} {cy} L{cx + L * math.cos(t):.1f} {cy + L * math.sin(t):.1f}" stroke-width="{sw}"/>'
    ticks = ''.join(f'M{cx + r * .72 * math.cos(t):.1f} {cy + r * .72 * math.sin(t):.1f} '
                    f'L{cx + r * .86 * math.cos(t):.1f} {cy + r * .86 * math.sin(t):.1f} '
                    for t in [i * math.pi / 2 for i in range(4)])
    return (f'<rect x="{cx - 4}" y="{cy - r - 9}" width="8" height="7" rx="1"/>'
            f'<rect x="{cx - 7}" y="{cy - r - 14}" width="14" height="6" rx="2"/>'
            f'<rect x="{cx + r * .62:.1f}" y="{cy - r * .9:.1f}" width="7" height="6" rx="1" transform="rotate(45 {cx + r * .66:.1f} {cy - r * .86:.1f})"/>'
            f'<circle cx="{cx}" cy="{cy}" r="{r}"/>'
            + thin(ticks) + hand_(a1, r * .6, 2.4) + hand_(a2, r * .78, 1.6) + dot(cx, cy, 2.6))


def stone(cx, cy, rx=9, ry=6, rot=0, k=0):
    """A smooth pebble."""
    return (f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" transform="rotate({rot} {cx} {cy})"/>'
            + thin(f'M{cx - rx * .4:.1f} {cy - ry * .35:.1f} q{rx * .25:.1f} {-ry * .3:.1f} {rx * .55:.1f} {-ry * .2:.1f}'))


def heart_stone(cx, cy, s=14, rot=0):
    """A pebble shaped like a heart, with rounded lobes."""
    d = (f'M0 {s * .85:.1f} C{-s * .5:.1f} {s * .55:.1f} {-s * 1.15:.1f} {s * .1:.1f} {-s * 1.05:.1f} {-s * .35:.1f} '
         f'C{-s * .95:.1f} {-s * .95:.1f} {-s * .2:.1f} {-s * .95:.1f} 0 {-s * .45:.1f} '
         f'C{s * .2:.1f} {-s * .95:.1f} {s * .95:.1f} {-s * .95:.1f} {s * 1.05:.1f} {-s * .35:.1f} '
         f'C{s * 1.15:.1f} {s * .1:.1f} {s * .5:.1f} {s * .55:.1f} 0 {s * .85:.1f} Z')
    return (f'<g transform="translate({cx} {cy}) rotate({rot})"><path d="{d}"/>'
            + thin(f'M{-s * .7:.1f} {-s * .45:.1f} q{s * .15:.1f} {-s * .3:.1f} {s * .4:.1f} {-s * .28:.1f}') + '</g>')


def chalk(x, y, rot=0, L=34, pat='plain'):
    """A stick of chalk centred at (x, y)."""
    s = f'<rect x="{-L / 2}" y="-6" width="{L}" height="12" rx="5"/>'
    if pat == 'ink':
        s = f'<rect x="{-L / 2}" y="-6" width="{L}" height="12" rx="5" fill="{INK}"/>'
    elif pat == 'stripe':
        s += thin(' '.join(f'M{-L / 2 + 7 + i * 7} -6 V6' for i in range(int(L / 7) - 1)))
    elif pat == 'dots':
        s += ''.join(dot(-L / 2 + 7 + i * 7, (-2 if i % 2 else 2), 1.6) for i in range(int(L / 7) - 1))
    return f'<g transform="translate({x} {y}) rotate({rot})">{s}</g>'


def chalk_held(tx, ty, a=-40, L=60, pat='plain'):
    """Chalk with its tip at (tx, ty), held by a hand, going off at a degrees."""
    r = math.radians(a)
    cx, cy = tx + L / 2 * math.cos(r), ty + L / 2 * math.sin(r)
    return chalk(cx, cy, a, L, pat) + grip(tx + 40 * math.cos(r), ty + 40 * math.sin(r), a + 180 - 60)


def bird(x, y, s=1.0, kind='robin', flip=False, peck=False):
    """A small bird standing with its feet at (x, y), facing right (left if flip)."""
    if kind == 'pigeon':
        b = ('<path d="M-30 -18 L-44 -14 L-30 -10" />'
             '<path d="M-34 -14 Q-30 -34 -4 -32 Q14 -32 16 -18 Q12 -4 -10 -6 Q-28 -6 -34 -14 Z"/>'
             + thin('M-22 -20 Q-10 -12 4 -20')
             + '<circle cx="14" cy="-38" r="9"/><path d="M22 -40 L30 -37 L22 -35 Z" fill="' + INK + '"/>' + dot(16, -40, 1.8)
             + thin('M-6 -6 V0 M2 -6 V0 M-10 0 h6 M-2 0 h6'))
    elif kind == 'black':
        b = (f'<path d="M-22 -16 L-40 -26 L-36 -14 Z" fill="{INK}"/>'
             f'<ellipse cx="-4" cy="-16" rx="20" ry="11" fill="{INK}"/>'
             f'<circle cx="14" cy="-28" r="9" fill="{INK}"/><path d="M22 -30 L32 -27 L22 -24 Z" fill="#fff" stroke-width="1.6"/>'
             f'<circle cx="16" cy="-30" r="2.6" fill="#fff" stroke="none"/>'
             + thin('M-6 -5 V0 M2 -5 V0 M-10 0 h6 M-2 0 h6'))
    else:  # robin: round, with a breast patch
        b = ('<path d="M-16 -20 L-30 -28 L-28 -14 Z"/>'
             '<circle cx="0" cy="-20" r="16"/>'
             + thin('M4 -30 Q-2 -18 8 -8') + '<path d="M15 -24 L23 -21 L15 -18 Z" fill="' + INK + '"/>'
             + dot(8, -26, 2) + thin('M-3 -4 V0 M4 -4 V0 M-7 0 h6 M0 0 h6'))
    t = f'translate({x} {y}) scale({-s if flip else s} {s})'
    if peck:
        t += ' rotate(20)'
    return f'<g transform="{t}">{b}</g>'


def branch(x0, y0, x1, y1):
    mx, my = (x0 + x1) / 2, (y0 + y1) / 2
    return (f'<path d="M{x0} {y0} Q{mx} {my - 6} {x1} {y1}" fill="none" stroke-width="6"/>'
            f'<path d="M{x0} {y0} Q{mx} {my - 6} {x1} {y1}" fill="none" stroke="#fff" stroke-width="1.6"/>'
            + thin(f'M{mx - 20} {my - 4} q-6 -14 -18 -18 M{mx + 24} {my - 2} q8 -12 20 -12')
            + f'<ellipse cx="{mx - 40}" cy="{my - 24}" rx="9" ry="5" transform="rotate(30 {mx - 40} {my - 24})"/>'
            + f'<ellipse cx="{mx + 46}" cy="{my - 16}" rx="9" ry="5" transform="rotate(-20 {mx + 46} {my - 16})"/>')


def fence(x0, x1, by, h=90, step=34):
    s = ''
    x = x0
    while x + 26 <= x1:
        s += f'<path d="M{x} {by} V{by - h + 8} L{x + 13} {by - h} L{x + 26} {by - h + 8} V{by} Z"/>'
        x += step
    return (f'<path d="M{x0 - 4} {by - h * .3:.0f} H{x - step + 30} M{x0 - 4} {by - h * .75:.0f} H{x - step + 30}" '
            f'fill="none" stroke-width="5"/>' + s)


def brick_wall(x0, x1, by, top):
    s = f'<rect x="{x0}" y="{top}" width="{x1 - x0}" height="{by - top}"/>'
    rows, y, j = [], by - 18, 0
    d = ''
    while y > top:
        d += f'M{x0} {y} H{x1} '
        y -= 18
    y = by
    while y - 18 >= top - 1:
        off = 0 if j % 2 == 0 else 18
        for x in range(x0 + 36 - off, x1, 36):
            if x > x0:
                d += f'M{x} {y} V{max(y - 18, top)} '
        y -= 18
        j += 1
    return s + thin(d)


def paving(x0, x1, y0, y1, n=4, k=.3):
    """Paving slabs on the ground, seen from slightly above."""
    s = f'<path d="M{x0} {y0} H{x1} M{x0} {y1} H{x1}" fill="none" stroke-width="1.6"/>'
    s += thin(f'M{x0} {(y0 + y1) / 2} H{x1}')
    step = (x1 - x0) / n
    for i in range(1, n):
        x = x0 + i * step
        s += thin(f'M{x - (y1 - y0) * k / 2:.1f} {y1} L{x + (y1 - y0) * k / 2:.1f} {y0}')
    return s


def saucepan(cx, by, w=110, h=52, mud=True, handle=1):
    t = w / 2
    s = (f'<rect x="{cx + handle * t - (54 if handle < 0 else 0)}" y="{by - h + 4}" width="54" height="10" rx="5"/>'
         f'<path d="M{cx - t} {by - h} V{by - 10} Q{cx - t} {by} {cx - t + 12} {by} H{cx + t - 12} Q{cx + t} {by} {cx + t} {by - 10} V{by - h} Z"/>'
         f'<ellipse cx="{cx}" cy="{by - h}" rx="{t}" ry="{w * .14:.1f}"/>')
    if mud:
        s += (f'<ellipse cx="{cx}" cy="{by - h + 3}" rx="{t - 6}" ry="{w * .1:.1f}" fill="{INK}" stroke="none"/>'
              f'<ellipse cx="{cx - t * .25:.1f}" cy="{by - h + 2}" rx="{t * .22:.1f}" ry="2.5" fill="#fff" stroke="none"/>')
    return s


def mud_patch(cx, cy, rx, ry):
    d = (f'M{cx - rx} {cy} C{cx - rx} {cy - ry} {cx - rx * .3:.1f} {cy - ry * 1.1:.1f} {cx} {cy - ry * .8:.1f} '
         f'C{cx + rx * .4:.1f} {cy - ry * 1.2:.1f} {cx + rx} {cy - ry * .9:.1f} {cx + rx} {cy} '
         f'C{cx + rx} {cy + ry} {cx + rx * .2:.1f} {cy + ry * 1.1:.1f} {cx - rx * .2:.1f} {cy + ry * .9:.1f} '
         f'C{cx - rx * .7:.1f} {cy + ry * 1.1:.1f} {cx - rx} {cy + ry * .7:.1f} {cx - rx} {cy} Z')
    dots = ''.join(dot(cx + rx * a, cy + ry * b, 2) for a, b in ((-.6, -.2), (-.3, .3), (.1, -.4), (.4, .2), (.7, -.1), (-.05, .5), (.25, -.05)))
    return f'<path d="{d}"/>' + dots


def flowerpot(cx, by, w=34, h=30, upside=False):
    t, b = (w * .36, w / 2) if upside else (w / 2, w * .36)
    s = f'<path d="M{cx - t} {by - h} L{cx - b} {by} H{cx + b} L{cx + t} {by - h} Z"/>'
    rim = f'<rect x="{cx - (b if upside else t) - 3}" y="{(by - 8) if upside else (by - h - 2)}" width="{2 * (b if upside else t) + 6}" height="9" rx="2"/>'
    return s + rim


def spoon(x, y, rot=0, L=70):
    """A wooden spoon, bowl at (x, y), handle going off at rot degrees."""
    return (f'<g transform="translate({x} {y}) rotate({rot})">'
            f'<rect x="8" y="-4" width="{L}" height="8" rx="4"/><ellipse cx="0" cy="0" rx="13" ry="9"/></g>')


def pie(cx, cy, rx=70, ry=24, deco=True):
    """A mud pie in a round tin, seen from slightly above."""
    s = (f'<path d="M{cx - rx} {cy} L{cx - rx + 8} {cy + 18} Q{cx} {cy + ry + 22} {cx + rx - 8} {cy + 18} L{cx + rx} {cy}"/>'
         f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}"/>'
         f'<path d="M{cx - rx + 8} {cy + 2} Q{cx - rx + 4} {cy - ry - 4} {cx} {cy - ry - 8} Q{cx + rx - 4} {cy - ry - 4} {cx + rx - 8} {cy + 2} '
         f'Q{cx} {cy + ry} {cx - rx + 8} {cy + 2} Z" fill="{INK}"/>')
    if deco:
        s += (petal_flower(cx - rx * .4, cy - 6, 7) + petal_flower(cx + rx * .3, cy - 10, 7)
              + leaf(cx - rx * .05, cy - 14, 30) + leaf(cx + rx * .62, cy - 2, -30)
              + stone(cx + rx * .02, cy + 4, 6, 4) + stone(cx - rx * .7, cy, 5, 4) + stone(cx + rx * .45, cy + 8, 5, 3.5))
    return s


def petal_flower(x, y, r=7):
    petals = ''.join(f'<circle cx="{x + r * math.cos(t):.1f}" cy="{y + r * .8 * math.sin(t):.1f}" r="{r * .62:.1f}" stroke-width="1.8"/>'
                     for t in [i * math.pi * 2 / 5 - math.pi / 2 for i in range(5)])
    return petals + f'<circle cx="{x}" cy="{y}" r="{r * .42:.1f}" stroke-width="1.8"/>'


def leaf(x, y, rot=0, s=1.0):
    return (f'<g transform="translate({x} {y}) rotate({rot}) scale({s})">'
            '<path d="M-14 0 Q0 -10 14 0 Q0 10 -14 0 Z" stroke-width="1.8"/>' + thin('M-12 0 H12') + '</g>')


def window(x, y, w, h, inside=''):
    """A window frame with four panes; inside is drawn in the glass first."""
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}"/>' + inside
            + f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="none" stroke-width="6"/>'
            + f'<path d="M{x + w / 2} {y} V{y + h} M{x} {y + h / 2} H{x + w}" fill="none" stroke-width="4"/>'
            + f'<rect x="{x - 10}" y="{y + h}" width="{w + 20}" height="9" rx="2"/>')


# ── Make an obstacle course and time yourself ────────────────────────────
GY = 252  # ground line for the obstacle course


def rope_chairs(a, b):
    """Two chairs back to back with a skipping rope tied between their backs."""
    return (chair(a, GY) + chair(b, GY, flip=True)
            + f'<path d="M{a + 22} {GY - 94} Q{(a + b) / 2} {GY - 70} {b - 22} {GY - 94}" fill="none" stroke-width="3"/>'
            + f'<path d="M{a + 17} {GY - 100} l10 12 M{b - 17} {GY - 100} l-10 12" fill="none" stroke-width="2"/>')


def course(cush=70, chairs=(150, 270), buck=344):
    s = cushion(cush, GY, 64, 30) + rope_chairs(*chairs)
    if buck:
        s += bucket(buck, GY, 38, 38, upside=True)
    return s


D[key('Make an obstacle course and time yourself')] = [
    ground(GY) + course()
    + arrow(f'M20 {GY - 8} Q70 {GY - 110} 116 {GY - 14} L130 {GY - 10} '
            f'C200 {GY - 12} 250 {GY - 12} 300 {GY - 6} C336 {GY + 22} 380 {GY + 16} 378 {GY - 18} '
            f'C376 {GY - 62} 330 {GY - 66} 318 {GY - 48}', dashed=True),

    ground(GY) + cushion(170, GY, 64, 30) + rope_chairs(286, 370)
    + fig(110, GY - 48, 'kid', legs=((92, GY - 2, 1), (176, GY - 44, 156, GY - 64, 1)), look=1, down=1.2,
          mouth='flat', arms=((-1, 60, 150), (1, 160, 150)))
    + _snail(44, GY, 1.0)
    + arrow(f'M210 {GY - 12} H244', dashed=True),

    ground(GY)
    + f'<path d="M118 {GY - 4} V{GY + 12}" fill="none" stroke-width="5"/>'
    + walk(80, GY, d=1, stride=.5, look=1, mouth='smile')
    + stand(300, GY, 'adult', look=-1, mouth='open',
            arms=((-1, 210, 140, 236, 156), (1, None, None)))
    + stopwatch(206, 102, 28, -40, 70)
    + hold(210, 140, 10.5)
    + motion('M190 52 l-6 -10', 'M206 46 V34', 'M222 52 l6 -10'),

    ground(GY) + course(cush=170, chairs=(500, 560), buck=0)
    + fig(170, 160, 'kid', legs=((126, 186, 142, 194, -1), (214, 196, 206, 158, 1)), lean=14, look=1, mouth='grin',
          arms=((-1, 118, 114), (1, 228, 92)))
    + motion('M30 106 H82', 'M20 132 H76', 'M36 158 H90')
    + stand(352, GY, 'adult', look=-1, mouth='grin', arms=((-1, 316, 160, 318, 190, False), (1, None, None)))
    + stopwatch(306, 150, 14, 30, 160) + hold(318, 160, 10.5),
]


# ── Draw on the path with chalk ──────────────────────────────────────────
def sun_flat(cx, cy, rx, ry, n=12, done=None):
    """A big sun drawn flat on the ground (an ellipse with rays)."""
    s = f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="none" stroke-width="3"/>'
    s += thin(f'M{cx - rx * .3:.1f} {cy - ry * .25:.1f} h6 M{cx + rx * .22:.1f} {cy - ry * .25:.1f} h6 '
              f'M{cx - rx * .3:.1f} {cy + ry * .2:.1f} Q{cx} {cy + ry * .6:.1f} {cx + rx * .3:.1f} {cy + ry * .2:.1f}')
    rays = ''
    for i in range(n if done is None else done):
        t = i * 2 * math.pi / n
        rays += (f'M{cx + rx * 1.12 * math.cos(t):.1f} {cy + ry * 1.12 * math.sin(t):.1f} '
                 f'L{cx + rx * 1.34 * math.cos(t):.1f} {cy + ry * 1.5 * math.sin(t):.1f} ')
    return s + f'<path d="{rays}" fill="none" stroke-width="3"/>'


def chalk_flower(x, y, r=16, petals='plain', centre='plain', n=5, stem=60):
    """A flower drawn in chalk on the path. petals/centre: plain, ink or dots. n petals drawn so far."""
    s = ''
    if stem:
        s += (f'<path d="M{x} {y + r} V{y + r + stem}" fill="none" stroke-width="3"/>'
              f'<path d="M{x} {y + r + stem * .6} q{r * .9} {-r * .9} {r * 1.6} {-r * .5} q{-r * .4} {r * .9} {-r * 1.6} {r * .5} Z" stroke-width="2.4"/>')
    for i in range(n):
        t = i * math.pi * 2 / 5 - math.pi / 2
        px, py = x + r * 1.1 * math.cos(t), y + r * 1.1 * math.sin(t)
        s += f'<circle cx="{px:.1f}" cy="{py:.1f}" r="{r * .7:.1f}" fill="{INK if petals == "ink" else "#fff"}" stroke-width="3"/>'
        if petals == 'dots':
            s += dot(px - r * .2, py - r * .15, 2) + dot(px + r * .22, py + r * .1, 2) + dot(px - r * .05, py + r * .3, 2)
    s += f'<circle cx="{x}" cy="{y}" r="{r * .55:.1f}" fill="{INK if centre == "ink" else "#fff"}" stroke-width="3"/>'
    return s


D[key('Draw on the path with chalk')] = [
    ground(262)
    + stand(110, 262, 'kid', look=1, mouth='open', arms=((-1, None, None), (1, 156, 150, 160, 186)))
    + chalk(160, 136, -70, 30) + hold(156, 150)
    + stand(298, 262, 'adult', look=-1, mouth='smile')
    + bubble(28, 20, 120, 64, 104, 98, chalk(70, 52, -20, 36) + qmark(122, 52, 1.1))
    + motion('M168 104 l12 -8', 'M172 120 h14'),

    paving(20, 380, 214, 284, 5)
    + sun_flat(258, 248, 92, 26, 12)
    + fig(84, 202, 'kid', legs=((60, 254, 112, 254, -1), (52, 248, 102, 248, -1)), lean=28, look=1, down=1,
          arms=((-1, 150, 222), (1, 168, 236, 152, 196)))
    + chalk(176, 244, 35, 22) + hold(168, 236)
    + arrow('M150 178 C190 120 330 120 370 190'),

    paving(20, 380, 40, 280, 3, .1)
    + chalk_flower(86, 96, 18, 'plain', 'ink')
    + chalk_flower(196, 112, 18, 'ink', 'plain')
    + chalk_flower(306, 124, 18, 'dots', 'plain', n=3)
    + chalk_held(286, 116, -40, 60, 'dots')
    + motion('M268 98 l-8 -8', 'M262 114 h-12')
    + chalk(90, 246, -10, 50, 'ink') + chalk(170, 252, 6, 50, 'stripe') + chalk(250, 246, -4, 50),

    paving(20, 380, 30, 280, 4, .12)
    + '<rect x="44" y="56" width="312" height="190" rx="90" fill="none" stroke-width="3"/>'
    + '<rect x="104" y="112" width="192" height="78" rx="39" fill="none" stroke-width="3"/>'
    + ''.join(f'<rect x="{196 + i * 8}" y="{192 + j * 9}" width="8" height="9" fill="{INK if (i + j) % 2 == 0 else "#fff"}" stroke-width="1.2"/>'
              for i in range(2) for j in range(6))
    + '<g transform="translate(260 218)"><rect x="-22" y="-12" width="44" height="24" rx="8"/>'
      '<rect x="-16" y="-17" width="10" height="6" rx="2" fill="#1d1d1f"/><rect x="8" y="-17" width="10" height="6" rx="2" fill="#1d1d1f"/>'
      '<rect x="-16" y="11" width="10" height="6" rx="2" fill="#1d1d1f"/><rect x="8" y="11" width="10" height="6" rx="2" fill="#1d1d1f"/>'
      '<rect x="-4" y="-8" width="14" height="16" rx="3"/></g>'
    + arrow('M88 214 C40 170 54 92 120 78 H240')
    + motion('M224 210 h-14', 'M226 226 h-14'),
]


# ── Play hopscotch ───────────────────────────────────────────────────────
HX0, HY0, HCW, HD, HK = 82, 252, 34, 28, .3  # grid left x, near y, cell length, half depth, slant


def HP(u, v):
    """A point on the hopscotch ground: u along the grid, v into the picture."""
    return HX0 + u + v * HK, HY0 - v


COLS = (1, 1, 1, 2, 1, 2, 1, 1)  # along the grid: a single box, or a pair side by side


def box_centre(n):
    """Centre of box n (1 to 10) on the ground."""
    k = 0
    for c, cols in enumerate(COLS):
        for j in range(cols):
            k += 1
            if k == n:
                v = HD if cols == 1 else (HD * .5 if j == 0 else HD * 1.5)
                return HP(c * HCW + HCW / 2, v)


def _quad(c):
    return [HP(c * HCW, 0), HP((c + 1) * HCW, 0), HP((c + 1) * HCW, 2 * HD), HP(c * HCW, 2 * HD)]


def _poly(pts):
    return 'M' + ' L'.join(f'{x:.1f} {y:.1f}' for x, y in pts) + ' Z'


def hopscotch(upto=len(COLS), stone_in=None):
    s = ''
    for c in range(upto):
        if c == len(COLS) - 1:  # the last box is a half circle
            u0 = c * HCW
            pts = [HP(u0 + HCW * 1.1 * math.sin(t / 12 * math.pi), HD - HD * math.cos(t / 12 * math.pi)) for t in range(13)]
            s += '<path d="' + _poly(pts) + '" fill="none" stroke-width="3"/>'
            continue
        s += f'<path d="{_poly(_quad(c))}" fill="none" stroke-width="3"/>'
        if COLS[c] == 2:
            a, b = HP(c * HCW, HD), HP((c + 1) * HCW, HD)
            s += f'<path d="M{a[0]:.1f} {a[1]:.1f} L{b[0]:.1f} {b[1]:.1f}" fill="none" stroke-width="3"/>'
    if stone_in:
        x, y = box_centre(stone_in)
        s += stone(x, y, 9, 5)
    return s


def _hopper(n, d=1):
    """A child hopping on one foot in box n, the other foot tucked up behind."""
    x, y = box_centre(n)
    hx, hy = x + 8 * d, y - 50
    return fig(hx, hy, 'kid', legs=((x, y, d), (hx + 44, hy + 20, hx + 30, hy + 32, d)),
               look=d, mouth='grin',
               arms=((-1, hx - 58, hy - 104), (1, hx + 58, hy - 104)))


_b1, _b2, _b4 = box_centre(1), box_centre(2), box_centre(4)
_end = HP((len(COLS) - 1) * HCW + HCW * 1.1, HD)

D[key('Play hopscotch')] = [
    hopscotch(6)
    + ghost(_poly(_quad(6)))
    + ghost(_poly([HP(7 * HCW + HCW * 1.1 * math.sin(t / 12 * math.pi), HD - HD * math.cos(t / 12 * math.pi)) for t in range(13)]))
    + chalk_held(*HP(6 * HCW, 2 * HD), -60)
    + arrow(f'M{HP(6 * HCW, 0)[0] + 10:.1f} {HY0 + 22} C{HP(7 * HCW, 0)[0]:.1f} {HY0 + 34} '
            f'{_end[0] + 16:.1f} {HY0 + 20} {_end[0] + 14:.1f} {HY0 - 10}', dashed=True),

    hopscotch(stone_in=1)
    + stand(46, 266, 'kid', look=1, mouth='smile', arms=((-1, None, None), (1, 84, 112, 82, 160)))
    + arrow(f'M92 100 C{_b1[0] + 14:.1f} 96 {_b1[0] + 10:.1f} 160 {_b1[0]:.1f} {_b1[1] - 14:.1f}', dashed=True),

    hopscotch(stone_in=1)
    + _hopper(4)
    + arrow(f'M{_b4[0] + 74:.1f} 120 C{_end[0] - 10:.1f} 110 {_end[0] + 10:.1f} 150 {_end[0] - 4:.1f} 190')
    + arrow(f'M{_end[0] - 20:.1f} {HY0 + 18} C{_end[0] - 120:.1f} {HY0 + 40} {HX0 + 40} {HY0 + 40} {HX0 - 4} {HY0 + 14}'),

    hopscotch()
    + stone(_b1[0] + 2, _b1[1], 9, 5)
    + fig(_b2[0] + 8, _b2[1] - 48, 'kid',
          legs=((_b2[0] + 2, _b2[1], -1), (_b2[0] + 50, _b2[1] - 44, _b2[0] + 34, _b2[1] - 28, 1)),
          lean=-50, look=-1, down=1.2, mouth='smile',
          arms=((-1, _b1[0] + 4, _b1[1] - 8, _b1[0] - 18, _b1[1] - 40), (1, _b2[0] + 30, _b2[1] - 130)))
    + motion(f'M{_b1[0] - 14:.1f} {_b1[1] - 12:.1f} v-16', f'M{_b1[0] - 26:.1f} {_b1[1] - 4:.1f} l-8 -12'),
]


# ── Count the birds you can see ──────────────────────────────────────────
def tally(x, y, n, h=22, gap=7):
    """Tally marks: groups of four strokes crossed by a fifth."""
    d = ''
    gx = x
    while n > 0:
        k = min(n, 5)
        for i in range(min(k, 4)):
            d += f'M{gx + i * gap} {y} v{h} '
        if k == 5:
            d += f'M{gx - 4} {y + h - 4} L{gx + 3 * gap + 4} {y + 4} '
        gx += 4 * gap + 12
        n -= k
    return f'<path d="{d}" fill="none" stroke-width="2.4"/>'


_garden = window(232, 40, 140, 150, branch(232, 120, 372, 108) + bird(320, 106, .85, 'robin')
                 + thin('M232 176 q30 -20 60 -6 q30 12 80 -4'))

D[key('Count the birds you can see')] = [
    _garden
    + cushion(116, 262, 110, 22)
    + cross_legged(116, 242, 'kid', look=1, mouth='flat',
                   arms=((-1, 118, 160, 80, 190), (1, 152, 218, 160, 196)))
    + '<rect x="115" y="134" width="7" height="24" rx="3.5"/>' + hold(118, 160)
    + arrow('M152 112 C190 76 240 76 288 92', dashed=True),

    ground(254)
    + fence(200, 384, 254, 90)
    + branch(20, 96, 170, 80) + bird(104, 80, .9, 'robin')
    + bird(286, 166, 1.0, 'pigeon')
    + bird(150, 252, 1.0, 'black')
    + palm(52, 214, 1.5, 3)
    + motion('M86 40 l-6 -8', 'M104 34 V24', 'M122 40 l6 -8', 'M264 108 l-6 -8', 'M284 104 V92',
             'M304 108 l6 -8', 'M140 202 l-6 -8', 'M158 198 V186'),

    '<rect x="60" y="30" width="230" height="240" rx="3"/>'
    + bird(96, 92, .9, 'robin') + tally(130, 70, 7)
    + bird(96, 152, .7, 'pigeon') + tally(130, 130, 3)
    + bird(96, 210, .8, 'black') + tally(130, 188, 1)
    + pen_held(146, 210, 15)
    + arrow('M146 180 V198'),

    ground(266)
    + stand(110, 266, 'kid', look=1, mouth='grin',
            arms=((-1, 66, 178, 60, 160), (1, 214, 90, 170, 92)))
    + '<rect x="40" y="168" width="40" height="52" rx="2"/>' + thin('M48 182 h24 M48 194 h24 M48 206 h14') + hold(66, 178)
    + branch(250, 128, 384, 112) + bird(316, 122, 1.0, 'robin')
    + arrow('M226 86 C254 70 284 78 300 92', dashed=True)
    + burst(110, 60, 38, 52, (-150, -120, -60, -30)),
]


# ── Make a mud pie kitchen ───────────────────────────────────────────────
D[key('Make a mud pie kitchen')] = [
    ground(262, 20, 380)
    + fence(214, 384, 236, 96)
    + mud_patch(304, 254, 76, 20)
    + saucepan(270, 254, 56, 28, mud=False, handle=-1)
    + flowerpot(332, 246, 30, 26, upside=True) + bucket(364, 260, 30, 30)
    + spoon(306, 240, -70, 50)
    + stand(56, 262, 'kid', look=1, mouth='grin')
    + stand(146, 262, 'adult', look=1, mouth='smile', arms=((-1, None, None), (1, 226, 104, 200, 120)))
    + arrow('M238 112 C270 116 296 150 300 200', dashed=True),

    saucepan(186, 252, 170, 70, handle=-1)
    + spoon(196, 176, -60, 90)
    + grip(226, 124, 240)
    + arrow('M130 196 C110 214 150 226 186 220 C230 214 250 196 234 182')
    + '<g transform="translate(292 68) rotate(-120)"><path d="M-18 -26 H18 L15 22 Q15 26 11 26 H-11 Q-15 26 -15 22 Z"/>'
      '<ellipse cx="0" cy="-26" rx="18" ry="5"/></g>'
    + grip(304, 60, 200)
    + motion('M262 96 l-4 14', 'M254 122 l-4 14', 'M248 146 l-3 10'),

    pie(200, 196, 120, 40, deco=False)
    + petal_flower(134, 190, 10) + leaf(186, 178, 30, 1.4) + stone(236, 204, 8, 5)
    + stone(110, 206, 6, 4) + petal_flower(290, 190, 9)
    + grip(286, 74, 110)
    + petal_flower(286, 74, 10)
    + arrow('M300 100 C300 130 284 156 266 166'),

    ground(268)
    + stand(110, 268, 'kid', look=1, mouth='grin',
            arms=((-1, 150, 170, 110, 200), (1, 210, 168, 180, 186)))
    + pie(180, 156, 40, 13)
    + hold(150, 170) + hold(210, 168)
    + stand(310, 268, 'adult', look=-1, mouth='laugh', eyes='happy',
            arms=((-1, 262, 150, 262, 200), (1, None, None)))
    + burst(310, 64, 36, 50, (-160, -120, -60, -20))
    + arrow('M176 112 C200 90 230 92 250 110', dashed=True),
]


# ── Find a stone shaped like a heart ─────────────────────────────────────
_pebbles = (stone(214, 258, 9, 5) + stone(260, 266, 7, 4, 20) + heart_stone(306, 256, 9, 10)
            + stone(344, 266, 8, 5, -10) + stone(176, 270, 6, 4))

D[key('Find a stone shaped like a heart')] = [
    ground(276)
    + walk(110, 276, d=1, stride=1.0, look=1, down=1.4, mouth='flat')
    + _pebbles
    + motion('M128 160 L214 246', 'M130 156 L298 244')
    + arrow('M40 290 H96', dashed=True),

    stone(70, 262, 10, 6) + stone(118, 276, 8, 5) + stone(340, 270, 12, 7)
    + palm(220, 196, 3.0, 4)
    + stone(204, 186, 13, 8, -10) + stone(238, 190, 12, 8, 15) + heart_stone(220, 166, 12, -10)
    + arrow('M110 250 C100 200 120 166 150 156'),

    palm(200, 190, 3.6, 4)
    + heart_stone(198, 160, 26, 0)
    + arrow('M128 138 C116 90 150 58 186 56')
    + arrow('M286 150 C306 190 298 226 262 248'),

    ground(268)
    + stand(110, 268, 'kid', look=1, mouth='grin', arms=((-1, None, None), (1, 186, 172, 170, 200)))
    + heart_stone(206, 164, 12)
    + hold(186, 172)
    + stand(310, 268, 'adult', look=-1, mouth='grin', arms=((-1, 226, 174, 250, 210), (1, None, None)))
    + arrow('M184 124 C200 108 222 112 236 132')
    + motion('M206 138 v-10', 'M190 146 l-8 -6', 'M222 146 l8 -6'),
]


# ── Kick a ball against a wall 50 times ──────────────────────────────────
WALL = brick_wall(300, 384, 262, 92)
_steps = ''.join(f'<ellipse cx="{x}" cy="{y}" rx="9" ry="5" fill="none" stroke-width="1.6" stroke-dasharray="3 4"/>'
                 for x, y in ((156, 252), (196, 258), (236, 252), (276, 258)))

D[key('Kick a ball against a wall 50 times')] = [
    ground(262) + WALL + _steps
    + stand(70, 262, 'kid', look=1)
    + ball(114, 248, 14)
    + arrow('M290 222 C250 204 190 204 140 222'),

    ground(262) + WALL
    + fig(110, 210, 'kid', legs=((96, 260, 1), (170, 222, 150, 226, 1)), lean=-8, look=1, mouth='grin',
          arms=((-1, 54, 170), (1, 166, 160)))
    + ball(204, 222, 14)
    + motion('M176 210 l-10 -6', 'M176 234 l-10 6')
    + arrow('M222 214 C250 204 272 204 294 212'),

    ground(262) + WALL
    + fig(110, 210, 'kid', legs=((96, 260, 1), (150, 230, 140, 218, 1)), lean=-4, look=1, down=1, mouth='open',
          arms=((-1, 58, 176), (1, 162, 176)))
    + ball(156, 248, 14)
    + arrow('M296 252 C262 262 214 266 178 254', dashed=True)
    + motion('M182 232 l8 -6', 'M184 246 h10'),

    ground(262) + WALL
    + '<rect x="308" y="104" width="68" height="136" rx="2"/>'
    + ''.join(tally(316 + (i % 2) * 30, 112 + (i // 2) * 25, 5, 16, 4) for i in range(10))
    + stand(150, 262, 'kid', look=1, mouth='grin', eyes='happy',
            arms=((-1, 96, 70, 100, 110), (1, 204, 70, 200, 110)))
    + ball(226, 248, 14)
    + burst(150, 56, 50, 64, (-160, -125, -55, -20)),
]
