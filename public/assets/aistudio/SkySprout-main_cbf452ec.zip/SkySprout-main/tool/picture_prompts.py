"""Writes build/picture_prompts.csv: one row per step picture to make.

Each row has the file name the app and website look for, the challenge, the
step and a full prompt (the shared style from docs/challenge_pictures.md plus
the step's own picture prompt and its kind's accent colour).

    python3 tool/picture_prompts.py
"""
import csv
from pathlib import Path

from build_site import ROOT, catalog

STYLE = (
    'Simple instruction-sheet illustration, like a printed how-to diagram for children. '
    'Clean black ink line art with even line weight on a plain white background, no shading, '
    'no gradients, no text or letters. Mostly hands and objects, drawn from a slightly-above '
    'three-quarter view, centred with generous white space, 4:3 landscape. '
    'The only colour is {accent} ({name}), used just for one or two curved arrows and dashed '
    'motion lines that show what moves. Scene: {scene}.'
)
ACCENTS = {
    'lego': ('red', '#D6372F'),
    'craft': ('purple', '#8A3FB0'),
    'draw': ('blue', '#1F74C9'),
    'outdoor': ('green', '#2F8A3C'),
    'kind': ('golden yellow', '#C98A00'),
    'cook': ('orange', '#E0661B'),
}


def main():
    out = ROOT / 'build' / 'picture_prompts.csv'
    out.parent.mkdir(exist_ok=True)
    rows = 0
    with out.open('w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['file', 'kind', 'challenge', 'step', 'text', 'prompt'])
        for c in catalog():
            cat = c['cat']
            name, accent = ACCENTS[cat]
            for i, (text, prompt) in enumerate(zip(c['steps'], c['prompts']), 1):
                scene = prompt or text
                w.writerow([f"{c['key']}_{i}.webp", cat, c['title'], i, text,
                            STYLE.format(accent=accent, name=name, scene=scene)])
                rows += 1
    print(f'Wrote {out} with {rows} pictures')


if __name__ == '__main__':
    main()
