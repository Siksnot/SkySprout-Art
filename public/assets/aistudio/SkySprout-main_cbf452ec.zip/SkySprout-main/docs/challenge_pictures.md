# Challenge pictures

Every starter challenge has 3 to 6 steps in `assets/catalog/challenges.txt`, and
each step can have one picture. The app's "Show me how" screen and the website
(`site/index.html`) show them; a step without a picture shows a placeholder.

## The look

One style for all 480 pictures, like a printed instruction sheet:

- Black ink line art, even line weight, on plain white. No shading or gradients.
- Mostly hands and objects, seen from slightly above, centred with white space round them.
- One accent colour per kind, used only for one or two curved arrows and dashed
  motion lines that show what moves:

  | Kind | Colour |
  |---|---|
  | Bricks | red `#D6372F` |
  | Craft | purple `#8A3FB0` |
  | Drawing | blue `#1F74C9` |
  | Outdoors | green `#2F8A3C` |
  | Kindness | golden yellow `#C98A00` |
  | Kitchen | orange `#E0661B` |

- No words or numbers in the picture. The app and website draw the black
  numbered circle and the handwritten-style caption on top, so they always match
  the step text and never come out garbled.
- 4:3 landscape, saved as WebP at about 1200 × 900, under 150 KB.

Use a reference image only for its general look. Don't copy a film's or
product's artwork, characters or logos, and don't draw real toy brands (say
"toy bricks", not Lego).

## Making them

    python3 tool/picture_prompts.py

writes `build/picture_prompts.csv`: one row per picture with its file name, the
step text and a full prompt (the shared style, the kind's colour and the scene
from `challenges.txt`). Paste each prompt into the image generator, keep the
ones that match the look, and save them under the file name in the first
column, for example `build_a_dinosaur_2.webp`.

The file name is the challenge's key, then `_` and the step number. The key
is the challenge text in lower case with every run of other characters turned
into `_`, cut to 48 characters, unless the challenge has an `id:` line, which
gives the key instead. If a challenge's text changes, add `id: <old key>` so
its pictures keep their names.

## Where they go

Either works, and the app tries them in this order:

1. **In the app**: put the files in `assets/catalog/img/`. They ship in the APK,
   work offline and add to its size (about 480 × 100 KB ≈ 50 MB for all of
   them, so bundle only a few).
2. **Supabase Storage** (recommended): the app downloads a picture the first
   time it's shown and keeps it on the device. The website reads the same files.

### Supabase setup (once)

1. In the Supabase dashboard, open **Storage** and choose **New bucket**.
2. Name it `challenges` and switch **Public bucket** on. Leave the other settings.
3. Open the bucket and drag the `.webp` files in (no folders).

A file is then at
`https://<project>.supabase.co/storage/v1/object/public/challenges/<file>`.
The free plan's 1 GB of storage and 5 GB a month of downloads is plenty.

Public means anyone with a file's address can see that picture, which is fine
for these. Never put children's photos in this bucket; their photos stay on
the device.

## The website

    python3 tool/build_site.py

rebuilds `site/index.html` from the catalog. It's one self-contained file:
upload it anywhere, for example to `magnolia213.xyz/kidshub/challenges/`.
Re-run it after editing challenges and upload it again. Pictures appear on the
site as soon as they're in the bucket.

## The challenge editor

`python3 tool/build_site.py` also writes `site/editor.html`, a private editor
published as a Claude artifact (https://claude.ai/artifact/8SNyQSR1Kv3rJ7cAUtrbwM).
Parents change a challenge by hand or ask Claude to rewrite it, and saves go
into the artifact's database (collection `edits`, one document per challenge
key, `removed: true` for ones to drop). Nothing reaches the app until Claude
applies the saved edits to `assets/catalog/challenges.txt`, re-runs the build
and clears the applied edits; then upload `build/catalog.txt` as below.

## Changing challenges after release

The app doesn't need a new version on Google Play to get new or changed
challenges. Each time it opens online it downloads `catalog.txt` from the
`challenges` bucket, keeps it on the device for when it's offline, and
brings every family's list up to date.

1. Edit `assets/catalog/challenges.txt`. The top of the file says what each
   line means. To add a challenge, add a new `## ` section with its `kind:`,
   `points:`, `minutes:`, `age:`, `need:` and steps. To reword one, change its
   `## ` line and add `id: <old key>` under it (the key is in the picture file
   names, for example `id: build_a_dinosaur`), so families keep it and it keeps
   its pictures. To take one away, add `removed: yes` rather than deleting it.
2. Run `python3 tool/build_site.py`. It writes `build/catalog.txt` (and the
   website).
3. In the Supabase dashboard, open **Storage**, then the `challenges` bucket,
   and upload `build/catalog.txt`, replacing the old one. Upload the pictures
   of any new steps too.

Apps pick it up the next time they're opened while online (Supabase may keep
serving the old copy for up to an hour). What families see:

- New challenges are added to their list once. If a parent deletes one, it
  doesn't come back.
- Challenges no parent has changed get the new wording, kind, points and
  timer; ones marked `removed: yes` are switched off.
- Challenges a parent has changed or written themselves are left alone.

Once you've uploaded a `catalog.txt`, the app uses it over the one built into
the app, so upload a new one whenever you change the file, even when you also
release a new version of the app. If the download is missing or broken, the
app keeps using the copy it has.
