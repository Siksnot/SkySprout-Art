# Ask Claude in the challenge editor

In the parent portal, Challenges → tap a challenge (or Add) opens the editor.
Families signed in to Kids Hub online also get an **Ask Claude** box: quick
buttons (Easier, Harder, More fun, Simpler words, Safety check) or their own
request, and Claude rewrites the name, steps and what you need. Nothing is kept
until the parent taps Save, and Undo puts it back.

The app never holds the Claude API key. It calls the Supabase Edge Function
`challenge-ai` (`supabase/functions/challenge-ai/index.ts`) with the parent's
login; the function checks the login, adds the key and asks Claude. Families
using the app without an account don't see the box.

## Switch it on (once)

1. Get an API key at https://console.anthropic.com (Settings → API keys), and
   set a monthly spend limit there (Settings → Limits). Each ask is a few
   hundred words on a small model, so it costs a fraction of a penny.
2. In the Supabase dashboard for the Kids Hub project, open **Edge Functions →
   Secrets** and add `ANTHROPIC_API_KEY` with that key.
3. Open **Edge Functions → Deploy a new function → Via editor**, name it
   `challenge-ai`, paste in `supabase/functions/challenge-ai/index.ts`, and
   deploy. Leave "Verify JWT" on.

Or with the Supabase CLI:

    supabase link --project-ref vfkpybbxcwajzcnugxnm
    supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
    supabase functions deploy challenge-ai

Until it's deployed, Ask Claude says it isn't switched on yet; the rest of the
editor works as normal. To use another model, add a `CHALLENGE_AI_MODEL` secret.

## Play Store

- Google Play's AI-generated content policy applies. The answers only reach the
  signed-in parent, who reviews them before saving, and the rules in the
  function keep them child-safe. Mention the feature in the store listing.
- Data safety: the challenge text and the parent's request go to Anthropic to
  answer the request. No child's name, photo or account details are sent.
